# Reference Documents

**Purpose:** Overviews of legacy, context, and reference documents. These are not actively maintained but provide useful background.

---

## Sky-Basics

**What it is:** High-level grounding context for Sky Ecosystem.

**Key content:**
- Sky = evolution of MakerDAO (Central Bank + Commercial Bank model)
- Core tokens: USDS (stablecoin), sUSDS (savings), SKY (governance), DAI (legacy)
- Agent framework: Primes (capital deployers), Halos (operational), Executors (governance)
- Star Primes: Spark (lending/liquidity), Grove (institutional credit)

**Use for:** Avoiding confusion about Sky ecosystem basics.

---

## Relevant-Spark-Code

**What it is:** README and code excerpts from the Spark ALM Controller repository.

**Key content:**
- ALMProxy: Holds custody, routes calls via `doCall()`
- MainnetController / ForeignController: Entry points with rate limit enforcement
- RateLimits: Linear replenishment model (maxAmount, slope, lastAmount, lastUpdated)
- Roles: DEFAULT_ADMIN_ROLE, RELAYER, FREEZER, CONTROLLER
- OTC swap support with slippage and recharge rate mechanics

**Use for:** Understanding the existing deployed infrastructure that Laniakea builds on.

---

## context-old-PAS-overview

**What it is:** Older governance specification using ATWL (Allocation Target Whitelist) terminology.

**Status:** Superseded by Configurator-Unit document.

**Key differences from current:**
- Uses "ATWL" instead of "BEAM" terminology
- Same underlying concepts: timelocked additions, instant removals, SORL constraints
- Three-contract pattern: ATWLState, ATWLModifier, Configurator

**Use for:** Historical context only. Do not use ATWL terminology in new docs.

---

## laniakea-slides

**What it is:** Bullet points from internal presentation slides.

**Key content:**
- Laniakea objectives: 1 Prime/week, 1 Halo/week, Sentinel monitoring
- Seven requirements: PAS, LCTS, Sentinel, Risk Framework, Passthrough Halo, KYC Network, Sky Intents
- srUSDS provides external risk capital

**Use for:** Quick reference on high-level objectives.

---

*These documents are not actively updated. For current specifications, see `agent-master.md`.*
