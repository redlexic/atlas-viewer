# Laniakea (Sky Ecosystem Write-up)

This repository contains a structured write-up of Sky’s Laniakea system: a set of documents describing the protocol architecture, agent framework, risk framework, governance operations, and supporting mechanisms.

## Where to Start

- Open `agent-master.md` (primary index and navigation).
- Canonical documents live under `active/`.
- Background/source material lives under `reference/` and is not maintained as canonical.

## Canonical Pillars (`active/`)

- `active/whitepaper/` — high-level narrative + appendices
- `active/risk-framework/` — modular risk framework (duration/matching/capital/correlation/ASC)
- `active/smart-contracts/` — PAS/Configurator + PAU patterns + LCTS
- `active/governance-operations/` — Sentinel + Atlas/Synome separation
- `active/legal-and-trading/` — passthrough halo + identity + intents

## Contribution Notes

- Keep `active/` self-contained: do not rely on or link to `reference/` from canonical docs.
- Update `agent-master.md` when adding/moving documents or changing status.

## Git / Collaboration

- Default branch: `main`
- Upstream repo: `https://github.com/Rune23/Laniakea`
- Recommended workflow: branch → commit → push → PR
- Agent workflow: only ask an agent to run git commands when you explicitly say “run git commands”.
