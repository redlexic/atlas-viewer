# Sky & Laniakea Agent Master

**Version:** 0.19
**Last Updated:** 2026-01-04

---

## What is Sky

### The Business

Sky is one of the largest decentralized stablecoin protocols. It evolved from MakerDAO, which created DAI—the first decentralized stablecoin at scale.

**Key Numbers:**
- **~9B+ USDS** in circulation (time-varying)
- **Large market opportunity** — stablecoins sitting idle, wanting yield
- **Majority of profits** flow to SKY holders via buybacks + staking rewards (parameterized by governance)

**Value Proposition:**
Institutions and smart money are increasingly using USDS for its broadly recognized risk-adjusted return. Sky generates profits from the stablecoin business model—lending spreads, RWA income, DeFi yields—and distributes most of that to token holders.

### The Central Bank Model

Sky operates as a **decentralized central bank**:

```
Sky Core → Primes → Halos → End Investments
```

| Layer | Role | Examples |
|-------|------|----------|
| **Sky Core** | Central bank: holds balance sheet, issues USDS, sets monetary policy | — |
| **Primes** | Commercial banks: borrow from Sky Core, deploy capital at scale | Spark, Grove, Keel, Obex |
| **Halos** | Investment products: wrap specific strategies | CLO tranches, yield vaults |
| **Executors** | Operators: run systems with collateral backing | Settlement, verification |

Each layer posts risk capital. If a Prime or Halo fails, losses are absorbed by their risk capital first—Sky Core is protected.

### Core Tokens

| Token | Purpose |
|-------|---------|
| **USDS** | Stablecoin (1:1 USD); ~$9B supply |
| **sUSDS** | Savings token; deposit USDS → earn Sky Savings Rate |
| **SKY** | Governance; staking rewards + deflationary via buyback/burn |
| **stUSDS** | Segregated risk capital for SKY-backed borrowing |

### What Makes Sky Different

- **Real-time transparent rules** — All governance logic public
- **Cryptoeconomic enforcement** — Rules enforced by code and incentives, not courts
- **Autonomous operation** — Agents execute 99% of operations without human intervention
- **Escalation to human judgment** — Edge cases can escalate to governance

---

## Documentation Overview

This repo maintains the Laniakea system write-up as a set of pillar documents under `active/`, organized by category (see **Laniakea Pillars** below).

- **Whitepaper** lives in `active/whitepaper/` (main doc + appendices) and is the public-facing narrative wrapper around the system.
- **System specs** live in the other `active/` categories (risk framework, smart contracts, governance ops, legal/trading) and are the canonical technical source material.
- **Writing principle:** progressive disclosure (simple narrative in the whitepaper; precise mechanics in pillar docs and appendices).
- **Whitepaper guidance:** `active/whitepaper/README.md` (canonical checklist).
- **Note on background material:** this repo also contains non-distributed background sources used during drafting; the distributed document set is `active/` + this master doc.

---

## Laniakea Pillars

These are organized to match the folder structure under `active/`:

1. **Whitepaper** (`active/whitepaper/`)
   - [sky-whitepaper.md](active/whitepaper/sky-whitepaper.md)
   - [appendix-a-protocol-features.md](active/whitepaper/appendix-a-protocol-features.md)
   - [appendix-b-agent-primitives.md](active/whitepaper/appendix-b-agent-primitives.md)
   - [appendix-c-tokens.md](active/whitepaper/appendix-c-tokens.md)
   - [appendix-d-glossary.md](active/whitepaper/appendix-d-glossary.md)
   - [appendix-e-infrastructure.md](active/whitepaper/appendix-e-infrastructure.md)

2. **Risk Framework** (`active/risk-framework/`)
   - [README.md](active/risk-framework/README.md)
   - [duration-model.md](active/risk-framework/duration-model.md)
   - [asset-classification.md](active/risk-framework/asset-classification.md)
   - [matching.md](active/risk-framework/matching.md)
   - [asset-type-treatment.md](active/risk-framework/asset-type-treatment.md)
   - [collateralized-lending-risk.md](active/risk-framework/collateralized-lending-risk.md)
   - [market-risk-frtb.md](active/risk-framework/market-risk-frtb.md)
   - [asc.md](active/risk-framework/asc.md)
   - [capital-formula.md](active/risk-framework/capital-formula.md)
   - [correlation-framework.md](active/risk-framework/correlation-framework.md)
   - [examples.md](active/risk-framework/examples.md)
   - [sentinel-integration.md](active/risk-framework/sentinel-integration.md)
   - [risk-capital-ingression.md](active/risk-framework/risk-capital-ingression.md)
   - [tugofwar.md](active/risk-framework/tugofwar.md)
   - [weekly-settlement-cycle.md](active/risk-framework/weekly-settlement-cycle.md)

3. **Smart Contracts** (`active/smart-contracts/`)
   - [architecture-overview.md](active/smart-contracts/architecture-overview.md) (PAS overview)
   - [configurator-unit.md](active/smart-contracts/configurator-unit.md) (PAS governance layer)
   - [lcts.md](active/smart-contracts/lcts.md)

4. **Governance Operations** (`active/governance-operations/`)
   - [sentinel-network.md](active/governance-operations/sentinel-network.md)
   - [atlas-synome-separation.md](active/governance-operations/atlas-synome-separation.md)

5. **Legal and Trading** (`active/legal-and-trading/`)
   - [passthrough-halo.md](active/legal-and-trading/passthrough-halo.md)
   - [identity-network.md](active/legal-and-trading/identity-network.md)
   - [sky-intents.md](active/legal-and-trading/sky-intents.md)

---

## The Laniakea System

Laniakea is Sky's infrastructure for **automated capital deployment at scale**. The documents in `active/` describe a complete system where capital flows through governed layers, risk is managed scientifically, and autonomous agents execute operations without human intervention.

### The Story in Brief

Capital enters at the top (Sky Core) and flows down through commercial bank equivalents (Primes) into investment products (Halos) that deploy into real-world assets. Every flow is rate-limited. Every actor posts risk capital. Autonomous Sentinels operate the machinery within governance-defined bounds. A unified risk framework determines capital requirements based on how long you might have to hold an asset. Weekly auctions allocate scarce resources. Queue-based token standards ensure fair access to capacity-constrained assets.

### Current vs Post-Laniakea

| Aspect | Current | Post-Laniakea |
|--------|---------|---------------|
| Settlement | Monthly | Weekly (Tue-Wed cycle) |
| Risk Capital | Manual verification | Sentinel automation (stk-verify) |
| Capital Requirements | Asset-specific | Unified GRF with SPTP |
| Rate Limits | Implicit | Explicit PAU with SORL |
| Halo Deployment | Bespoke | Factory-deployed |
| Resource Allocation | Governance-set | Weekly auctions (OSRC, SPTP) |

---

## Laniakea Part 1: Capital Flow Architecture

**Source:** [architecture-overview.md](active/smart-contracts/architecture-overview.md)

### The Four Layers

Capital flows through a unified hierarchy:

```
Generator Layer → Prime Layer → Halo Layer → End Investments
     (ERC20)         (vaults)       (vaults)      (RWAs, DeFi)
                        │
                        └──► Foreign Prime → Foreign Halo (altchains)
```

| Layer | Role | Connection Down |
|-------|------|-----------------|
| **Generator** | Interface with stablecoin ERC20 | ERC4626 vault to Primes |
| **Prime** | Commercial banks; deploy capital at scale | Vaults to Halos, bridge to Foreign |
| **Halo** | Investment products; wrap strategies | Asset transfers to custodians/RWAs |
| **Foreign** | Altchain deployments | Same vault patterns as mainnet |

### The PAU Pattern (Universal Building Block)

Every layer uses identical contracts, differently configured:

| Component | Purpose |
|-----------|---------|
| **Controller** | Entry point, enforces rate limits |
| **ALMProxy** | Holds custody, executes calls via `doCall()` |
| **RateLimits** | Linear replenishment with configurable max and slope |

**Key principle:** Same contracts, different configuration. Layers differ only in approved targets and rate limit values.

### Prime Agents

Each Prime has: SubProxy (treasury), Foundation (legal entity), Nested Contributors, Agent Artifacts (governance documentation).

| Prime | Focus | Products |
|-------|-------|----------|
| **Spark** | DeFi | SparkLend, Spark Liquidity Layer (6 chains), Spark Savings |
| **Grove** | Credit | CLO allocations, RWA strategies |
| **Keel** | Ecosystem | Solana deployment, USDS adoption |
| **Obex** | Incubator | Prime and Halo development |

---

## Laniakea Part 2: Governance & Rate Control

**Source:** [configurator-unit.md](active/smart-contracts/configurator-unit.md)

### The BEAM Hierarchy

Three-tier access control determines who can do what:

| BEAM | Level | Holders | Powers |
|------|-------|---------|--------|
| **aBEAM** | Admin | Core Council | Create inits, grant cBEAMs (14-day timelock) |
| **cBEAM** | Configurator | GovOps teams | Set rate limits (with SORL), call controller actions |
| **pBEAM** | Process | Sentinels | Execute operations directly on contracts |

**SORL (Second-Order Rate Limit):** Max 20% rate limit increase per 18h cooldown. Decreases always instant.

### Key Invariants

1. **Rate limits are universal** — Every capital flow is rate-limited
2. **Governance above contracts** — No redeployment needed for parameter changes
3. **Instant decrease, constrained increase** — Emergency response never blocked
4. **Timelock additions, instant removals** — Monitoring window + emergency response

---

## Laniakea Part 3: Risk Framework (GRF)

**Source:** [README.md](active/risk-framework/README.md)

### The Core Principle

**Capital Requirement = Drawdown Magnitude × Forced Realization Probability**

If liabilities are long-duration, forced realization probability is low → only need capital for fundamental risk. If liabilities are short-duration → need capital for full drawdown.

### SPTP (Stressed Pull-to-Par)

Time until an asset converges to its fundamental value under stress:

| Asset | SPTP | If Matched | If Unmatched |
|-------|------|------------|--------------|
| JAAA (CLO AAA) | 42mo | ~4-5% risk weight | ~10% FRTB |
| T-bills | 4wk-3mo | ~0.2-0.5% | ~1-2% FRTB |
| Sparklend | None (perpetual) | Cannot match | Gap risk 1-2%+ |

### 101 SPTP Buckets

Liabilities sorted into 101 buckets at 0.5-month granularity. Structural caps derived from bank run research (SVB, Credit Suisse, etc.).

### Risk Capital Waterfall

**JRC (Junior)** absorbs first: IJRC (Prime's own), TEJRC (tokenized external).
**SRC (Senior)** absorbs after: ISRC (Sky surplus), ESRC (srUSDS holders).

```
Loss → Tip JRC (10%) → Remaining JRC → SRC → Genesis Capital → Peg Adjustment
```

**Encumbrance Ratio:** Required Risk Capital / Total Risk Capital (target ≤90%)

---

## Laniakea Part 3b: Risk Capital Ingression

**Source:** [risk-capital-ingression.md](active/risk-framework/risk-capital-ingression.md)

### The Core Principle

Not all risk capital counts equally. The **ingression rate** determines how much of egressed capital is effectively recognized on a Prime's balance sheet.

### Universal Ingression Curve

All ingression uses the same shape: **flat zone + quarter circle** (3:1 max-to-anchor ratio).

```
Rate 1.0 |======-------____
         |                  ---__
         |                       \
     0.0 +----------|------------|-----> Capital
         0       anchor         max
         |-- flat --|--- curve ---|
```

### Three Ingression Layers

| Layer | Base | Anchor | Max | What It Measures |
|-------|------|--------|-----|------------------|
| **EJRC** | IJRC | 1-4× | 3-12× | External JRC quality (synomic + duration) |
| **SRC** | Effective JRC | 1.5× | 4.5× | Senior capital leverage |
| **MC-based** | Effective MC | 5× | 15× | Prime token market validation |

### EJRC Quality Dimensions

Two independent multipliers stack:
- **Synomic:** 2× if decision framework is auditable in Synome
- **Duration:** 1× to 2× based on uningression delay (3mo minimum for credit, 24mo max)

Three EJRC types: Normie TEJRC (LCTS, non-synomic, zero duration), Non-synomic duration (bespoke), Synomic duration (between Synomic agents).

### MC-Based Cap

Prime token metrics (worst-of-observed) determine **effective MC**:

| Metric | Healthy Level | Multiplier |
|--------|---------------|------------|
| Weekly ADV | 1.0% of MC | ×100 |
| Monthly ADV | 0.8% of MC | ×125 |
| Quarterly ADV | 0.6% of MC | ×167 |
| Monthly turnover | 3.5% | ×29 |
| Quarterly turnover | 6.5% | ×15 |
| Yearly turnover | 10% | ×10 |

Total effective RC cannot exceed ~12.85× effective MC.

---

## Laniakea Part 4: Weekly Settlement Cycle

**Source:** [weekly-settlement-cycle.md](active/risk-framework/weekly-settlement-cycle.md)

### The Heartbeat

| Period | Timing | Purpose |
|--------|--------|---------|
| **Measurement Period** | Tue noon → Tue noon | Data collection, bid submission |
| **Processing Period** | Tue noon → Wed noon | Calculation, verification, prepayment |
| **Moment of Settlement** | Wed noon | Everything takes effect |

### What Happens at Settlement

1. **OSRC Auction** — Allocate Senior Risk Capital capacity (sealed-bid, uniform-price)
2. **SPTP Auction** — Allocate duration-matching capacity (runs AFTER tug-of-war)
3. **Interest/Distributions** — Primes prepay; Generator distributes
4. **LCTS Settlement** — Queue-based tokens convert proportionally
5. **Penalties Begin** — Late actors accrue penalties from Wed noon

### Tug-of-War

**Source:** [tugofwar.md](active/risk-framework/tugofwar.md)

When Lindy-measured capacity doesn't match reservations, Primes "tug" for capacity:
- **Phase 1:** All Primes tug simultaneously; distance 0 (own bucket) = natural priority
- **Phase 2:** Primes trade up, releasing excess capacity downward via cascade

---

## Laniakea Part 5: Queue-Based Tokens (LCTS)

**Source:** [lcts.md](active/smart-contracts/lcts.md)

### Why LCTS Exists

LCTS solves: **How do you fairly distribute limited conversion capacity among many users?**

Without LCTS, capacity-constrained conversions create gas wars. LCTS pools users in generations and distributes capacity proportionally.

### The Multi-Generation Model

```
Week N:
├── Before Tue noon: Gen 1 ACTIVE (deposits, withdrawals allowed)
├── Tue noon: Gen 1 → LOCKED, Gen 2 → ACTIVE
├── Wed noon: Gen 1 settles proportionally, unlocks or finalizes
```

### Where LCTS is Used

| Token Type | Requirement | Examples |
|------------|-------------|----------|
| **External Risk Capital** | Mandatory | srUSDS, TEJRC, TISRC |
| **Halo Units** | Default | Most capacity-constrained strategies |

---

## Laniakea Part 6: Sentinel Network

**Source:** [sentinel-network.md](active/governance-operations/sentinel-network.md)

### Why Sentinels Exist

The PAU pattern provides machinery; Sentinels operate it. They solve continuous operation, risk visibility, governance efficiency, and commercial incentives.

### Sentinel Taxonomy

| Category | Sentinels | Purpose |
|----------|-----------|---------|
| **Governance** | stl-gen, stl-prime, stl-halo, stl-exec | Settlement, verification, staking, buybacks |
| **Operations** | stl-unit, stl-erc, stl-auction | Per-unit LCTS, auctions |
| **Execution** | stl-base, stl-stream, stl-trade | Strategy execution (baseline, optimizer, trader) |
| **Halo Bridge** | stl-control, stl-connect, stl-extend | Real-world asset interface |
| **Infrastructure** | stl-synome | Synome node operation |

### Key Roles

- **stl-erc** — Operates LCTS for risk capital tokens; calls `settle()`, manages exchange rates
- **stl-auction** — Runs sealed-bid auctions for OSRC and SPTP capacity
- **stl-base** — "Public autopilot" per Prime; holds Execution Engine, runs Base Strategy
- **stl-stream** — Private optimizer; streams intent to stl-base, earns carry when outperforming

---

## Laniakea Part 7: Atlas/Synome Separation

**Source:** [atlas-synome-separation.md](active/governance-operations/atlas-synome-separation.md)

### The Split

**Atlas** — Human-readable constitution (~10-20 pages). Describes WHAT must be true: principles, governance structure, agent type definitions.

**Synome** — Machine-readable graph database. Contains ALL operational data: Agent Artifacts, rate limits, penalty schedules, transaction logs.

The Atlas is a single root node within the Synome — the human-interpretable entry point to the machine-readable system.

### Synomic Agents

Primes, Halos, Executors are **Synomic Agents** — autonomous entities tethered to the Synome:
- Identity is Synome-native (SubProxy, token)
- Actions are Synome-bounded (rate limits, encumbrance ratios)
- Accountability is structural (penalties accrue automatically)

### Escalation to Human Judgment

99% of cases automated. The 1% edge cases escalate through governance to human judgment. This is what makes Synomic Agents "smart contracts with a backstop."

---

## Laniakea Part 8: Passthrough Halos

**Source:** [passthrough-halo.md](active/legal-and-trading/passthrough-halo.md)

### The Value Proposition

Passthrough Halos enable asset managers to offer Sky-compatible investment products with minimal legal overhead, standardized contracts, and immediate capital at scale.

### Why Immediate Capital?

When a new Halo Unit is properly onboarded (factory deployment, Sentinel integration, artifact reporting), every Prime's Sentinel automatically rebalances into it. No manual decision-making.

**For asset managers:** Your constraint becomes capacity management, not capital raising.

### Halo Unit Architecture

Each Halo Unit: LCTS Vault + PAU Infrastructure + Unit Sentinel (stl-unit).

---

## Laniakea Part 9: Identity Network

**Source:** [identity-network.md](active/legal-and-trading/identity-network.md)

### What is an Identity Network?

A special Halo type that operates KYC/identity verification services. Instead of deploying capital, an Identity Network maintains an **on-chain registry** of addresses verified to meet certain criteria (accredited investor, non-US person, etc.).

### Why Identity Networks Exist

Issuers and participants often prefer to trade only with known, verified counterparties. Institutional investors typically require counterparty verification. Identity Networks provide attestations about addresses that Exchange Halos verify before allowing trades in restricted markets.

### Key Properties

- **Multiple competing networks** — Different networks for different standards (US Accredited, Non-US QIB, EU MiFID II)
- **On-chain registry** — Simple `address → attestation status` mapping
- **Legal entity backing** — Each network controls an entity that performs actual KYC
- **Restricted Halo type** — Identity business only, no capital deployment

### Sentinel Integration

**stl-identity** operates the registry contract, processing attestation updates from the legal entity and handling expiry/revocation.

---

## Laniakea Part 10: Sky Intents

**Source:** [sky-intents.md](active/legal-and-trading/sky-intents.md)

### What is Sky Intents?

An intent-based trading protocol enabling:
- Trading without arbitrary transfer ability
- Fair matching with no MEV
- Permissioned trading via Identity Network integration

### Exchange Halo

A special Halo type that operates trading infrastructure:
- Runs orderbook (off-chain, centralized)
- Matches orders fairly (price-time priority)
- Settles via on-chain intents
- Specifies required Identity Networks per market

### Intent Protocol

Users sign intents authorizing specific trades. Intents can ONLY be settled as trades, not arbitrary transfers. Sentinels create intents within governance-set bounds (slippage, rate limits, allowed pairs).

### Key Flow

```
1. User/Sentinel creates intent (signed authorization to trade)
2. Order submitted to Exchange Halo's orderbook
3. Matching engine matches orders (off-chain, fair, no MEV)
4. Settlement batch submitted on-chain
5. Atomic settlement of all matched trades
```

### Prime Integration

Primes connect PAUs to Sky Intents via allowances. stl-base creates trading intents within bounds — enabling rapid trading, repricing, market making without giving arbitrary transfer ability.

---

## Generator Agents (Future)

Generators issue new Sky Generated Assets (SGAs) — stablecoins for other currencies:
- Each Generator spawns its own Stars (≈Primes) and Halos
- Inherits Sky's risk framework and liquidity infrastructure
- Enables regional expansion (e.g., MXNS for Mexico)

Frame as future growth opportunity, not current architecture.

---

## Glossary

### Core Tokens

| Term | Definition |
|------|------------|
| **USDS** | Sky stablecoin (1:1 USD) |
| **sUSDS** | Savings token; earns Sky Savings Rate |
| **SKY** | Governance token; staking rewards + buyback/burn |
| **stUSDS** | Segregated risk capital for SKY-backed borrowing |
| **DAI** | Legacy stablecoin; 1:1 convertible with USDS |

### Agents & Layers

| Term | Definition |
|------|------------|
| **Prime** | Capital-deploying agent; "commercial bank" |
| **Halo** | Lighter agent; wraps specific strategies |
| **Executor** | Operates systems with collateral backing |
| **Generator** | Issues USDS (current) or SGAs (future) |
| **Generator Agent** | Agent that can issue Sky Generated Assets |
| **SGA** | Sky Generated Asset — stablecoin from a Generator Agent |

### Infrastructure

| Term | Definition |
|------|------------|
| **PAU** | Parallelized Allocation Unit (Controller + ALMProxy + RateLimits) |
| **BEAM** | Bounded External Access Module |
| **pBEAM/cBEAM/aBEAM** | Process/Configurator/Admin BEAM levels |
| **SORL** | Second-Order Rate Limit |
| **LCTS** | Liquidity Constrained Token Standard |
| **Sentinel** | Autonomous system operating within Sky |
| **Identity Network** | Special Halo type providing KYC/attestation services |
| **Exchange Halo** | Special Halo type operating trading infrastructure |
| **Sky Intents** | Intent-based trading protocol for fair, MEV-free trading |
| **stl-identity** | Sentinel operating Identity Network registry |
| **stl-exchange** | Sentinel operating Exchange Halo orderbook |

### Risk Framework

| Term | Definition |
|------|------------|
| **GRF** | General Risk Framework |
| **SPTP** | Stressed Pull-to-Par — time until asset converges to fundamental |
| **JRC/SRC** | Junior/Senior Risk Capital |
| **IJRC/EJRC** | Internal/External Junior Risk Capital |
| **TEJRC** | Tokenized External JRC — LCTS-based, non-synomic, zero duration |
| **Encumbrance Ratio** | Required Risk Capital / Total Risk Capital |
| **Ingression Rate** | Ratio of effectively recognized capital to nominally egressed capital |
| **Egression** | External party injects capital into a Prime |
| **Ingression** | Prime receives and recognizes capital on its balance sheet |
| **Uningression Delay** | Countdown period after exit is called; determines EJRC quality |
| **Equivalent MC** | A metric converted to market cap units via multiplier |
| **ADV** | Average Daily Volume |
| **Turnover** | Percentage of unique tokens that changed hands (not just volume) |

### Governance

| Term | Definition |
|------|------------|
| **Atlas** | Constitutional governance document |
| **Synome** | Machine-readable operational database |
| **SSR** | Sky Savings Rate |
| **Core Council** | Group of Executors for Sky Core operations |

---

## Document Index

### Root Documents

| Document | Purpose |
|----------|---------|
| README.md | Repository overview and entrypoints |
| agent-master.md | Primary entrypoint for navigation and editing |
| compressed-memory.md | Project context summary (internal) |
| reference-docs.md | Background document overviews (non-canonical) |

### Active Documents (Laniakea System)

All documents referenced by **Source:** links above. Status reflects completeness:

| Document | Status | Laniakea Part |
|----------|--------|---------------|
| [architecture-overview.md](active/smart-contracts/architecture-overview.md) | Draft | Part 1: Capital Flow |
| [configurator-unit.md](active/smart-contracts/configurator-unit.md) | Draft | Part 2: Governance |
| [risk-framework/README.md](active/risk-framework/README.md) | Draft | Part 3: Risk Framework |
| [asc.md](active/risk-framework/asc.md) | Draft | Part 3: Risk Framework |
| [risk-capital-ingression.md](active/risk-framework/risk-capital-ingression.md) | Draft | Part 3b: Ingression |
| [weekly-settlement-cycle.md](active/risk-framework/weekly-settlement-cycle.md) | Draft | Part 4: Settlement Cycle |
| [tugofwar.md](active/risk-framework/tugofwar.md) | Draft | Part 4: Settlement Cycle |
| [lcts.md](active/smart-contracts/lcts.md) | Draft | Part 5: Queue Tokens |
| [sentinel-network.md](active/governance-operations/sentinel-network.md) | Draft | Part 6: Sentinels |
| [atlas-synome-separation.md](active/governance-operations/atlas-synome-separation.md) | Draft | Part 7: Data Architecture |
| [passthrough-halo.md](active/legal-and-trading/passthrough-halo.md) | Draft | Part 8: Institutional Integration |
| [identity-network.md](active/legal-and-trading/identity-network.md) | Draft | Part 9: Identity Network |
| [sky-intents.md](active/legal-and-trading/sky-intents.md) | Draft | Part 10: Sky Intents |

### Whitepaper

| Document | Purpose |
|----------|---------|
| [whitepaper/sky-whitepaper.md](active/whitepaper/sky-whitepaper.md) | Main 8-part document |
| [appendix-a-protocol-features.md](active/whitepaper/appendix-a-protocol-features.md) | Sky Core mechanisms |
| [appendix-b-agent-primitives.md](active/whitepaper/appendix-b-agent-primitives.md) | Agent Framework capabilities |
| [appendix-c-tokens.md](active/whitepaper/appendix-c-tokens.md) | Complete token reference |
| [appendix-d-glossary.md](active/whitepaper/appendix-d-glossary.md) | Term definitions |
| [appendix-e-infrastructure.md](active/whitepaper/appendix-e-infrastructure.md) | Deployed contracts |

## Using This Repo With Agents

This repository is designed to be navigated and edited with an agentic coding assistant.

### Canonical vs Background

- **Canonical docs:** everything under `active/` plus this file (`agent-master.md`).
- **Background docs:** everything under `reference/` (useful source material, but not maintained as the canonical spec and may be outdated).
- **Rule:** canonical docs should not depend on or link to background docs; if a rule matters, restate it in `active/`.

### Editing Workflow

1. Start with the relevant pillar under `active/` (or the whitepaper).
2. Make changes in the leaf document(s) first.
3. Update this file’s index/status tables if files move or status changes.
4. Keep `active/whitepaper/appendix-d-glossary.md` in sync as new terms are introduced.

### Git Workflow

This is a normal git repo with a `main` branch, hosted on GitHub (currently: `https://github.com/Rune23/Laniakea`).

- Local folder name can differ from the GitHub repo name; git uses the `.git/` directory, not the enclosing folder name.
- Prefer working in branches and using PRs for review/traceability.
- **Agent policy:** the agent should only run git operations (commit/push/pull/branch changes) when explicitly requested (e.g., “run git commands”).

Common commands:
- Check current state: `git status`
- Update local `main`: `git checkout main && git pull --rebase origin main`
- Start a work branch: `git checkout -b <topic-branch>`
- Save work: `git add -A && git commit -m "<message>"`
- Share branch: `git push -u origin <topic-branch>`
- (After PR merge) sync: `git checkout main && git pull --rebase origin main`

Notes:
- Avoid case-only renames on macOS without `git mv` (case-insensitive filesystems can make these changes behave differently across machines/CI).

### Open Questions

| Question | Status |
|----------|--------|
| Correlation framework approach (GRF Part 6) | Next up |
| How to handle cross-doc dependencies | TBD |
| Independent trader registry design | TBD (referenced in ingression) |

---

## TODO / Fixes

- **Keep whitepaper guidance in one place:** `active/whitepaper/README.md` is canonical.
- **Finish correlation framework** in `active/risk-framework/correlation-framework.md`.
- **Complete Sentinel spec** in `active/governance-operations/sentinel-network.md` (edge cases, failure modes, integration details).
- **Resolve or explicitly defer open questions** in Draft docs: `active/risk-framework/weekly-settlement-cycle.md`, `active/risk-framework/tugofwar.md`, `active/legal-and-trading/identity-network.md`, `active/legal-and-trading/sky-intents.md`, `active/governance-operations/atlas-synome-separation.md`.
- **Whitepaper fact/claim hygiene** in `active/whitepaper/sky-whitepaper.md` (single “as of” date, sourced metrics, remove/qualify brittle assertions).
- **Fill or fence TBD infra addresses** in `active/whitepaper/appendix-e-infrastructure.md`.
- **Status semantics cleanup:** decide whether `active/risk-framework/risk-capital-ingression.md` should be `Draft` or `Done/Current` and align references.

---

## Repo Streamlining Plan

Goal: make `active/` self-contained and unambiguous for distribution; keep background source material internal-only (not shipped, not required, and not linked as “current truth”).

1. **Background quarantine**
   - Keep all non-distributed background/source material clearly labeled as internal-only and potentially outdated.
   - Ensure any background doc that looks actionable is labeled as non-canonical and points readers to the corresponding `active/` doc(s).

2. **Status + metadata normalization**
   - Standardize doc headers across `active/`: `Status`, `Last Updated` (and optional `Category`).
   - Unify status vocabulary: `Current`, `Done`, `WIP`, `Draft`, `Planned`, `Deprecated`.
   - Resolve any mismatches between per-doc status headers and the status table below.

3. **Master index completeness**
   - Keep the “leaf doc” listing in this master doc as the single, canonical navigation map.
   - Ensure every file under `active/` appears exactly once in the relevant pillar section and in the Document Index table.

4. **Cross-link hygiene**
   - Make sure `active/` docs only rely on other `active/` docs for definitions/mechanics.
   - If a rule is derived from background/source material, restate it fully in `active/` and do not link out of the distributed document set.

5. **Glossary consolidation**
   - Treat `active/whitepaper/appendix-d-glossary.md` as canonical for terms.
   - Remove or align duplicate mini-glossaries/definitions in other docs, or explicitly point them to the glossary.

6. **Open questions + TODO tracking**
   - Standardize “Open Questions” sections in Draft/WIP docs (same format, short, actionable).
   - Keep this master doc’s `## TODO / Fixes` as the only repo-level backlog; each item should link to the exact doc/section it lives in.

7. **Validation pass**
   - Run a repo-wide sweep for broken paths and stale references (especially after renames).
   - Sweep `active/` for `TBD/TODO/FIXME` and either resolve, fence, or list them in `## TODO / Fixes`.

---

*This document is the primary entrypoint for working with the repo using agents. Keep it current as documents evolve.*
