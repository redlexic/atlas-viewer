# Project Context (Compressed)

**Last Updated:** 2026-01-04
**Purpose:** Optional short context for collaborators and agents. Primary entrypoint: `agent-master.md`.

---

## What This Repo Contains

- **Canonical document set:** `active/` + `agent-master.md`.
- **Background/source material:** `reference/` (not maintained as canonical; may be outdated).

## Canonical Structure (Pillars)

Under `active/`:
- `whitepaper/` — high-level narrative + appendices
- `risk-framework/` — modular risk framework (duration/matching/capital/correlation/ASC)
- `smart-contracts/` — PAS/Configurator + PAU patterns + LCTS
- `governance-operations/` — Sentinel + Atlas/Synome separation
- `legal-and-trading/` — passthrough halo + identity + intents

## Recent Consolidations

- Renamed primary entrypoint to `agent-master.md` and removed personal/collaboration-specific language.
- Whitepaper peg stability now includes ASC/DAB transition framing; detailed ASC rules live in `active/risk-framework/asc.md`.
- Risk framework split into focused modules under `active/risk-framework/` (no single GRF “main” doc).

## Work In Progress

Use `agent-master.md` for:
- repo-wide TODOs (`## TODO / Fixes`)
- per-document “Open Questions” lists
