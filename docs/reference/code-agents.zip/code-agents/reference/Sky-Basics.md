# Sky Ecosystem Guide

**Purpose:** High-level grounding context to avoid confusion in development sessions.

---

## What Sky Is

Sky is the evolution of MakerDAO. It expands the decentralized stablecoin model into a Central Bank + Commercial Bank type of system, where Sky itself regulates risk and then lends in bulk to Primes, that then deploy collateral into the broader ecosystem while maintaing regulatory capital requirements to ensure that they don't blow up and cause risk to the entire stablecoin ecosystem, similar to how banks are regulated in the real world, but with some advantages from blockchain and AI, and with real time public and transparent rules via the Atlas and Synome.

---

## Core Tokens

| Token | Role | Key Detail |
|-------|------|------------|
| **USDS** | Stablecoin | 1:1 with DAI, ~$5-6B supply |
| **sUSDS** | Savings token | Deposit USDS, earn yield automatically |
| **SKY** | Governance | 24,000 SKY = 1 MKR, staking rewards |
| **DAI** | Legacy stablecoin | Still exists, ~$5.4B supply |

---

## Sky Agent Framework

Agents are operational entities that do work on behalf of Sky Protocol. They're organized into categories:

### Primes
Capital-deploying agents that generate yield.

| Type | Description |
|------|-------------|
| **Star Primes** | Autonomous SubDAOs (e.g., Spark, Grove) |
| **Institutional Primes** | Regulated entities for TradFi integration (e.g., Obex) |

### Halos
Lighter-weight agents with specific operational functions.

| Type | Description |
|------|-------------|
| **Standard Halos** | Basic operational agents |
| **Institutional Network Halos** | Institutional-facing operational agents |
| *(others)* | Additional halo types as defined by governance |

### Generator Agents
Agents that create or bootstrap new agents/initiatives.

### Executor Agents
Core governance operators. Rotate between:
- **Operational phase** — Earn share of Prime profits, provide oversight
- **Core Council phase** — Participate in core governance, earn from governance budget

Executors offer **Ecosystem Accords** that enable other agents to operationalize. They underwrite operational risk.

---

## Key Stars (Star Primes)

| Star | Focus |
|------|-------|
| **Spark** | Lending, liquidity, yield (SPK token) |
| **Grove** | Institutional credit, RWAs, CLOs |

---

## Governance

- **Sky Atlas** — Constitutional document governing the ecosystem
- **vote.sky.money** — On-chain governance portal
- **forum.sky.money** — Discussion and proposals
- Monthly cycle for major changes, weekly cycle for operational decisions

## Key Terms

| Term | Meaning |
|------|---------|
| Star | Star Prime (autonomous SubDAO) |
| Prime | Capital-deploying agent category |
| Halo | Lighter operational agent category |
| Executor | Governance operator agent |
| Generator | Agent that creates other agents |
| Ecosystem Accord | Agreement enabling agent operations |
| Atlas | Constitutional governance document |
| SSR | Sky Savings Rate |
| TMF | Treasury Management Function |
| SLL | Spark Liquidity Layer |
