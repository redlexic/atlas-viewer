# Sky Whitepaper Strategy v2 (Deprecated)

**Status:** Deprecated (retained for history)
**Replaced By:** `active/whitepaper/README.md`
**Date:** December 2025

> This document is retained for historical context only. Do not update it.

---

## Audience

**Primary:** Crypto-native readers with technical interest
**Secondary:** Institutional observers (but not primary — they won't read whitepapers)

This is NOT a marketing document for mainstream audiences. It's a technical reference for people who already understand DeFi and want to understand Sky Ecosystem's architecture, economics, and governance at depth.

**Implications:**
- Can assume familiarity with DeFi primitives (vaults, staking, governance tokens)
- Can use technical terminology without over-explaining
- Should be precise and complete rather than simplified
- Should read like protocol documentation, not investor marketing

---

## Core Messaging Principles

### 0. Always "Sky Ecosystem"

The project is **Sky Ecosystem**, not "Sky" alone. This establishes ownership of the full term — when someone searches "Sky Ecosystem" or says it aloud, there should be no ambiguity.

**Naming convention:**

| Use | Don't Use |
|-----|-----------|
| Sky Ecosystem | Sky (standalone, as project name) |
| Sky Protocol | — (this is correct for the smart contracts) |
| Sky Agents | — (this is correct) |
| SKY token / SKY | — (this is correct for the token) |
| USDS, sUSDS | — (these are correct) |

**When "Sky" alone is acceptable:**
- As part of compound terms: "Sky Savings Rate", "Sky Protocol", "Sky Agents"
- When referring specifically to the token: "SKY"

**When "Sky Ecosystem" is required:**
- Every standalone reference to the project (no casual "Sky" shorthand)
- Document title and headers
- Any comparison with other projects

**Example patterns:**
- "Sky Ecosystem governs the decentralized Sky Protocol..."
- "Within Sky Ecosystem, capital flows through..."
- "Sky Ecosystem's Agent network includes..."

This matches the State Report's usage and establishes the searchable, ownable term.

---

### 1. Decentralization Must Be Explicit

Sky Ecosystem is decentralized. This is technically accurate and legally significant. The whitepaper must:

- State clearly that Sky Protocol is community-governed through SKY token holders
- Distinguish between Sky Protocol (decentralized smart contracts) and Sky Ecosystem (broader community)
- Emphasize that no single entity controls the protocol
- Note that USDS is "a decentralized yield-generating stablecoin" — not a payment stablecoin under GENIUS Act

**Key phrases (legal-approved):**
- "The Sky Protocol is community-governed through use of the SKY token"
- "decentralized governance"
- "decentralized, community-driven"

### 2. SKY Token: Mechanism Over Promise

Follow the legal-approved framing from the Sky Ecosystem State Report. Never say "investment" or "profit sharing." Describe mechanisms.

**Three core functions of staked SKY:**

1. **Governance participation** — "The ability to contribute to decentralized governance of all Protocol parameters, risk controls, capital allocation, and the multi-billion-dollar treasury"

2. **Programmatic allocation of protocol profits** — "Under current Protocol parameters, as determined through decentralized governance, approximately 75-100% of Protocol profits are allocated to stakers of the SKY token through programmatic, open-market buybacks that are redistributed as additional yield to staked SKY"

3. **Collateral utility** — "The ability to use governance-participating (staked) SKY as collateral for borrowing USDS while continuing to earn staking rewards"

**Key qualifiers to always include:**
- "under current Protocol parameters"
- "as determined through decentralized governance"
- "programmatically"
- "through the SKY buyback and staking rewards mechanism"

### 3. Agent Framework: Simple Overview, Detail in Appendix

Main document gets the structural explanation:
- Sky Core as protocol infrastructure
- Primes as capital deployers (Spark, Grove, Keel, Obex)
- Halos as investment product wrappers
- Sentinels as operational automation

Full primitive details → Appendix B (Sky Agent Primitives)

**One paragraph summary for main doc:**
> Sky Agents are autonomous and independent systems within the Sky Ecosystem that plug into the decentralized Sky Protocol primitives. The Agent network currently includes Spark (DeFi lending), Grove (private credit), Keel (ecosystem expansion), and Obex (incubation). These Agents compete to deliver the highest risk-adjusted returns while efficiently sharing the economies of scale of the entire ecosystem. For the complete list of Agent Framework primitives, see Appendix B.

### 4. SPTP: Omit from Main Document

The SPTP bucket system is too complex to explain briefly and not necessary for understanding Sky Ecosystem's value proposition.

**Replacement language for main doc:**
> Primes can deploy capital into longer-duration assets with variable rates, enabling higher yields when liability duration permits. The risk framework matches asset characteristics to liability profiles, allowing efficient capital deployment without requiring banks' traditional liquidity buffers.

Full SPTP mechanics → Appendix B (Agent Framework Primitives) under duration matching primitives

### 5. Growth Story: Laniakea Technical Improvements Only

Do NOT frame growth as market expansion, institutional adoption, or price appreciation. Frame it as protocol capability upgrades.

**Laniakea upgrade focus areas:**
- Weekly settlement cycle (replacing monthly)
- Automated risk capital verification
- Unified risk framework across all assets
- Rate-limited capital flows with governance controls
- Factory-deployed Halos for rapid product creation
- Auction-based resource allocation

**Framing:**
> The Laniakea upgrade represents a significant expansion of protocol capabilities, enabling automated settlement at scale, unified risk management, and rapid deployment of new investment products. These technical improvements allow the Agent network to operate more efficiently and deploy capital into a broader range of asset classes.

---

## Document Structure

### Part 1: What is Sky Ecosystem (1.5 pages)

**Content:**
- World's largest decentralized yield-generating stablecoin
- $9.86B USDS supply, $435M annualized revenue
- Community-governed through SKY token
- How Sky Ecosystem generates revenue: spread between base rate and savings rate
- Revenue sources: collateralized lending, digital asset lending, Treasuries, private credit, delta-neutral strategies

**Tone:** Factual, numbers-forward, establishes scale

### Part 2: History and Track Record (0.5 pages)

**Content:**
- Origin as MakerDAO (2017)
- Eight-year track record
- Evolution from single product to Agent network
- 2024-2025 rebrand and migration

**Tone:** Brief credibility establishment

### Part 3: Token System (2 pages)

**Content:**

**USDS:**
- Decentralized yield-generating stablecoin
- 1:1 USD peg
- Not a payment stablecoin under GENIUS Act — focused on capital formation
- Multi-chain availability via SkyLink

**sUSDS:**
- Savings token — deposit USDS, earn Sky Savings Rate
- ERC-4626 vault standard
- No lock-up, freely redeemable
- Earns yield on all supported chains

**SKY:**
- Community governance token
- Three functions: governance, programmatic profit allocation, collateral
- Total supply capped at 23.46B tokens
- Smart Burn Engine for buybacks
- Use exact legal-approved language from Section 2 above

**Tone:** Precise, mechanism-focused, legally careful on SKY

### Part 4: How the Protocol Works (2-3 pages)

**Content:**
- Sky Protocol as decentralized infrastructure
- Revenue generation mechanics
- Treasury waterfall: Security → Stability Buffer → Smart Burn
- Agent network overview (brief — full details in Appendix B)
- Risk management philosophy (brief — full details in Appendix A)

**Tone:** Technical but accessible to crypto-native readers

### Part 5: The Agent Network (1.5 pages)

**Content:**
- What are Sky Agents (autonomous systems plugging into Protocol primitives)
- Current Agents: Spark, Grove, Keel, Obex
- How Agents compete for capital allocation
- How new Agents are added (governance approval)
- Brief mention of Halos as investment product wrappers

**Do NOT include:**
- PAU pattern details
- Sentinel taxonomy
- BEAM hierarchy
- Rate limit mechanics

All of these → Appendix B

**Tone:** Structural overview, with clear pointer to appendix for depth

### Part 6: Risk Management (1.5 pages)

**Content:**
- Two-tier capital structure (Junior Risk Capital, Senior Risk Capital)
- Loss absorption order (JRC absorbs first → SRC → Genesis Capital)
- Encumbrance ratio monitoring
- Risk management methods "adapted from traditional finance"
- Reference S&P Global analysis

**Do NOT include:**
- SPTP bucket system
- Lindy measurement
- Tug-of-war allocation
- Detailed waterfall mechanics

**Simple framing:**
> The risk framework enables Primes to deploy into longer-duration assets with variable rates. Capital requirements are calculated based on asset characteristics and liability profiles, with a unified approach across all asset classes.

**Tone:** Institutional risk language, builds confidence without complexity

### Part 7: Protocol Upgrades (1 page)

**Content:**
- Laniakea upgrade overview
- Weekly settlement (replacing monthly)
- Automated operations
- Expanded Agent capabilities
- Factory-deployed products

**Do NOT include:**
- Specific timelines or dates
- Yield projections
- Market size claims
- Price expectations

**Tone:** Technical capability description, not growth prediction

### Part 8: Governance (1 page)

**Content:**
- SKY voting mechanics
- Decentralized parameter control
- The Atlas as governance constitution
- How protocol changes are made
- Emergency response capabilities

**Tone:** Brief, emphasizes decentralization

---

## Appendices

### Appendix A: Protocol Features
Exhaustive list of Sky Core mechanisms (already drafted)

### Appendix B: Sky Agent Primitives
Full Agent Framework capabilities including:
- PAU pattern
- Rate limits and SORL
- BEAM hierarchy
- Sentinel types
- Duration matching / SPTP (moved from main doc)
- Halo architecture
- All Agent primitives from current draft

### Appendix C: Token Reference
Complete token list (already drafted)

### Appendix D: Glossary
Term definitions (already drafted)

### Appendix E: Deployed Infrastructure
Contract addresses (already drafted)

---

## Writing Sequence

| Order | Part | Dependency |
|-------|------|------------|
| 1st | Part 3: Token System | Core — everything else references this |
| 2nd | Part 4: How the Protocol Works | Builds on Part 3 |
| 3rd | Part 1: What is Sky Ecosystem | Now we can summarize accurately |
| 4th | Part 2: History | Short, factual |
| 5th | Part 5: Agent Network | References Part 4 |
| 6th | Part 6: Risk Management | References Parts 4-5 |
| 7th | Part 7: Protocol Upgrades | References Parts 4-6 |
| 8th | Part 8: Governance | Can be written anytime |

---

## Review Checklist

Before finalizing each section, verify:

- [ ] "Sky Ecosystem" used for project references (not "Sky" alone)
- [ ] SKY token language matches approved patterns exactly
- [ ] No forward-looking yield numbers (historical only)
- [ ] "Decentralized" used accurately and consistently
- [ ] All governance-dependent items qualified with "under current parameters"
- [ ] No investment advice or profit guarantees
- [ ] Clear distinction between Protocol and Ecosystem
- [ ] Forward-looking statements clearly identified as expectations/plans

---

## What to Cut from Current Draft

The existing main.md skeleton has some framing that should change:

| Current | Revised |
|---------|---------|
| "$300B opportunity" | Remove — too marketing-focused |
| "75%+ flows to SKY holders" | Use full legal phrasing with qualifiers |
| "Basel III-inspired" | Keep but add "methods adapted from traditional finance" |
| "Generator Agents" | Brief mention as future capability, not growth story |
| "Institutional partnerships" | Remove — focus on technical capabilities |

---

## Source Documents

| Part | Primary Sources |
|------|-----------------|
| Part 1-2 | sky-ecosystem-state-report.md |
| Part 3 | sky-ecosystem-state-report.md, appendix-c-tokens.md |
| Part 4 | architecture-overview.md, appendix-a-protocol-features.md |
| Part 5 | architecture-overview.md, agent-master.md |
| Part 6 | risk-framework (see `active/risk-framework/README.md`) |
| Part 7 | agent-master.md (Laniakea System section) |
| Part 8 | Atlas-Synome-Separation.md |

---

*Historical note: this document originally superseded `reference/whitepaper-strategy.md` before both were deprecated in favor of `active/whitepaper/README.md`.*
