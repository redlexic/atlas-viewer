## Unified Risk Framework: Summary

### The Core Problem

Sky holds assets (tradfi securities, crypto lending positions, etc.) to back USDS liabilities. The current risk framework is fragmented — different methodologies for different asset types, with no coherent principle connecting them. This has resulted in excessive leverage and inadequate capital for the actual risks being taken.

### The Unifying Insight

The capital requirement for any position should reflect one question:

**What's the maximum loss we could be forced to realize?**

This decomposes into two factors:

**Capital Requirement = Drawdown Magnitude × Forced Realization Probability**

The drawdown magnitude depends on the asset. The forced realization probability depends on the liabilities — specifically, whether the liabilities funding that asset might demand liquidity before the asset recovers or matures.

### Part 1: Liability Duration Analysis (Demand Side)

**Purpose:** Determine how much of the USDS liability base is short-term (could demand liquidity soon) versus long-term (sticky, unlikely to redeem).

**Method:** The ultra-simple Lindy model.

For each lot of USDS:
- Measure current age (time since last transfer)
- Expected remaining holding time = current age (pure Lindy)
- Apply conservative haircut (e.g., assume 0.5x or 0.7x instead of 1x)

Aggregate across all lots to get a liability duration distribution — how much USDS falls into each tier:

| Tier | Duration | Description |
|------|----------|-------------|
| 0 | 0-1 day | Instant liquidity demand (ASC) |
| 1 | 1-14 days | Short-term (STRB horizon) |
| 2 | 14 days - 3 months | Medium-term |
| 3 | 3-12 months | Medium-long |
| 4 | 12-30 months | Long-term |
| 5 | 30+ months | Structural |

This tells you: "We have $X in Tier 0-1 liabilities that might need liquidity within two weeks, $Y in Tier 2-3 that might need liquidity within a year, $Z in Tier 4+ that is unlikely to redeem for years."

### Part 2: Asset Classification

Every asset has three relevant characteristics:

**A. Fundamental Risk**
What can go wrong even if you hold to maturity? Credit default, smart contract failure, counterparty failure, etc. This is the "risk weight" concept from banking — the irreducible risk that doesn't go away with time.

**B. Mark-to-Market Risk (Drawdown)**
How far could this asset fall from current price before recovering? This is the FRTB concept — the loss you'd realize if forced to sell during a stress period. Measured as expected shortfall at some confidence level (e.g., 97.5%) over a relevant horizon.

**C. Pull-to-Par Duration**
For assets that mature or converge to a known value (bonds, loans, etc.): how long until the mark-to-market risk resolves? For JAAA, this is roughly 2.5 years. For a 30-day T-bill, it's 30 days. For ETH, it's infinite (no pull to par).

### Part 3: The Matching Principle

Assets can be matched against liability tiers based on their pull-to-par duration:

**Matched assets (pull-to-par ≤ liability tier duration):**
- Forced realization probability is low
- You only need capital for fundamental risk (risk weight)
- This is HTM treatment

**Unmatched assets (pull-to-par > liability tier duration, or no pull-to-par):**
- Forced realization probability is high
- You need capital for full mark-to-market drawdown
- This is trading book / FRTB treatment

**Example:**
- You have $500M in Tier 4+ liabilities (12-30 month duration)
- JAAA has 2.5 year pull-to-par
- JAAA can be matched against Tier 4+ liabilities
- For that matched portion, capital = risk weight only (credit risk of underlying CLOs)
- If you hold more JAAA than your Tier 4+ liabilities, the excess is unmatched and requires full FRTB capital

### Part 4: Applying This to Different Asset Types

**Liquid TradFi (STRB - e.g., JAAA, money market ETFs):**

| Component | Treatment |
|-----------|-----------|
| Fundamental risk | Credit risk weight of underlying |
| Drawdown risk | FRTB: 10-day ES at 97.5%, stressed calibration |
| Pull-to-par | Varies by asset (2.5 years for JAAA) |
| Matching | Can be HTM-matched to liability tiers ≥ pull-to-par duration |
| Capital if matched | Risk weight only |
| Capital if unmatched | Full FRTB drawdown |

**Overcollateralized Crypto Lending (e.g., Sparklend):**

| Component | Treatment |
|-----------|-----------|
| Fundamental risk | Smart contract risk, oracle risk |
| Drawdown risk | Gap risk: bad debt from flash crash at stressed health factors |
| Pull-to-par | None (perpetual positions, no maturity) |
| Matching | Cannot be HTM-matched (no pull-to-par) |
| Capital | Must cover gap risk at relevant confidence level |

The gap risk calculation:
- Assume health factors could degrade to ~1 (minimal overcollateralization)
- Model bad debt as function of instantaneous price gap
- Size capital to survive a gap of X% (where X is derived from historical worst cases: 15-20% or higher)

**Overcollateralized TradFi Lending (e.g., lending against tokenized treasuries):**

| Component | Treatment |
|-----------|-----------|
| Fundamental risk | Credit risk of collateral, counterparty risk |
| Drawdown risk | Gap risk, but lower volatility than crypto |
| Pull-to-par | Depends on loan structure — if loans mature, there's a duration |
| Matching | Potentially matchable if loan book has defined duration |
| Capital | Hybrid — gap risk for unmatched portion, risk weight for matched portion |

### Part 5: The Capital Formula

For any Prime's portfolio, total capital requirement is:

**Total Capital = Σ (Matched Assets × Risk Weight) + Σ (Unmatched Assets × FRTB Drawdown) + Correlation Adjustment**

Where:
- Matched assets are those with pull-to-par ≤ their matched liability tier duration
- Unmatched assets are everything else
- The correlation adjustment ensures you can survive a scenario where multiple assets draw down simultaneously

### Part 6: Correlation (Still To Be Defined)

The principle should be something like:

*Assets that share a common stress catalyst belong to the same correlation group. Capital must cover the combined drawdown of each correlation group under its stressed scenario.*

Possible correlation groups:
- Crypto crash (all crypto collateral, crypto lending positions)
- Credit crisis (CLOs, corporate bonds, leveraged loans)
- Rate shock (duration-sensitive fixed income)
- Stablecoin-specific (anything correlated with USDS confidence)

Capital is the maximum of the grouped stress scenarios, not the sum (since they're alternatives, not simultaneous).

### Part 7: How This Changes Current Practice

**For JAAA specifically:**
- Current: 1.6% CRR regardless of liability matching
- Proposed: If matched to Tier 4+ liabilities, ~4-5% risk weight. If unmatched, ~10% FRTB capital.
- The $1B position is only justifiable if there's $1B of Tier 4+ liabilities to match against

**For Sparklend:**
- Current: 0.1% CRR
- Proposed: Must cover gap risk at HF=1 for 15-20% crash, likely 1-2% minimum
- No HTM relief available (no pull-to-par)

**For overall portfolio:**
- Current: Different methodologies stitched together
- Proposed: Unified framework where liability duration determines how much HTM capacity you have, and all assets compete for that capacity based on their pull-to-par duration

### Summary of Principles

1. **Liability duration determines HTM capacity.** Use Lindy-based demand analysis to measure how much of your liability base is short-term vs long-term.

2. **Asset pull-to-par determines HTM eligibility.** Only assets with pull-to-par duration ≤ liability tier duration can be HTM-matched.

3. **Matched assets get risk weight treatment.** You only need capital for fundamental risk (credit, smart contract, etc.).

4. **Unmatched assets get FRTB treatment.** You need capital for full stressed drawdown over the relevant forced-sale horizon.

5. **Crypto lending is inherently unmatched.** No pull-to-par means no HTM relief. Capital must cover gap risk.

6. **Correlation groups prevent diversification illusions.** Capital must survive each stress scenario applied to its correlated asset group.

7. **Conservative by default.** When uncertain about liability duration or asset characteristics, assume short-duration liabilities and full drawdown risk.

---

Does this capture the unified framework correctly? The main open question is probably the correlation system — whether we can find a principles-based approach rather than arbitrary constants.