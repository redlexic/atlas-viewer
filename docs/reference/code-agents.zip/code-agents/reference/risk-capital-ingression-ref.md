# Risk Capital Ingression Framework

---

## Glossary

| Term | Definition |
| --- | --- |
| **Risk Capital Ingression** | The process by which a Star formally receives and recognizes Risk Capital as part of its balance sheet, allowing it to count toward Capital Ratio Requirements. |
| **Risk Capital Egression** | The act of *injecting* Risk Capital into a Star. Once egressed, the capital becomes exposed to losses under the Star’s loss waterfall according to the applicable terms. |
| **Ingression Load** | The encumbrance a Star takes on when ingression occurs — the “weight” applied to its internal capital base. |
| **Ingression Factor** | The ratio determining how heavy that load is for a specific capital type. Lower factors mean higher efficiency. |
| **Ingression Capacity** | The remaining ability of a Star to ingress more capital before reaching ratio or load limits. |
| **EIF — External Ingression Factor** | Ratio that determines how much Internal Junior Risk Capital (IJRC) becomes loaded when ingressing External Junior Risk Capital (EJRC). |
| **SIF — Senior Ingression Factor** | Ratio that determines how much Junior Risk Capital (JRC) becomes loaded when ingressing Senior Risk Capital (SRC). |
| **Qualified Star** | A Star that meets the operational and transparency standards allowing it to egress **Qualified External Junior Risk Capital (QEJRC)** with higher efficiency (lower EIF / SIF). |
| **Qualified Halo** | A Halo Agent that meets stricter modeling, transparency, and performance standards allowing it to egress **QEJRC** across the ecosystem under special Halo-specific rules. |
| **Unqualified Egressor** | Any external participant or Star that has not met qualification standards; its capital counts as **Unqualified External Junior Risk Capital (UEJRC)**. |
| **External–Senior Substitution (ESS)** | The act of loading a Star’s SIF using additional JRC instead of SRC — used when a Star wants to reduce potential losses, optimize cost, or temporarily replace SRC with cheaper JRC. |

---

## Overview

### Risk Capital Ingression

**Risk Capital Ingression** defines how a Star receives Risk Capital from external sources and recognizes it as part of its official Risk Capital base under the **Sky Risk Framework**.

- **Ingression:** The act of receiving and accounting for new capital on the Star’s balance sheet.
- **Egression:** The act of injecting capital into a Star in exchange for yield exposure (the *Ingression Rate*).

There are two ingressable capital layers:

1. **Junior Risk Capital (JRC):** Takes losses **pari passu** with the Star’s internal capital.
2. **Senior Risk Capital (SRC):** Takes losses **only after** the Star’s liquidation.

The Ingression system measures not just loss absorption, but also *capital intelligence* — distinguishing between aligned, governance-active capital (QEJRC) and passive or speculative capital (UEJRC).

---

## Qualified Egressor System

The **qualification system** differentiates between *who* is allowed to egress smart capital — **Qualified Stars** and **Qualified Halos** — and how efficiently that capital can be ingressed.

The higher the qualification level of the source, the more efficiently the receiving Star can ingress its capital:

- Less internal capital is encumbered.
- More Senior Risk Capital can be ingressed safely.

This efficiency is governed by two key ratios:

- **EIF (External Ingression Factor)**
- **SIF (Senior Ingression Factor)**

---

## EIF — External Ingression Factor

The **EIF** defines how much Internal JRC must be loaded when a Star ingresses External JRC.

| Source Type | EIF | Example Interpretation |
| --- | --- | --- |
| **QEJRC** (from Qualified Star or Qualified Halo) | **0.5** | Ingress 10 M → load 5 M IJRC. High efficiency. |
| **UEJRC** (from Unqualified Egressor) | **1.0** | Ingress 10 M → load 10 M IJRC. Lower efficiency. |

A Star with access to qualified capital can ingress **twice as much external JRC** for the same internal encumbrance.

---

## SIF — Senior Ingression Factor

The **SIF** determines how much JRC must be loaded when ingressing Senior Risk Capital.

| Junior Capital Type | SIF | Example |
| --- | --- | --- |
| **IJRC** | **1.0** | Ingress 10 M SRC → load 10 M IJRC |
| **QEJRC** | **1.0** | Ingress 10 M SRC → load 10 M QEJRC |
| **UEJRC** | **2.0** | Ingress 10 M SRC → load 20 M UEJRC |

All SRC behaves identically, but the *quality of the JRC base* determines how much load is applied.

- SRC cannot be egressed as JRC.
- JRC that has been SIF-loaded cannot be egressed.

---

## SRC Origination and Egression

**Senior Risk Capital (SRC)** is managed through the **weekly SRC Origination Auction**.

1. **Origination**
    - Stars and Halos bid to originate new SRC (becoming **OSRC**).
    - Once originated, the SRC is controlled by the Star or Halo until the next auction.
2. **Ingression**
    - SRC is only ingressed as Risk Capital if the Star has enough ingression capacity (per SIF limits).
    - Ingressed SRC = **inSRC**.
3. **Egression**
    - Unused OSRC can be egressed as **egSRC**.
    - Should be egressed promptly to avoid paying for idle capital.

| Entity | Allowed Actions |
| --- | --- |
| **Stars** | Originate, ingress, and egress SRC. |
| **Halos** | Originate SRC, but may only egress it (cannot ingress). |

---

## External–Senior Substitution Ingression (ESS Ingression)

**ESS Ingression** allows a Star to fill part or all of its SIF load using extra JRC instead of SRC.

This can be done:

- To reduce expected losses.
- When JRC is temporarily cheaper than SRC.

Rules:

- Available **only** to Stars.
- JRC used for ESS cannot be egressed later.
- There’s no difference between QEJRC and UEJRC

---

## Qualified Stars

A **Qualified Star** can egress **QEJRC** that receives favorable treatment when ingressed by other Stars.

**Qualification Criteria**

- Operates a fully transparent **Baseline Sentinel** adhering to governance and compliance standards.
- Demonstrates sound risk behavior through its Atlas reporting and artifact governance.
- Maintains reliable on-chain metrics (capital sufficiency, loss history, behavior scores).

**Privileges**

- Can egress **QEJRC** with lower EIF (0.5).
- Its egressed JRC also carries favorable SIF treatment when used to ingress SRC.
- Builds ecosystem-level trust and earns higher Ingression Rates.

---

## Qualified Halos

**Qualified Halos** are Halo Agents capable of modeling, sourcing, and egressing QEJRC across multiple Stars. They can gain the unique ability to ingress UEJRC and egress it as QEJRC at high efficiency by building up their *qualification level* through performance over time.

**Special Rules:**

- Must maintain capacity to model and egress JRC to *all major Stars*.
- Begin with **EIF = 1.0** (neutral efficiency).
- Over time, successful performance (low loss, above-average returns) increases their *qualification level*, reducing EIF progressively to **as low as 0.2**.
- The Halo Agent must deploy capital it owns at the Halo Agent level into Qualified Halo Units, where it acts as IJRC for ingression.
- If a Halo lacks sufficient IJRC to ingress all of the capital in the Halo Unit, it may deploy the un-ingressed capital as **UEJRC.** Any losses the Halo Units deployments incur on egressed risk capital (Whether it is the ingressed, or un-ingressed portion) takes pari passu losses on the Halos IJRC.

---