Annual State 
of Sky Ecosystem December 2025 | Inaugural Edition 
Published by
State of 

Sky Ecosystem 
2025 has been a year of deliberate transformation and  acceleration for Sky Ecosystem1, which powers USDS2, the  world’s largest decentralized yield-generating stablecoin and  third-largest stablecoin overall. 
Sky Ecosystem outpaced the global stablecoin market's 50%  expansion with a remarkable 86% surge in USDS supply,  from $5.3 billion to $9.86 billion, while delivering outstanding  risk-adjusted returns3 on savings USDS (sUSDS). 
During this period, Sky Protocol4 remained one of the  highest-earning protocols in decentralized �inance (DeFi) with  $435 million in annualized revenue and $168 million in  annualized protocol pro�its, while launching the SKY buyback  and staking rewards mechanism5 in February, which bought  back $92.2 million of SKY tokens thus far. Sky Ecosystem also  successfully completed the full rebrand and technical  migration from MakerDAO to Sky Ecosystem. 
Looking to 2026, we believe Sky Ecosystem is now positioned  for a true breakout year driven by institutional adoption. 
It's important to note that while Sky Ecosystem operates  within the broader crypto ecosystem, we have seen from  historical performance that the revenue generated and USDS  supply growth remain generally uncorrelated with broader  crypto price volatility. 
From our analysis, demand for proven yield-bearing  stablecoins rises in risk-off environments, while lending  opportunities expand in risk-on periods offering better yield,  giving Sky Ecosystem a resilient growth pro�ile across varying  market conditions. 
We believe Sky Ecosystem is only at the start of its growth trajectory. 
The overall stablecoin market has doubled in two years and is  set to accelerate further following the GENIUS Act’s passage  in July 2025 and supportive statements from political leaders  like United States Secretary of the Treasury Scott Bessent,  who forecasts a $3 trillion stablecoin market by 2030  (currently $309 billion). We believe that Sky Ecosystem is  uniquely positioned technically, �inancially, and from a  product perspective to capture and compound an outsized  share of this expansion for the long-term bene�it of Sky  Ecosystem and SKY token holders. 
The pages that follow highlight the key 2025 developments  and metrics that we believe will position Sky Ecosystem for  accelerated growth in 2026. Beginning in January, the Sky  Frontier Foundation will publish quarterly updates covering  ecosystem performance, �inancial metrics, and our  expectations of Sky Ecosystem. 

December 2025 | Inaugural Edition Published by Sky Frontier Foundation 

Who Is 
Sky Frontier Foundation? 
Sky Frontier Foundation (SFF or the Foundation) is an  independent foundation, founded in August 2025,  supporting the innovation, development and acceleration of  Sky Ecosystem – built to accelerate its growth and unlock  new frontiers in DeFi and digital �inance. SFF incubates some  of the new Sky Agents and funds breakthrough technologies;  Sky Agents are autonomous and independent systems within  the Sky Ecosystem that plug into the decentralized Sky  Protocol primitives such as lending, stablecoin generation, or  operational oversight.  
This report represents the Foundation’s analysis of the Sky  Ecosystem, based solely on publicly available data on or  before December 15, 2025. 
All views, opinions, and statements contained herein are  those of the Sky Frontier Foundation and do not represent the  Sky Ecosystem, its governance participants, or any a�iliated  parties. We are proud to contribute to the public discussion  of Sky Ecosystem and encourage other members of Sky  Ecosystem to share their own perspectives. Full disclaimers  and legal notices can be found at the end of this document. 

December 2025 | Inaugural Edition Published by Sky Frontier Foundation
State of Sky Ecosytem 
Sky Ecosystem 2025 Financials Milestones 2025 

USDS supply grew 
86% ($5.3B to $9.86B) Outpacing global stablecoin market’s 50% growth 
SKY BUYBACKS 
$92.2M USD Up 25,713% since Jan 1 
Completed the transition from MKR to SKY 
GENIUS ACT 
Signedinto law onJuly 18, 2025 

Annualized 
Protocol Revenue $435M 
Annualized 
Operational Expenses 61.5% 
Annualized 
Protocol Profits 24.4% 
New SKY Agents Launched 

December 2025 | Inaugural Edition Numbers as of December 15, 2025 Published by Sky Frontier Foundation
Understanding 

Sky Ecosystem 
Sky Ecosystem governs the decentralized Sky Protocol,  which allows users to mint USDS and generates revenue  primarily from the capital backing that stablecoin. 
The difference between what it earns (the "base rate") and what  
Metric 
Sky Ecosystem by the numbers 
As of Dec 15 
$9.86B 
Financials 
it pays to sUSDS holders (the "savings rate") is considered ”net  protocol revenue”. Protocol pro�its represent the net protocol  revenue after subtracting all operating expenses, such as  security, oracle, and governance-related costs. 
Revenue is generated through the Sky Protocol from a  diversi�ied set of sources, including use of the Protocol for  collateralized lending, digital asset-backed lending, U.S.  Treasuries, private credit and delta-neutral strategies.  Emerging opportunities such as use of the Protocol for  infrastructure and renewable energy �inancing are expected to  be included in 2026. 
USDS Supply 
Annualized Protocol Gross Revenue 
Annualized Protocol Net Revenue 
Annualized Protocol Pro�its 
Sky Buybacks 
$435M $211.6M 
$168M $92.2M 

It is worth noting that the aggregated  revenue and pro�its do not accrue to any  speci�ic Sky Ecosystem entity, but  constitute the revenue and pro�its of the  
Capital held in the Sky Ecosystem is allocated through the  Protocol in a decentralized, highly innovative and competitive  Sky Ecosystem Agent network, consisting of  
In 2025, stablecoin supply increased, while expenses decreased 

decentralized Protocol. 
Operational expenses declined signi�icantly  
governance-approved operators such as Spark, Grove and Keel. 
These Sky Agents compete to deliver the highest risk-adjusted  returns, while e�iciently sharing the economies of scale of the  entire Sky Ecosystem. A larger and higher-performing Agent  network could directly translate into stronger yields and  greater revenue per dollar of USDS issued. 
Metric 
End-of-Period  USDS Supply 
Annualized  
Jan 1, 2025 $5.3B 
Dec 15, 2025 $9.86B 
Jan 1, 2025 +86% 

in 2025 due to protocol upgrade  e�iciencies and the reallocation of certain  research and development costs to  external entities such as the Sky Frontier  
Expenses$113.4M $43.6M -61.5% Operational  
Annualized  

Foundation, which received endowment  capital from the Sky Ecosystem.
Operational  Pro�its 
$135M 
$168M 
+24.4% 

December 2025 | Inaugural Edition Published by Sky Frontier Foundation 

Growth Drivers in 2026 
The stablecoin industry has reached a clear in�lection point and is  poised for substantial growth in 2026 and beyond. This acceleration  is driven by maturing infrastructure, the regulatory clarity delivered  by the GENIUS Act’s passage in July 2025, and strong political  support, including United States Secretary of the Treasury Scott  Bessent’s public forecast that the stablecoin market could reach 
$3 trillion by 2030. 
We believe that Sky Ecosystem is uniquely positioned to capture an  outsized share of this expansion for several key reasons: 
I. Historically, holders of sUSDS consistently have received one of the  highest risk-adjusted yields of any major yield-bearing stablecoin.  
II. An eight-year proven track record has made USDS the largest  of any decentralized yield-bearing stablecoin and the  third-largest stablecoin overall.  
III. The Sky Protocol is strongly backed with $32 million in capital  reserves as of December 15 and generates annualized protocol  revenue of $435 million and annualized protocol pro�its of  $168 million.  
IV. Four Sky Agents were successfully launched in 2025, with  plans to introduce approximately four more in 2026, each  competitively incentivized to maximize risk-adjusted returns  and drive USDS issuance and protocol revenue.  
V. Sky Ecosystem’s revenue and USDS supply growth has  historically been fundamentally independent of crypto price  volatility and market conditions. 
These advantages, already demonstrated in 2025, provide the  foundation for the significant growth we anticipate for Sky  Ecosystem in the year ahead. 
Special note on the GENIUS Act, 
passed in July 2025: 
The GENIUS Act, signed into law on July 18,  2025, establishes a federal regulatory  framework for centralized payment  stablecoins—those issued by banks or  nonbanks for settlement and redemption at a  �ixed value, backed 1:1 by high-quality  reserves like U.S. dollars, Treasuries, or repos.  It emphasizes transparency through monthly  reserve disclosures, audited �inancials for  large issuers, and strict anti-money  laundering rules, while carving out compliant  stablecoins from securities laws. 
This legislation does not apply to Sky  Ecosystem's decentralized model or USDS,  which operates as a yield-bearing algorithmic  stablecoin focused on capital formation  rather than payments. Instead, the Act  directionally aligns with the veri�iable  collateralization, transparency, and user  safeguards that have characterized Sky  Ecosystem since its inception. We believe  Sky Ecosystem complements centralized  stablecoins by enabling decentralized  savings and yield generation. To be clear, U.S.  citizens and institutions may freely hold  USDS, sUSDS, stUSDS, and SKY, regardless of  the GENIUS Act. USDS is not a payment  stablecoin as de�ined under the Act.

December 2025 | Inaugural Edition Published by Sky Frontier Foundation 

SKY Token Economics & Governance Updates 
The Sky Protocol is community-governed through use of the SKY  token. Holders who stake SKY actively participate in securing and  directing the Protocol, and the system is designed so that the vast  majority of Protocol pro�its programmatically bene�it the stakers of  the SKY token. 
Specifically, staked SKY provides three core functions and  associated benefits: 
The ability to contribute to decentralized governance of all  Protocol parameters, risk controls, capital allocation, and  the multi-billion-dollar treasury.  
Under current Protocol parameters, as determined through  decentralized governance, approximately 75-100% of  Protocol pro�its are allocated to stakers of the SKY token  through programmatic, open-market buybacks that are  redistributed as additional yield to staked SKY.  
The ability to use governance-participating (staked) SKY as  collateral for borrowing USDS while continuing to earn  staking rewards, effectively lowering borrowing costs  without sacri�icing governance abilities or yield.
The following numbers show the extent of the SKY buyback and  staking rewards mechanism since its launch in late February 2025  up to December 15, 2025.  

December 2025 | Inaugural Edition Published by Sky Frontier Foundation 
Since launching in early 2025, the SKY Buyback program has  

SKY buybacks & staking rewards are  increasing signi cantly 
already repurchased over 6.3% of the total 23.46 billion token  supply, while current annualized buybacks of approximately  $102.2 million represent 7.63% of Sky's total market capitalization. 

Metric Jan 1, 2025 Total SKY 
Dec 15, 2025 
% Change 
In addition to the above buybacks, there were two  governance-approved decisions in the last 13 months which  

Buybacks in USD 
Total SKY 
$367,500 
$92.2M 
25,713% 
further support long-term SKY economics heading into 2026: 
I. Total SKY supply is now capped at 23.46 billion tokens  (approved November 2024).  

Buybacks 5.97M SKY 1.48B SKY 
24,690% 
II. Approximately 14% of the original MKR supply remains  unclaimed after the migration to SKY. Through the  established quarterly redemption-and-burn process, all  

Metric Dec 15, 2025 
SKY tokens backing unclaimed MKR will be burnt at the  rate of 2% per quarter over the next ~24 years. 

The SKY buyback and rewards mechanism  launched in February 2025, so no data  exists for January 1 and percentage  changes are not shown for the bottom  
Total SKY Distributed to SKY Stakers 
SKY Buybacks 
in USD Annualized SKY Distributed to SKY  
232.9M SKY $102.2M 
From our perspective, the combination of rapidly growing  staking rewards, a hard supply cap, and ongoing structural  de�lation creates attractive compounding economics for  participants who stake SKY and help govern the Protocol. 

columns in the table.
Stakers Annualized 2.03B SKY 

December 2025 | Inaugural Edition Published by Sky Frontier Foundation 

2026 Product Development & Capital 
Deployment Outlook 
From our analysis, the initiatives planned within the Sky Ecosystem  for 2026 are expected to strengthen the core competitive moat that  simultaneously delivers superior yields to sUSDS holders, higher net  revenue margins, and therefore substantially greater value to Sky  Ecosystem and SKY token holders. 
Based on public community proposals and other public  statements made by Sky Ecosystem members, we see three  focused initiatives that will drive this outcome: 
I. Agent Network Expansion: There are plans to introduce  approximately four more Sky Agents in 2026, each  competitively incentivized to maximize risk-adjusted  returns and drive USDS issuance and protocol revenue. In  addition, Grove is expected to launch its token in H1, with  additional high-conviction Sky Agents following in H2,  which we expect to expand lending capacity, optimize  risk-adjusted yields, and directly lift both USDS demand  and protocol revenue. 
II. Operational Leverage: The Foundation understands that  security and oracle costs are anticipated to decline from  21% to approximately 11% of net revenue as �ixed  expenses are absorbed across a much larger base,  translating directly into wider margins and higher  protocol pro�its. 
III. Resilient Base Rate: The Foundation estimates that gross  yields on deployed capital may remain in the 4.2–4.3%  range throughout 2026, which would preserve a 60–70  basis point spread over the consensus estimates of 3.7%  (H1 average) and 3.5% (H2 average) SOFR. 
We believe these advancements reinforce a simple but  powerful loop: 
Better yields attract more USDS supply, higher margins generate  more protocol pro�its, and the overwhelming majority of that is  programmatically allocated back to holders of the SKY token through  the SKY buyback and staking rewards mechanism.

December 2025 | Inaugural Edition Published by Sky Frontier Foundation 

State Of Sky Ecosystem 
2025 Summary 
Published by
Report Date: December 2025 
Next Report: January 2026 
 (Q4 2025 Earnings) 
Decentralized finance is maturing rapidly and bridging the  gap with traditional finance. Stablecoins now exceed $309  billion in supply globally and facilitate over $1 trillion in  monthly onchain transactions, while DeFi protocols  generated more than $10 billion in revenue in 2025. These  figures indicate that DeFi and stablecoins have reached an  inflection point of scale and utility. 
In our view, Sky Ecosystem has spent the past several years  methodically upgrading the Sky Protocol infrastructure,  product suite, branding, and token economics to prepare for  this moment. USDS has achieved clear product-market �it as  the largest decentralized stablecoin delivering the best  risk-adjusted yield. In a 2026 environment of expected lower  rates, sUSDS is positioned to maintain a 60–70 bps spread over  consensus SOFR (3.5–3.7%), which we believe will drive  meaningful USDS supply growth. 
As a result, Sky Protocol revenue and pro�its may well  accelerate, translating into signi�icantly larger distributions to  staked SKY holders in 2026 via the buyback and staking  rewards mechanism. We believe Sky Ecosystem remains poised  to lead the next wave of DeFi and stablecoin adoption  throughout 2026. 
To track progress, the Sky Frontier Foundation has committed  to publishing quarterly updates using public data and  information as well as providing our own expectations and  models throughout 2026 to keep the community and  institutional observers informed as this growth unfolds. 

December 2025 | Inaugural Edition Published by Sky Frontier Foundation 

Media & Analyst Inquiries 
For additional data, interviews, or clari�ication on any aspect of this report,  members of the press and research community are invited to contact the Sky  Frontier Foundation at: 
press@skyfrontier.co
About This Report 
This is the inaugural comprehensive ecosystem report for Sky Ecosystem,  published by the Sky Frontier Foundation. It represents one of the �irst times this  level of detailed �inancial and operational transparency has been produced about  a fully decentralized protocol, delivering a level of transparency and strategic  foresight to the community that sets Sky Ecosystem apart.  
With this report, we are establishing a regular cadence of transparency: annual  updates followed by quarterly protocol update reports beginning in January 2026.  The aim is to lead by example, elevate disclosure standards across decentralized  �inance, and provide the clarity that institutions and market participants expect as  the industry matures.  
We are proud to contribute to the public discussion of Sky Ecosystem and  encourage other members of Sky Ecosystem to share their own perspectives. 
Key Terms: 
1 Sky Ecosystem: This is the broader system built around the protocol. It  encompasses the global and decentralized community of users, developers,  stakers, Agents and governance participants who actively direct the protocol via  the SKY token (voting on parameters, risk controls, treasury allocation, etc.). It  includes decentralized governance, community forums, third-party tools,  integrations, and supporting entities. 
2 USDS: In this report, USDS is used as shorthand for the full family of Sky  stablecoins, encompassing DAI, USDS, and sUSDS. Savings USDS (sUSDS) is the  only stablecoin of the three that generates the yield mentioned within this report. 
3 Risk-adjusted returns: Sky Ecosystem uses risk management methods  adapted from traditional �inance, as approved by the governance based on the  input from specialized third-party teams and companies. A large portion of the  collateral is low risk assets such as tokenized T-bills, or stablecoins such as  USDC backed by t-bills, for all high quality crypto asset exposure, such as BTC  and ETH, the risk management framework enforces a high degree of  overcollateralization, and for tokenized assets such as JAAA, the risk  management framework enforces credit enhancement with junior risk capital.  For more information regarding the risk frameworks used by Sky and their  independent assessment, refer to the S&P Global analysis here. 
4 Sky Protocol: This is the core decentralized infrastructure, a set of smart  contracts and onchain mechanisms that power the issuance of USDS, manage  collateral, deploy capital through Agents (like Spark, Grove, and Keel), handle risk  parameters, and programmatically allocate pro�its (e.g., via buybacks and staking  rewards). It's the technical "engine" running on Ethereum among other blockchains. 
5SKY buyback and staking rewards mechanism: The SKY buyback and staking  rewards mechanism is a core feature of the Sky Protocol that programmatically  uses protocol pro�its to repurchase SKY tokens on the open market. Typically, at  least 75% of pro�its are allocated to buybacks unless needed to bolster capital  reserves, with such decisions made through decentralized governance in the Sky  Ecosystem. In 2025, the majority of repurchased tokens were sent to a  non-accessible address and effectively removed from circulation. Going forward,  the ecosystem plans to distribute 100% of buybacks as additional yield to SKY  stakers, though this remains subject to change via decentralized governance. 

December 2025 | Inaugural Edition Published by Sky Frontier Foundation 

Legal Notice 
The analyses, characterizations, and views expressed in this report, including on  legal, regulatory, technical, and economic matters, are those of the Sky Frontier  Foundation (“the Foundation”) as of the date of publication. They are  judgment-based, may change without notice, and do not constitute legal  opinions, regulatory determinations, or guarantees of outcome. They are not  intended to be, and should not be relied upon as, a substitute for independent  analysis or professional advice. Any reliance on this report is at the reader’s sole  risk, and the Foundation assumes no duty to update or correct it. 
This Annual State of Sky Ecosystem report has been prepared for general  informational purposes only. It does not constitute legal, �inancial, investment, tax,  or other advice. No part of this document is intended as, or should be construed  as, an offer, solicitation, or recommendation to buy or sell any token, security, or  other �inancial instrument, or to engage in any transaction or strategy, nor to form  the basis of any investment or other decision. The Foundation is an independent  entity and does not control the Sky Protocol or its DAO governance processes. The Foundation is an independently governed entity with its own board of  directors, incorporated under the laws of the Cayman Islands. It operates  alongside, and not within or on behalf of, the decentralized Sky ecosystem. The  Foundation does not delegate tokens for governance purposes, has not  participated in governance decisions, and has no authority to direct or bind  SkyDAO’s governance decisions. The Foundation does not act on behalf of any  tokenholders, and no statement in this report should be interpreted as a  commitment by the protocol’s community or governing bodies. The Foundation’s  board of directors owes �iduciary duties solely to the Foundation, not to any  tokenholders or other protocol participants. No �iduciary, advisory, or other  relationship is created between the Foundation and any reader of this report. 
Certain information contained in this report has been obtained from third-party  sources, including publicly available blockchain data, governance proposals,  community communications, and market data providers. The Foundation has not  independently veri�ied such information and makes no representation or warranty  as to its accuracy, completeness, timeliness, or reliability. Any errors in such  third-party data may affect the analyses and conclusions presented herein. 
The regulatory treatment of digital assets, decentralized protocols, stablecoins,  and related activities varies signi�icantly across jurisdictions and remains uncertain  and subject to rapid change. Future regulatory developments, legislative changes,  enforcement actions, or judicial decisions could materially and adversely affect the  Sky Ecosystem, USDS, SKY, and the matters discussed in this report in ways that  cannot be predicted. The discussion of the GENIUS Act and other regulatory  matters herein re�lects the Foundation’s interpretation as of the date of publication  and should not be relied upon as legal guidance. 
All information is provided “as is” without warranty of any kind. The Foundation  makes no guarantee as to the accuracy or completeness of the information and  disclaims any liability for any direct or indirect loss arising from use of, or reliance  on, this material. In no event shall the Foundation, its directors, o�icers,  employees, or agents be liable for any damages whatsoever, including without  limitation any direct, indirect, incidental, special, consequential, or punitive  damages, arising out of or in connection with this report.

December 2025 | Inaugural Edition Published by Sky Frontier Foundation 
Forward-Looking Statements 
This report contains forward-looking statements – for example, discussions of  future plans, operational planning assumptions, or anticipated outcomes of  DAO-governed protocol mechanisms – which re�lect current expectations and  assumptions about future events. These statements are inherently uncertain and  not guarantees of future performance. Actual results and events could differ  materially from those anticipated, due to various risks and factors outside the  Foundation’s control (including market volatility, regulatory changes, and decisions  made through decentralized governance).  
The Foundation does not participate in, and has no ability to control or guarantee  outcomes of decentralized governance processes that determine protocol  parameters, risk controls, capital allocation, or strategic direction. All projections,  estimates, and expectations regarding protocol performance assume governance  decisions and market conditions that are entirely outside the Foundation’s control  and that may not occur as anticipated or at all. The Foundation has no ability to  ensure that any planned development, Agent launch, or protocol upgrade will  occur on the anticipated timeline or at all. 
Any subjective anticipations regarding protocol development or ecosystem growth  are subject to independent decisions by protocol participants and governing  bodies over which the Foundation exercises no control. The various anticipated  metrics and estimates contained in this report are based on numerous assumptions  that may prove to be inaccurate. Actual performance or developments may vary  materially from the presented estimates due to the factors described above and  other unforeseen circumstances. 
Readers are cautioned not to place undue reliance on forward-looking statements.  The Foundation undertakes no obligation to update or revise any forward-looking  statements to re�lect subsequent events, new information, or changes in  circumstances. All forward-looking statements in this report speak only as of the  date of publication and should be evaluated in light of the uncertainties inherent in  decentralized, community-driven projects. No representation is made that any  forward-looking statement will be achieved or that the assumptions underlying  such statements are reasonable.
December 2025 | Inaugural Edition Published by Sky Frontier Foundation 
Annual State 
of Sky Ecosystem Published by
Report Date: December 2025 
Next Report: January 2026 
 (Q4 2025 Earnings) 
