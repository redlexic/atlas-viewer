# srUSDS

**srUSDS — Senior Risk USDS**

srUSDS is a higher-risk, higher-yield version of USDS designed for advanced DeFi users who want to supply **External Senior Risk Capital (ESRC)** to Stars in the Sky ecosystem.

Initially, Sky itself also originates ESRC from srUSDS depositors in order to strengthen the stability of the ecosystem and to bootstrap the tokens liquidity.

When users deposit USDS into the srUSDS contract, it becomes part of the **Senior Risk Capital pool**, which Stars can bid for and use as a capital buffer in their allocations through the **Allocation System Risk Framework**.

Each week, Stars compete in an **SRC Origination Process**, bidding on how much capital they want and the yield they will pay. The income from these bids (”SRC Income”) determines the srUSDS yield for the next week.

srUSDS holders earn these returns over time but also bear risk:

- srUSDS only loses value if Stars that use the capital experience catastrophic losses and are fully liquidated.
- Otherwise, it accrues yield continuously as SRC income flows back to the pool.

In short, **srUSDS tokenizes the “senior” layer of Sky’s risk capital**, allowing users to earn higher yields from supporting Star activity and bootstrapping Sky stability, while taking on the small but real risk of loss in extreme liquidation events.

## srUSDS technical flows

From USDS deposit to withdrawal.

### deposit sUSDS/USDS to srUSDS converter

The srUSDS Converter is a smart contract on Ethereum Mainnet that accepts sUSDS deposits, with an adapter also accepting and converting USDS deposits. The srUSDS Converter also handles withdrawals, as explained below.

1. User deposits sUSDS
2. The deposited sUSDS now sits in the Deposit Queue, with the user able to withdraw it out of the Deposit Queue at any time.
3. The sUSDS remains in the Deposit Queue until the next Settlement, at which point it converts to srUSDS.

### Depositing of sUSDS to srUSDS at Settlement

1. When the settlement happens, all sUSDS in the Inbound Queue is converted to srUSDS at the Last Conversion Rate.
2. The Origination Cost for the next week is then found through the Senior Risk Origination Auction by looking at the total demand for originating SRC vs the total amount of sUSDS in the Deposit Queue and the Withdrawal Queue - this is initially tightly managed by the Core Council rather than being a fully market driven process
3. The srUSDS Conversion Rate is then updated based on the computed price of the Origination Auction, and prepared as the Last Conversion Rate for the next Settlement a week later.
    1. The modification of the Last Conversion Rate is done via a BEAM

### If a loss happens while the user holds srUSDS

If a loss happens, the total loss is computed before the next Settlement. All SRC then receives a haircut proportional to the loss incurred and their share of the overall SRC. For srUSDS holders this is done through a modification of the Last Conversion Rate to take into account the haircut.

### Withdrawing srUSDS to sUSDS/USDS at Settlement

1. When a user wants to withdraw their srUSDS back as sUSDS/USDS they must first deposit their srUSDS into the Withdrawal Queue of the srUSDS Converter
2. At Settlement, all srUSDS in the Withdrawal Queue is converted to sUSDS at the Last Conversion Rate
    1. Control via the BEAM either last time the Settlement happened, or when a loss event happened
3. The former srUSDS holder can then extract their sUSDS out of the srUSDS Converter at any time after Settlement.
    1. The moment that Deposit and Withdrawal Queue are processed, at Settlement, is done via a BEAM.

# Short term use by Sky

Before Stars are able to use srUSDS to originate additional SRC, Sky itself will originate about 150m SRC through srUSDS. This is done simply by setting a target SRC Income in order to try to attract 150m in deposits. The 150m of “Sky Originated SRC” is not going to be available for origination by Stars, but once the amount of deposits have exceeded 150m, then Stars can also begin originating SRC. Initially it will be a very simple auction process where each Star plans in advance how much SRC it wants to originate at different price points, and then each week it is determined which Stars succeeded in originating, and at what price.