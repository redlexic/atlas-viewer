# Atlas A.1 - Governance Scope Summary

**Source:** A.1 - The Governance Scope.md
**Size:** 5,945 lines, ~71,300 words
**Purpose:** Rules regulating balance-of-power processes, adjudication, and governance interpretation

---

## Core Governance Philosophy

### Spirit of the Atlas & Universal Alignment

The governance framework is built on the **"Spirit of the Atlas"** - foundational principles enshrined in Immutable Documents that guide all governance actions. The system optimizes for **Universal Alignment**: harmony between the ecosystem and its environment while preventing **"slippery slope misalignment"** (incremental deviations from core principles).

Facilitators have broad discretionary authority to interpret the Atlas when explicit guidance is absent, with all interpretations documented as precedent.

### Document Hierarchy & Immutability

The Atlas employs a nested document tree structure:

1. **Immutable Documents** (3 layers): Scopes, Articles, and Sections
   - Currently modifiable during transition to Endgame
   - Will be permanently locked once Endgame State is reached

2. **Primary Documents**: Core documents, Active Data Controllers, and Budget Controllers
   - Operationalize the Spirit through practical rules

3. **Supporting Documents**: Active Data, Budgets, Element Annotations, Action Tenets, and Precedents
   - Provide context and real-time adaptability

4. **Accessory Documents**: Translations and Archives

---

## Governance Actors & Decision-Making

### Alignment Conservers (ACs)

Two specialized roles held to the highest standards of Universal Alignment:

**Aligned Delegates (ADs)**
- Control delegated voting power from SKY token holders through Delegate Contracts
- Cannot simultaneously hold multiple ecosystem roles (conflict prevention)
- Must maintain strict operational security and anonymity
- Ranked Delegates (top by delegated voting power) receive budget allocations
- Budget modified by voting-activity metrics and voting-communication metrics

**Facilitators**
- Interpret the Atlas and Artifacts on behalf of Executor Agents
- Every Operational and Core Executor must have a Facilitator
- Responsible for swift action against AC misalignment
- Authority to derecognize participants who breach requirements
- Subject to adjudication by Core GovOps if they fail to act on credible misalignment evidence

### Token Holders & Delegation

- SKY holders and Staking users delegate voting power to Aligned Delegates' Delegate Contracts
- Retain full token ownership while delegating voting rights
- Delegated voting power determines AD rankings and compensation
- Vote on:
  - **Governance Polls** (non-binding sentiment)
  - **Executive Votes** (binding protocol changes)

### Core Council Risk Advisor

- Specialized Professional Ecosystem Actor role (currently BA Labs)
- Provides financial analysis and risk management advice to Core Council
- Must maintain independence from conflicting business activities
- Limited Ethena waiver for BA Labs

---

## Governance Cycles & Decision Processes

### Weekly Governance Cycle

**Two Subtypes:**

**1. Operational Weekly Cycle**
- Begins Monday, 3-day Governance Polls
- Polls determine Executive Vote contents
- Requires Facilitator or recognized Ecosystem Actor proposal
- General rule: Governance Poll + Executive Vote
- Executive Votes occur approximately bi-weekly (30-day expiration)
- Housekeeping items can bypass polls with Forum justification

**2. Atlas Edit Weekly Cycle**
- For editing Atlas documents (Primary/Supporting types)
- Requires Ranked Delegate with sufficient AD Buffer to "trigger" proposal
- Triggering Threshold stake required (lost if proposal rejected)
- Governance Poll only (no Executive Vote)
- Protects against spurious proposals through economic stake

### Monthly Governance Cycle

Referenced for slower, deliberative decisions requiring longer timeframes than Weekly Cycle permits.

### Executive Process

End-to-end process for protocol changes:

**Roles:**
- **Governance Point**: Gathers content, prepares Executive Sheet, creates Executive Document, publishes to Voting Portal
- **Technical Point**: Spell Team (Sidestream/Dewiz roster) crafts and reviews smart contracts
- **Spell Crafter**: Primary technical contact, develops spell code
- **Spell Reviewer**: Reviews code quality and accuracy

**Artifacts:**
- **Executive Sheet**: Google Sheets tracking planned spell contents
- **Executive Document**: Human-readable proposal description
- **Spell**: Smart contract executing approved changes

**Execution Requirement:** Executive Votes require more SKY support than any other active proposal to execute.

---

## Capital Allocation & Budgets

### Budget Controller Documents

Primary documents managing ecosystem funding with two subdocument types:

**Active Data Documents**
- Contain variable state for reporting project status/results
- Modifiable outside standard governance cycles

**Budget Documents**
- Specify budget rates (SKY or USDS per time unit)
- Authorize executive votes or smart contracts to disburse payments from Sky Surplus Buffer

Budget Controllers define modification rules and processes. Budgets can be adjusted through processes specified by their Controller, enabling responsive capital allocation.

### Aligned Delegate Compensation

- Budget allocated to Ranked Delegates (Levels 1-3 based on delegated voting power)
- Funds accumulate in AD Buffers (cannot access until 1-month threshold)
- Monthly compensation cycle with payouts from Aligned Delegates Buffer Multisig
- Budget reductions for insufficient voting activity or communication
- Emergency communications requirement (Signal account maintenance)

---

## Risk Management & Accountability

### Misalignment Handling

Strict accountability for Alignment Conservers:

- **First mild breach**: Warning, no substantial penalty (learning opportunity)
- **Second breach or severe first breach**: Immediate derecognition
- Derecognition permanently removes individual from AC role
  - Enforcement challenging with pseudonymous actors
- Facilitators must act "swiftly" on credible misalignment evidence
- Failure to act promptly is itself misalignment

### Operational Security Requirements

ADs and Facilitators must maintain high operational security standards:
- Privacy, cybersecurity, physical resilience best practices
- Regular protocol reviews and updates
- Anonymity protection critical
- Breaches result in immediate derecognition
- Known identities barred from future AC participation

### Adjudication Process

- **Core Facilitator** adjudicates most AC misalignment allegations
- **Core GovOps** adjudicates allegations against Core Facilitator
- Community members and Facilitators can raise formal allegations
- Evidence-based decisions with documented precedents
- Reputation system planned for long-term trust accumulation

---

## Emergency Response System

### Emergency Situations

Defined as requiring immediate intervention to prevent:
- Emergency Shutdown initiation
- Severe peg divergence
- Harm to ecosystem members/users

Urgent situations include time-sensitive matters where standard governance cycles are too slow.

### Emergency Response Group (ERG)

**Composition:**
- Facilitators, Aligned Delegates, Ecosystem Actors with domain expertise
- Membership managed by Scope Facilitators
- Includes: Endgame Edge, JanSky, Phoenix Labs, Jetstream, Atlas Axis, Steakhouse, Blocktower, Core Council Risk Advisor, spell teams, and others
- Teams assign 2+ members (different timezones/jurisdictions for resilience)
- Members not publicly disclosed (security)

**Coordination:**
- Support Facilitators declare emergencies (broad discretion)
- Emergency Response Signal Group coordination via approved mechanisms (currently PagerDuty)
- Video calls for incident response
- Record retention for continuous improvement

### Emergency Procedures

**Known/Uncontentious Remedies:**
- Expedite Executive Vote

**Unknown Remedies:**
- ERG develops solution
- Governance Polls optional for emergencies

**Considerations Before Expediting:**
- SKY holders may miss votes due to non-standard timing
- Insufficient discussion time may yield sub-optimal solutions
- Increased governance burden on community/teams

---

## Executor Roles & Permissions

### Executor-Facilitator Relationship

- **Operational Executor Agents**: Must have Facilitator to interpret Atlas/Artifacts
- **Core Executor Agents**: Must have Facilitator to interpret Atlas/Artifacts
- Facilitators enter agreements to provide interpretation services
- Facilitators subject to same high operational security and accountability standards as ADs

### Professional Ecosystem Actors

Complete work for Sky Ecosystem per Atlas specifications:
- **Active/Incubating Ecosystem Actors**: Perform projects (development, data analysis, marketing, legal, operations)
- Only actor type permitted to do work not strictly bounded by Atlas
- Receive funding for specified projects benefiting ecosystem

---

## Key Governance Security Mechanisms

### Executive Process Controls

- **Chainlog**: Authoritative registry of protocol contracts
- **Ecosystem Spell Validation**: Verification that spell matches Executive Document
- **Spell Team Rotation**: Selected from Spell Roster (Sidestream/Dewiz)
- **Dual Review**: Separate crafter and reviewer roles
- **Fork Testing**: Mainnet fork created and reviewed pre-deployment
- **Voting Portal**: Canonical location for Executive Vote publication (vote.sky.money)

### Content Liaisons

Ecosystem Actors serving as points of contact for specific Executive Vote content areas, confirming technical accuracy of proposals.

---

## Frequently Recurring Terms & Concepts

- **Atlas Edit Proposal**: Proposal to modify Atlas documents via Weekly or Monthly Cycle
- **Delegate Contract**: Smart contract receiving delegated voting power for an Aligned Delegate
- **Triggering Threshold**: USDS amount Ranked Delegate must stake in AD Buffer to trigger Atlas Edit proposal
- **Executive Sheet**: Tracking spreadsheet for planned Executive Vote contents
- **Spell Process**: End-to-end development of smart contract spell
- **Universal Alignment**: Core objective of harmonizing ecosystem with environment
- **Slippery Slope Misalignment**: Incremental deviations leading to systemic divergence
- **Derecognition**: Permanent removal from Alignment Conserver role
- **Active Data**: Variable state modifiable outside standard governance cycles
- **Spirit of the Atlas**: Foundational principles guiding all governance interpretation

---

## Autonomous Operations Enablers

### Real-Time Adaptability

- Active Data documents modifiable by designated processes without governance votes
- Budget Controllers enable responsive capital allocation
- Facilitator broad discretionary authority for interpretation
- Emergency Response Group pre-authorized for crisis action
- Non-Standard Weekly Polls for urgent time-sensitive decisions

### Precedent-Based Evolution

- All Facilitator Actions documented as Facilitator Action Precedents
- Atlas Interpretations recorded with full context
- Action Tenets provide adjudication principles for recurring scenarios
- Scenarios (Aligned/Misaligned) demonstrate practical application
- Historical versions archived permanently for institutional memory

---

## Laniakea Relevance

### Governance Framework for Autonomous Systems

**Facilitator Discretion Model:**
- Laniakea Sentinels (stl-*) need similar interpretive authority within bounded contexts
- Document all interpretations as precedents (Synome transaction logs)
- Balance between rigid rules and adaptive response to unforeseen situations

**Emergency Response:**
- Core Council / stl-exec emergency powers parallel ERG
- Pre-authorized crisis response mechanisms
- Multi-jurisdiction resilience (geographically distributed Sentinel nodes)

**Risk Management:**
- Derecognition model applicable to rogue Sentinel operators
- Operational security requirements for GovOps actors
- Adjudication process for disputes (Core Council as arbiter)

### Budget Controller Pattern

**Active Data Documents:**
- Could track Laniakea operational state (SPTP capacity utilization, OSRC demand, etc.)
- Modifiable outside governance cycles for real-time updates
- Enables Sentinel auto-adjustments within guardrails

**Budget Controllers:**
- Prime Agent capital allocations via Budget Controller pattern
- Responsive allocation based on performance metrics
- Reduced governance overhead for routine adjustments

### Alignment & Precedent Systems

**Spirit of the Atlas:**
- Laniakea needs equivalent "Spirit of Laniakea" principles
- Guide Sentinel behavior when technical specs don't cover edge cases
- Prevent slippery slope misalignment in automated systems

**Precedent Documentation:**
- All Sentinel actions logged to Synome (like Facilitator Action Precedents)
- Build institutional knowledge over time
- Enable pattern recognition for anomaly detection

---

## Summary: Core Principles

This governance framework balances:
1. **Rigorous accountability** (derecognition, operational security)
2. **Operational flexibility** (broad Facilitator discretion, Active Data)
3. **Autonomous decision-making** (Budget Controllers, ERG pre-authorization)
4. **Clearly defined boundaries** (Spirit of Atlas, Universal Alignment)
5. **Multi-layered oversight** (ACs, Facilitators, Core GovOps)
6. **Economic incentives** (AD compensation tied to performance)
7. **Reputation-based trust** (precedents, adjudication history)

These principles enable autonomous operation within safety bounds while preserving alignment through distributed checks, economic incentives, and institutional memory.
