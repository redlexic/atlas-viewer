# A.3 Stability Scope Summary

**Source:** `/Users/runechristensen/code-agents/reference/A.3 - The Stability Scope.md`

This summary focuses on Sky's current risk management infrastructure as defined in the Atlas Stability Scope, with emphasis on components relevant to Laniakea development.

---

## 1. Risk Capital Framework

### 1.1 Required Risk Capital (RRC)

RRC is the capital Prime Agents must hold to protect Sky from potential losses on investments made through the Allocation System Primitive.

**Three Components of Instance Total RRC:**

| Component | Risk Covered | Calculation |
|-----------|--------------|-------------|
| **Financial RRC** | Market/credit risk on investments | Basel-inspired model: EAD x LGD x PD calculations |
| **Smart Contract RRC** | Bugs, exploits, bridge vulnerabilities | Smart Contract Risk Rating (SCRR) based on audits, lines of code, composition |
| **Administrative RRC** | Multisig abuse, privileged access exploitation | Administrative Risk Rating (ARR) based on control mechanisms |

**Capital Requirement Ratio (CRR):** RRC expressed as percentage of invested capital. If CRR = 5% and investment = 100M USDS, then RRC = 5M USDS.

**Aggregate RRC:** Sum of Instance Total RRC across all Active Instances deployed by a Prime.

### 1.2 Total Risk Capital (TRC)

TRC is capital that is **currently eligible, available, and verifiably under the Prime's control**. Must exceed Aggregate RRC at all times.

**Two-Tier Seniority Structure:**

```
                    ┌─────────────────────────────────────┐
                    │      Junior Risk Capital (JRC)      │
                    │   First to absorb losses (100%)     │
                    ├─────────────────────────────────────┤
                    │      Senior Risk Capital (SRC)      │
                    │   Only absorbs after JRC depleted   │
                    └─────────────────────────────────────┘
```

**Junior Risk Capital Types:**

| Type | Abbrev | Source | Notes |
|------|--------|--------|-------|
| Internal JRC | IJRC | Prime's own capital | Foundation of risk capacity; first-loss position |
| Prime-External JRC | SEJRC | Rented from other Primes | Via JRC Rental Primitive; capital stays with lender |
| Tokenized External JRC | TEJRC | External providers via smart contract | Depositors provide sUSDS; to be specified |

**JRC Loss Allocation Rules:**

1. **Tip JRC Mechanism:** First 10% of Total JRC (losses absorbed solely by Prime's IJRC)
2. **Post-Tip Allocation:** Losses exceeding Tip JRC allocated pro-rata across remaining IJRC + all EJRC
3. **Per-Event Basis:** Rules applied independently per distinct risk event

### 1.3 Encumbrance Ratio

**Definition:** Aggregate RRC / Total Risk Capital

**Target:** Maintain encumbrance ratio ≤ 90% (current interim requirement)

**Breach Severities:**

| Severity | Threshold | Implication |
|----------|-----------|-------------|
| Low | 100% ≤ ER < 103% | Escalating penalties over time |
| High | ER ≥ 103% | More severe penalties, faster escalation |

**Penalty Schedule (Low Severity):**
- 0-30 min: 500% APY on shortfall
- 30-60 min: 1,000% APY on shortfall
- 60+ min: 1,500% APY on shortfall

**Penalty Schedule (High Severity):**
- 0-15 min: 1,500% APY on shortfall
- 15-30 min: 2,000% APY on shortfall
- 30-60 min: 2,500% APY on shortfall
- 60+ min: 3,000% APY on shortfall

---

## 2. Allocation System Primitive (ASC)

The ASC is Sky's mechanism for Prime Agents to invest capital from Sky's Collateral Portfolio.

### 2.1 Capital Flow

```
Sky Core → Agent Credit Line → Allocation Vault → Allocation System Instances
                ↓
        Interest accrues on borrowed funds
        Must be paid down regularly
        Unpaid interest reduces available TRC
```

### 2.2 Key Constraints

1. Borrowed funds must be deposited into Agent's Allocation Vault
2. Funds cannot be transferred to SubProxy or other accounts
3. Interest payments must return Allocation Vault to principal-only balance
4. Investments limited to approved Instances (conduits)

### 2.3 Risk Capital Sourcing Ratios

**External Per Internal (EPI) Ratio = 1.00**
- Max EJRC = IJRC amount
- Example: 20M IJRC enables sourcing 20M EJRC

**Senior Per Junior (SPJ) Ratio**
- Defines how much SRC each type of JRC can "enable"
- SPJ capacity = sum of (JRC amount × JRC type's SPJ ratio)
- Unenabled OSRC does not count toward TRC

**Alternative SPJ Capacity Use:**
- Primes may use SPJ capacity to source additional EJRC instead of enabling SRC
- Such EJRC permanently has SPJ ratio of 0 (cannot enable any SRC)

---

## 3. Direct Allocation Buffer (DAB)

### 3.1 Purpose

The Demand Absorption Buffer stabilizes USDS during periods of excess supply by providing sell-side liquidity.

### 3.2 Requirements

| Requirement | Value |
|-------------|-------|
| DAB as % of required ASC | 25% |
| Maximum USDS price in DAB | 1.001 USD per USDS |

### 3.3 Qualifying Assets

- USDS or DAI in PSMs
- Autonomous systems that generate USDS dynamically through allocation

### 3.4 Related: Actively Stabilizing Collateral (ASC)

**Minimum Requirement:** 5% of Collateral Portfolio

**Resting ASC:** Provides buy support at ≥ 0.999 USD/USDS (10bps downside spread)
- USDC in LitePSM, PSM3 (Base, Arbitrum, Unichain, Optimism)
- Cash Stablecoins in Curve (paired with USDS)
- USDC in GUNI pools

**Latent ASC:** Convertible to Resting ASC within 15 minutes
- Cash Stablecoins in SparkLend, Aave, Morpho
- Max 25% of total ASC

### 3.5 Peg Defense Event

**Trigger:** Average USDS price on LayerZero-connected DEXes falls below 0.999 USD

**Obligation:** Buy USDS at rate of 6.25% of ASC requirement every 6 hours

**Methods:**
1. Selling other collateral for USDS
2. Using USDS as collateral to borrow assets (e.g., USDC on Aave) and buy USDS

---

## 4. Senior Risk Capital (srUSDS)

### 4.1 Overview

srUSDS is the tokenized form of External Senior Risk Capital (ESRC). Users deposit USDS to provide risk capital in exchange for higher yields.

### 4.2 Mechanics

**Deposit/Redemption Queues:**
- Users add USDS to deposit queue (converts to srUSDS)
- Users add srUSDS to redemption queue (converts back to USDS)
- Queue entries can be withdrawn before Monthly Settlement Cycle
- All queues processed at Monthly Settlement Cycle

### 4.3 Conversion Rate

Represents USDS redeemable per srUSDS unit. Updated monthly based on ESRC pool performance.

**Formula:**
```
New Rate = Previous Rate × (1 + Monthly srUSDS Yield)
```

**Monthly srUSDS Yield:**
```
[(Interest Paid on ESRC - Losses to ESRC) / ESRC Principal - Sky Spread] × (1 - ESRC Earnings Fee)
```

**Initial conversion rate:** 1:1 (srUSDS:USDS)

### 4.4 Revenue to Sky

| Source | Description |
|--------|-------------|
| **Sky Spread** | Difference between Prime borrow rate and (SSR + Distribution Reward Fee) |
| **ESRC Earnings Fee** | 5% fee on net interest earnings before distribution |

### 4.5 SRC Origination Process (Monthly Auction)

1. **Pool Determination:** TSRC = ISRC (from surplus buffers) + ESRC (from srUSDS)
2. **Bidding:** Primes bid via Powerhouse interface (quantity + max price in bps above Base Rate)
3. **Allocation:** Bids ranked by price; TSRC allocated to highest bids
4. **Clearing:** Lowest successful bid sets uniform clearing price for all winners
5. **Settlement:** Cost deducted from Prime's account; OSRC credited for upcoming month
6. **Duration:** OSRC valid for one month only; no automatic rollover

### 4.6 Haircut Mechanics

**Loss Absorption Order:**
1. Junior Risk Capital absorbs first 100% of losses
2. Only after JRC depleted does SRC begin absorbing losses
3. SRC then absorbs 100% of remaining losses

**Ultimate Backstop (SKY Backstop Event):**
- If SKY price = 0 during backstop event
- Pro-rata haircut across Genesis Agents' Genesis Capital
- Transfer of eligible assets to Surplus Buffer
- If deficit not fully cleared, USDS target price adjusted below $1
- 24B SKY distributed to compensate affected parties

---

## 5. Risk Management Patterns

### 5.1 Layered Loss Absorption

```
Loss Event
    ↓
┌─────────────────────────────┐
│    Tip JRC (10% of JRC)     │  ← Prime's IJRC absorbs first
├─────────────────────────────┤
│   Remaining JRC (pro-rata)  │  ← IJRC + EJRC share proportionally
├─────────────────────────────┤
│     Senior Risk Capital     │  ← Only after JRC = 0
├─────────────────────────────┤
│   Genesis Capital Haircut   │  ← Ultimate backstop
├─────────────────────────────┤
│   USDS Peg Adjustment       │  ← Last resort
└─────────────────────────────┘
```

### 5.2 Real-Time Monitoring & Enforcement

- Risk Capital calculations updated in real-time based on market variables
- Penalties calculated during Monthly Settlement Cycle
- Immediate capital requirement adjustment for market changes
- 7-day phase-in (50%) + 21-day phase-in (50%) for methodology changes

### 5.3 Skin-in-the-Game Requirements

- EPI ratio ensures Primes have minimum own capital before sourcing external
- SPJ ratio ensures adequate JRC backing for SRC enablement
- Tip JRC mechanism ensures Prime bears initial losses (incentive alignment)
- Encumbrance ratio target (≤90%) provides buffer above minimum requirements

### 5.4 Enforcement Escalation

1. **Financial Penalties** — APY-based on shortfall amount and duration
2. **Token Issuance** — Sky may require Prime to issue/sell tokens
3. **Investment Restrictions** — GovOps may limit exposure to Instances
4. **Conservatorship** — Sky Facilitators take direct control (expedited vote required)
5. **Executor Accord Termination** — For inadequate OEA supervision

### 5.5 Data Integrity

- Prime responsible for updating risk calculation inputs
- Operational GovOps verifies accuracy if not performing updates
- Late/missing data → exposure reduction
- Future: monetary penalties for late data submission

---

## 6. Laniakea Relevance

### 6.1 Direct Mappings

| Sky Current | Laniakea Equivalent | Notes |
|-------------|---------------------|-------|
| Allocation System Primitive | PAU (Parallelized Allocation Unit) | Same function, PAU adds rate limits |
| srUSDS | LCTS-managed External Risk Capital | Weekly (not monthly) settlement via LCTS |
| TEJRC | LCTS-managed TEJRC | Multi-generation model enables concurrent deposits |
| Monthly Settlement Cycle | Weekly Settlement Cycle | LCTS processes Tue noon lock, Wed noon settle |
| Prime Agent | Prime (in four-layer model) | Generator → Prime → Halo → RWA Endpoints |
| Core GovOps monitoring | Sentinel Network | stl-prime, stl-halo, stk-verify, stk-settle |

### 6.2 Evolution Points

**srUSDS → LCTS Multi-Generation Model:**
- Current: Monthly deposit/redemption queues with single processing window
- Laniakea: Multi-generation LCTS with concurrent active/locked/finalized generations
- Benefit: Deposits accepted during processing period; weekly vs monthly cycles

**Risk Capital Verification → Sentinel Automation:**
- Current: Core Council Risk Advisor performs Independent Calculation
- Laniakea: stk-verify provides continuous independent verification
- stk-settle calculates PnL, interest, penalties automatically

**Encumbrance Ratio Monitoring → Real-Time Sentinel Alerts:**
- Current: Reviewed during Monthly Settlement Cycle
- Laniakea: Sentinel monitoring with real-time breach detection

### 6.3 GRF Integration

**RRC Calculation → GRF Methodology:**
- Financial RRC maps to GRF's drawdown magnitude × forced realization probability
- SPTP (Stressed Pull-to-Par) provides liability matching framework
- Rate vs Credit Spread distinction critical for SPTP eligibility

**Key GRF Concepts for RRC:**

| GRF Concept | Application to RRC |
|-------------|-------------------|
| SPTP Buckets | Liability matching for capital treatment |
| Rate Hedging | Required for SPTP eligibility on fixed-rate assets |
| SPTP Reservation | Weekly auctions for capacity allocation |
| Drawdown × FRP | Unifies Financial, Smart Contract, Admin RRC logic |

### 6.4 Key Architectural Insights

1. **Seniority Tranching Works** — JRC/SRC structure provides clean loss absorption with aligned incentives
2. **Queue-Based Conversion Scales** — srUSDS queues are prototype for LCTS pattern
3. **Skin-in-the-Game Ratios** — EPI/SPJ ratios prevent excessive leverage; apply to Laniakea capacity allocation
4. **Real-Time + Periodic Settlement** — Current hybrid (real-time monitoring, monthly settlement) evolves to Laniakea's weekly settlement with continuous Sentinel monitoring
5. **Penalty Escalation Model** — Time-based severity escalation prevents gaming while allowing recovery time

### 6.5 Migration Considerations

**What Carries Over:**
- TRC/RRC concepts and seniority structure
- Loss allocation waterfall (Tip → JRC → SRC → Backstop)
- Encumbrance ratio mechanics
- ASC/DAB liquidity requirements

**What Evolves:**
- Monthly → Weekly settlement cadence
- Single queue → Multi-generation LCTS
- Manual verification → Sentinel automation
- Fragmented RRC models → Unified GRF methodology
- Implicit rate limits → Explicit PAU rate limits with SORL

---

## Summary

Sky's current Stability Scope establishes a sophisticated risk capital framework with:
- **Two-tier capital structure** (JRC/SRC) with clear loss absorption hierarchy
- **Quantitative capital requirements** (RRC) based on financial, smart contract, and administrative risk
- **Encumbrance ratio monitoring** with escalating penalties
- **Liquidity requirements** (ASC/DAB) for peg stability
- **Monthly settlement cycles** with queue-based conversion (srUSDS prototype)

Laniakea builds on these foundations by:
- Accelerating settlement cadence (weekly vs monthly)
- Automating verification (Sentinels replace manual calculation)
- Generalizing capital requirements (GRF unifies RRC methodologies)
- Adding rate limit infrastructure (PAU pattern with SORL)
- Enabling concurrent deposit processing (LCTS multi-generation model)

The core risk principles (seniority, skin-in-the-game, real-time monitoring, escalating enforcement) remain intact while operational efficiency and automation increase significantly.
