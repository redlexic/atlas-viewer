# A.2 Support Scope - Comprehensive Summary

## Overview

The Support Scope (A.2) governs all routine aspects of ecosystem support, including governance process infrastructure, Agent support, and Ecosystem Actor support. This document summarizes the key operational mechanisms that define how Sky operates today.

---

## 1. Sky Primitives

**Definition**: A Sky Primitive is a standardized interface that allows Agents to connect to, and leverage, Sky Protocol's permissioned infrastructure. Each Prime Agent strategy is unique, so each may combine Primitives differently.

### 1.1 Primitive Lifecycle

Primitives have two distinct status layers:
- **Global Activation Status**: Whether the Primitive is available for the Agent to use
- **Instance Status**: The operational state of a specific deployment (`Active`, `Suspended`, `Completed`)

**Key Lifecycle Stages:**
1. **Pre-Transformation Stage**: Founder has "Founder Access" to freely edit Scaffold Artifact and Activate Primitives
2. **Pre-Root Edit Stage**: Must Activate/Invoke Agent Token, Executor Accord, then Root Edit Primitives in order
3. **Post-Root Edit Stage**: Changes require token holder vote and Operational Executor Facilitator review

### 1.2 The Four Primitive Categories

#### A. Genesis Primitives
*Address initial Agent setup - one-time deployment*

| Primitive | Purpose | Status After Invocation |
|-----------|---------|------------------------|
| **Agent Creation** | Establishes Agent identity, name, and vision | `Completed` |
| **Prime/Executor Transformation** | Transforms Proto-Agent into Prime or Executor Agent | `Completed` |
| **Agent Token** | Creates governance token with distribution rules | `Active` |

**Key Process**: Founder deposits capital, pays creation fee, Core GovOps creates Scaffold Artifact with Genesis Account (controlled by Founder) and SubProxy Account (controlled by Sky Governance as Agent treasury).

**Prohibition**: Once Activated, Genesis Primitives cannot be deactivated.

#### B. Operational Primitives
*Enable Agent operation, governance, and AI features*

| Primitive | Purpose | Key Mechanism |
|-----------|---------|---------------|
| **Executor Accord** | Links Prime Agent to Operational Executor Agent | Defines operational relationship; cannot be deactivated |
| **Root Edit** | Enables token holder votes to modify Agent Artifact | Specifies voting process, quorum, approval thresholds |
| **Light Agent** | Creates sub-agents operating on parent's Executor Accord | Lower cost, no direct Sky Primitive access |

**Executor Accord Implications**:
- Once established, Operational GovOps takes over operational duties from Core GovOps
- Prime Agents operate autonomously according to their strategy with automated operational insurance from Executor Agents

**Root Edit Requirements**:
- Must specify: proposal format, eligible submitters, voting period, quorum, approval threshold, emergency procedures
- Until tokens are "Publicly Held" (2,000+ holders owning 10%+ of genesis supply), Root Edit is not operational - must use Atlas Edit Proposal process

#### C. Ecosystem Upkeep Primitives
*Ensure Agents contribute to long-term ecosystem sustainability*

| Primitive | Requirement | Calculation |
|-----------|-------------|-------------|
| **Distribution Requirement** | Buy and distribute 0.25% of token supply annually | 12 equal monthly distributions; value = tokens x 24hr TWAP |
| **Market Cap Fee** | Pay 0.30% of market cap annually to Sky | 12 equal monthly payments (0.025%/month) |
| **Upkeep Rebate** | Claim rebate when holding other Prime tokens | Rebate = (share of issuing agent's supply) x (issuing agent's upkeep fees) |

**Rules**:
- Agents must choose Distribution Requirement OR Market Cap Fee (can choose both)
- Cannot deactivate both - must always have at least one active
- Upkeep Rebate is Globally Activated by default in all Scaffold Artifacts and cannot be deactivated

#### D. Allocation System Primitive (Supply Side)
*The base mechanism for capital deployment*

**Core Function**: Enables Prime Agents to:
1. Put up Risk Capital
2. Deploy USDS collateral into yield opportunities
3. Borrow at the Base Rate from Sky
4. Follow Asset Liability Management (ALM) restrictions

**Instance Setup Process:**
1. Initial concept and feasibility discussions
2. Preliminary Risk Capital and ALM arrangement
3. Capital & Operational Plan preparation (including pro-forma RRC estimate)
4. Preliminary check with Operational GovOps
5. Codification in Powerhouse system
6. Off-chain snapshot vote
7. Official Artifact update

**Rate Limiter System:**
- `maxAmount`: Hard cap on allocation level
- `slope`: Linear refill rate over time
- Current rate limit formula: `min(slope * (block.timestamp - lastUpdated) + lastAmount, maxAmount)`

**Sky Direct Exposures**: Special category of exposures held by Sky but implemented through Prime Agent Allocation Systems:
- No Risk Capital requirements for Prime
- No ALM requirements for Prime
- All yield goes to Sky (not Prime)
- Current examples: Treasury Bills (BUIDL, JTRSY, USTB), CLOs (JAAA), PSMs, Curve Pools

---

## 2. Monthly Settlement Cycle (MSC)

**Definition**: A standardized, system-wide process executed at the end of each calendar month synchronizing core financial operations, governance functions, and risk management.

### 2.1 What Gets Settled

1. **Net Revenue Calculation**: Allocated through Treasury Management Function waterfall
2. **Senior Risk Capital Origination**: Clearing price established, costs deducted, OSRC credited
3. **srUSDS Conversions**: Queued deposits/redemptions processed
4. **Pioneer Incentive Pools**: Funded with SSR x Unrewarded USDS balance
5. **Smart Burn Operation**: Burn Rate calculated and executed
6. **GovOps Functions**: Payment processing, compliance monitoring, penalty application

### 2.2 Process Timeline

| Day | Actor | Action |
|-----|-------|--------|
| End of month | Core GovOps | Create Monthly Settlement Cycle Post on Sky Forum |
| +7 days | Operational Executor Agents | Submit Initial Calculation |
| +7 days | Core Council Risk Advisor | Submit Independent Calculation |
| +12 days | Core GovOps | Post Final Calculation (resolve any Disputed Amounts) |
| Next Executive Vote | Core Facilitator | Include payments in Sky Core Executive Vote |

### 2.3 Calculation Methodology

**Simplified Profit & Loss Calculation (Stage 1):**

```
Step 1: Total Allocation System Revenue = Sum of all Instance Revenue
Step 2: Total Allocation System Profit = Sum of Instance Profit
        where Instance Profit = max(Instance Revenue - Instance Expense, 0)
        Instance Expense = interest at Agent Credit Line Borrow Rate
Step 3: Adjusted Allocation System Profit = Total Profit - Distortion Penalty - Low Yield ASC Penalty
Step 4: Amount Due to Sky = Total Revenue - Adjusted Profit
```

**Key Penalties:**
- **Distortion Penalty**: Discretionary (0-100% of profit) if Prime's decisions were distorted by asymmetric P&L structure
- **Low Yield ASC Penalty**: Formulaic penalty = min(10 x Excess Low Yield ASC %, 100%)

### 2.4 Dispute Resolution

- **Agreed Amount**: Deviation between Initial and Independent Calculation <= 1%
- **Disputed Amount**: Deviation > 1% - requires Core GovOps resolution
- **Prime Agent Dispute**: Must post Dispute Notice within 5 days of calculation posting

### 2.5 Implementation Stages

| Stage | Description | Key Feature |
|-------|-------------|-------------|
| 1 | Simplified P&L Calculation | Executive Votes for all transfers |
| 2 | Virtual Base Rate | Interest calculated offchain, paid via Executive Votes |
| 3 | Onchain Base Rate | Interest accrues onchain to Allocator Vaults |

---

## 3. Treasury Management

**Purpose**: Defines how all Net Revenue of the Sky Protocol is distributed among downstream functions/buffers, ensuring all functions are adequately funded.

### 3.1 The Waterfall (Allocation Steps)

Each step must be fully funded before funds flow to the next:

```
Net Revenue (Step 0)
    |
    v
Step 1: Security & Stability Maintenance (10%)
    |-- Core Executor Budget: up to 5%
    |-- Core Executor Reward: up to 3% (for Executors whose terms ended in last 4 years)
    |-- Aligned Delegates: up to 1%
    |-- Governance Accessibility (Integrators): 0.5%
    |-- Governance Accessibility (Prime Agents): 0.5%
    |
    v (90% passes through)
Step 2: High Activity Staking Rewards (5%)
    |-- Funds HASR Buffer
    |-- Paid to Governance Accessibility Integrators
    |-- Distributed to qualified High Activity Stakers
    |
    v (95% passes through)
Step 3: Stability Capital Retention (variable %)
    |-- SCR = (1 - (SCB/TS)/TSCB) * RF
    |-- Target SCB = 0.75% + (TS * 1.4e-14), max 5%
    |-- Retention Factor = 25% + (TS * 1.6e-13), max 75%
    |
    v (remainder passes through)
Step 4: Smart Burn & Standard Activity Staking Rewards
    |-- Smart Burn Buffer: 80%
    |-- Standard Activity Staking Rewards Buffer: 20%
```

### 3.2 Income Sources

- Stability Fees from Base Rate
- Internal Senior Risk Capital Income
- External Senior Risk Capital Fees (5% of ESRC earnings)
- Agent Upkeep Fees
- Agent Creation Fees
- Sky Core Vault Income
- LitePSM Income

### 3.3 Expense Categories

- Sky Savings Rate (sUSDS holders)
- Sky Savings Rate via Integration Boost
- Distribution Rewards
- Reimbursement Rewards
- Pioneer Rewards

### 3.4 Smart Burn Engine

**Purpose**: Buys and burns SKY using intelligent algorithm - more when price is low, retaining capital when high.

**Burn Rate Formula**:
```
Burn Rate = (1 - MC / TMC) * 50%
```
where:
- MC = Current Market Capitalization
- TMC = 8.5 + (200 * growth_rate) * annual_profits
- growth_rate = 3-year moving average historical growth rate
- annual_profits = 1-year moving average of Net Revenue

---

## 4. Operational Patterns for Autonomous Systems

### 4.1 Agent Autonomy Framework

Prime Agents operate autonomously according to their Agent Artifact strategy with:
- **Operational Insurance**: Provided by Operational Executor Agents
- **GovOps Delegation**: Executor Agents delegate operational work to GovOps actors
- **Validation Handoff**: After Executor Accord, Operational GovOps takes over from Core GovOps

### 4.2 Process Triggers

Primitives use standardized triggers:
- **Time-Based Triggers**: Monthly cycles, settlement dates
- **Document Update Triggers**: Changes to specific documents
- **External Triggers**: Facilitator-initiated processes (not exclusive)

### 4.3 Instance Management

Agents can independently manage Primitive instances:
- Create new instances (with proper Invocation)
- Suspend instances (non-terminal)
- Complete instances (terminal)
- Update instance parameters

**Governance Options:**
- Root Edit Primitive vote
- Omni Document-configured process

### 4.4 Rate Limiting

All Allocation System operations use rate limiters:
- Inflow rate limits: Constrain allocation increases
- Outflow rate limits: Constrain withdrawals (often more permissive)
- Rate Limit IDs: Unique bytes32 keys per transaction type

### 4.5 Validation & Codification

All Primitive inputs go through Powerhouse interface:
- Canonical data gateway
- Enforces format consistency
- Tracks invocation and update steps

---

## 5. Workforce / Ecosystem Actor Rules

### 5.1 Types of Ecosystem Actors

| Type | Role | Examples |
|------|------|----------|
| **Governance Process Support** | Verify AEPs, prepare PRs, update statuses, prepare Polls | Designated by Core GovOps |
| **Integrators** | Offer access to Sky Protocol via frontends/infrastructure | Must be aligned with Sky's USDS adoption strategy |
| **Incubating Ecosystem Actors** | Being developed to support Sky/Agents | Assigned projects by Sky Governance |
| **Specialized Actors** | Specific operational roles | Guardian, Policyholder, Resilience Technical Committee |

### 5.2 Integrator Requirements

- Must be aligned with Sky's overall strategy for USDS adoption
- Must comply with all relevant legal and regulatory requirements
- Alignment determined by Operational GovOps (consulting Viridian Advisors in near-term)
- Sky Core may maintain or revoke Reward Codes at sole discretion

**Consequences of Non-Compliance:**
- Withhold, revoke, or demand repayment of Distribution Rewards
- Removal from Integrator Program
- Deactivation of Distribution Reward and Integration Boost Primitive instances

### 5.3 Communication Infrastructure

**Responsible Moderators:**
- Sky Forum: Core Facilitator
- Sky/Sky Builder Discord: Core Facilitator + TechOps Services
- Sky X/Twitter: Maker Growth
- MakerDAO Subreddit: Maker Growth

**Moderation Policies:**
- Err on side of charity - warn before banning (unless egregious)
- Bans permanent by default; unbanning requires Ranked Delegate proposal + Governance Poll
- AI/bots allowed for moderation with human review process
- Only Core Facilitator can ban users with ongoing governance proposals

### 5.4 Incubating Ecosystem Actor Template

Required documentation:
- Name and short description
- Budget information
- Deliverables and focus areas
- Team information (headcount by skill sets)

### 5.5 Dispute Resolution

**Process:**
1. Actor requests formal dispute resolution from Core GovOps
2. Core GovOps makes preliminary reasonableness determination (3 working days)
3. Core GovOps manages process, gathers information
4. Core Facilitator reviews information and delivers decision (isolated for impartiality)
5. Core GovOps communicates decision to parties

---

## Laniakea Relevance

### Autonomous Agent Operations

The Support Scope establishes the foundational patterns for autonomous agent operations that Laniakea will leverage:

1. **Primitive-Based Architecture**: Laniakea agents can model their capabilities as Primitives with:
   - Global Activation Status (capability availability)
   - Instance Status (deployment state)
   - Standardized process definitions
   - Input validation requirements

2. **Executor Accord Pattern**: The relationship between Prime Agents and Operational Executor Agents provides a template for:
   - Autonomous operation with operational insurance
   - Delegated validation and GovOps
   - Strategy execution within defined parameters

3. **Settlement Cycle Synchronization**: The MSC provides a heartbeat for:
   - Revenue calculations and allocations
   - Risk capital settlements
   - Penalty applications
   - System-wide state synchronization

### Sentinel Network Integration

The Support Scope's validation and verification patterns align with Sentinel Network requirements:

1. **Multi-Party Verification**: MSC uses Operational Executor Agent calculations vs Core Council Risk Advisor Independent Calculations with 1% deviation tolerance
2. **Dispute Resolution**: Structured process with clear roles (Core GovOps manages, Core Facilitator decides)
3. **True-Up Mechanism**: Corrections flow to subsequent cycles

### Treasury/Resource Management

The Treasury Management waterfall provides a model for:
- Prioritized resource allocation
- Buffer management (Stability Capital, Smart Burn, HASR)
- Dynamic retention formulas based on system state
- Automated burn mechanisms tied to market conditions

### Ecosystem Actor Framework

For workforce management in Laniakea:
- Tiered actor types with distinct roles and requirements
- Compliance monitoring and consequences
- Incubation pipeline with structured templates
- Communication infrastructure with clear governance

### Rate Limiting Patterns

The Allocation System's rate limiting infrastructure provides:
- Inflow/outflow constraints for security
- Time-based refill mechanisms
- Slippage protection for operations
- Per-operation unique identification

### Key Design Principles for Laniakea

1. **Layered Activation**: Global vs Instance status separation allows strategic capability management
2. **Progressive Decentralization**: Founder Access -> Token Holder Control transition pattern
3. **Standardized Interfaces**: Powerhouse as canonical data gateway
4. **Built-in Penalties**: Distortion and Low Yield penalties prevent gaming
5. **Self-Adjusting Parameters**: SCR, RF, and TMC formulas scale with system growth
