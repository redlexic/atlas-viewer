# Atlas A.0 - Preamble Summary

**Source:** A.0 - Atlas Preamble.md
**Size:** 329 lines, ~4,700 words
**Purpose:** Foundational definitions and principles for the Sky Atlas

---

## Key Philosophy: Alignment Engineering

The Atlas establishes **Alignment Engineering** as its core governance philosophy - designing organizational structures where self-interested actions align with Universal Alignment (harmony with human values and public good).

### Core Concepts

**Universal Alignment**
- Holistic understanding of how actions influence environment and create second-order effects
- Rooted in human morality, values, and natural world context
- A spectrum (actors are more or less aligned), not binary
- Cannot be measured deterministically - evolves through debate and changes over time

**Alignment Artifacts**
- Outputs of Alignment Engineering used to coordinate positive-sum outcomes
- Strength determined by minimum Universal Alignment required to take aligned actions
- Strong artifacts minimize "inner incentive" (effort to overcome misaligned first-order incentives)
- The Atlas itself is the foundational Alignment Artifact

**Misalignment Threats**
- **Slippery Slope Misalignment**: Incremental misaligned acts justified by small scale, good intentions, or "ends justify means"
- Any misalignment is serious - if not addressed, leads to disequilibrium or alignment failure
- In decentralized ecosystems: risk of governance attack or financial collapse

### Letter vs Spirit of the Rule

**Letter of the Rule:** Strict adherence to precise wording, potentially exploiting loopholes
**Spirit of the Rule:** Understanding true purpose and contributing to Universal Alignment

**Universal Alignment Assumption:** All rules have underlying intent to serve human values and promote public good within context.

Example: Corporation using unregulated pollutant that's technically legal but harms environment violates spirit while following letter. Universally aligned actor voluntarily avoids the loophole and works to close it.

---

## The Six Scopes

| Scope | Focus Area |
|-------|------------|
| **Governance** (GOV) | Balance of powers, Alignment Artifact interpretation, appeals processes |
| **Support** (SUP) | Ecosystem support, tools, activities, Sky Primitives |
| **Stability** (STA) | USDS Stablecoin, financial stability, surplus buffer, asset reserve |
| **Protocol** (PRO) | Technical development, maintenance, security |
| **Accessibility** (ACC) | Frontends, distribution efforts |
| **Agent** (AGT) | Agent Artifacts for all Agents (Primes, Executors) |

---

## Key Actors

### Alignment Conservers (ACs)
External entities facilitating and protecting Sky Governance, enabling SKY holders to make decisions benefiting long-term interests even with relatively little alignment.

**Aligned Delegates (ADs)**
- Anonymous ACs using Delegate Contracts to receive delegated SKY voting power
- Highly influential and potentially risky due to controlling large voting power
- Primary responsibility: uphold Spirit of the Atlas and maintain Universal Alignment
- Subject to strict requirements enforced by Governance Scope

**Facilitators**
- Anonymous ACs with responsibility over specific Scopes
- Can directly access governance processes and smart contracts
- Interpret Atlas and Artifacts on behalf of Executor Agents
- Every Operational and Core Executor must have a Facilitator

### Agents
First-class economic citizens autonomously pursuing business opportunities.

**Agent Types:**
1. **Proto-Agent**: Initial state, no specialized role
2. **Prime Agent**: Transform via Transformation Primitive to gain functionality
   - Maintain/automate Sky features in new markets
   - Innovate custom products
   - Only Agent type with access to all Sky Primitives
   - Cannot directly operationalize protocol-level elements (must use Operational Executors)
3. **Executor Agent**: Specialized Agents implementing Prime strategies that interface with Sky Protocol
   - **Operational Executor Agents**: Handle day-to-day execution of Prime strategies, provide collateralized insurance
   - **Core Executor Agents**: Oversee Operational Executors, ensure alignment with Atlas

**Prime-Executor Relationship:**
- Primes encode initiatives in their Agent Artifact
- Operational Executors use Artifact as operational blueprint
- Ensures separation between strategy (Primes) and operations (Executors)
- Primes cannot be active without an "Operational Executor Accord"

### Core Council
Group of Executors responsible for Sky Core operationalization:
- Monitor Operational Executor compliance
- Enforce Sky Core Atlas
- Oversee Sky Core governance processes
- Evolve Risk Framework
- Monitor Alignment Conservers
- Address governance disputes

Begins with single seat (Core Council Executor Agent 1), expands to up to 7 members long-term.

### GovOps (Governance Operations)
Specialized Ecosystem Actors within Executor Agent entities:
- Manage technical implementation of Prime Agents' Instances of Sky Primitives
- Execute on-chain/off-chain tasks for operational/governance processes
- Work with Executor Facilitators (who interpret Atlas/Artifact)

**Types:**
- **Operational Executor GovOps**: Implement Prime Agent strategies per Primitive Configuration Documents
- **Core Council GovOps**: Operate within Core Executor Agents

---

## Sky Primitives

Core building blocks of Sky ecosystem - primary interface between Agents and Atlas.

**Purpose:**
- Standardized tools and interfaces
- Empower Prime Agents to create, innovate, evolve Sky Protocol in decentralized manner
- Used by Executor Agents as intermediary layer between Primes and Sky Protocol

---

## Key Infrastructure

### The Atlas Document Structure
**Immutable Documents:** Enshrine Spirit of the Atlas, become permanently immutable at Endgame State
**Adaptive Documents:** Operationalize Spirit practically, continuously improved through governance
**Supporting Documents:** Provide expanded definitions, hypothetical fact-patterns, practical applications

**Endgame State:** Final technical and alignment engineering state where all aspects that can be immutable have been made immutable, creating highly resilient Governance Equilibrium.

### Sky Ecosystem Tokens

**USDS:** Stablecoin (1:1 with DAI)
**sUSDS:** Savings token earning Sky Savings Rate
**SKY:** Governance token
**stUSDS:** Risk capital token for SKY Staking leverage, ensures SKY-backed borrowing funded by segregated risk capital

**SKY Staking:**
- Users stake SKY to receive Staking Rewards
- Freely unstakeable at any time
- Allows borrowing USDS against SKY at SKY Borrow Rate

### Skylink
Multichain solution connecting USDS, SKY, and other tokens from Ethereum to other chains/L2s:
- Native USDS
- Native Sky Savings Rate
- Native Token Rewards
- Native 1:1 USDC ↔ USDS conversion

---

## Governance Mechanisms

**Voting Power:** Ability of Aligned Delegates to vote on behalf of SKY holders
**Delegate Contracts:** Smart contracts through which SKY holders delegate voting power while retaining token ownership

**Decision Types:**
- **Governance Polls**: Sentiment gathering, non-binding
- **Executive Votes**: Binding protocol changes

### Facilitator Discretionary Powers

**Broad Discretionary Capacity:**
- Where Atlas lacks clear guidance: Facilitators infer Spirit to maximize Universal Alignment
- Can supersede existing Atlas provisions when unsuitable for current challenges
- Discretion is temporary (during Atlas evolution period)

**Bootstrapping Governance Polls:**
- Core Facilitator can run polls to enable SKY holder votes on Atlas changes
- Can formalize actions taken under discretionary capacity (encouraged but not required)
- Feasibility determination is itself at Facilitator discretion

**Precedence:** Facilitator discretionary capacity takes precedence over conflicting Atlas provisions.

---

## Communication Channels

Critical consideration with significant impact on incentivized alignment. The Atlas regulates Communication Channels to ensure alignment preservation across ecosystem coordination.

---

## Definitions Summary

Key terms defined in Preamble (inherited context for all Atlas documents):

- **Organizational Alignment**: Implementing strategies ensuring all members share common goal/vision
- **Ecosystem Intelligence**: Decentralized ecosystem acting with collective intelligence based on alignment of parts
- **Aligned Structure**: Network actively employing Alignment Engineering
- **Explicit Incentives**: First-order incentives coded into Alignment Artifacts
- **Implicit Incentives**: Motivations inferred from "letter of the rules" and enforcement likelihood
- **Incentive Slack**: Discrepancy between explicit and implicit incentives, creates misalignment risk
- **Incentivized Alignment**: Myopic following of letter of rule without Inner Incentive
- **Inner Incentive**: Second-order incentive used to counteract misaligned first-order incentives
- **Governance Equilibrium**: State where governance remains decentralized with high confidence via redundant feedback loops
- **Whole Weeks**: Time calculation method for quarterly/yearly cycles (first week where all days from Monday fall within quarter)
- **Target Document**: Immutable/Primary Document to which Supporting Document is attached
- **Unrewarded USDS**: USDS not receiving SSR, Integration Boost, or USDS Token Rewards
- **Sky Forum**: Platform for governance proposals, debate, alignment (https://forum.sky.money/)

---

## Laniakea Relevance

**Alignment Engineering Principles:**
- Laniakea must design systems where self-interested Prime/Halo actions align with protocol stability
- Risk frameworks should minimize "inner incentive" required to act responsibly
- Slippery slope misalignment prevention through strong invariants and automated enforcement

**Agent-Executor Pattern:**
- Maps to Prime-Halo relationship: Primes strategize, Halos execute RWA operations
- Separation of concerns: business logic (Prime Artifacts) vs operational execution (Halo operational procedures)
- Operational Executor insurance model relevant to Halo risk capital requirements

**GovOps Implementation:**
- Sentinel systems (stl-* Sentinels) are autonomous GovOps actors
- Interpret Artifacts (pBEAM configurations) and execute within bounds (cBEAM guardrails)
- Core Council oversight maps to stl-exec with CC seat having Synome override permissions

**Facilitator Discretion:**
- Early-stage Laniakea systems may need similar broad interpretation capacity
- Balance between rigid rules and adaptive response to unforeseen situations
- Document precedents for institutional knowledge accumulation (like Synome transaction logs)

**Sky Primitives as Interface Layer:**
- Laniakea Primitives (PAU, LCTS, SPTP, OSRC) are Sky Primitives for capital deployment
- Standardized interfaces enabling Prime innovation while maintaining protocol safety
- Executor Agents (via stl-unit, stl-erc Sentinels) operationalize Prime strategies using these Primitives
