# Atlas Summaries

Extracted summaries from the Sky Atlas documents (A.0 through A.6), focusing on:
- Current operational patterns relevant to Laniakea
- Key governance and risk mechanisms
- Synome-eligible content (machine-readable data)

## Files

| File | Source | Focus |
|------|--------|-------|
| `A0-preamble-summary.md` | A.0 - Atlas Preamble | Philosophy, definitions, actor types |
| `A1-governance-summary.md` | A.1 - Governance Scope | Decision processes, emergency response, accountability |
| `A2-support-summary.md` | A.2 - Support Scope | Sky Primitives, Monthly Settlement Cycle, Treasury waterfall |
| `A3-stability-summary.md` | A.3 - Stability Scope | Risk Capital Framework (RRC/TRC/JRC/SRC), Encumbrance, srUSDS |
| `A4-protocol-summary.md` | A.4 - Protocol Scope | BEAM pattern, stUSDS, deflationary tokenomics |
| `A5-accessibility-summary.md` | A.5 - Accessibility Scope | Geographic filtering, compliance philosophy |
| `A6-agent-summary.md` | A.6 - Agent Scope | Prime structure, Spark/SLL, Agent Artifacts |

## Key Insights for Atlas/Synome Split (Pillar 8)

### What Stays in Atlas (Human Layer)
- Spirit of the Atlas / Universal Alignment (A.0)
- Governance structure and decision processes (A.1)
- Sky Primitive definitions and lifecycle (A.2)
- Risk Capital Framework principles (A.3)
- Token architecture and BEAM pattern (A.4)
- Compliance philosophy (A.5)
- Agent type definitions (A.6 intro)

### What Moves to Synome (Machine Layer)
- Agent Artifacts with addresses, rate limits, ICDs (A.6.1-A.6.5)
- Active Data Documents (A.1)
- BEAM parameter tables (A.4)
- Penalty schedules and formulas (A.3)
- Instance Configuration Documents
- Transaction logs and precedents

### Direct Mappings to Laniakea Concepts

| Atlas Concept | Laniakea Equivalent |
|---------------|---------------------|
| Monthly Settlement Cycle | Weekly Settlement Cycle |
| srUSDS queues | LCTS multi-generation model |
| BEAM (min/max/step/tau) | pBEAM/cBEAM/aBEAM hierarchy |
| Core Council Risk Advisor | stl-verify Sentinel |
| Operational GovOps | stl-* Sentinels |
| Facilitator discretion | Sentinel bounded autonomy |
| Active Data | Synome state nodes |
| Precedents | Synome transaction logs |

## Reading Order

1. **A0** - Foundational philosophy and definitions
2. **A1** - Governance structure
3. **A2** - Operational mechanisms (Primitives, Settlement)
4. **A3** - Risk framework
5. **A4** - Technical patterns (BEAM, stUSDS)
6. **A6** - Agent implementation (Spark as prototype)
7. **A5** - Compliance (shortest, least relevant to core Laniakea)

## Source Documents

Original Atlas documents in `/reference/`:
- `A.0 - Atlas Preamble.md` (329 lines)
- `A.1 - The Governance Scope.md` (5,945 lines)
- `A.2 - The Support Scope.md` (6,087 lines)
- `A.3 - The Stability Scope.md` (3,769 lines)
- `A.4 - The Protocol Scope.md` (908 lines)
- `A.5 - The Accessibility Scope.md` (143 lines)
- `A.6 - The Agent Scope.md` (26,838 lines)

**Total:** 44,019 lines, ~364,000 words

## Extraction Method

Summaries created via parallel Sonnet agents on 2025-12-27, each focused on:
- Current Sky practices (not outdated legacy)
- Information useful for whitepaper overview
- Concepts relevant to Sky's evolution toward post-Laniakea state
