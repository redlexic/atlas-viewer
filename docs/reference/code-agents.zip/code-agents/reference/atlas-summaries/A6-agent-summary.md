# Agent Scope Summary (A.6)

## Overview

The Agent Scope (A.6) regulates all Agents within the Sky Ecosystem and comprises all Agent Artifacts. Each Agent Artifact governs the operations of a particular Agent, containing all rules, processes, parameters, and information defining strategic vision and day-to-day operational logic.

---

## 1. Prime Agent Structure

### What Makes a Prime Agent
Prime Agents are the highest tier of Agents in the Sky Ecosystem. Key characteristics:

- **Genesis Supply**: Each Prime has 10 billion tokens at genesis
- **Token Emissions**: Permanently disabled post-genesis (cannot be reverted by Agent governance; Sky Governance retains override for Risk Capital violations)
- **Prime Transformation Primitive**: One-time transformation elevating an Agent to Prime status
- **SubProxy Account**: On-chain treasury controlled by the Agent
- **Foundation Structure**: Each Prime has an associated Foundation (e.g., Spark Foundation, Grove Foundation)
- **Nested Contributors**: Core contributors that serve both the Agent and Sky (e.g., Phoenix Labs for Spark)

### Current Prime Agents
1. **Spark** - DeFi lending/liquidity (SparkLend, SLL, Spark Savings)
2. **Grove** - Institutional credit platform, RWA allocations, CLOs
3. **Keel** - Solana ecosystem expansion, USDS adoption
4. **Launch Agent 3** - Distribution rewards, integration boosts
5. **Obex** - Agent incubator for Prime and Halo development

### Prime Governance Model
- **Root Edit Primitive**: Primary mechanism for updating Agent Artifacts
- **Token Holder Voting**: Requires 1% token holding to submit proposals (Nested Contributors exempt)
- **Operational Facilitator Review**: 7-day alignment review period
- **Snapshot Voting**: 3-day polls, 10% quorum, >50% approval required
- **Artifact Edit Restrictions**: Cannot violate Sky Core Atlas or Primitives

### Key Governance Addresses (Examples)
| Agent | SubProxy Account |
|-------|-----------------|
| Spark | `0x3300f198988e4C9C63F75dF86De36421f06af8c4` |
| Grove | `0x1369f7b2b38c76B6478c0f0E66D94923421891Ba` |
| Keel  | `0x355CD90Ecb1b409Fdf8b64c4473C3B858dA2c310` |
| Obex  | `0x8be042581f581E3620e29F213EA8b94afA1C8071` |

---

## 2. Spark Prime - Deep Dive

### Strategic Focus
Spark builds on USDS in the Ethereum and adjacent DeFi ecosystem through three products:
1. **Spark Liquidity Layer (SLL)** - Cross-chain USDS/sUSDS/USDC liquidity
2. **SparkLend** - Lending market with direct Sky liquidity
3. **Spark Savings** - Best risk-adjusted stablecoin yields at scale

### Spark Liquidity Layer (SLL)

#### Architecture
The SLL is the prototype for all Prime Agents' Allocation Systems. Key components:

**Core Contracts (per chain):**
- ALM Proxy - Main custody/execution contract
- Controller (MainnetController/ForeignController) - Action orchestration
- Rate Limits - Caps on operations

**Deployed Chains:**
- Ethereum Mainnet
- Base
- Arbitrum
- Unichain
- Optimism
- Avalanche

#### Operational Roles

| Role | Description |
|------|-------------|
| `DEFAULT_ADMIN_ROLE` | Controls upgrades, role management, mint recipient setting |
| `RELAYER_ROLE` | Off-chain ALM Planner system executing operations |
| `FREEZER_ROLE` | Emergency freeze capability |
| `ALM_CONTROLLER_ROLE` | Controller contracts, RateLimit updates |

**Core Operator Relayer Multisig**: `0x8Cc0Cb0cfB6B7e548cfd395B833c05C346534795`
- 2/5 signing requirement
- Jointly controlled by Amatsu and Spark Assets Foundation

#### Rate Limits System
Rate limits control maximum operational velocity across the SLL:

**Mainnet Rate Limit Types:**
- `LIMIT_USDS_MINT` - Maximum USDS mintable
- `LIMIT_USDS_BURN` - Maximum USDS burnable
- `LIMIT_USDS_TO_USDC` - PSM swap limits
- `LIMIT_USDC_TO_CCTP` - Cross-chain transfer caps
- `LIMIT_USDC_TO_DOMAIN` - Per-destination bridging limits

**Rate Limit Functions:**
```solidity
// Query current limit
getCurrentRateLimit(bytes32 key) returns (uint256)

// Set rate limit (maxAmount, slope controls refill rate)
setRateLimitData(bytes32 key, uint256 maxAmount, uint256 slope)

// Trigger consumption
triggerRateLimitDecrease(bytes32 key, uint256 amountToDecrease)
triggerRateLimitIncrease(bytes32 key, uint256 amountToIncrease)
```

#### SLL Operational Processes

**USDS Minting Flow:**
1. Relayer verifies `isActive` status
2. Check RateLimits allow required amount
3. Call `MainnetController` to mint from Sky Allocation Vault
4. Transfer USDS from Buffer to ALM Proxy

**Cross-Chain Bridging (CCTP):**
1. Check RateLimits for destination domain
2. Verify mint recipient configured for destination
3. Approve CCTP to spend USDC
4. Initiate transfer (split if exceeds per-message limit)

**Protocol Deposits (ERC4626/Aave):**
1. Verify `isActive` and sufficient balance
2. Check instance-specific RateLimits
3. Approve vault/pool to spend assets
4. Execute deposit, receive yield-bearing shares/aTokens

### Morpho Integration
Spark deploys to Morpho vaults across chains:

**Ethereum Mainnet Instances:**
- Morpho DAI Instance
- Morpho USDS Instance
- Morpho USDC Instance

**Base Instances:**
- Morpho Blue USDC ERC4626 Vault

**Grove also uses Morpho:**
- Grove x Steakhouse High Yield Vault (USDC, AUSD on Ethereum)
- Grove x Steakhouse High Yield Vault (USDC on Base)

### Spark Savings Configuration
Each Spark Savings vault has:
- **Default Admin Role**: Upgrade control (Spark governance)
- **Setter Role**: Yield rate control within bounds
- **Taker Role**: Withdrawals to SLL ALM Proxy
- **Min/Max Yield**: Bounds on rates setter can implement
- **Supply Cap**: Maximum deposits

**Current Configurations:**
| Vault | Max Yield | Supply Cap |
|-------|-----------|------------|
| USDC (Ethereum) | 10% | 250M |
| USDT (Ethereum) | 10% | 250M |
| ETH (Ethereum) | 5% | 50,000 |
| USDC (Avalanche) | 10% | 150M |

### Encumbrance Ratio Management
- **Target**: 90% (Required Risk Capital / Total Risk Capital)
- **Actions if exceeded**: Increase TRC or reduce RRC through allocation adjustments
- **Inherits from Sky Core**: Base TRC management requirements

---

## 3. Halo Structure

### Halo vs Prime
While the document focuses primarily on Prime Agents, the Halo tier is referenced in context of:

- **Obex's Mission**: Incubator for deploying both Prime and Halo Agents
- **Light Agent Primitive**: Used by Primes like Grove to create lighter-weight entities
- **Ecosystem Scaling**: Halos provide pathway for new agent founders without full Prime infrastructure

### Obex as Halo Factory
Obex provides:
- Streamlined pathways for Agent establishment
- Turnkey services: legal, risk, tech, operational requirements
- Cohort-based Agent founder support
- Rich content and workstreams for development

---

## 4. Agent Artifacts - Structure

### Standard Artifact Components

Each Prime Agent Artifact follows consistent structure:

```
Agent Artifact
├── Introduction (strategic overview)
├── Sky Primitives
│   ├── Genesis Primitives
│   │   ├── Agent Creation Primitive (one-time)
│   │   ├── Prime Transformation Primitive (one-time)
│   │   ├── Executor Transformation Primitive
│   │   └── Agent Token Primitive
│   ├── Operational Primitives
│   │   ├── Executor Accord Primitive
│   │   ├── Root Edit Primitive
│   │   └── [Additional primitives as needed]
│   └── Rewards Primitives
│       ├── Distribution Reward Primitive
│       ├── Integration Boost Primitive
│       └── Core Governance Reward Primitive
└── Omni Documents
    ├── Governance Information
    ├── Strategic Intent
    ├── Ecosystem Accords
    └── Infrastructure Management
```

### Primitive Instance Structure
Each primitive follows consistent instance pattern:

```
Primitive
├── Primitive Hub Document
│   ├── Global Activation Status (Active/Completed/Inactive)
│   ├── Active Instances Directory
│   ├── Completed Instances Directory
│   ├── In Progress Invocations Directory
│   └── Hub Data Repository (Archived/Failed/Suspended)
├── Active Instances
│   └── Instance Configuration Document
│       ├── Parameters (customized per instance)
│       ├── Operational Process Definition
│       └── Data Repository
├── Completed Instances
└── In Progress Invocations
```

### Instance Configuration Document (ICD)
Each allocation/protocol integration has an ICD containing:
- Protocol name and type
- Contract addresses (pool, token, vault)
- Asset addresses (underlying, yield-bearing)
- Rate Limit IDs and values (inflow/outflow)
- Instance-specific operational procedures

---

## 5. Operational Patterns for Autonomous Agent Operation

### Key Automation Components

#### 1. ALM Planner (Off-chain)
- Automated relayer system
- Controls routine SLL operations
- Maintains Spark Savings liquidity per Target Liquidity configs
- Falls back to Core Operator Multisig if fails

#### 2. Rate Limit Enforcement
Rate limits are enforced on-chain, providing autonomous bounds:
- Prevent excessive minting/burning
- Cap cross-chain transfers
- Limit protocol deposits per instance
- Refill automatically based on `slope` parameter

#### 3. Target Liquidity Automation
Spark Savings vaults maintain:
- 10% of deposits OR fixed minimum (e.g., 1M USDC)
- Automated via ALM Planner software
- Taker role withdraws to/from SLL ALM Proxy as needed

#### 4. Rewards Rate Maintenance
- Setter role updates rates to match configuration
- USDC/USDT vaults: track Sky Savings Rate
- ETH vault: 90% of SparkLend ETH supply rate

### Emergency Procedures

#### Freeze Operations
- `FREEZER_ROLE` can halt SLL contracts
- Separate Sky Ecosystem vs Agent-specific emergency protocols
- Recovery procedures: withdraw from L2 protocols, bridge to mainnet

#### Recovery Sequence
1. Withdraw all ERC4626 balances (call `redeem`)
2. Withdraw all Aave balances
3. Bridge liquidity from L2 ALM Proxy to Mainnet

### Operational GovOps Pattern
Standard review flow for changes:
1. Proposal submission (Forum + Powerhouse)
2. Operational Facilitator alignment review (7 days)
3. Token holder vote (3 days, 10% quorum)
4. Artifact update via GitHub/Powerhouse
5. On-chain execution via Spell/Proxy

---

## 6. Laniakea Relevance

### Alignment with Laniakea Concepts

#### Agent-as-Primitive Architecture
The Sky Primitives system directly maps to Laniakea's modular design:
- **Primitives** = Laniakea's composable building blocks
- **Instance Configuration Documents** = Agent configuration/parameters
- **Hub Documents** = State management and routing

#### Autonomous Operation Patterns
SLL operational patterns provide templates for Laniakea agents:
- **Rate Limits** = Resource budgeting and safety bounds
- **Role-based Access** = Permission hierarchies (Admin > Relayer > Freezer)
- **Off-chain Planner** = External reasoning/planning systems
- **On-chain Execution** = Deterministic action execution with audit trail

#### Multi-Chain Coordination
The SLL cross-chain model demonstrates:
- Single source of truth (Mainnet) with distributed execution
- CCTP bridging patterns for value transfer
- Domain-specific rate limits and recipients
- Recovery procedures for chain-specific failures

#### Encumbrance and Risk Capital
The Encumbrance Ratio concept provides:
- Quantitative risk management framework
- Required vs Total Risk Capital tracking
- Automated triggers for rebalancing actions
- Integration with broader ecosystem risk framework

#### Instance Configuration Documents as Agent State
ICDs contain all parameters for protocol interactions:
- Contract addresses and ABIs
- Rate limits and thresholds
- Custom operational procedures
- These could serve as templates for Laniakea agent deployment configs

### Potential Laniakea Integration Points

1. **SLL Operator Automation**: Replace multisig relayers with AI-driven autonomous operators while maintaining rate limit safety bounds

2. **Risk Capital Management**: AI agents monitoring Encumbrance Ratio and recommending/executing rebalancing actions

3. **Cross-Protocol Optimization**: Autonomous reallocation between SLL instances based on yield opportunities and risk parameters

4. **Governance Participation**: AI agents analyzing proposals, generating alignment assessments, facilitating voting

5. **Emergency Response**: Automated monitoring with AI-driven incident response within defined freeze/recovery procedures

### Key Parameters for Agent Systems
From this analysis, autonomous agents operating in this framework need awareness of:

| Parameter Type | Examples | Purpose |
|---------------|----------|---------|
| Rate Limits | Mint/Burn caps, bridge limits | Safety bounds |
| Encumbrance Ratio | 90% target | Risk tolerance |
| Target Liquidity | 10% or 1M floor | Withdrawal buffer |
| Rewards Rate | SSR-linked | Yield maintenance |
| Quorum/Approval | 10%/50% | Governance thresholds |

---

## Source Reference
Full document: `/Users/runechristensen/code-agents/reference/A.6 - The Agent Scope.md`
