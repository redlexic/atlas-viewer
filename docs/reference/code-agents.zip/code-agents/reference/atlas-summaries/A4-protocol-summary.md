# Atlas A.4 - Protocol Scope Summary

**Source:** A.4 - The Protocol Scope.md
**Size:** 908 lines, ~8,600 words
**Purpose:** Technical and governance framework for Sky Protocol's smart contract infrastructure

---

## Core Protocol Components

### Token Architecture

**USDS (Stablecoin)**
- 1:1 upgrade path from DAI
- Governed via Peg Stability Module and Allocation System
- Can be deposited to receive sUSDS (yield-bearing savings token)

**SKY (Governance Token)**
- 24,000 SKY per MKR conversion
- Delayed upgrade penalty: increases 1% per quarter to drive migration
- Deflationary tokenomics: No new emissions except emergency recapitalization
- Continuous buyback/burn via Smart Burn Buffer

**Deprecated Mechanisms:**
- Legacy emission mechanisms being replaced
- Moving to non-inflationary alternatives: reward funding, conversion contracts

### SkyLink Multichain System

Cross-chain infrastructure enabling:
- Native token transfers to L2s and major L1s
- Native savings rates (sUSDS earning SSR)
- Native token rewards distribution
- Native staking mechanisms
- 1:1 USDC ↔ USDS conversion on all supported chains

---

## Reward Mechanisms

### Sky Savings Rate (SSR)

Distributed via **sUSDS** (built-in yield-bearing mechanism):
- Users deposit USDS → receive sUSDS
- sUSDS accrues value at SSR
- Redeem sUSDS → receive USDS + accrued yield

### SKY Token Rewards

Normalized to match SSR value:
```
SKY Reward Amount = (Total Eligible USDS Balance × SSR) / Current SKY Price
```

**Distribution:**
- SKY token rewards distributed alongside SSR
- Agent tokens (SPK, etc.) distributed through same framework
- Ensures reward value parity across token types

### SKY Staking System

**Two-Tier Reward Structure:**

1. **High Activity Staking Reward (HASR)**
   - For users meeting high activity threshold
   - Higher reward rate

2. **Standard Activity Staking Reward (SASR)**
   - For users meeting standard activity threshold
   - Base reward rate

**Activity Determination:**
- Measured at monthly settlement cycles
- Thresholds set by governance
- Agent tokens (SPK, other Prime tokens) optional additional rewards

**SKY-Backed Borrowing:**
- Stake SKY as collateral
- Borrow USDS at SKY Borrow Rate
- Funded via segregated stUSDS system (see below)

---

## stUSDS: Segregated Risk Capital System

**Critical Technical Pattern for Laniakea**

### Purpose
Isolate protocol from SKY collateral risks by using dedicated risk capital pool.

### Dynamic Risk Isolation

**stUSDS Holders:**
- Deposit USDS → receive stUSDS
- Earn stUSDS Rate (higher than SSR to compensate for risk)
- Bear haircut risk if SKY liquidations fail

**Key Innovation:**
- Protocol isolated from SKY collateral losses
- stUSDS holders explicitly accept downside risk
- Dynamic debt ceiling eliminates manual governance bottleneck

### Dynamic Debt Ceiling

```
Max SKY-Backed Debt = Total USDS in stUSDS Contract
```

**Advantage:** Replaces static DC-IAM (Debt Ceiling Instant Access Module)
- No manual ceiling adjustments needed
- Ceiling scales automatically with stUSDS deposits
- Market-driven capacity limits

### Interest Rate Model

**stUSDS Rate Formula:**
```
stUSDS Rate = SSR
            + (SKY Borrow Rate - SKY Borrow Min Rate) × Utilization
            - Rfactor × f(Utilization)
```

**SKY Borrow Rate Formula:**
```
SKY Borrow Rate = SKY Borrow Base Rate
                + Slope1 × min(Utilization, Target Utilization)
                + Slope2 × max(0, Utilization - Target Utilization)
```

Where:
- `SKY Borrow Min Rate = SSR + stUSDS Distribution Reward`
- `Utilization = Total SKY-Backed Debt / Max Debt Ceiling`
- `f(Utilization)` is profit function maximizing stUSDS holder returns

### Key Parameters

**Target Utilization:** 90%
- System designed to operate at high utilization
- Balances capital efficiency with liquidation buffer

**Liquidation Ratio:** 120%
- SKY positions liquidated if collateral value < 120% of debt

**Interest Rate Slopes:**
- **Slope 1:** 12.575% (spread from 0% to 90% utilization)
- **Slope 2:** 12.575% (spread from 90% to 100% utilization)

**Max Profit Utilization:** 70%
- Utilization level maximizing stUSDS holder profit
- Below this: stUSDS holders earn more as utilization increases
- Above this: Begins transferring value to SKY borrowers

**Time-Weighted Utilization:**
- Calculated over 1-day intervals
- Smooths out short-term spikes
- Prevents gaming via flash transactions

### Liquidation Parameters

**Auction Mechanism:** StairstepExponentialDecrease
- Tau: 0 days (immediate start)
- Tolerance: 0.5 (50% tolerance)
- Cut: 0.99 (price reduction factor)
- Step: 60 seconds (price update frequency)

**Economic Parameters:**
- **Buf:** 120% (liquidation ratio)
- **Cusp:** 40% (minimum acceptable bid)
- **Tail:** 6,000 seconds (auction duration)
- **Chip:** 0.1% (proportional incentive)
- **Tip:** 300 USDS (flat incentive)
- **Chop:** 13% (liquidation penalty)
- **Hole:** 250,000 USDS (max total auction size)
- **Dust:** 30,000 USDS (minimum vault size)

---

## BEAM: Bounded External Access Module

**Critical Governance Pattern for Automated Parameter Management**

### Architecture

Whitelisted operators adjust parameters within governance-set bounds WITHOUT requiring governance vote for each change.

**Four Constraint Parameters per Controlled Parameter:**
1. **min**: Minimum allowed value
2. **max**: Maximum allowed value
3. **step**: Maximum change size
4. **tau**: Minimum time between changes

**Safety Mechanism:** Prevents parameter changes exceeding `step` size within `tau` timeframe.

### stUSDS BEAM Controls

| Parameter | Description | Min | Max | Step | Tau |
|-----------|-------------|-----|-----|------|-----|
| **str** | stUSDS rate | 200bp | 5000bp | 500bp | 16h |
| **duty** | SKY borrow rate | 210bp | 5000bp | 500bp | 16h |
| **cap** | Max stUSDS deposits | — | 1B USDS | — | — |
| **line** | Max SKY debt ceiling | — | 1B USDS | — | — |

### Operator Structure

**Two Operator Types:**

1. **Operator Multisig** (2/3 multisig)
   - Controlled by Atlas Axis
   - Manual adjustments following governance policy
   - Full BEAM parameters (500bp step, 16h tau)

2. **Operator Hot Wallet** (Automated bot)
   - Supervised by TechOps/Atlas Axis
   - Algorithmic updates based on market conditions
   - Reduced constraints: 400bp step, 4h tau
   - Enables more responsive adjustments

**Update Triggers (Hot Wallet):**
```
IF (|Current Utilization - Last Update Utilization| > 2.4%)
   AND (tau elapsed since last update)
THEN trigger parameter update
```

### Update Methodology

**Short-Term (Bootstrapping):**
- High initial rates (~40% str) to attract stUSDS liquidity
- Gradually reduced as pool reaches target size
- Manual multisig adjustments

**Long-Term (Steady State):**
- Fully automated conformance to interest rate formulas
- Hot wallet executes formula-driven updates
- No governance intervention needed for routine adjustments

**Cap/Line Scaling:**
When utilization > 85%:
```
New cap = 1.2 × current borrowing
New line = 1.14 × current borrowing
```

**Security:** Incremental increases prevent sudden exposure spikes

---

## Protocol Upgrade Procedures

### Routine Adjustments

**Operational Weekly Governance Cycle:**
- Core Executor Agents modify parameters
- Executive Vote pathway for routine changes
- Consultation with Core Council Risk Advisor

**Example:** Adjusting stability fee, debt ceiling, liquidation ratio

### Critical Changes

**Require Governance Poll (except emergencies):**
- Critical auction parameters
- Fundamental protocol mechanics
- New collateral type onboarding

**Emergency Exception:**
- Immediate changes allowed if threat to protocol safety
- Documented and ratified post-facto

### Oracle Protection

**SKY-Backed Borrowing Capped OSM Wrapper:**
Prevents price spike exploitation attacks.

**Mechanism:**
```
Effective SKY Price = min(PIP_SKY, Governance-Set Cap)
```

**Current Cap:** 0.025 USDS (modifiable via Executive Vote)

**Purpose:**
- Prevents attacker from manipulating SKY price upward
- Limits maximum borrowing capacity per SKY unit
- Protects against oracle manipulation

---

## Token Transfer Standards

### Stablecoin Transfers (DAI/USDS)

**Destination:** DssBlow2 contract → Surplus Buffer

**Address:** `0x81EFc7Dd25241acd8E5620F177E42F4857A02B79`

**Mechanism:**
- Burns DAI/USDS
- Credits Surplus Buffer
- Increases protocol equity

### Non-Stablecoin Transfers

**Destination:** Pause Proxy contract

**Address:** `0xbe8e3e3618f7474f8cb1d074a26affef007e98fb`

**Risk Warning:**
- Wrong token sends to DssBlow2 are **unrecoverable**
- Sender responsibility to use correct destination
- Protocol cannot recover misrouted tokens

---

## PAU Infrastructure Patterns

### Vesting Stream Mechanism

**Contract:** MCD_VEST_SKY_TREASURY

**Purpose:** Short-term SKY staking rewards distribution

**Phases:**

1. **Bootstrap Phase:**
   - Initial: 1B SKY vested over 180 days
   - Source: Sky Frontier Foundation grant
   - Kickstarts staking participation

2. **Post-Bootstrap:**
   - Funded by protocol buybacks
   - `vestTot` (total vesting amount) adjusted based on buyback volume
   - `vestTau` (vesting duration) adjusted for reward smoothing

**Distribution Flow:**
```
Vesting Stream → Rewards Distribution Contract → Staking Rewards
```

### Distribution Reward Primitive

**stUSDS Distribution Reward:** 0.1% total
- 0.05% Integrator reward
- 0.05% Prime Agent reward

**Purpose:** Incentivize ecosystem promotion
- Integrators earn by facilitating stUSDS adoption
- Prime Agents earn by building on stUSDS infrastructure

**Similar Framework:** USDS Distribution Reward
- Same incentive structure
- Drives organic growth through aligned participant rewards

---

## Deflationary Tokenomics

### Smart Burn Buffer

**Mechanism:**
1. Protocol revenue accrues in Surplus Buffer
2. When Surplus Buffer > threshold: transfer to Splitter
3. Splitter allocates to SKY buyback
4. Buyback executed → SKY burned

**Kicker Module Parameters:**
- **khump (threshold):** 200M USDS
- **kbump (lot size):** 10,000 USDS per transfer
- **hop (interval):** 2,880 seconds between transfers
- **Burn parameter:** 100% to SKY accumulation via Flapper

**Result:** Continuous deflationary pressure on SKY supply

### No New Emissions

**Policy:** No new SKY minted except emergency recapitalization

**Implication:**
- SKY supply decreases over time (via buyback/burn)
- Scarcity increases as protocol grows
- Aligns SKY holder incentives with protocol success

**Exception:** Emergency recapitalization
- Only if protocol becomes undercollateralized
- Last resort mechanism
- Requires extreme circumstances

---

## Laniakea-Relevant Insights

### 1. BEAM Pattern: Bounded Automation

**Application to Laniakea:**
- SORL (Second-Order Rate Limit) already uses BEAM-style constraints
- Could extend to: OSRC capacity limits, SPTP bucket caps, redemption limits
- Enable algorithmic adjustments (via stl-erc Sentinel) within safety bounds
- Reduce governance overhead while maintaining safety

**Implementation:**
```
Parameter: OSRC weekly capacity
min: 10M USDS
max: 500M USDS
step: 50M USDS (max increase per adjustment)
tau: 7 days (one week minimum between increases)

Sentinel can adjust weekly based on demand signals without governance vote
```

### 2. Segregated Risk Capital Pattern (stUSDS)

**Laniakea Equivalent:**
- stUSDS ≈ srUSDS (Senior Risk USDS)
- Both provide risk capital for higher-risk activities
- Both isolate protocol from specific risk category

**Key Lessons:**
- Dynamic debt ceiling eliminates governance bottleneck
- Time-weighted utilization prevents gaming
- Dual operator structure (automated + manual) balances responsiveness with safety

### 3. Time-Weighted Metrics

**stUSDS uses 1-day intervals for utilization calculation**

**Laniakea Application:**
- Lindy-based liability duration measurement (weekly snapshots)
- Could use time-weighted averaging for SPTP capacity utilization
- Prevents manipulation via short-term spikes

### 4. Dynamic Ceiling Formula

**stUSDS Example:**
```
When utilization > 85%:
  cap = 1.2 × current borrowing
```

**Laniakea Parallel:**
- SPTP bucket structural caps based on double exponential bank run model
- Could add dynamic scaling: if bucket consistently hits cap, slightly increase via formula
- Avoid manual governance votes for every capacity adjustment

### 5. Multi-Tier Incentive Design

**SKY Staking:** HASR vs SASR based on activity levels

**Laniakea Application:**
- Could differentiate OSRC auction participant rewards based on consistency
- Bonus yield for Primes maintaining continuous SPTP reservations
- Graduated penalties based on breach severity/duration

### 6. Gradual Penalty Mechanisms

**MKR → SKY upgrade penalty:** increases 1% per quarter

**Laniakea Application:**
- Gradual penalty accrual for encumbrance breaches (already in GRF)
- Could add: late settlement penalty escalation (low → medium → high severity based on delay duration)

### 7. Operator Supervision Structure

**BEAM Operators:**
- Automated bot for routine, formula-driven updates
- Manual multisig for policy decisions
- Emergency intervention capability preserved

**Laniakea Parallel:**
- stl-erc Sentinel (automated) for routine LCTS settlement
- stl-auction Sentinel (automated) for auction matching
- Core Council / stl-exec (manual) for emergency intervention
- All operate within pBEAM/cBEAM/aBEAM hierarchy

### 8. Oracle Protection Patterns

**Capped OSM Wrapper:** `min(actual price, cap)`

**Laniakea Application:**
- Could cap OSRC auction spread at maximum to prevent yield manipulation
- SPTP asset valuations capped at par during stress to prevent artificial capacity expansion
- Protects against oracle manipulation or extreme market dislocations

---

## Summary: Core Principles

1. **Bounded Automation (BEAM):** Allow automated parameter adjustments within safety constraints
2. **Risk Segregation (stUSDS):** Isolate specific risk categories into dedicated capital pools
3. **Dynamic Scaling:** Formula-driven capacity increases reduce governance overhead
4. **Time-Weighting:** Prevent short-term manipulation via averaging over intervals
5. **Dual Operators:** Combine automated execution with human oversight
6. **Deflationary Design:** Continuous buyback/burn aligns stakeholder incentives
7. **Multi-Tier Rewards:** Differentiate incentives based on participation quality
8. **Oracle Protection:** Cap critical price inputs to prevent manipulation

These patterns provide battle-tested approaches for **autonomous operation within safety bounds** - the core challenge Laniakea solves for capital deployment at scale.
