# Atlas A.5 - Accessibility Scope Summary

**Source:** A.5 - The Accessibility Scope.md
**Size:** 143 lines, ~1,000 words
**Purpose:** Distribution, frontends, communication channels, and geographic availability rules

---

## What "Accessibility" Means in Sky

Accessibility encompasses:
- **Distribution efforts** - Marketing, user acquisition campaigns
- **User-facing frontends** - Web interfaces, mobile apps
- **Communication channels** - Twitter, Telegram, Discord, forums
- **Geographic availability** - Compliance with location-based restrictions

**Key Distinction:** Accessibility is about HOW users reach and interact with Sky Protocol, not the protocol itself.

---

## Geographic Access Controls

### Limited Filtering (Hide Yield Features)

**Who:** Users with IPs flagged for limited filtering

**What's Hidden:**
- Staking Rewards
- Sky Savings Rate (SSR)
- Any yield/rewards features
- Integration Boost displays

**Rationale:** Regulatory caution in jurisdictions with unclear staking/yield product rules

**Responsibility:** Ecosystem Actors determine their own filtering strategies

### Full Block (Complete Denial of Service)

**Restricted Locations:**
- Cuba
- Iran
- Syria
- North Korea
- Crimea / Sevastopol
- Donetsk People's Republic
- Luhansk People's Republic
- Kherson Oblast
- Zaporizhzhia Oblast

**Mechanism:** IP-based blocking at frontend level

**Requirement:** Frontends operated by Ecosystem Actors on behalf of Agents **must** comply

---

## Compliance Requirements

### For Frontends

**Mandatory IP Filtering:**
- Implement infrastructure to reduce exposure to restricted locations
- "Actively explore and implement reasonably available options" for geographic restrictions
- Compliance monitored - penalties apply for failures

**Moderation Policies:**
- Communication channel moderation rules from A.2.8.1.2 apply to Accessibility channels
- Ecosystem Actors responsible for content moderation

### Brand Regulation

**Sky Website:**
- IP rights must transfer to Dai Foundation-like entity
- Ensures continuity and protects brand

**DAI Token:**
- Remains valid token
- **No actively maintained brand presence** beyond:
  - Community assets
  - Educational materials
- Deliberate wind-down of official DAI branding (migration to USDS focus)

---

## Access Control Philosophy

**Passive (IP-Based) NOT Active (KYC-Based)**

No explicit KYC requirements mentioned in this scope. Access control relies on:
- IP geolocation
- Frontend-level filtering
- No identity verification for general users

**Rationale:**
- Maintains permissionless ethos for non-restricted jurisdictions
- Compliance achieved through geographic filtering, not identity collection
- Shifts responsibility to frontend operators (not protocol layer)

---

## Notable Programs

### Early Bird Reward Airdrop

**Allocation:** 27.2M SKY
**Purpose:** Bootstrap early user adoption
**Mechanism:** Airdrop to early participants (specific criteria not detailed in this scope)

### Liquidity Bootstrapping Program

**Budget:**
- 20M USDS
- 320M SKY

**Purpose:** Initial liquidity provision for USDS/SKY markets
**Phase:** Transitional - ensuring smooth token launches

### Zero-Budget Accessibility Communication

**Current Budget:** 0 USDS/month

**Implication:** Accessibility communication channels currently unfunded or operated by volunteers/existing Ecosystem Actors without dedicated budget.

**Potential Future State:** Budget could be allocated if formal communication strategy developed

---

## Laniakea Relevance

### Institutional KYC Network (Pillar #6)

Accessibility Scope focuses on **retail/permissionless access**. Laniakea's Institutional KYC Network will handle **permissioned access** for:
- Passthrough Halo participants
- Regulated asset managers
- Institutional USDS holders

**Complementary Approaches:**
- Accessibility Scope: IP filtering, no KYC (retail)
- Institutional KYC Network: Full KYC, compliance infrastructure (institutional)

**Boundary:** Halo Units likely require KYC due to investment product characteristics

### Frontend Compliance Pattern

**Sky Pattern:**
- Decentralized protocol (permissionless)
- Frontends enforce geographic restrictions
- Shifts compliance burden to application layer

**Laniakea Application:**
- Core protocol (Generator, Prime, Halo PAUs) permissionless
- Frontend interfaces to Halo Units enforce KYC/geographic rules
- Halo Artifacts specify compliance requirements
- Passthrough Halo legal structure ensures institutional compliance

**Advantage:** Protocol remains neutral; compliance handled at edges

### Distribution Reward Primitive

**Mentioned in A.4 Protocol Scope:**
- stUSDS Distribution Reward: 0.1% (0.05% Integrator + 0.05% Prime)
- Incentivizes promotion by Integrators and Prime Agents

**Accessibility Alignment:**
- Distribution rewards drive frontend/integrator adoption
- Accessibility Scope governs HOW those frontends operate (geographic rules, moderation)
- Closed loop: Protocol incentivizes distribution → Accessibility regulates distribution methods

---

## Key Takeaways

1. **IP-Based Filtering:** Primary compliance mechanism (not KYC)
2. **Frontend Responsibility:** Ecosystem Actors operating frontends must implement geographic restrictions
3. **Yield Feature Hiding:** Regulatory caution for staking/yield products in uncertain jurisdictions
4. **Full Block List:** Hard restrictions on sanctioned regions
5. **Passive Access Control:** Maintains permissionless protocol while achieving compliance at application layer
6. **Brand Wind-Down:** DAI brand deliberately phased out; Sky/USDS focus
7. **Bootstrapping Programs:** Early Bird + Liquidity programs drive initial adoption
8. **Zero-Budget Comms:** Current state unfunded; potential for future allocation

**Philosophy:** Decentralization at protocol layer, compliance at frontend layer - enables global permissionless access while respecting regulatory boundaries.
