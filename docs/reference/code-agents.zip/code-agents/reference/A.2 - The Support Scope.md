# A.2 - The Support Scope [Scope]  <!-- UUID: 1ce14bd8-c7b3-4f74-a152-292a8d8ebed0 -->

The Support Scope governs all routine aspects of ecosystem support, including governance process infrastructure and management, Agent support and Ecosystem Actor support.

## A.2.1 - Governance Process Support [Article]  <!-- UUID: f83a880f-6440-49ac-8e28-b16b4e2c9912 -->

The Support Scope regulates the routine governance processes needed to operationalize the Atlas. This Article defines key infrastructure and processes supporting this objective.

### A.2.1.1 - Governance Process Support [Section]  <!-- UUID: ef1ad0bf-069c-4199-8620-a508b34c2348 -->

The Support Scope must facilitate the routine governance processes of the Sky Ecosystem, pursuant to the principles and procedures defined herein.

#### A.2.1.1.1 - In General [Core]  <!-- UUID: 4b76256c-c625-49ce-a91d-88d3fbd2452f -->

Sky Governance deploys various core processes to implement its decision-making, including Aligned Delegate processes, the Weekly Governance Cycle, the Monthly Governance Cycle and the modification of Active Data. The Support Scope regulates routine governance processes based in the explicit rules of the Atlas. In contrast, the Governance Scope governs situations in which a document is appealed or is otherwise contentious for reasons of ambiguity or conflict with other documents.

##### A.2.1.1.1.0.3.1 - Ambiguity - Element Annotation [Annotation]  <!-- UUID: 62e031ef-de5a-4425-8561-439b6f72a548 -->

The element "ambiguity" refers to instances where the language of an Atlas document allows for multiple possible interpretations.

##### A.2.1.1.1.0.3.2 - Contentious - Element Annotation [Annotation]  <!-- UUID: 6691933f-0d3f-4a20-b609-57001a6a3491 -->

The element "contentious" describes a situation where there is disagreement or dispute regarding the interpretation, application, or validity of a document.

##### A.2.1.1.1.0.3.3 - Document Is Appealed - Element Annotation [Annotation]  <!-- UUID: b5be838e-23a8-4ed4-b713-d5a57fe1864d -->

The element means that a formal request has been made to the Core Facilitator to review an Atlas document for potential conflicts with other documents or misalignment. See [A.1.2.3 - Conflict Resolution](e883ceb7-707d-4b1d-af3c-ed6f9aeac565).

#### A.2.1.1.2 - Coordination Of Scope Framework Processes [Core]  <!-- UUID: 53388cf1-7934-4048-a372-2aec5e5b8430 -->

The Scopes establish various specialized processes, including those for submitting governance proposals or modifying the Atlas. Core GovOps is responsible for monitoring and ensuring that these processes are executed in accordance with the established rules. An action carried out through a Scope-defined process is considered valid only if Core GovOps has been properly notified.

##### A.2.1.1.2.0.3.1 - Monitoring And Ensuring - Element Annotation [Annotation]  <!-- UUID: f51addb2-fba3-476f-b3e4-1c5b4b9013fc -->

This element refers to the ongoing responsibility of Core GovOps to monitor the progress of routine governance processes, check for compliance with the rules, and confirm that all necessary documentation and approvals are in place.

##### A.2.1.1.2.0.3.2 - Properly Notified - Element Annotation [Annotation]  <!-- UUID: df31f503-1238-4380-9a0e-25e2ef7c81d0 -->

This element means that Core GovOps have been informed in accordance with the prescribed procedures, including the timing, method, and content of the notification, as required by the relevant Scope.

#### A.2.1.1.3 - Designation Of Governance Process Support Ecosystem Actors [Core]  <!-- UUID: d537c3df-287c-45a5-aa69-2b4242b2259f -->

Core GovOps can designate Ecosystem Actors (including individuals, companies or Forum or Chat pseudonyms) as Governance Process Support Ecosystem Actors. This designation can include granting them moderation rights and other forms of administration rights on the relevant communication channels. 

Governance Process Support Ecosystem Actors can assist with governance processes including verifying Atlas Edit Proposals (AEPs), preparing and merging Pull Requests, updating the status of AEPs, preparing Polls, editing the Atlas, etc.

#### A.2.1.1.4 - Resources [Core]  <!-- UUID: 048600dc-3e21-4e1b-9e69-a0b5aff92ff8 -->

Core GovOps is granted a budget to procure the necessary administrative support and services from Governance Process Support Ecosystem Actors. The budget can only be used to perform tasks described in [A.2.1.1 - Governance Process Support](ef1ad0bf-069c-4199-8620-a508b34c2348) and its subdocuments. Core GovOps can modify the budget using an Operational Weekly Governance Cycle poll.

##### A.2.1.1.4.1 - Current Budget [Core]  <!-- UUID: 5efada66-f3d2-4e3e-b26c-123467069437 -->

The budget available to fund Governance Process Support tasks is 0 USDS per quarter.

## A.2.2 - Atlas Core Development [Article]  <!-- UUID: fbcb5bb8-eefb-47b6-859f-52d71992d5cc -->

This Article defines key infrastructure and processes supporting the development of the Atlas.

### A.2.2.1 - Atlas Core Development [Section]  <!-- UUID: 71ca2fee-680a-4ffb-81c8-f157b40d419e -->

Atlas development is a critical infrastructure priority, essential for the stability, security, and efficient operation of the Sky Ecosystem. It must be fully supported to ensure that all necessary elements for safeguarding, managing, and operating the Ecosystem are comprehensively addressed. This Section defines processes to support Atlas development.

#### A.2.2.1.1 - Funding [Core]  <!-- UUID: 60470fc3-1cf6-4549-9850-6b38d1899183 -->

Atlas Core Development can be performed by Ecosystem Actors paid through direct funding from Executive Votes.

##### A.2.2.1.1.1 - Executive Votes [Core]  <!-- UUID: 73d256a8-fb79-4faf-9d06-ad908b4d82fc -->

The Core Facilitator can initiate direct funding through monthly Executive Votes to key Atlas contributors.

###### A.2.2.1.1.1.0.4.1 - Key Atlas Contributors [Action Tenet]  <!-- UUID: 969b5bf3-f982-4fc2-a29e-704b1d9962a9 -->

Key Atlas contributors are individuals or teams that play a crucial role in the development of the Atlas. Relevant workstreams can include community building, research, data collection, data processing, data review, drafting, peer review, etc. The Core Facilitator, in consultation with Atlas Axis or other relevant Ecosystem Actors, will distribute funding based on criteria such as the scope of the contribution, its impact on the Atlas, and the quality of the work produced.

##### A.2.2.1.1.2 - Direct Funding Cap [Core]  <!-- UUID: 086bc45a-e3f8-46e4-b574-6f432dfd2306 -->

The direct funding can at most be 150,000 USDS and 1,000,000 SKY per month.

##### A.2.2.1.1.3 - Direct-Funding Payment Procedure [Core]  <!-- UUID: d2af6340-ccd4-4d55-9c36-3e7ab88e0bef -->

Direct funding payments to Atlas contributors are initiated through requests submitted by the contributors themselves. These funding requests are approved by the Core Facilitator, in consultation with Atlas Axis or another relevant Ecosystem Actor. Payments are triggered directly by the Core Facilitator. Payments can be requested to multiple addresses at once to accommodate contributor teams.

###### A.2.2.1.1.3.0.4.1 - Trigger - Core Facilitator Must Add Atlas Core Development Payments To Executive Vote [Action Tenet]  <!-- UUID: 860d84bc-dc59-4801-8972-11bb7a66f538 -->

In this context, the element "trigger" means that the Core Facilitator is responsible for requesting the addition of Atlas Core Development payments to an Executive Vote. The Core Facilitator is also responsible for providing provenance for such requests by confirming payment requests on the Executive Sheet. See [A.1.10.1.3.0.3.1 - Executive Sheet - Element Annotation](52aef6ac-9eda-4795-9dab-73ea85b8ca31).

##### A.2.2.1.1.4 - Aligned Delegates Eligible to Receive Budget [Core]  <!-- UUID: f3bb065b-5e0a-4722-9c32-4c75d250125a -->

Aligned Delegates are eligible to receive budgets through this funding process. This constitutes an exception to [A.1.4.5 - ACs Can Be Operationally Active In Only One Role At A Time](9b1d1c2f-ace0-4637-8050-4711ae9f9a8c), which generally prohibits ACs from simultaneously assuming multiple ecosystem roles.

## A.2.3 - Sky Primitives [Article]  <!-- UUID: fcde2604-a138-4c1b-9d9a-14895835c907 -->

This Article governs the Sky Primitives. A Sky Primitive is a standardized interface that allows Agents to connect to, and leverage, Sky Protocol’s permissioned infrastructure. This Article defines each of the Sky Primitives available for Prime Agents to use to expand the Sky Ecosystem. Each Prime Agent strategy is unique, so each may combine the Sky Primitives differently.

### A.2.3.1 - Primitives In General [Section]  <!-- UUID: df611e97-f99d-4244-8573-e706fbd1dfbc -->

The documents herein define general principles relating to Agent Artifact evolution, enumerate the currently available Sky Primitives, and prescribe the procedures by which Agents can activate, invoke and deploy the Primitives.

#### A.2.3.1.1 - Initial Stages Of Artifact Evolution [Core]  <!-- UUID: 73eb0d53-2746-4db8-8b61-608f7439d560 -->

The documents herein define the initial stages of the lifecycle of an Agent Artifact, beginning with the prerequisite of capital deployment and continuing until the Agent gains full operational status with an active Executor Accord and Root Edit Primitive. At that point, the Agent is interoperable with other Sky Agents and possesses a formal governance process by which token holders can guide its activities.

##### A.2.3.1.1.1 - Founder Deposits Capital And Pays Agent Creation Fee [Core]  <!-- UUID: 96ecd286-9361-4cb0-8062-9dd930780f3e -->

The prospective Agent founder kicks off the lifecycle of an Agent by deploying an initial minimum amount of capital and paying an Agent Creation fee in an off-chain process as defined in [A.2.3.3.1.1 - Capital Injection](bed7471a-54aa-4167-88dd-22ebd63f8827).

##### A.2.3.1.1.2 - Core GovOps Creates Scaffold Agent Artifact [Core]  <!-- UUID: b485d31f-e7e2-45fd-aefb-2a55206390a2 -->

After receiving the initial capital and Agent Creation fee, Core GovOps proceeds to set up a Scaffold Agent Artifact ("Scaffold Artifact"), which serves as a base template containing all Sky Primitives. In the Scaffold Artifact, the Global Activation Status of all Sky Primitives is initially set to `Inactive`. The sole exception is the Upkeep Rebate Primitive, whose Global Activation Status in the newly generated Scaffold Artifact is `Active` by default. See [A.2.3.1.2 - Primitive Global Activation Status](dde8cf4c-4823-4fea-96b8-a9b9d6b24533).

##### A.2.3.1.1.3 - Founder Inputs [Core]  <!-- UUID: 1b66ee09-3e81-4ae3-b3df-69787e0f662a -->

The documents herein specify the Agent Founder’s inputs following the creation of the Scaffold Artifact.

###### A.2.3.1.1.3.1 - Founder Required Primitive Activation [Core]  <!-- UUID: 1a48e833-d960-4bdf-8f67-0f9d9307e00d -->

The Founder is responsible for Globally Activating the Agent Creation, Prime Transformation / Executor Transformation, Agent Token, Executor Accord, and Root Edit Primitives. Additionally, the Founder must Activate either the Distribution Requirement Primitive or the Market Cap Fee Primitive - or may choose to Activate both.

The Primitives named above must first be Globally Activated before the Founder can Invoke them to finalize Agent setup. The Founder may choose to Globally Activate these Primitives individually at different times or all at once; only the Primitive Invocation must be done in a specified order.

###### A.2.3.1.1.3.2 - Founder Access [Core]  <!-- UUID: a4f65994-2526-4522-a986-cd444a5cb896 -->

_"_Founder Access" gives the Founder of an Agent the ability to freely edit the Scaffold Artifact, including Activating any desired Primitives and adding custom Omni Documents. "Founder Access" is revoked at the moment the Founder Invokes either the Prime Transformation or Executor Transformation Primitive. From that point on, the Founder cannot add or edit Omni Documents, but can only Activate and Invoke specific Primitives so that the Agent can complete setup. See [A.2.3.1.2.4.1 - Agent Launch And Sequence of Primitive Global Activation](2f5ff5c8-bcd1-44a4-ba56-2075ac8e9c61).

###### A.2.3.1.1.3.2.1 - Short Term Suspension of “Founder Access” [Core]  <!-- UUID: 5dd07957-8e5b-4694-a0ba-a8aa88863552 -->

In the short term, "Founder Access" will not be operational. Instead, if a Prime Founder wishes to edit their Scaffold Artifact, they must use the customary Atlas Edit Proposal processes specified in the Sky Core Atlas at [A.1.10.2 - Atlas Edit Weekly Cycle](14e99d92-71fc-44d9-9dbf-933bce2e1b32) or [A.1.11.2 - Atlas Edit Monthly Cycle](d2cbddd2-58ef-4311-a71d-d2c340364cb5).

###### A.2.3.1.1.3.3 - Founder Invokes Agent Creation Primitive [Core]  <!-- UUID: d0b283e9-dac1-49c6-8dd7-b061c7a87335 -->

To proceed to the next stage, the Founder must Invoke the Agent Creation Primitive. From the Agent’s perspective, invoking, or calling, a Primitive always involves submitting required inputs into the respective Primitive itself. Here, the  Agent Founder must input the name of the Agent and an introduction providing a brief overview of the Agent’s vision or business model into the Agent Creation Primitive.

##### A.2.3.1.1.4 - Core GovOps Validates Agent Creation Primitive Inputs [Core]  <!-- UUID: 93d6147b-8760-431e-b38c-4a7afcb27e5f -->

Core GovOps validates the Founder’s inputs into the Agent Creation Primitive and the "Founder Access"-related edits to the Scaffold Artifact, ensuring that all information is well specified and that the Scaffold Artifact is aligned.

##### A.2.3.1.1.5 - Core GovOps Creates Genesis And SubProxy Accounts [Core]  <!-- UUID: 16d9dede-7fbf-4215-8e60-c06a8e6c3218 -->

After validating the Scaffold Artifact and Agent Creation Primitive inputs, Core GovOps creates a Genesis Account and SubProxy Account for the Agent. This data is automatically added to the Agent Creation Primitive.

##### A.2.3.1.1.6 - Founder Must Globally Activate Distribution Requirement And/Or Market Cap Fee Primitive [Core]  <!-- UUID: 94eacab6-0df2-45c6-89fe-af4f8c2e6263 -->

Prior to invoking the Prime Transformation or Executor Transformation Primitive, the Agent Founder must Globally Activate either the Distribution Requirement Primitive or the Market Cap Fee Primitive - or may choose to Activate both.

##### A.2.3.1.1.7 - Founder Invokes Prime / Executor Transformation Primitive [Core]  <!-- UUID: 2592b3d0-531e-42a3-a098-cf4b82bdd567 -->

When ready, the Founder Invokes the Prime Transformation or Executor Transformation Primitive to become either a Prime Agent or Executor Agent, respectively.

##### A.2.3.1.1.8 - Core GovOps Validates Transformation Primitive Inputs [Core]  <!-- UUID: 05e70418-5dbf-4d02-9d2a-9afea6619dd0 -->

Upon successful validation by Core GovOps, the Transformation Primitive is deployed and the Agent Artifact is upgraded to reflect that the Agent is either a Prime Agent or an Executor Agent.

##### A.2.3.1.1.9 - Post-Transformation Primitive Artifact Freeze [Core]  <!-- UUID: 20f4cfe0-1855-4942-ac0d-f5cb738e82fc -->

After the Transformation Primitive is successfully Invoked, the Agent’s "Founder Access" is revoked. The Founder can no longer freely edit the Agent Artifact, but may only Invoke certain Primitives in a specified order until the Agent setup is complete.

##### A.2.3.1.1.10 - Founder Invokes Agent Token Primitive [Core]  <!-- UUID: f5132655-afdd-4a93-adbe-64526759720c -->

The Founder next Invokes the Agent Token Primitive to create a token for the Agent that can be used to raise capital, build a community, and conduct governance processes.

##### A.2.3.1.1.11 - Core GovOps Validates Agent Token Primitive Inputs [Core]  <!-- UUID: 416dc0f2-fb0d-4ea2-975d-9bf2d9b0e1d4 -->

Core GovOps reviews the inputs to the Agent Token Primitive to ensure that they are well specified and aligned.

##### A.2.3.1.1.12 - Core GovOps Mints Tokens [Core]  <!-- UUID: 0e033de5-ce15-45df-ae85-9ed69bd40da0 -->

After validating the Agent Token Primitive inputs, Core GovOps proceeds to mint the Agent’s initial supply of tokens according to the instructions specified in the Primitive.

##### A.2.3.1.1.13 - Agent Invokes Executor Accord Primitive [Core]  <!-- UUID: 9b074b3d-73db-4a3a-9491-571021e4e61b -->

The Agent must reach an understanding with an Operational Executor Agent that will operationalize the Agent’s strategy. After doing so, the Agent records this understanding by invoking the Executor Accord Primitive. Note that this step is only applicable to Prime Agents.

##### A.2.3.1.1.14 - Core GovOps Validates Executor Accord Primitive Inputs [Core]  <!-- UUID: c1ff42c9-1ffc-46f0-9dac-da54eb4eb042 -->

CoreGovOps reviews the inputs to the Executor Accord Primitive to ensure that there is a valid Executor Accord with an Executor Agent and that the terms of the Executor Accord are reasonably specific. Upon successful validation, the Executor Accord Primitive is considered successfully Invoked and the Artifact is upgraded to include the Executor Accord. Now that the Agent has a documented relationship with an Executor Agent, Core GovOps will no longer perform validation of the Agent’s Primitive inputs. Instead, Operational GovOps associated with the Executor Agent specified in the Executor Accord will carry out certain operational tasks on behalf of the Prime Agent see [A.1.13.3.4 - Agent Role Delineation](fdf32ca5-5e2e-481e-9047-4d1599547216).

##### A.2.3.1.1.15 - Agent Invokes Root Edit Primitive [Core]  <!-- UUID: 63f85a1a-da2d-4828-ae32-da56f46d500d -->

The Agent Invokes the Root Edit Primitive and sets up a governance process for voting to occur.

##### A.2.3.1.1.16 - Operational GovOps Validates Root Edit Primitive Inputs [Core]  <!-- UUID: d5ee3f2c-cd2f-4428-974b-341e4cce7295 -->

Operational GovOps reviews the inputs to the Root Edit Primitive to ensure it specifies a process that they can operationalize and does not conflict with any of the requirements regarding the voting process set forth in the Sky Core Atlas.

Upon validation, the Root Edit Primitive is considered successfully Invoked, and the Artifact is upgraded with its functionality. At this point the Agent is fully operational. The Agent Artifact can only be edited through a token holder vote or, if applicable, by the Operational Executor Facilitator as authorized by Omni Documents. The Agent can Invoke and deploy any Primitives that it has previously Activated and can also Activate additional Primitives through a Root Edit.

#### A.2.3.1.2 - Primitive Global Activation Status [Core]  <!-- UUID: dde8cf4c-4823-4fea-96b8-a9b9d6b24533 -->

The documents herein define Primitive Global Activation Status.

##### A.2.3.1.2.1 - Primitives Must First Be Activated To Be Invoked [Core]  <!-- UUID: dcd0bead-7ad1-4fe0-b485-b3565d670c78 -->

An Agent may only Invoke a Primitive that it has previously Globally Activated; the process of Invocation is defined below at [A.2.3.1.3.3 - Changing Primitive Instance Status](263f3b28-9cd4-4ba2-b8e5-152c2ce0c050). In this way, an Agent’s decision regarding which Primitives to Activate allows the Agent to express its strategy to token holders. For example, an Agent that was focused on asset gathering might Globally Activate the Distribution Reward and Integration Boost Primitives, but not the Allocation System Primitive.

##### A.2.3.1.2.2 - Initial Primitive Global Activation Status [Core]  <!-- UUID: 377150b3-d64b-4436-ab6d-758b05d82f26 -->

Scaffold Artifacts by default include all Sky Primitives. To begin with, all Sky Primitives have the Global Activation Status of `Inactive`; the exception is the Upkeep Rebate Primitive, which comes Globally Activated in all Scaffold Artifacts.

##### A.2.3.1.2.3 - Primitive Activation Does Not Require Invocation [Core]  <!-- UUID: 1560f392-db95-43d0-968b-af8d1afa4e84 -->

Activation gives the Agent the ability to Invoke a Primitive (thereby creating an instance of that Primitive), but does not require the Agent to do so.

##### A.2.3.1.2.4 - Changing A Primitive’s Global Activation Status [Core]  <!-- UUID: 51cfca28-c8de-457a-abc4-8ce1f64abb91 -->

An Agent can change the Global Activation Status of a Primitive as defined herein.

###### A.2.3.1.2.4.1 - Agent Launch And Sequence of Primitive Global Activation [Core]  <!-- UUID: 2f5ff5c8-bcd1-44a4-ba56-2075ac8e9c61 -->

Sky Primitives can be Globally Activated (and their instances later Invoked) by an Agent at different points in the Artifact’s lifecycle. The process is divided into three main stages, outlined in the documents herein.

###### A.2.3.1.2.4.1.1 - “Pre Transformation Primitive” Stage [Core]  <!-- UUID: b5cbcb47-ff44-4809-8071-2b5f7b30efbb -->

After the Scaffold Artifact has been established, but before invoking the Prime Transformation or Executor Transformation Primitive, the Agent Founder retains unilateral authority ("Founder Access") to Activate any desired Primitives while freely editing the Agent Artifact. The Founder must Globally Activate either the Distribution Requirement Primitive or the Market Cap Fee Primitive - or may choose to Activate both. No Operational Executor Facilitator approval or token holder vote is required at this stage. See [A.2.3.1.1.3.2 - Founder Access](a4f65994-2526-4522-a986-cd444a5cb896).

###### A.2.3.1.2.4.1.2 - “Pre Root Edit Primitive” Stage [Core]  <!-- UUID: 7b25b220-92f9-4936-8296-31c0f3d8ddbc -->

After the Prime Transformation or Executor Transformation Primitive has been Invoked, but before the Root Edit Primitive is Invoked, the Agent Founder can no longer freely edit the Artifact. During this period, the Agent must Activate and Invoke (1) the Agent Token Primitive, then (2) the Executor Accord Primitive, and finally (3) the Root Edit Primitive, in that order, to complete its governance setup - assuming that these Primitives were not already Globally Activated during the "Pre Transformation Primitive" Stage. No other Primitives can be Globally Activated by the Agent during this period.

###### A.2.3.1.2.4.1.3 - “Post Root Edit Primitive” Stage [Core]  <!-- UUID: 857b85e5-b57e-4043-82eb-6fbb68cf1d51 -->

After the Root Edit Primitive is Invoked, changing the Global Activation Status of a Primitive - whether activating or deactivating - requires a token holder vote and review by the Operational Executor Facilitator.

###### A.2.3.1.2.4.2 - Global Primitive Deactivation [Core]  <!-- UUID: d0fb8761-2fcb-4d81-b498-38cd44f47fb0 -->

Generally, a Prime Agent may freely deactivate a Primitive’s Global Status pursuant to the governance process defined in its Root Edit Primitive. However, there are exceptions to this rule given the special functionality of certain Primitives. See [A.2.3.1.2.4.2.1 - Prohibition On Deactivating Certain Primitives](3ce3a1ae-9300-4159-9676-261d0404360f). 

If a Primitive’s Global Status is deactivated, _all_ existing instances of that Primitive immediately become `Suspended`. While the Primitive remains Globally Inactive, the Agent is barred from creating new instances or reactivating existing instances of that Primitive.

###### A.2.3.1.2.4.2.1 - Prohibition On Deactivating Certain Primitives [Core]  <!-- UUID: 3ce3a1ae-9300-4159-9676-261d0404360f -->

The documents herein specify the Sky Primitives that, once Globally Activated, cannot be deactivated.

###### A.2.3.1.2.4.2.1.1 - Prohibition On Deactivating Genesis Primitives [Core]  <!-- UUID: 04bbf091-b2a8-47e4-ad03-f3fd66e70279 -->

Once Activated, the Agent Creation, Prime / Executor Transformation, and Agent Token Primitives cannot be deactivated. These Primitives are deployed once, and thereafter their Global Status is `Completed` and cannot be altered.

###### A.2.3.1.2.4.2.1.2 - Prohibition On Deactivating Executor Accord And Root Edit Primitives [Core]  <!-- UUID: a4797404-1015-4cd5-a2ea-bc1a2699b575 -->

To maintain recognized operational status within the ecosystem, Agents must have active Executor Accord and Root Edit Primitives at all times. Once Globally Activated, these Primitives cannot be deactivated, as doing so renders the Agent unable to operate or make further changes to its Artifact. Should an Agent seek to wind down, rather than deactivating these Primitives, it must follow the approved termination process defined in [A.1.13.5 - Agent Termination Protocol](fe833d0e-8451-45e0-84a5-229d6ec964a8).

###### A.2.3.1.2.4.2.1.3 - Prohibition On Deactivating Upkeep Rebate Primitive [Core]  <!-- UUID: 85121142-aa54-4957-b0e1-8f4294512c7e -->

The Upkeep Rebate Primitive is by default Globally Activated in all Scaffold Agent Artifacts; it is not possible to deactivate it.

###### A.2.3.1.2.4.2.1.4 - Prohibition On Deactivating Both Distribution Requirement And Market Cap Fee Primitives [Core]  <!-- UUID: 984dcacc-d242-4203-90c2-d5cf61c92702 -->

An Agent must always have either the Distribution Requirement Primitive or the Market Cap Fee Primitive Globally Activated; it is not possible to deactivate both.

###### A.2.3.1.2.4.2.2 - Global Primitive Reactivation [Core]  <!-- UUID: cb452f09-007a-4000-a37f-46e8be48c066 -->

An Agent may reactivate a Globally Inactive Primitive according to the governance process defined in its Root Edit Primitive. Reactivating the Primitive restores the Agent’s ability to create new instances (via proper Invocation) but does _not_ automatically revive previously deactivated instances. Each existing instance remains inactive unless separately reactivated through the appropriate governance process.

#### A.2.3.1.3 - Primitive Instance Status [Core]  <!-- UUID: 4531962c-9847-40d6-b534-8a3a301703d0 -->

The documents herein define Primitive Instance Status.

##### A.2.3.1.3.1 - Primitive Instance Status Definition [Core]  <!-- UUID: f507250e-8558-4692-914d-7760ea266a50 -->

Each valid Invocation of a Primitive causes the Agent Artifact to be updated with a specific instance of a Primitive. For example, each Invocation of the Token SkyLink Primitive launches a SkyLink deployment to a specific blockchain. The Agent may manage each Primitive instance independently (e.g., Activate or suspend it as circumstances change). A Primitive instance thus has its own Status or life cycle that is independent of the Primitive’s Global Activation Status.

##### A.2.3.1.3.2 - Instance Status Values [Core]  <!-- UUID: d3908a6c-a5b4-40d3-a982-89ad606a24d9 -->

The documents herein specify the potential values of the Status of an instance of a Primitive. An instance of a Primitive must always have exactly one of these values.

###### A.2.3.1.3.2.1 - Active Instance Status [Core]  <!-- UUID: dfd19e92-2660-4393-8dff-a3a7e4ad75ff -->

The instance Status of `Active` indicates that an instance of a Primitive is fully operational and may be used for its intended purpose by the Agent and potentially other parties. For example, a Token SkyLink deployment is active and can be used to bridge tokens between blockchains.

###### A.2.3.1.3.2.2 - Suspended Instance Status [Core]  <!-- UUID: 3e5de640-5bc2-4953-a233-913e3337b4bb -->

The instance Status of `Suspended` indicates that an instance of a Primitive was `Active` at one point in time and may be `Active` again, but is not currently operational. This may be due to the Primitive not meeting performance expectations (e.g. for an Allocation System instance), security issues, or due to failure of the Agent operating the Primitive to satisfy other requirements such as those specified in the Risk Capital or Asset Liability Management frameworks.

###### A.2.3.1.3.2.3 - Completed Instance Status [Core]  <!-- UUID: 82b88f94-b83a-432a-bb8e-4e726535156a -->

The instance Status of `Completed` indicates that an Instance of a Primitive has reached a terminal state and will not become `Active` again. This status applies in two cases: 1) a previously active Instance has permanently ceased operations; or 2) an Instance designed for a single Invocation has achieved its intended outcome and requires no further management (e.g., the one-time deployment of the Prime Transformation Primitive).

##### A.2.3.1.3.3 - Changing Primitive Instance Status [Core]  <!-- UUID: 263f3b28-9cd4-4ba2-b8e5-152c2ce0c050 -->

A Prime Agent that has a Globally Active Primitive may freely create (assuming the Primitive was properly Invoked), suspend, archive, or update individual instances of that Primitive, subject to the rules defined in the Agent Artifact and the Sky Core Atlas. For example, the Agent may run multiple Integration Boost instances in parallel (each with its own markets and configurations), toggling them on or off as needed, without affecting the underlying Integration Boost Primitive’s Global Activation Status. Changing a Primitive’s Instance-Level Status can be effected through the governance process defined in the Root Edit Primitive, or through an appropriately configured Omni Document. See [A.1.13.2.7.2 - Omni Document Process](26ec6b08-8187-44b4-abb3-aee3868161a4).

#### A.2.3.1.4 - Invocation of Primitive Instance [Core]  <!-- UUID: da763556-c316-431d-b57e-cc4df5a52fb8 -->

The documents herein define the process by which an Agent may Invoke instances of Sky Primitives. If the Invocation is valid, the Agent Artifact is upgraded and the Agent gains the Primitives’ specific functionality.

##### A.2.3.1.4.1 - Invocation Status [Core]  <!-- UUID: 83ac15ef-30e5-4958-95f4-a7bc2de10e97 -->

The documents herein define the Statuses assigned to an Invocation that is in progress.

##### A.2.3.1.4.2 - Required Inputs Into Sky Primitive [Core]  <!-- UUID: 316daff4-3260-45da-afde-eea3d357b9eb -->

To Invoke a Primitive, an Agent must supply all required inputs as defined in the Sky Core Atlas. Every Primitive instance abides by a standardized data model specified at the Sky Core level, ensuring that all Prime Agents, Executor Agents and other actors are able to submit and track the necessary data reliably.

###### A.2.3.1.4.2.1 - Required Inputs Submitted To Powerhouse [Core]  <!-- UUID: 3a8fe63b-a95d-4c6d-b8ae-48f4fe62e4c3 -->

The actual submission and handling of these data inputs occurs exclusively through the Powerhouse interface, which serves as the Sky ecosystem’s shared data infrastructure. Powerhouse thus becomes the canonical gateway for exchanging information with the Primitive, enforcing consistency in both the format of the data and the steps taken to Invoke (and later update) the Primitive.

##### A.2.3.1.4.3 - Validation of Primitive Inputs [Core]  <!-- UUID: c1e8985f-a21d-4264-b0e3-7cebee40e062 -->

Once the Agent has provided all required inputs to the relevant Primitive(s), the proposed Artifact Update undergoes review / validation by designated actors such as Operational Executor Facilitators. The identity and responsibilities of these actors are detailed in subsequent documents of this Article.

##### A.2.3.1.4.4 - Token Holder Vote [Core]  <!-- UUID: a06c8e7a-e20f-459a-99e3-a62a5c0c4fd1 -->

After the Primitive inputs have been validated, Agent token holders vote on whether to upgrade the Artifact with the Primitive(s).

##### A.2.3.1.4.5 - Formal Integration Of Primitives [Core]  <!-- UUID: 6948d758-ad79-47b8-8466-74c75ec9db9e -->

If the vote is successful, the Agent Artifact is officially upgraded with a Primitive Instance, which latter has its own independent Status that is distinct from the Primitive’s Global Activation Status. See [A.2.3.1.3 - Primitive Instance Status](4531962c-9847-40d6-b534-8a3a301703d0). This upgrade means that the respective Primitive(s) is formally integrated into the Agent’s Artifact and the Atlas as a whole; the Prime Agent can now operationalize the Primitive’s special functionality.

#### A.2.3.1.5 - Primitives [Core]  <!-- UUID: 947a5b27-d2dc-41e4-b6fd-696e35e2929d -->

The documents herein list the current Sky Primitives and set forth the process for amending them. Each Primitive is defined in more detail below.

##### A.2.3.1.5.1 - Current Primitives [Core]  <!-- UUID: 203b8c79-c7cf-4fcc-94e3-5bf42f791619 -->

The current Sky Primitives are:

- Genesis Primitives
   ◦ Agent Creation Primitive
   ◦ Prime Transformation Primitive
   ◦ Executor Transformation Primitive
   ◦ Agent Token Primitive

- Operational Primitives
   ◦ Executor Accord Primitive
   ◦ Root Edit Primitive
   ◦ Light Agent Primitive

- Ecosystem Upkeep Primitives
   ◦ Distribution Requirement Primitive
   ◦ Market Cap Fee Primitive
   ◦ Upkeep Rebate Primitive

- SkyLink Primitives
   ◦ Token SkyLink Primitive

- Demand Side Stablecoin Primitives
   ◦ Distribution Reward Primitive
   ◦ Integration Boost Primitive
   ◦ Pioneer Chain Primitive

- Supply Side Stablecoin Primitives
   ◦ Allocation System Primitive
   ◦ Junior Risk Capital Rental Primitive
   ◦ Asset Liability Management Rental Primitive

- Core Governance Primitives
   ◦ Core Governance Reward Primitive

##### A.2.3.1.5.2 - Amendments To Primitives [Core]  <!-- UUID: 1a46fd49-7b37-4a14-a311-eb1dbe947d85 -->

The set of available Sky Primitives may be amended in accordance with the governance processes established in the Sky Core Atlas.

### A.2.3.2 - Primitive Process Definition Schema [Section]  <!-- UUID: bdbb8ac9-d87e-4052-9e69-8267f38a54cf -->

Process Definitions function as the first-class objects through which Sky Primitives transform high-level governance logic into actionable document-driven workflows. All Sky Primitive Process Definitions are structured according to a common data schema - a set of fields that describe when they can start, how they run step by step, and what they must input or produce upon completion.

The documents herein define this data schema for Sky Primitive Process Definitions, which are applied to the universal specifications for each Sky Primitive. This common data schema aligns the entire ecosystem, while each Agent Artifact automatically references and extends the universal rules to incorporate the Agent’s unique Instance-level strategies, parameters and document-driven process flows.

At present, only the Distribution Reward Primitive and the Integration Boost Primitive specifications are structured using this schema. In future iterations of the Atlas, the schema will be applied to all Primitive specifications in this Article.

#### A.2.3.2.1 - Process Initiation Logic [Core]  <!-- UUID: 5df2043c-000a-4627-9c3a-2fdc12b78c47 -->

The documents herein define when a Process is triggered, and what conditions must be satisfied, if any, for the Process to properly initiate.

##### A.2.3.2.1.1 - Triggers [Core]  <!-- UUID: 134d8e80-6ec7-49fe-b7bb-6846694be11c -->

The presence of a Time-Based Trigger or Document Update Trigger for a given Process does not necessarily mean such Trigger is the sole means to initiate the Process. For example, an Atlas Document that is external to the Sky Primitives specifications may authorize a Facilitator to manually initiate a process.

###### A.2.3.2.1.1.1 - Time-Based Trigger [Core]  <!-- UUID: 1040dd2b-e7f8-4f68-b6c6-4b910f394a5a -->

This field defines the triggering date/time for recurring or scheduled Processes.

###### A.2.3.2.1.1.2 - Document Update Triggers [Core]  <!-- UUID: 16be342d-0584-4092-9943-97a8c4eeb672 -->

Document Update Triggers are a type of gating condition that automatically or deterministically compels initiation of a Process in response to a specific Core Atlas or Agent Artifact Document Update in a previous Process Definition.

Once the specified Atlas or Artifact Document Update occurs (and assuming any specified Dependencies are also met), the Process must be initiated.

If no such deterministic Document Update-based trigger exists for a Process to initiate, this field is set to "None."

##### A.2.3.2.1.2 - Dependencies [Core]  <!-- UUID: 64bec5dc-e288-4c8e-b638-c7180a92aca9 -->

Dependencies are gating conditions that must be satisfied for the Process to be able to proceed, regardless of a triggering event.

Examples of Dependencies include actors possessing suitable permissions, or a key stakeholder consenting to move forward.

If a trigger has occurred, but Dependencies are unmet, the Process cannot proceed.

#### A.2.3.2.2 - Process Flow [Core]  <!-- UUID: 6964c2d4-2994-487b-b68a-f1df5fa916f7 -->

This field describes the step-by-step operational procedure that occurs once a Process is properly initiated. A step can reference specific Core Atlas or Artifact Documents and broadly describe how their state is manipulated and decisions are made. More granular specifications regarding Document state changes are defined in the `Required Primitive Inputs` schema component [A.2.3.2.3 - Required Primitive Inputs](1474b30b-7e2b-4c9a-8624-3c2c5f53abc8). Process flow steps can both consume and produce relevant Document data.

#### A.2.3.2.3 - Required Primitive Inputs [Core]  <!-- UUID: 1474b30b-7e2b-4c9a-8624-3c2c5f53abc8 -->

This field specifies the Agent Artifact Documents and their associated fields that must be manipulated using the Powerhouse interface as part of a Process. If any of the required Inputs is missing or incorrect, the Process cannot be completed.

##### A.2.3.2.3.1 - Sequential Stages [Core]  <!-- UUID: e9422783-6196-4117-9099-b5ec0c338c05 -->

Some Processes require Primitive Inputs that are organized into multiple sequential stages (also called "Input stages"). Each Input stage must be completed before progressing to the next, ensuring that all dependencies and validations are met in order. Once an Input stage is completed, the subsequent Input stage is initiated automatically, continuing in this manner until all stages have been finished. 

Upon completing the final Primitive Input stage, the Process Definition transitions to the `Required Outputs` schema component; this component defines the necessary updates to Sky Core Atlas or Agent Artifact Documents.

###### A.2.3.2.3.1.1 - Required Output Trigger [Core]  <!-- UUID: 9c4f4cad-5124-44d8-b19e-bd931fae7963 -->

Where a Process Definition has more than one set of `Required Outputs`, with each set corresponding to (or "triggered by") a particular Input stage, the `Required Primitive Inputs` schema component must explicitly correlate each Input stage with the `Required Outputs` it triggers. See [A.2.3.2.4.1 - Multiple Required Outputs And Their Respective Input Stage or Mutually Exclusive Pathway](10c53693-4784-40ad-a8c6-fd2551f14280).

##### A.2.3.2.3.2 - Mutually Exclusive Pathways [Core]  <!-- UUID: 926cd44b-e26c-4ae9-9091-d97c362d7e29 -->

Some Processes require Primitive Inputs that are organized into two or more mutually exclusive pathways (also "mutually exclusive Input pathways"). Once a pathway is chosen—either manually or automatically via the application of a defined decision or condition—the Process follows that pathway through to completion, rendering the other pathways inapplicable.

###### A.2.3.2.3.2.1 - Required Output Trigger [Core]  <!-- UUID: a61d4797-9a1f-455c-8fe1-b62164e702b3 -->

When multiple "sets" of `Required Outputs` exist, with each set corresponding to (or "triggered by") a particular Mutually Exclusive Input Pathway, the `Required Primitive Inputs` schema component must explicitly correlate each Mutually Exclusive Input Pathway with the `Required Outputs` it triggers. Because the pathways are mutually exclusive, only the Required Output set associated with the selected Pathway will be executed. The other Output sets remain inactive.

#### A.2.3.2.4 - Required Outputs [Core]  <!-- UUID: dee40c3b-2f89-44c6-8813-c48888df08a7 -->

This field specifies the particular Sky Core Atlas and/or Agent Artifact Documents that must be updated as an end result of a Process.

Where applicable, a Document Update can serve as a "trigger" that deterministically compels another Process Definition to be initiated by a system or actor. The `Trigger - Process` field links to the respective Process Definition that is triggered by the Required Output.

Some processes do not need formal "Required Outputs" because the only process flow step is a simple update of an Artifact Document. In these edge cases, the change specified in `Required Primitive Inputs` (e.g., toggling a field to Globally Activate a Primitive) fully completes the process, effectively completing it in a single step. Once the designated Document and field are updated as prescribed, the Process is considered finalized.

##### A.2.3.2.4.1 - Multiple Required Outputs And Their Respective Input Stage or Mutually Exclusive Pathway [Core]  <!-- UUID: 10c53693-4784-40ad-a8c6-fd2551f14280 -->

Where a Process Definition has more than one set of Required Outputs, and each set corresponds to (or is "triggered by") either a specific Input stage or a specific Mutually Exclusive Input Pathway, the Process Definition’s `Required Primitive Input` field must define which `Required Output` set is Invoked upon completion of that stage or pathway.

1. **For Sequential Stages**
When multiple sequential stages exist, each stage’s successful completion triggers its corresponding Required Output set. As subsequent stages are completed in turn, each triggers its own distinct Required Outputs, ensuring that all designated outputs eventually execute in sequence.

2. **For Mutually Exclusive Pathways**
If the Required Primitive Input process instead (or additionally) involves mutually exclusive paths, once a pathway is chosen—either manually or automatically by a specified condition—only the Required Output set tied to that pathway is applied. Outputs associated with the unselected/unexecuted pathways remain inactive.

##### A.2.3.2.4.2 - Agent Artifact Document Specification [Core]  <!-- UUID: 3b3e537c-4989-4674-94bc-05928146ab42 -->

In the Sky Primitives Data Schema, references to an Agent Artifact Document are made in terms of the generic Document type. See [A.1.2.2.2 - List Of Document Types And Their Specifications](428b7f2e-30b0-4119-a10a-9c3496f19bd2). In practice, each Agent has its own Instance of that Document type in its Artifact. Thus, when a Primitive’s process flow indicates that an Agent Artifact Document must be updated, it is to be interpreted as referring to the _specific Instance_ of that Document type in the Prime Agent’s Artifact.

### A.2.3.3 - Prerequisites For Activating Agent Creation Primitive [Section]  <!-- UUID: 9204bcaf-cfec-4f49-a115-31fad73ebd62 -->

The Agent Creation Primitive is the first Sky Primitive that must be activated by prospective Agent founders. Because an Agent Artifact does not yet exist at this stage, the prerequisite requirements set forth herein must be met, including off-chain obligations and governance outputs. Only after satisfying these prerequisites does the Agent Creation Primitive become accessible to the prospective founder.

#### A.2.3.3.1 - Agent Inputs [Core]  <!-- UUID: df925d98-2e73-4b26-859b-33caa8865f0f -->

The prospective Agent founder must deploy the required startup capital and pay the Agent creation fee.

##### A.2.3.3.1.1 - Capital Injection [Core]  <!-- UUID: bed7471a-54aa-4167-88dd-22ebd63f8827 -->

The required capital and the process for deploying it will be specified in a future iteration of the Atlas.

##### A.2.3.3.1.2 - Creation Fee [Core]  <!-- UUID: 708ad6b6-8e4a-46b3-9848-523d00a57420 -->

The prospective founder must pay the required creation fee. The required fee and the process for paying it will be specified in a future iteration of the Atlas.

#### A.2.3.3.2 - Core GovOps Outputs [Core]  <!-- UUID: e1cef578-801c-4905-a88b-e9703b048d2a -->

After the prospective Agent founder deploys the required startup capital and pays the Agent creation fee, Core GovOps creates a Proto-Agent and sets up a Scaffold Agent Artifact.

##### A.2.3.3.2.1 - Proto-Agent Creation [Core]  <!-- UUID: 1f577977-2f4c-41a0-a3ba-f09fc77b8d09 -->

Core GovOps creates a Proto-Agent with no specific functionality in the ecosystem.

##### A.2.3.3.2.2 - Scaffold Artifact Setup [Core]  <!-- UUID: f55fdc70-dfe4-4c52-9be4-10bf3a6dc990 -->

Core GovOps prepares a Scaffold Agent Artifact  ("Scaffold Artifact") containing all Sky Primitives. In the Scaffold Artifact, the Upkeep Rebate Primitive is globally activated by default. See [A.2.3.1.2.2 - Initial Primitive Global Activation Status](377150b3-d64b-4436-ab6d-758b05d82f26). All other Primitives are initially set to `Inactive`. The Scaffold Artifact also includes an initial set of Omni Documents that provide general information about the Agent and organize the various Sky Primitive Instance Configuration Documents. Core GovOps must add the Scaffold Artifact to the Atlas’ Agent Artifact Scope.

##### A.2.3.3.2.3 - Address Deploying Capital [Core]  <!-- UUID: 39d1cae8-a070-47a2-b69b-96e0f4f6a080 -->

The address deploying the start-up capital is assigned `Founder Access` to the Scaffold Agent Artifact. See [A.2.3.1.1.3.2 - Founder Access](a4f65994-2526-4522-a986-cd444a5cb896).

### A.2.3.4 - Genesis Primitives [Section]  <!-- UUID: 3d5e3668-8333-4908-adcc-5784cfe7f6b5 -->

Genesis Primitives are a category of Primitives addressing different aspects of initial Agent setup—such as Agent creation, token launch and configuration, and transformation pathways.

#### A.2.3.4.1 - Agent Creation Primitive [Core]  <!-- UUID: 82b95f6d-4883-4f08-ac3a-9d8189013fbe -->

This Primitive may only be Invoked after the prospective Agent founder meets the prerequisites defined in [A.2.3.3 - Prerequisites For Activating Agent Creation Primitive](9204bcaf-cfec-4f49-a115-31fad73ebd62), resulting in the creation of a Proto-Agent. Invoking the Agent Creation Primitive allows the Proto-Agent to establish its identity by declaring its name, as well as articulate its intended vision, business model or ecosystem goals.

##### A.2.3.4.1.1 - Agent Creation Primitive Process Definition [Core]  <!-- UUID: 46e64020-f283-48a6-b327-75ea15927ee4 -->

The documents herein define the Process Definition for initial setup and ongoing management of an Instance of the Agent Creation Primitive.

###### A.2.3.4.1.1.1 - Agent Creation Instance Setup Process [Core]  <!-- UUID: 754e1599-28d7-499a-b68f-e2155e87105a -->

The documents herein define the process for setting up an Instance of the Agent Creation Primitive.

###### A.2.3.4.1.1.1.1 - Founder Inputs [Core]  <!-- UUID: cfde405d-e7e1-48eb-b044-3e9514c0aa96 -->

The Founder uses the Powerhouse interface to input the Agent's name and an introduction outlining the Agent's vision.

###### A.2.3.4.1.1.1.2 - Validation [Core]  <!-- UUID: d2b0f57b-1596-4355-9c63-aec6466cf316 -->

Core GovOps validates the Founder’s inputs. This includes verifying that all of the documents created by the Founder using Founder Access are well-specified, that the documents are Aligned, and that all necessary Primitives to complete setup have been Activated. The necessary Primitives are the Agent Creation, Prime/Executor Transformation, Agent Token, Executor Accord, and Root Edit Primitives. In addition, at least one of the Distribution Requirement or the Market Cap Fee Primitives must be Activated. (See [A.2.3.1.1.3.1 - Founder Required Primitive Activation](1a48e833-d960-4bdf-8f67-0f9d9307e00d).) After confirming these conditions, Core GovOps creates a Genesis Account and a SubProxy Account for the Agent.

###### A.2.3.4.1.1.1.3 - Official Update Of Artifact [Core]  <!-- UUID: c73a1815-b2dc-4cec-9ef4-ae6e6aabf633 -->

After successful validation, the Agent Creation Primitive is considered successfully Invoked, and the Agent Artifact is officially upgraded to reflect an Agent Creation Primitive Instance, with a Status of `Completed`.

###### A.2.3.4.1.1.2 - Agent Creation Instance Ongoing Management [Core]  <!-- UUID: b7238f7c-253d-4881-bbb8-10e3ca2d62ba -->

The documents herein define the process for the ongoing management of an Instance of the Agent Creation Primitive.

###### A.2.3.4.1.1.2.1 - Agent Creation Primitive Results In One-Time Creation [Core]  <!-- UUID: 1ca2f5f3-1be7-4855-bbb7-49630e7e2ae6 -->

Because the Agent Creation Primitive is deployed solely to effect the one-time creation of the Agent, no further management process is needed post-deployment.

##### A.2.3.4.1.2 - Agent Creation Primitive Input Requirements [Core]  <!-- UUID: 7a7a2631-e5e2-4b63-8f2b-45ecaec7af2e -->

The documents herein define the required inputs for a valid Invocation of the Agent Creation Primitive. If any input is noncompliant or omitted, the Primitive will be invalidated.

###### A.2.3.4.1.2.1 - Global Activation Status [Core]  <!-- UUID: f9de4749-2bf4-4871-a5a8-6fb6849af7ad -->

The Agent Creation Primitive must be Globally Activated.

###### A.2.3.4.1.2.2 - Agent Name And Introduction [Core]  <!-- UUID: c7e7507e-4d57-4842-932c-88cf232a53a8 -->

The Agent Creation Primitive must specify the Agent’s Name and provide a brief overview of its vision or business model.

###### A.2.3.4.1.2.3 - Agent SubProxy Account [Core]  <!-- UUID: 585dc747-65f1-4443-b61b-9779031f9258 -->

The Agent Creation Primitive must specify the SubProxy address of the Agent. This field is populated by Core GovOps. The SubProxy is an account that serves as the Agent’s treasury. The SubProxy Account is controlled by Sky Governance.

###### A.2.3.4.1.2.4 - Agent Genesis Account [Core]  <!-- UUID: 761966db-e9db-41f8-a9fe-cf8b0c1a7d26 -->

The Agent Creation Primitive must designate the Genesis Account.  This field is populated by Core GovOps. The Genesis account initially controls 100% of the tokens of the Agent. The Genesis Account is initially controlled by the Agent Founder.

#### A.2.3.4.2 - Prime Transformation Primitive [Core]  <!-- UUID: 81411106-fd6d-4f9c-b3ae-7af7b5e62482 -->

Prior to Activating this Primitive, a Proto-Agent has been created, meaning it has not yet adopted any specialized role. Since a Proto-Agent cannot perform actions in the Sky Ecosystem, it must first transform into either a Prime Agent or Executor Agent to gain functionality. The Prime Transformation Primitive defined herein allows an Agent to transform into a Prime Agent, subject to certain conditions.

##### A.2.3.4.2.1 - Prime Transformation Primitive Process Definition [Core]  <!-- UUID: ddfbb811-94f5-43bb-bf5e-a9bab2be046d -->

The documents herein define the Process Definition for initial setup and ongoing management of an Instance of the Prime Transformation Primitive.

###### A.2.3.4.2.1.1 - Prime Transformation Primitive Setup Process [Core]  <!-- UUID: 3f1824b6-5325-43ac-b3d5-151fb0f55dec -->

The documents herein define the process for setting up the Prime Transformation Primitive.

###### A.2.3.4.2.1.1.1 - Agent Inputs [Core]  <!-- UUID: aef13d1b-08d6-4c89-8858-65f8acbe4adc -->

The Proto-Agent must use the Powerhouse interface to input their desired Agent Type into the Primitive. For the Prime Transformation Primitive process, the Proto-Agent must specify ‘Prime Agent’ as their desired Agent Type.

###### A.2.3.4.2.1.1.2 - Validation [Core]  <!-- UUID: 43598845-989e-44fc-8cb4-c60b67fd1f28 -->

Core GovOps validates the Proto-Agent’s inputs, namely, the Agent Type.  Additionally, Core GovOps performs a further review to confirm that all the documents created by the Founder using Founder Access are well-specified, that the documents are Aligned, and that all necessary Primitives have been Activated. The necessary Primitives are the Agent Creation, Prime/Executor Transformation, Agent Token, Executor Accord, and Root Edit Primitives. In addition, at least one of the Distribution Requirement or the Market Cap Fee Primitives must be Activated. (See [A.2.3.1.1.3.1 - Founder Required Primitive Activation](1a48e833-d960-4bdf-8f67-0f9d9307e00d).)

###### A.2.3.4.2.1.1.3 - Official Update Of Artifact [Core]  <!-- UUID: 2182141b-a2bc-46bc-b9a6-2cb62e55b302 -->

After successful validation, the Prime Transformation Primitive is considered successfully Invoked, and the Agent Artifact is officially upgraded to reflect a Prime Transformation Primitive Instance, with a Status of `Completed`.

###### A.2.3.4.2.1.2 - Prime Transformation Primitive Ongoing Management [Core]  <!-- UUID: c1cae3bb-283e-44bf-9860-b721a1625bae -->

The documents herein define the process for the ongoing management of an Instance of the Prime Transformation Primitive.

###### A.2.3.4.2.1.2.1 - Prime Transformation Primitive Results In One-Time Creation [Core]  <!-- UUID: 248bfb90-8bd8-410a-86d3-527e355eca43 -->

Because the Prime Transformation Primitive is deployed solely to effect the one-time transformation of the Proto-Agent, no further management process is needed post-deployment.

##### A.2.3.4.2.2 - Prime Transformation Primitive Input Requirements [Core]  <!-- UUID: 062b9275-9778-4f24-b0e5-bccf9129c179 -->

The documents herein define the required inputs for a valid Invocation of the Prime Transformation Primitive.  If any input is noncompliant or omitted, the Primitive will be invalidated.

###### A.2.3.4.2.2.1 - Global Activation Status [Core]  <!-- UUID: cd67fe26-d82d-4859-be8d-36f1a9c42a65 -->

The Prime Transformation Primitive must be Globally Activated.

###### A.2.3.4.2.2.2 - Prime Agent Type [Core]  <!-- UUID: 857468db-7ff3-4986-b808-a7cd9854000a -->

The Prime Transformation Primitive must specify the Prime Agent’s Type, e.g., that it is a Prime Agent.

#### A.2.3.4.3 - Executor Transformation Primitive [Core]  <!-- UUID: 2f249be5-8edb-41e4-b429-734e1ba2cbc7 -->

The Executor Transformation Primitive allows an Agent to transform into an Executor Agent, subject to certain conditions.

#### A.2.3.4.4 - Agent Token Primitive [Core]  <!-- UUID: 2047c361-db28-4952-a70c-83d07b562064 -->

The Agent Token Primitive enables Agents to define, mint, and distribute their governance tokens including foundation allocations, token rewards, and airdrops.

##### A.2.3.4.4.1 - Agent Token Primitive Process Definition [Core]  <!-- UUID: f7a81be7-057c-4a05-97ab-78a37c674010 -->

The documents herein define the Process Definition for initial setup and ongoing management of an Instance of the Agent Token Primitive.

###### A.2.3.4.4.1.1 - Agent Token Primitive Setup Process [Core]  <!-- UUID: 3e49628d-1f82-4980-9855-75ad5e86aa54 -->

The documents herein define the process for setting up the Agent Token Primitive.

###### A.2.3.4.4.1.1.1 - Agent Inputs [Core]  <!-- UUID: f74588a5-cbde-4635-9e18-bca3d9c80612 -->

The Agent must use the Powerhouse interface to input key data into the Agent Token Primitive, including token name, ticker, symbol, genesis supply, total supply, distribution rules, emissions schedule, pending token address and token admin address. The token admin address should be the Agent SubProxy Account. The Agent must also specify whether token emissions beyond the current supply have been irreversibly disabled.

###### A.2.3.4.4.1.1.2 - Validation [Core]  <!-- UUID: 6f63137d-5385-46e9-96ac-fc16a568f54a -->

Core GovOps validates the Agent’s inputs.

###### A.2.3.4.4.1.1.3 - Official Update Of Artifact [Core]  <!-- UUID: 309e17ed-c75a-48f5-859f-70a5cb29a1f8 -->

After successful validation, the Agent Token Primitive is considered successfully Invoked. The Agent Artifact is officially upgraded to reflect an Agent Token Primitive Instance, with a Status of `Active`.

###### A.2.3.4.4.1.1.4 - Core GovOps Output [Core]  <!-- UUID: d26166c3-b07f-4583-8303-051a90468ed3 -->

Upon successful validation, the token contract can now be deployed on-chain by Core GovOps. The minted supply must be allocated as specified in the Agent Token Primitive Instance. The Primitive is automatically updated to replace the pending token address with the actual token address.

###### A.2.3.4.4.1.2 - Agent Token Primitive Ongoing Management [Core]  <!-- UUID: d8f6b024-f4f8-4897-99f2-d433137c8850 -->

The documents herein define the process for the ongoing management of an Instance of the Agent Token Primitive.

###### A.2.3.4.4.1.2.1 - Agent Token Primitive Results In One-Time Creation [Core]  <!-- UUID: 0489781a-243c-4704-86e5-efe422cdd41c -->

Because the Agent Token Primitive is deployed solely to create a one-off Token for an Agent, no further management process is needed post-deployment.

##### A.2.3.4.4.2 - Agent Token Primitive Input Requirements [Core]  <!-- UUID: 9d88d70e-7dfc-42f3-9d58-0d2a905861fd -->

The documents herein define the required inputs for a valid Invocation of the Agent Token Primitive. If any input is noncompliant or omitted, the Primitive will be invalidated.

###### A.2.3.4.4.2.1 - Global Activation Status [Core]  <!-- UUID: fb858d4e-5d42-4496-807b-979e1946f8f0 -->

The Agent Token Primitive must be Globally Activated.

###### A.2.3.4.4.2.2 - Agent Token Name [Core]  <!-- UUID: 98fa133d-878a-4337-9d47-ad01ef19b9bb -->

The Agent Token Primitive must specify the name of the token.

###### A.2.3.4.4.2.3 - Agent Token Symbol [Core]  <!-- UUID: 46bbc08e-dcfc-4ed5-9e2f-3e78fd8735f9 -->

The Agent Token Primitive must specify the symbol of the token.

###### A.2.3.4.4.2.4 - Agent Token Genesis Supply [Core]  <!-- UUID: ed342c6e-15ae-4c95-ad4e-4702c27eba62 -->

The Agent Token Primitive must specify the genesis supply of the token.

###### A.2.3.4.4.2.5 - Agent Token Address [Core]  <!-- UUID: 745126ca-1d64-461e-b8b9-603216d7e74b -->

The Agent Token Primitive must specify either the pending or permanent address of the token (depending on whether the Primitive has been successfully Invoked).

###### A.2.3.4.4.2.6 - Agent Token Admin [Core]  <!-- UUID: 70e08dd1-8a2d-441b-95c4-92bce3bd37e8 -->

The Agent Token Primitive must specify the Admin of the token.

###### A.2.3.4.4.2.7 - Agent Token Emissions [Core]  <!-- UUID: 0f71bdc3-f18d-4e6f-8041-d73026a91d27 -->

The Agent Token Primitive must specify whether token emissions beyond the current supply have been irreversibly disabled. Once Disabled is set to `True`, the action cannot be undone by the Agent. Sky Governance retains the ability to revert the Disabled setting where the Agent is in violation of Risk Capital requirements and emissions are required by the Risk Framework.

###### A.2.3.4.4.2.8 - Agent Token Distribution Rules [Core]  <!-- UUID: 3d43ba11-ac87-41a5-a98d-c80071aaf1eb -->

The Agent Token Primitive must specify the process for distributing the initial token supply.

### A.2.3.5 - Operational Primitives [Section]  <!-- UUID: 0192ec95-9207-480e-8c51-88d2a1da95ad -->

Operational Primitives are a category of Primitives enabling the Agents’ own operation and governance and AI features, as well as the ability to create derivative Light Agents.

#### A.2.3.5.1 - Executor Accord Primitive [Core]  <!-- UUID: 88017877-3ec1-4c43-a035-6bebdf11d9bb -->

The Executor Accord Primitive is the foundational mechanism that allows Prime Agents to operate autonomously according to the strategy specified in their Agent Artifacts with automated operational insurance provided by separate Operational Executor Agents that delegate the work to GovOps actors.

##### A.2.3.5.1.1 - Executor Accord Primitive Process Definition [Core]  <!-- UUID: b2b42304-f715-4cc2-8fbf-68c794876386 -->

The documents herein define the Process Definition for initial setup and ongoing management of an Instance of the Executor Accord Primitive.

###### A.2.3.5.1.1.1 - Executor Accord Primitive Setup Process [Core]  <!-- UUID: af7c2593-b397-4fff-9b81-3d640508a163 -->

The documents herein define the process for setting up an Instance of the Executor Accord Primitive.

###### A.2.3.5.1.1.1.1 - Agent Inputs [Core]  <!-- UUID: d082d5de-a0b2-4441-8ba8-06d1e5fe2aed -->

The Prime Agent and Operational Executor Agent must come to a consensus about the details of the Executor Accord. These details must be entered into the Powerhouse interface along with independent confirmation from each Agent that they agree to those terms.

###### A.2.3.5.1.1.1.2 - Validation [Core]  <!-- UUID: dad19a7b-769c-43e3-a7b9-ce91d267c3b1 -->

Core GovOps validates the Agent’s inputs, ensuring that the terms of the Executor Accord are reasonably specific.

###### A.2.3.5.1.1.1.3 - Official Update Of Artifact [Core]  <!-- UUID: 458ec13a-5352-4720-a6eb-70f1bec6cb20 -->

After successful validation, the Executor Accord Primitive is considered successfully Invoked. The Agent Artifact is officially upgraded to reflect an Executor Accord Primitive Instance, with a Status of `Active`.

###### A.2.3.5.1.1.1.4 - Operational GovOps Takes Over Operational Duties [Core]  <!-- UUID: 8179ca9b-2875-4f7c-9573-9ed6fc5f91cf -->

Upon successful validation, the Prime Agent has a documented relationship with an Executor Agent and so Core GovOps will no longer perform validation of the Agent’s Primitive inputs. Instead, the Operational GovOps associated with the Executor Agent specified in the Executor Accord will carry out operational tasks on behalf of the Prime Agent.

###### A.2.3.5.1.1.2 - Executor Accord Primitive Ongoing Management [Core]  <!-- UUID: 8fe7d3f4-51bc-41bb-95b0-6dfe26fab562 -->

The documents herein define the process for the ongoing management of an Instance of the Executor Accord Primitive.

##### A.2.3.5.1.2 - Executor Accord Primitive Required Inputs [Core]  <!-- UUID: 5785964a-75ca-4109-af39-5ae1e872b89d -->

The documents herein define the required inputs for a valid Invocation of the Executor Accord Primitive. If any input is noncompliant or omitted, the Primitive will be invalidated and the Executor Accord will not be set up.

###### A.2.3.5.1.2.1 - Executor Accord Primitive Activation Status [Core]  <!-- UUID: 7dcc0b40-f577-4590-92d2-62697bfff33a -->

The Executor Accord Primitive must be Globally Activated.

###### A.2.3.5.1.2.2 - Executor Accord Terms [Core]  <!-- UUID: 2ac80f9d-744d-4dde-9ecd-9497642716dc -->

The Executor Accord Primitive must include the terms of the Executor Accord between the Prime Agent and Operational Executor Agent.

###### A.2.3.5.1.2.3 - Agent Agreement [Core]  <!-- UUID: bf03d18d-e5f9-434c-9aff-f6f0679f5746 -->

The Executor Accord Primitive must include independent confirmation from each Agent that they agree to the terms of the Executor Accord.

#### A.2.3.5.2 - Root Edit Primitive [Core]  <!-- UUID: 78488c6b-d77f-4344-b954-476e415a2c7d -->

The Root Edit Primitive allows Prime Agents, through a token holder vote, to direct the Operational Executor Agent specified in the Executor Accord Primitive to directly modify the Prime Agent Artifact.

##### A.2.3.5.2.1 - Root Edit Primitive Process Definition [Core]  <!-- UUID: f543db65-dac7-494d-bd0d-a24bf600157d -->

The documents herein define the Process Definition for initial setup and ongoing management of an Instance of the Root Edit Primitive.

###### A.2.3.5.2.1.1 - Root Edit Primitive Setup Process [Core]  <!-- UUID: 1fbca4e2-e89f-4819-afba-e58702ca2ed9 -->

The documents herein define the process for setting up an Instance of the Root Edit Primitive.

###### A.2.3.5.2.1.1.1 - Agent Inputs [Core]  <!-- UUID: 131380cc-df22-4862-a275-49e6a7302cf8 -->

The Agent must use the Powerhouse interface to specify the process by which Root Edits occur. See [A.1.13.2.7 - Artifact Edit Processes](2be8d2f0-bf02-4aa1-ad37-afb7a811a3b8).

###### A.2.3.5.2.1.1.2 - Validation [Core]  <!-- UUID: 2a466974-af55-4d3f-84a5-7ac840ffb620 -->

Core GovOps validates the Agent’s inputs.

###### A.2.3.5.2.1.1.3 - Official Update Of Artifact [Core]  <!-- UUID: 3a95c852-efc0-43aa-b4fe-358332aaaf74 -->

After successful validation, the Root Edit Primitive is considered successfully Invoked. The Agent Artifact is officially upgraded to reflect a Root Edit Primitive Instance, with a Status of `Active`.

###### A.2.3.5.2.1.2 - Root Edit Primitive Ongoing Management [Core]  <!-- UUID: 023847b4-9987-449f-9f2c-6c719856295f -->

The documents herein define the process for the ongoing management of an Instance of the Root Edit Primitive.

###### A.2.3.5.2.1.2.1 - Root Edit Primitive Artifact Edit Proposal [Core]  <!-- UUID: 71ae684b-da79-4ece-ab38-91a498b3bdb1 -->

The process for using the Root Edit Primitive begins with a party presenting a proposal for an Artifact Edit. The Root Edit Primitive specifies the requirements to submit a proposal, the required form of the proposal, and any other prerequisites that must be satisfied prior to the proposal being voted on.

###### A.2.3.5.2.1.2.2 - Root Edit Primitive Review By Operational Facilitator [Core]  <!-- UUID: 823cad54-4438-4ec3-9e13-d2624795fabd -->

The Operational Facilitator reviews the proposal. This review encompasses two aspects. First, the Operational Executor reviews the proposal for alignment with the Atlas. Second, the Facilitator reviews the proposal for compliance with any requirements set out in the Root Edit Primitive for the Agent, such as eligible actors to submit proposals, form of the proposal, or required time for review before submitting a proposal.

###### A.2.3.5.2.1.2.3 - Root Edit Primitive Voting [Core]  <!-- UUID: 7e4574c0-a83c-4e3f-bfa6-1f66db2a0aed -->

If the Operational Facilitator concludes that the proposal is aligned with the Atlas and consistent with the process specified in the Root Edit Primitive, then the Operational Facilitator moves forward with conducting the vote. The Root Edit Primitive specifies how the vote should be conducted (e.g. on-chain or off-chain), the time period over which voting should occur, and other relevant parameters for the vote such as quorum and approval requirements.

###### A.2.3.5.2.1.2.4 - Root Edit Primitive Artifact Update [Core]  <!-- UUID: 34d06691-afc4-4ade-9ada-ad180c2aef0f -->

After the voting period ends, the Operational Facilitator reviews the outcome of the vote. If the vote is successful, the Operational Facilitator actions the Artifact Edit in the Powerhouse system. In either case, the Operational Facilitator records the outcome of the vote, including all pertinent materials, in the Powerhouse system.

##### A.2.3.5.2.2 - Root Edit Primitive Required Inputs [Core]  <!-- UUID: cec43505-2bf3-48ce-81d9-852f65edc468 -->

The documents herein define the required inputs for a valid Invocation of the Root Edit Primitive. If any input is noncompliant or omitted, the Primitive will be invalidated and the Root Edit Primitive will not be set up.

###### A.2.3.5.2.2.1 - Root Edit Primitive Activation Status [Core]  <!-- UUID: 416b0a3a-fa97-40ad-8b58-50650f4a956b -->

The Root Edit Primitive must be Globally Activated.

###### A.2.3.5.2.2.2 - Artifact Edit Process [Core]  <!-- UUID: dc7fd889-80dd-4ac0-b807-f01ab440ba8a -->

The Root Edit Primitive must specify the process by which updates to the Agent Artifact may be made by Agent token holder vote. The details of this process may be specified by the Agent, subject to the following conditions: (1) Agent token holders must vote to approve Artifact Edit proposals, (2) the Operational Facilitator must review each proposal for alignment and conformance with the process specified in the Root Edit Primitive, (3) the vote must be conducted by the Operational Facilitator, and (4) the Operational Facilitator must action the Artifact Edit if the vote passes. The process definition must include the elements included in the documents herein.

###### A.2.3.5.2.2.2.1 - Proposal Format [Core]  <!-- UUID: 7a473c50-f947-481b-8466-468b8d1708d9 -->

The Root Edit Primitive must specify the required format of proposals.

###### A.2.3.5.2.2.2.2 - Actors Eligible To Submit Proposals [Core]  <!-- UUID: b5e21f94-5239-44c5-8eec-b5a5e6e05cf9 -->

The Root Edit Primitive must specify the requirements for actors to be eligible to submit proposals.

###### A.2.3.5.2.2.2.3 - Requirements For Proposals To Be Included In Vote [Core]  <!-- UUID: 0580f68b-06b4-41b0-b091-c88c8e6a0f81 -->

The Root Edit Primitive must specify the requirements for proposals to be included in a vote, such as any required review period or any reviews that must be conducted by other parties such as expert advisors.

###### A.2.3.5.2.2.2.4 - Voting Period [Core]  <!-- UUID: 0ca3f0ee-92ee-420e-915d-37aae1ab4848 -->

The Root Edit Primitive must specify the period over which voting should occur.

###### A.2.3.5.2.2.2.5 - Quorum Requirement [Core]  <!-- UUID: d4ad86a0-ec69-49b6-a794-6826cde3be0e -->

The Root Edit Primitive must specify the percent of outstanding tokens that must participate in a vote for it to be considered valid.

###### A.2.3.5.2.2.2.6 - Approval Threshold [Core]  <!-- UUID: 0c36f76d-17de-4958-bace-d1b1d7473982 -->

The Root Edit Primitive must specify the percent of tokens participating in the vote that must vote in favor of the proposal for it to be approved.

###### A.2.3.5.2.2.2.7 - Handling Of Emergency Or Urgent Situations [Core]  <!-- UUID: dda24bc9-d7e3-4593-9cdd-afe62355d198 -->

The Root Edit Primitive must specify any procedures for expedited voting in emergency or urgent situations.

###### A.2.3.5.2.2.2.8 - Special Voting Processes [Core]  <!-- UUID: b6fa5678-0b62-4607-b0e9-b3d27f57f689 -->

The Root Edit Primitive must specify any exceptions to the general process, such as subject matter requiring supermajority approval.

##### A.2.3.5.2.3 - Short-Term Limitations On Usage Of Root Edit Primitive [Core]  <!-- UUID: 459f257e-ef68-43b0-8d39-7836d98067ff -->

In the short term, usage of the Root Edit Primitive by Prime Agents will be limited as specified in the documents herein.

###### A.2.3.5.2.3.1 - Limitations On Usage Of Root Edit Primitive Prior To Tokens Being Publicly Held [Core]  <!-- UUID: 8c15762a-ea7e-4c6d-9089-60d30c219c0f -->

Until the tokens of a Prime Agent are Publicly Held, as defined in [A.2.3.5.2.3.1.1 - Publicly Held Definition](d6265f88-d2d0-457b-8958-a3c22f9a5718), the Root Edit Primitive will not be operational. Instead, if a Prime Agent wishes to edit its Agent Artifact, it must use the customary Atlas Edit Proposal processes specified in the Sky Core Atlas at [A.1.10.2 - Atlas Edit Weekly Cycle](14e99d92-71fc-44d9-9dbf-933bce2e1b32) or [A.1.11.2 - Atlas Edit Monthly Cycle](d2cbddd2-58ef-4311-a71d-d2c340364cb5). The process for Prime Agents to use the Atlas Edit Proposal process is further specified in [A.2.3.5.2.3.2 - Atlas Edit Proposal Process For Prime Agents](364e52eb-4529-46a9-9852-edaaab88baeb).

###### A.2.3.5.2.3.1.1 - Publicly Held Definition [Core]  <!-- UUID: d6265f88-d2d0-457b-8958-a3c22f9a5718 -->

The tokens of a Prime Agent shall be deemed Publicly Held if they are held by at least 2,000 Public Holders who collectively own 10% or more of the Prime Agent’s portion of its genesis supply, as defined in [A.2.3.4.4.2.4 - Agent Token Genesis Supply](ed342c6e-15ae-4c95-ad4e-4702c27eba62).

Public Holders are unique wallet addresses, excluding any address reasonably believed to be controlled by the Prime Agent, its core contributors, or their affiliates. An entity is affiliated with another if it directly or indirectly controls, is controlled by, or is under common control with such other entity.

To qualify as a Public Holder, tokens owned by a wallet address must not be subject to any contractual, legal, or technical transfer restrictions, including:

(a) time-based vesting or lock-up schedules;
(b) contractual resale limitations (including any limitations imposed by token purchase agreements, SAFTs, or other similar instruments); or
(c) smart contract restrictions that prevent transfer without further governance action.

Tokens held in liquidity pools or staking contracts shall be attributed to the beneficial owners of the deposited tokens, rather than to the pool or contract itself, for purposes of determining both the number of Public Holders and their collective ownership.

The Core Executor Agents are responsible for determining whether the tokens of a Prime Agent are Publicly Held. If the Core Executor Agents believe that a Prime Agent’s tokens are sufficiently decentralized despite failing to meet the technical criteria specified herein, they may conduct a Governance Poll to determine whether the Prime Agent’s tokens should be deemed Publicly Held.

###### A.2.3.5.2.3.2 - Atlas Edit Proposal Process For Prime Agents [Core]  <!-- UUID: 364e52eb-4529-46a9-9852-edaaab88baeb -->

Prime Agents that do not have an operational Root Edit Primitive must work with Core GovOps to use the Atlas Edit Weekly Cycle (see [A.1.10.2 - Atlas Edit Weekly Cycle](14e99d92-71fc-44d9-9dbf-933bce2e1b32)) process to update their Agent Artifacts, as specified in the documents herein.

###### A.2.3.5.2.3.2.1 - Prime Agent Submits Draft Proposal To Core GovOps [Core]  <!-- UUID: 461272f0-e9ae-43df-9571-4be49a2286c7 -->

The Prime Agent must submit a draft of the proposed edit to Core GovOps by 23:59 UTC on Monday in a given week. The draft need not be in the form of Atlas documents but should reflect a finished work product of the Prime Agent that is logically organized, contains all pertinent information, and is free of ambiguities to the best of the Prime’s ability.

###### A.2.3.5.2.3.2.2 - Core GovOps Submits Atlas Edit Weekly Cycle Proposal [Core]  <!-- UUID: 07d1ed44-c457-49b9-a054-50e26aa70acc -->

Upon receiving the draft from the Prime Agent, Core GovOps drafts a formal Atlas Edit Weekly Cycle proposal containing the relevant content, shares a draft with the Prime Agent for review, and then submits that proposal to be voted on Monday of the following week.

###### A.2.3.5.2.3.2.2.1 - Potential Delays In Submission [Core]  <!-- UUID: 4b37392d-9c0f-4572-8293-e7c6b3fc3743 -->

Core GovOps may in their discretion delay submitting a proposed edit based on factors including, but not limited to:
    
◦ the size of the proposed edit;    
◦ any ambiguities in the proposed edit;    
◦ broader issues raised by the proposed edit requiring other changes or consultation with other stakeholders;    
◦ delays by the Prime Agent in responding to questions or requests to review drafts by Core GovOps; and    
◦ the overall workload of Core GovOps.

###### A.2.3.5.2.3.2.3 - Atlas Edit Weekly Cycle Proposal Is Approved Or Rejected [Core]  <!-- UUID: afeaa98f-b8f5-48d9-adb2-8ceed287667d -->

The Atlas Edit Weekly Cycle proposal, if triggered by a Ranked Delegate and not rejected by the Core Facilitator for misalignment, is either approved or rejected by SKY holders by Thursday of the following week. A proposal that is not triggered or is rejected by the Core Facilitator for misalignment is treated as rejected.

###### A.2.3.5.2.3.2.4 - If Approved Then Prime Agent Begins Operationalizing Change [Core]  <!-- UUID: 61414e64-815d-4bab-8b8b-f81d787453b6 -->

If the Atlas Edit Weekly Cycle proposal is approved by SKY holders, then the Prime Agent may begin operationalizing that logic immediately thereafter.

#### A.2.3.5.3 - Light Agent Primitive [Core]  <!-- UUID: 44028423-2cd1-40cb-89ac-3f762b602b90 -->

The Light Agent Primitive enables users to create Light Agents, which are sub-agents operating on top of the Agent’s Executor Accord, conferring the advantages of Sky GovOps at a lower cost, but without direct access to other Sky Primitives.

### A.2.3.6 - Ecosystem Upkeep Primitives [Section]  <!-- UUID: 25673fd2-76cb-4c4d-8ec6-8c489207bcfc -->

Ecosystem Upkeep Primitives ensure that all Agents contribute to long-term ecosystem sustainability. Prime Agents must choose between either the Distribution Requirement Primitive or the Market Cap Fee Primitive; whereas the Upkeep Rebate Primitive applies universally to all Prime Agents. The term "Ecosystem Upkeep Fees" refers to the upkeep obligation of a Prime Agent pursuant to either the Distribution Requirement Primitive or the Market Cap Fee Primitive.

#### A.2.3.6.1 - Distribution Requirement Primitive [Core]  <!-- UUID: 0804ab13-d276-4ad9-a935-dc9f7fc2e350 -->

The Distribution Requirement Primitive requires Agents to periodically buy and distribute 0.25% of their token supply per year. The annual requirement of 0.25% of the token supply is divided into twelve (12) equal monthly distributions. Distributions must occur on the first day of each month, with tokens purchased by the Prime Agent on the open market and transferred to an address designated by Sky Core in [A.2.3.6.1.1 - Sky Core-Designated Address](3b05c60a-4f95-4dd8-bfaf-409a9f39ee9f). 

Prime Agents choose between fulfilling either the Distribution Requirement Primitive or the Market Cap Fee Primitive.

##### A.2.3.6.1.1 - Sky Core-Designated Address [Core]  <!-- UUID: 3b05c60a-4f95-4dd8-bfaf-409a9f39ee9f -->

The address to which tokens must be transferred will be specified in a future iteration of the Atlas.

##### A.2.3.6.1.2 - Calculation of Distributed Tokens [Core]  <!-- UUID: ef26607b-9635-4d42-a2cf-6c755f53883a -->

The value of the distributed tokens is calculated as the number of tokens distributed, multiplied by the Time-Weighted Average Price (TWAP) of the token over the 24-hour period ending at 23:59 UTC on the last day of each month, immediately preceding the distribution event. This value is applied in the rebate calculation under the Upkeep Rebate Primitive. See [A.2.3.6.3 - Upkeep Rebate Primitive](569e1c2b-0e69-43e7-8491-06cc5f7d2988).

#### A.2.3.6.2 - Market Cap Fee Primitive [Core]  <!-- UUID: a21616f4-1611-4e0b-87b2-efbdff9f6f28 -->

The Market Cap Fee Primitive requires Prime Agents to pay an annual fee equivalent to 0.30% of their market capitalization to Sky, accounted for monthly. The annual fee of 0.30% of the market capitalization is divided into twelve (12) equal monthly payments, equating to 0.025% of the market capitalization per month. Payments must occur on the first day of each month, with the fee transferred to an address designated by Sky Core in [A.2.3.6.2.1 - Sky Core-Designated Address](2a5f0e38-e51a-4a68-a4b8-1a912b8bb12e). 

Prime Agents choose between fulfilling either the Distribution Requirement Primitive or the Market Cap Fee Primitive.

##### A.2.3.6.2.1 - Sky Core-Designated Address [Core]  <!-- UUID: 2a5f0e38-e51a-4a68-a4b8-1a912b8bb12e -->

The address to which the fee must be transferred will be specified in a future iteration of the Atlas.

##### A.2.3.6.2.2 - Valuation [Core]  <!-- UUID: 4b856873-8c6a-449a-8ca6-487d8fed9029 -->

The market capitalization is determined as the total token supply multiplied by the TWAP of the token over the 24-hour period ending at 23:59 UTC on the last day of each month, immediately preceding the payment event. This value is applied in the rebate calculation under the Upkeep Rebate Primitive. See [A.2.3.6.3 - Upkeep Rebate Primitive](569e1c2b-0e69-43e7-8491-06cc5f7d2988).

#### A.2.3.6.3 - Upkeep Rebate Primitive [Core]  <!-- UUID: 569e1c2b-0e69-43e7-8491-06cc5f7d2988 -->

The Upkeep Rebate Primitive allows a Prime Agent ("Holding Agent") to claim a rebate on its Ecosystem Upkeep Fees when it holds any portion of the token supply of another Prime Agent ("Issuing Agent").

Ecosystem Upkeep Fees are accounted on a monthly basis. The Upkeep Rebate is calculated on the same cadence per Holding Agent as follows:

(1) The Holding Agent’s share of the Issuing Agent’s token supply at the time the Issuing Agent pays its Ecosystem Upkeep Fees, multiplied by
(2) The total monthly Ecosystem Upkeep Fees paid by the Issuing Agent. For a Prime Agent deploying the Distribution Requirement Primitive, the value of its total monthly Ecosystem Upkeep Fee is calculated pursuant to [A.2.3.6.1.2 - Calculation of Distributed Tokens](ef26607b-9635-4d42-a2cf-6c755f53883a). For a Prime Agent deploying the Market Cap Fee Primitive, the value of its total monthly Ecosystem Upkeep Fee is calculated pursuant to  [A.2.3.6.2.2 - Valuation](4b856873-8c6a-449a-8ca6-487d8fed9029).

This resulting rebate amount is applied against the Holding Agent’s Ecosystem Upkeep Fees due in the calendar month immediately following the Issuing Agent’s payment.

### A.2.3.7 - SkyLink Primitives [Section]  <!-- UUID: 7b5d8965-a64c-4c44-b742-607f51f69d8f -->

SkyLink Primitives are Sky Primitives that are technical infrastructure that extends the Sky Protocol. SkyLink Primitives are built autonomously by Prime Agents, but owned by Sky Core and shared among all Prime Agents. Prime Agents are reimbursed for the cost of setting up SkyLink Primitives and given additional first-mover incentives.

#### A.2.3.7.1 - Token SkyLink Primitive [Core]  <!-- UUID: 4504d2d4-ee45-4a07-8c5b-9baf20b12e76 -->

The Token SkyLink Primitive allows users to bridge USDS, sUSDS, SKY, or an Agent token to new blockchains and enables other multichain features.

##### A.2.3.7.1.1 - Token SkyLink Process Definition [Core]  <!-- UUID: 18386a64-1f20-4495-99a0-2271c7d607b0 -->

The documents herein define the Process Definition for initial setup and ongoing management of the Token SkyLink Primitive.

###### A.2.3.7.1.1.1 - Token SkyLink Setup Process Definition [Core]  <!-- UUID: 408400c0-db9d-41d8-b657-de59ac18a288 -->

The documents herein define the process for setting up an Instance of the Token SkyLink Primitive.

###### A.2.3.7.1.1.1.1 - Token SkyLink Setup Real World Agreements And Planning [Core]  <!-- UUID: f1836fc1-8691-4520-8159-e6d451a256b3 -->

The documents herein define the preliminary, off-chain human coordination stage of setting up an Instance of the Token SkyLink Primitive.

###### A.2.3.7.1.1.1.1.1 - Token SkyLink Setup Target Chain Identification And Feasibility Analysis [Core]  <!-- UUID: 298ee5be-2f95-46b2-8dc7-8cf68f99c038 -->

The Prime Agent researches potential target blockchains for token bridging, including evaluation of user base, DeFi ecosystem, and bridging security requirements. The Prime Agent confirms that the target chain supports LayerZero or can be integrated easily with the LayerZero Omnichain Fungible Token standard. The Prime Agent also estimates potential use of the token on the target chain to justify the bridge deployment and audit costs. The output of this step is a preliminary decision to proceed with deploying a bridge to the target chain including a scope of work for the bridge deployment and estimated audit costs.

###### A.2.3.7.1.1.1.1.2 - Token SkyLink Setup Initial Alignment With Operational GovOps [Core]  <!-- UUID: eec4c93e-5012-4547-b1ad-ab6ba6d7042c -->

The Prime Agent presents the bridging plan to Operational GovOps, including a technical summary, proposed timeline, and estimate of audit costs. The Prime Agent and Operational GovOps also discuss any guidelines in the Atlas or the Agent Artifact that may affect bridging. The Prime Agent receives early feedback on the plan and modifies it accordingly. The output of this step is an informal agreement to proceed with developing a bridge deployment along with any documented conditions or feedback from Operational GovOps.

###### A.2.3.7.1.1.1.1.3 - Token SkyLink Setup Audit Preparation And Proposal Of Costs [Core]  <!-- UUID: aa9f9672-2d80-404b-9c6e-fe69615fc125 -->

The Prime Agent contacts a reputable third-party security audit firm for reviewing the bridge implementation. The Prime Agent negotiates audit scope, timeline, and fees with the audit firm. The Prime Agent documents the projected cost for the bridge, including development, audit, and deployment costs, for future reimbursement. The outcome of this step is a formal agreement with the audit firm and a detailed cost breakdown for bridge deployment and auditing.

###### A.2.3.7.1.1.1.2 - Token SkyLink Setup Codification and Validation [Core]  <!-- UUID: 18ce8e21-898d-4bf9-9bf8-ef1c1e7266ee -->

The documents herein define how agreements to setup an Instance of the Token SkyLink Primitive are codified and validated in the Powerhouse system and how governance votes happen.

###### A.2.3.7.1.1.1.2.1 - Agent Inputs [Core]  <!-- UUID: 5027bb60-ea5f-4f1a-9ce6-a9a0afae33e5 -->

The Prime Agent drafts an update to the Prime Agent Artifact adding the Token SkyLink to the list of active Token SkyLink deployments and including the information specified in [A.2.3.7.1.2.2 - List of Active Token SkyLink Deployments](bf3ede73-bba3-4048-b105-a49400611fcb). The Prime Agent submits the draft to the Powerhouse system. The output of this step is a draft Prime Agent Artifact update in the Powerhouse system.

###### A.2.3.7.1.1.1.2.2 - Validation And Off-Chain Vote [Core]  <!-- UUID: cac40223-e628-4248-a44d-2aaa6f03ba00 -->

The Operational Executor Facilitator reviews the proposal to ensure that it is complete and aligned with the Atlas. The Operational Executor Facilitator then initiates an off-chain snapshot vote, following the quorum and majority rules in the Prime Agent Artifact. When complete, the result of the vote is recorded in the Powerhouse system. The output of this step is the snapshot vote result recorded in the Powerhouse system.

###### A.2.3.7.1.1.1.2.3 - Official Update of Artifact [Core]  <!-- UUID: 79abf483-f256-4ef6-9aa7-558a8800e7a8 -->

If the Token SkyLink Invocation is successfully approved, the Operational Executor Facilitator finalizes and publishes the update to the Prime Agent Artifact, making it effective in the Atlas. The output of this step is an updated Prime Agent Artifact with the Token SkyLink Instance Activated.

###### A.2.3.7.1.1.1.3 - Token SkyLink Setup Deployment [Core]  <!-- UUID: 21241867-d25e-47ee-b4c2-13224dcd0292 -->

The documents herein define how the deployment of an Instance of the Token SkyLink Primitive is executed on-chain.

###### A.2.3.7.1.1.1.3.1 - Token SkyLink Setup Bridge Deployment And Initial Audit [Core]  <!-- UUID: af88c454-2171-41ce-a8e8-1d6c40d4e209 -->

The Prime Agent, through Operational GovOps, deploys the Token SkyLink contract on the target chain. The Prime Agent shares the Token SkyLink contract’s final address with the audit firm for verification. Operational GovOps confirms that the bridge contract address and references match the updated Prime Agent Artifact. The audit firm completes and updates the bridging audit registry with the results of the audit. The output of this step is a deployed bridge contract with audit results uploaded to the bridging audit registry.

###### A.2.3.7.1.1.1.3.2 - Token SkyLink Setup Activation On New Chain [Core]  <!-- UUID: c18d8c58-d347-4efd-9c33-4fd89cf40f90 -->

Core GovOps formalizes the audit results with a Sky Core Executive Vote to fully activate bridging functionality. Operational GovOps updates the Prime Agent Reimbursement Module to begin counting any bridged tokens toward the incremental reward. The output of this step is fully enabled bridging on the target chain with the Prime Agent Reimbursement Module updated to track bridging based rewards.

###### A.2.3.7.1.1.2 - Token SkyLink Ongoing Management [Core]  <!-- UUID: d7adf706-c9cc-4408-9668-cec0fdc90be8 -->

The documents herein define the process for managing an Instance of the Token SkyLink Primitive.

###### A.2.3.7.1.1.2.1 - Token SkyLink Management Settlement Cycle [Core]  <!-- UUID: 97fb1954-b9f4-429e-bc29-e9eea9fe2e0e -->

During each settlement cycle, the Prime Agent Reimbursement Module tallies the total token bridging volume on the new chain. The Prime Agent Reimbursement Module calculates the reimbursement due for bridge development costs as a percent of the token bridging volume, in addition to normal Distribution Rewards if applicable. Core GovOps executes a payment to the Prime Agent for the amount due for reimbursement of bridge development costs, to the extent that such costs have not already been fully reimbursed. Core GovOps updates the Powerhouse system to reflect the amount of bridge development costs that have been reimbursed.

##### A.2.3.7.1.2 - Token SkyLink Input Requirements [Core]  <!-- UUID: 7d9a8373-ed56-4b01-8ec7-ebf2ed4ef8b0 -->

The documents herein define the required inputs for a valid Token SkyLink Primitive. If any input is noncompliant or omitted, the Primitive will be invalidated and the SkyLink deployment will not move forward.

###### A.2.3.7.1.2.1 - Token SkyLink Activation Status [Core]  <!-- UUID: 94a0a22c-cbd6-4022-80e8-4681f60c7cec -->

The Token SkyLink Primitive must be Globally Activated.

###### A.2.3.7.1.2.2 - List of Active Token SkyLink Deployments [Core]  <!-- UUID: bf3ede73-bba3-4048-b105-a49400611fcb -->

The Token SkyLink Primitive must list each active Token SkyLink deployment. The listing must include the following information: (1), the token being bridged, (2) the target chain of the bridge, (3) the address of the bridge contract on the Ethereum Mainnet, (4) the address of the bridge contract on the target chain, (5) the audit of the bridge contract, (6) the bridge parameters, (7) the total bridge deployment and audit costs, and (8) the amount of bridge deployment and audit costs that have been reimbursed to date.

### A.2.3.8 - Demand Side Stablecoin Primitives [Section]  <!-- UUID: 26415305-432d-423b-9553-3f325279712d -->

Demand Side Stablecoin Primitives are Sky Primitives that target demand generation for USDS. Prime Agents can create and control multiple instances of these Primitives which exist as technical infrastructure incentivizing the adoption or usage of USDS by end users or third parties.

#### A.2.3.8.1 - Distribution Reward Primitive [Core]  <!-- UUID: e632c38f-3e4e-4c7e-acfd-b6ec45a422e6 -->

The documents herein govern the Distribution Reward Primitive.

##### A.2.3.8.1.1 - Introduction [Core]  <!-- UUID: 02189c79-a529-4388-98ad-a743d2a8980d -->

The documents herein provide an introduction to the Distribution Reward Primitive.

###### A.2.3.8.1.1.1 - Purpose [Core]  <!-- UUID: 6f1bc619-b8a9-4917-a34b-f52016942c01 -->

The purpose of the Distribution Reward is to incentivize Prime Agents and third parties to drive USDS adoption by providing a financial reward to these actors for all USDS and sUSDS balances attributable to them.

###### A.2.3.8.1.1.2 - Allowed Number Of Instances [Core]  <!-- UUID: 45149960-fbf3-4079-be4e-fe2a71e5e43f -->

Multiple instances of the Distribution Reward Primitive are allowed. Each instance corresponds to a Distribution Reward program with an associated Distribution Reward Code.

###### A.2.3.8.1.1.3 - Multi-Instance Coordinator Document [Core]  <!-- UUID: c788ebcf-98a4-4b97-ae3c-db578c75dc2e -->

An Agent Artifact that has more than one active instance of the Distribution Reward Primitive is not required to have a `Multi-Instance Coordinator Document`, since each Instance can be managed independently.

##### A.2.3.8.1.2 - Global Specification [Core]  <!-- UUID: 7f0959dc-c6e2-4e64-9526-76563a2a6d29 -->

The requirements herein apply universally across all possible deployments of the Distribution Reward Primitive by Prime Agents. They include the steps that Agents must take to deploy the Primitive, including Global Activation of the Primitive, Instance Invocation, and ongoing management of the Primitive Instance(s).

###### A.2.3.8.1.2.1 - Base Elements [Core]  <!-- UUID: dc123bca-eac1-40e1-ad1f-f888a6ec8d1f -->

The documents herein define base elements of the Distribution Reward Primitive.

###### A.2.3.8.1.2.1.1 - Integrator Program [Core]  <!-- UUID: 37c38f07-b5a0-40df-939c-a54330ea3c7b -->

Integrators are actors that offer access to the Sky Protocol via their frontends or infrastructure. The documents herein define the Integrator Program, which includes the Distribution Reward and Integration Boost. (Base elements specific to the Integration Boost Primitive are defined in [A.2.3.8.2.2.1 - Base Elements](c398b383-3752-4534-aec6-4cd8e7292119))

###### A.2.3.8.1.2.1.1.1 - Integrator Requirements [Core]  <!-- UUID: 1c2b6983-1e03-41b9-a2bf-70f3eca19b98 -->

The documents herein define the requirements for Integrators.

###### A.2.3.8.1.2.1.1.1.1 - Alignment [Core]  <!-- UUID: 98e98f68-e749-4d0a-8972-7e36ed166326 -->

The Integrator must be aligned with Sky’s overall strategy regarding promoting adoption of USDS. In the near term, this determination of a prospective or current Integrator’s alignment with Sky’s overall strategy is made by Operational GovOps in consultation with Ecosystem Actor Viridian Advisors. In the future Operational GovOps may make this determination themselves or consult with another actor to do so. Sky Core may choose whether to maintain an Integrator’s Reward Code in its sole and absolute discretion.

###### A.2.3.8.1.2.1.1.1.2 - Compliance With Local Laws And Regulations As A Condition Precedent To Integrators Receiving Distribution Rewards [Core]  <!-- UUID: f3b4b43d-b2e5-4f56-aeac-9627d3acc31e -->

This document and its subdocuments define the jurisdictional compliance rules applicable to Integrators that operate user-facing frontends that integrate with, and thus offer access to, the Sky Protocol and receive Distribution Rewards.

Integrators are solely responsible for complying with all relevant legal and regulatory requirements related to their participation in the Integrator Program. Integrators represent and warrant that their participation and activities under the Integrator Program are and will remain in full compliance with all applicable laws and regulations.

In connection with integrating with, and thereby providing access to, the Sky Protocol, Integrators must operate their frontends and infrastructure in compliance with all relevant legal and regulatory requirements in the jurisdictions applicable to their services. This requires compliance with all relevant legal and regulatory requirements in relation to frontend operations, marketing, and promotions in the jurisdictions where the Integrator provides access to the Sky Protocol through the integration.

An Integrator’s right to participate in the Integrator Program is contingent upon its ongoing compliance with all applicable laws and regulations.

###### A.2.3.8.1.2.1.1.1.2.1 - Consequence For Integrator Non-Compliance With Local Laws And Regulations [Core]  <!-- UUID: a01622fa-e81c-4bcb-8e31-7e66e36f2e57 -->

Sky Ecosystem Governance, in its absolute and unilateral discretion, retains the right to withhold, revoke, or demand immediate repayment of any and all Distribution Rewards from any Integrator that is determined, suspected, or alleged to be in violation of the Atlas or any legal, regulatory, or other obligations associated with its integration with, and provision of access to, the Sky Protocol.

###### A.2.3.8.1.2.1.1.1.2.2 - Removal From Integrator Program [Core]  <!-- UUID: 0bdcef8a-b851-42ed-b2e2-77d85c14dad0 -->

If Sky Governance removes an Integrator from the Integrator Program, Operational GovOps must remove the Integrator from the list of Current Integrators in [A.2.3.8.1.2.1.5.1.0.6.1 - List Of Current Integrators](efbe7903-a76e-40f0-a440-56e463283157) and deactivate the Instances of the Distribution Reward and Integration Boost Primitive associated with them.

###### A.2.3.8.1.2.1.1.2 - Integrator Applications [Core]  <!-- UUID: abc79583-78da-4578-9ae0-51dc322ed1cb -->

The documents herein define the process for applying to become an Integrator.

###### A.2.3.8.1.2.1.1.2.1 - Near Term Process [Core]  <!-- UUID: 7fe5dbb2-a07d-4ef9-94de-f54a2d568c57 -->

In the near term, applications are made directly to Ecosystem Actor Viridian Advisors. Viridian Advisors must create and maintain a thread on the Sky Forum for Integrator Applications. Viridian Advisors reviews applications and coordinates with Prime Agents interested in working with specific applicants. Viridian Advisors issues Reward Codes to approved applicants.

###### A.2.3.8.1.2.1.1.2.1.1 - Integrator Program Applications [Active Data Controller]  <!-- UUID: d251bbac-df0e-4aff-a26b-33d60e153e19 -->

The list of Integrator Program applicants is defined as Active Data in [A.2.3.8.1.2.1.1.2.1.1.0.6.1 - List Of Integrator Applications](30db9618-ddf2-4df7-ad81-3f8f3395ff62).

The Active Data is updated as follows:
- The Responsible Party is Viridian Advisors.
- The Update Process must follow the protocol for ‘Direct Edit’.

###### A.2.3.8.1.2.1.1.2.1.1.0.6.1 - List Of Integrator Applications [Active Data]  <!-- UUID: 30db9618-ddf2-4df7-ad81-3f8f3395ff62 -->

The current Integrator Applications are:

###### A.2.3.8.1.2.1.1.2.2 - Long Term Process [Core]  <!-- UUID: 6283379c-d871-40a9-a915-d716d7df5642 -->

In the long term, Integrator applications come exclusively through Prime Agents. Prime Agents may establish whatever processes they deem appropriate to receive inbound requests for potential partnerships.

###### A.2.3.8.1.2.1.1.3 - Integrator Onboarding [Core]  <!-- UUID: 361e2e68-b2ab-4b1e-93ce-030cf25e509e -->

The documents herein define the process for onboarding new Integrators.

###### A.2.3.8.1.2.1.1.3.1 - Near Term Process [Core]  <!-- UUID: fc46821f-9d3d-4807-b519-d54faf546702 -->

The near term Integrator Onboarding process is as follows. When a Prime Agent’s Invocation of the Distribution Reward Primitive involves an actor who is not yet an approved Integrator, that actor must submit an Integrator Application to Viridian Advisors. Viridian Advisors determines, in consultation with Operational GovOps, whether the Integrator Requirements are met, and if so issues a Reward Code to the applicant. After the Reward Code has been issued, the Invocation of the Primitive may proceed.

###### A.2.3.8.1.2.1.1.3.2 - Long Term Process [Core]  <!-- UUID: 0dda062b-5168-47be-bfa8-867f52eaae02 -->

In the long term, Operational GovOps will review Integrator applications and determine whether the prospective partner satisfies the Integrator Requirements; if so, Operational GovOps issues a Reward Code. Operational GovOps may contract with Viridian Advisors or another actor to perform the work of reviewing applications and issuing Reward Codes.

###### A.2.3.8.1.2.1.2 - Reward Codes [Core]  <!-- UUID: cda71b0c-37cc-4f6a-92a3-b6a14895bfe1 -->

The documents herein define base elements related to Reward Codes.

###### A.2.3.8.1.2.1.2.1 - Assignment [Core]  <!-- UUID: 225454ec-ac16-470e-b780-114acbb2a453 -->

The documents herein define the process for assigning Reward Codes.

###### A.2.3.8.1.2.1.2.1.1 - Near Term Process [Core]  <!-- UUID: e00e28d1-dad1-4cff-8ea4-1290c27d3b07 -->

In the near term, Reward Codes are assigned by Ecosystem Actor Viridian Advisors.

###### A.2.3.8.1.2.1.2.1.2 - Long Term Process [Core]  <!-- UUID: 5c7aeef0-3490-4fdd-b486-a825b67285e0 -->

In the long term, Reward Codes are assigned by Operational GovOps. Operational GovOps may contract with Viridian Advisors or another Ecosystem Actor to perform this work for them, at the discretion of Operational GovOps.

###### A.2.3.8.1.2.1.2.2 - Marking [Core]  <!-- UUID: ec2c6d8a-e10f-471a-8f85-67803159cc37 -->

To be eligible for the Distribution Reward, USDS balances must be "marked" with a Reward Code using the agreed-on Tracking Methodology.

###### A.2.3.8.1.2.1.2.2.1 - Ethereum Mainnet General Tracking Methodology [Core]  <!-- UUID: 87fd6861-ba8a-4bde-945e-ee9ad37ae3e2 -->

The general Tracking Methodology for Ethereum Mainnet is to specify the Reward Code as a parameter to depositing USDS into the Sky Savings Rate contract or Token Rewards contracts. This on-chain deposit data is then combined with withdrawal data. In the interim, this data is further processed by Ecosystem Actor Viridian Advisors to estimate net deposits associated with the Reward Code on a First In First Out (FIFO) basis. In the long term, Operational Executor Agents will wholly manage this process.

###### A.2.3.8.1.2.1.2.2.2 - Ethereum Mainnet CoW Swap Tracking Methodology [Core]  <!-- UUID: 1b5cc0ee-0ee8-467e-ab49-33c06ad417dc -->

The Tracking Methodology for CoW Swap on the Ethereum Mainnet is the same as the general process for the Ethereum Mainnet, with the exception that events on CoW Swap’s decentralized network of solvers are tracked instead.

###### A.2.3.8.1.2.1.2.2.3 - Base Tracking Methodology [Core]  <!-- UUID: f710bddf-dc1d-483c-9503-483574cb6333 -->

The Tracking Methodology for Base is to specify the Reward Code as a parameter in calls to the Base PSM contract. Conversions from USDS or USDC to sUSDS are considered "deposits" and net deposits are calculated using an approach similar to that on Ethereum Mainnet.

###### A.2.3.8.1.2.1.2.2.4 - Alternative Tracking Methodologies [Core]  <!-- UUID: 5eba1c21-4e93-4a0a-aa10-e99bcfa65f16 -->

The Tracking Methodologies specified above are not exclusive. Prime Agents and Operational GovOps can develop additional Tracking Methodologies, so long as those methodologies reasonably estimate USDS balances that are attributable to the holder of the Reward Code and there is no possibility that the same USDS balances could be "double counted" for multiple Reward Code holders. Tracking methodologies must be based on either (1) on-chain data or (2) off-chain data that can be independently verified or attested to by a third party.

###### A.2.3.8.1.2.1.2.2.5 - Lifetime [Core]  <!-- UUID: c0b77312-5e88-4311-bfe2-d95a1a2c5a7c -->

USDS balances are eligible for a Distribution Reward for a period of ten (10) years from the date of the event marking the USDS balance with the Reward Code. The date of the marking event is determined based on the Primitive Instance’s specified Tracking Methodology.

###### A.2.3.8.1.2.1.2.3 - Management [Core]  <!-- UUID: 75ddec36-c39e-4333-9ec1-2d329128e848 -->

In the near term, Ecosystem Actor Viridian Advisors manages the list of Actor Reward Codes. In the future, all current Integrators and onboarding Integrators must be specified in [A.2.3.8.1.2.1.5 - Current And Onboarding Integrators](f3952cc5-cde2-46b9-b575-034dda83570b) so that Prime Agents, through their Operational Executor Agents, can onboard new partners themselves without having to go through a single party.

###### A.2.3.8.1.2.1.3 - Distribution Reward Rate [Core]  <!-- UUID: 57384c49-e499-4c69-b22c-8e1f1dd34759 -->

The standard Distribution Reward rate is set at 0.2%. The Distribution Reward rate is annualized on all USDS and sUSDS balances associated with the relevant Reward Code.

###### A.2.3.8.1.2.1.3.1 - Boosted Distribution Reward Rate [Core]  <!-- UUID: 1d9219cb-9359-40de-96a0-ac60a8174c63 -->

An additional 0.3% Boosted Distribution Reward rate will be available starting January 2026 as specified in the documents herein. This Boosted Distribution Reward may be discontinued in the future at the discretion of Sky Governance.

###### A.2.3.8.1.2.1.3.1.1 - Approval Process [Core]  <!-- UUID: 3f3162cc-c83c-471d-9dfa-1e0ccada4261 -->

A Prime Agent may request the Boosted Distribution Reward rate for a specific Instance by posting on the Sky Forum under the "Sky Core" category. The Core Council will review requests and approve them at its discretion. The Core Facilitator must respond to each request with an approval or rejection decision in the thread of the original post.

###### A.2.3.8.1.2.1.3.1.2 - Specification In The Instance Configuration Document [Core]  <!-- UUID: ce66fc65-014f-447d-b068-2487ec11032e -->

Prime Agent Instances approved for the Boosted Distribution Reward rate must document this designation in their Instance Configuration Document under "Custom Instance Parameters".

###### A.2.3.8.1.2.1.3.1.3 - Limitations [Core]  <!-- UUID: f2b3688f-e9e0-4159-9af3-0502141babab -->

The Boosted Distribution Reward rate is not applicable to USDS and sUSDS balances held by the Prime Agent itself.

###### A.2.3.8.1.2.1.4 - Rewards Distribution [Core]  <!-- UUID: 8dfabd92-aabc-4605-9ca5-d10f413203dc -->

The documents herein define base elements of the Distribution Reward Primitive related to distribution of Distribution Rewards.

###### A.2.3.8.1.2.1.4.1 - Reward Cadence [Core]  <!-- UUID: 02d1e35f-0a24-43d9-9406-347eef58a9d1 -->

The Distribution Reward is calculated and distributed on a monthly basis.

###### A.2.3.8.1.2.1.4.2 - Reward Payment [Core]  <!-- UUID: 38cb0bfe-3733-4a11-8b3a-6728df00d08e -->

The Distribution Reward payment for each month is equal to 

(1) the average balance over the month, times 
(2) the annual Distribution Reward Fee specified in [A.2.3.8.1.2.1.3 - Distribution Reward Rate](57384c49-e499-4c69-b22c-8e1f1dd34759), divided by 
(3) twelve (12).

###### A.2.3.8.1.2.1.4.3 - Treasury Management [Core]  <!-- UUID: 935b90bb-a854-4c06-b6ea-48a1cf8fd2f1 -->

The documents herein define the treasury management process.

###### A.2.3.8.1.2.1.4.3.1 - Near-Term Process [Core]  <!-- UUID: 05fb732b-de55-4886-81a7-7c5d4c13d2d2 -->

In the near term, Amatsu calculates the Distribution Reward on behalf of the Support Facilitators. The Accessibility Facilitators then pay the Distribution Reward from the Distribution Reward Controller Wallet located on the Ethereum Mainnet at `0x05F471262d15EECA4059DadE070e5BEd509a4e73` within seven (7) days of the end of every month. The balance of this wallet may be topped up to 3 million USDS. This funding is subject to an Executive Vote.

###### A.2.3.8.1.2.1.4.3.2 - Long Term Process [Core]  <!-- UUID: 07953e87-c201-4ad5-9c1e-b32efc5fba94 -->

In the long term, Operational GovOps calculates the Distribution Reward for each month. Operational GovOps then pays the Distribution Reward recipient from its Buffer. Later Sky Core reimburses the Operational Agent Buffer for the amount paid as part of the Settlement Cycle. This minimizes the role of Sky Core in Distribution Reward payments and emphasizes the primary role of the Operational Executor Agent, acting through Operational GovOps, in implementing the Sky Primitives. The process is specified in further detail in [A.2.3.8.1.2.4.1 - Routine Protocol](c2abdd22-fe0f-489e-b281-450e066db701).

###### A.2.3.8.1.2.1.4.4 - Payment Errors [Core]  <!-- UUID: 1b5edf68-0825-449a-a404-34141a1892cc -->

If it is discovered that previous Distribution Reward calculations were made erroneously, underpayments are resolved retroactively. In cases where an Integrator was overpaid, the Prime Agent associated with the Integrator must reimburse Sky the overpayment amount and can use future Distribution Rewards that the Integrator earns to reimburse itself.

###### A.2.3.8.1.2.1.5 - Current And Onboarding Integrators [Core]  <!-- UUID: f3952cc5-cde2-46b9-b575-034dda83570b -->

The documents herein specify current and onboarding Integrators.

###### A.2.3.8.1.2.1.5.1 - Current Integrators [Active Data Controller]  <!-- UUID: 883f1b52-a6d2-417b-bb24-12917de83b53 -->

Current Integrators are Integrators who have a Reward Code specified in an `Active` Instance of the Distribution Reward Primitive. The list of Current Integrators is defined as Active Data in [A.2.3.8.1.2.1.5.1.0.6.1 - List Of Current Integrators](efbe7903-a76e-40f0-a440-56e463283157).

The Active Data is updated as follows:
- The Responsible Party is Operational GovOps.
- The Update Process must follow the protocol for ‘Direct Edit’.

###### A.2.3.8.1.2.1.5.1.0.6.1 - List Of Current Integrators [Active Data]  <!-- UUID: efbe7903-a76e-40f0-a440-56e463283157 -->

The current Active Integrators are:

###### A.2.3.8.1.2.1.5.2 - Onboarding Integrators [Active Data Controller]  <!-- UUID: 9a7f47ae-760f-44b5-9b5f-dd4fef86e1cc -->

Onboarding Integrators are actors whose application to the Integrator Program has been approved, but are specified in an Instance of the Distribution Reward Primitive or Integration Boost Primitive that is "Pending", or is not `Active` yet. The list of Onboarding Integrators is defined as Active Data in [A.2.3.8.1.2.1.5.2.0.6.1 - List Of Onboarding Integrators](eb644108-94fc-430f-ae5a-e3294b9dd9be). 

The Active Data is updated as follows:
- The Responsible Party is Operational GovOps.
- The Update Process must follow the protocol for ‘Direct Edit’.

###### A.2.3.8.1.2.1.5.2.0.6.1 - List Of Onboarding Integrators [Active Data]  <!-- UUID: eb644108-94fc-430f-ae5a-e3294b9dd9be -->

The current Onboarding Integrators are:

###### A.2.3.8.1.2.1.6 - Distribution Reward Reimbursement [Core]  <!-- UUID: fd551536-2177-4e78-87a1-c2528ff2fcaf -->

The documents herein specify the Distribution Reward reimbursement.

###### A.2.3.8.1.2.1.6.1 - Sky Core Distribution Reward Reimbursement [Active Data Controller]  <!-- UUID: 2c0eb02c-144e-4326-b5ec-85805653f0b7 -->

The Distribution Reward reimbursement payments are defined as Active Data in [A.2.3.8.1.2.1.6.1.0.6.1 - Sky Core Distribution Reward Reimbursement Amounts](169eb312-ed63-4a83-9f5d-43b621c0705e).
 
The Active Data is updated as follows:
- The Responsible Party is Core GovOps.
- The Update Process must follow the protocol for ‘Direct Edit’.

###### A.2.3.8.1.2.1.6.1.0.6.1 - Sky Core Distribution Reward Reimbursement Amounts [Active Data]  <!-- UUID: 169eb312-ed63-4a83-9f5d-43b621c0705e -->

The current Sky Core Accessibility Reward Reimbursement Amounts are:

###### A.2.3.8.1.2.2 - Global Activation [Core]  <!-- UUID: 49513ac9-43d6-4766-8a51-195e221de3f2 -->

An Agent who intends to deploy the Distribution Reward Primitive must first Globally Activate it.

###### A.2.3.8.1.2.2.1 - Process Initiation Logic [Core]  <!-- UUID: 776d926e-70d0-4771-bd60-d3fcef0a7ea3 -->

The process initiation logic is specified herein.

###### A.2.3.8.1.2.2.1.1 - Triggers [Core]  <!-- UUID: 090b3f8e-78a8-4df1-8db9-b9a6a2e23a33 -->

Triggers are specified herein.

###### A.2.3.8.1.2.2.1.1.1 - Time-Based Triggers [Core]  <!-- UUID: b4271bcd-12f5-4a14-bf5a-c77c9afd3629 -->

None.

###### A.2.3.8.1.2.2.1.1.2 - Document Update Triggers [Core]  <!-- UUID: e2766ea3-ddf9-434d-a6ab-6e13ca23e164 -->

None.

###### A.2.3.8.1.2.2.1.2 - Dependencies [Core]  <!-- UUID: 4e4476d8-0b98-4a2a-a3af-e879af06e01c -->

See [A.2.3.1.2.4.1 - Agent Launch And Sequence of Primitive Global Activation](2f5ff5c8-bcd1-44a4-ba56-2075ac8e9c61) for constraints on when an Agent can Globally Activate this Primitive.

###### A.2.3.8.1.2.2.2 - Process Flow [Core]  <!-- UUID: 89d26f82-b662-41df-8935-44aa7e93be6d -->

The Prime Agent uses the Powerhouse interface to Globally Activate (toggle on) the Distribution Reward Primitive.

###### A.2.3.8.1.2.2.3 - Required Primitive Inputs [Core]  <!-- UUID: 108c6d9c-8ecf-48bf-bc8b-365f8cf65c0c -->

The following inputs must be submitted into the Primitive using the Powerhouse interface:

- **Create** `Primitive Hub Document`
    ◦ Updated Field: Global Activation Status
        - New Value: set to `Activated`

###### A.2.3.8.1.2.2.4 - Required Outputs [Core]  <!-- UUID: faf79404-fe20-406d-a0a2-f3ac9e8592ab -->

The documents herein specify the required outputs from this process.

###### A.2.3.8.1.2.2.4.1 - Sky Core Atlas Updates [Core]  <!-- UUID: 74003afb-d603-4898-bd2a-bcf988e8c039 -->

No Sky Core Atlas documents are updated as the output of this process.

###### A.2.3.8.1.2.2.4.2 - Agent Artifact Updates [Core]  <!-- UUID: 6af6cd24-9513-42a7-be91-3f16845ebadf -->

No Agent Artifact documents are updated as the output of this process. The requirements specified in [A.2.3.8.1.2.2.3 - Required Primitive Inputs](108c6d9c-8ecf-48bf-bc8b-365f8cf65c0c) fully complete the Process.

###### A.2.3.8.1.2.3 - Instance Invocation Protocol [Core]  <!-- UUID: ad3a3f6b-7bc3-4e5f-b1c3-225b5b4cbe15 -->

After fulfilling the requirements for Global Activation, an Agent can Invoke its first Instance of the Distribution Reward Primitive by following the sequential process specified herein. Subsequent Invocations of the Primitive must also adhere to the same requirements defined below.

###### A.2.3.8.1.2.3.1 - Process Definition For Initial Opportunity Identification And Planning [Core]  <!-- UUID: f07b1cca-5db2-4b1b-b760-ea738d2776f3 -->

The documents herein specify the process definition for initial opportunity identification and planning.

###### A.2.3.8.1.2.3.1.1 - Process Initiation Logic [Core]  <!-- UUID: 005beba7-131f-43f9-93fc-29463905ef69 -->

The process initiation logic is specified herein.

###### A.2.3.8.1.2.3.1.1.1 - Triggers [Core]  <!-- UUID: 222fc95e-eead-49ec-9d55-730b2b3cb0a0 -->

Triggers are specified herein.

###### A.2.3.8.1.2.3.1.1.1.1 - Time-Based Triggers [Core]  <!-- UUID: dec5be6c-3123-4808-93e9-0486fc8e9572 -->

None.

###### A.2.3.8.1.2.3.1.1.1.2 - Document Update Triggers [Core]  <!-- UUID: 34497a9f-b623-45b3-a2f2-dc74a06c6700 -->

None.

###### A.2.3.8.1.2.3.1.1.2 - Dependencies [Core]  <!-- UUID: c89c3cd1-20c4-461f-a220-1754d97e2049 -->

This process is dependent on a Prime Agent Globally Activating the Distribution Reward Primitive pursuant to [A.2.3.8.1.2.2 - Global Activation](49513ac9-43d6-4766-8a51-195e221de3f2).

###### A.2.3.8.1.2.3.1.2 - Process Flow [Core]  <!-- UUID: 75ff9b92-47e1-454f-864b-b74742df918e -->

The process flow is defined herein.

- The Prime Agent identifies an opportunity to drive USDS adoption through a Distribution Reward to either 1) reward an existing Integrator for driving USDS adoption or 2) incentivize a new actor to onboard as an Integrator to drive USDS adoption.

- Existing Integrators

    ◦ The Prime Agent and the third party, if applicable, develop a plan to track USDS utilization attributable to the actor using either on-chain or off-chain data.

- Prospective Integrators

    ◦ Near Term process:
        - The Prospective Integrator must first apply to the Integrator program and be approved by Viridian Advisors per [A.2.3.8.1.2.1.1.2.1 - Near Term Process](7fe5dbb2-a07d-4ef9-94de-f54a2d568c57).  Post approval, Viridian Advisors issues a Reward Code to the Integrator.
        - The Prime Agent and the third party develop a plan to track USDS utilization attributable to the actor using either on-chain or off-chain data.

    ◦ Long Term process:
        - The Prospective Integrator must first apply to the Integrator program and be approved by Operational GovOps pursuant to [A.2.3.8.1.2.1.1.2.2 - Long Term Process](6283379c-d871-40a9-a915-d716d7df5642). Post approval, Operational GovOps issues a Reward Code to the Integrator.
        - The Prime Agent develops a plan to track USDS utilization attributable to it using either on-chain or off-chain data. Where applicable, the plan should include how the Prime Agent will support the prospective Integrator in including the Reward Code in their on-chain infrastructure.

- The Prime Agent may also be (or choose to be) an Integrator itself and deploy a Reward Code on its frontend to earn the Distribution Reward.

    ◦ Near Term process:
        -** **If the Prime Agent is not already an approved Integrator, it must apply to the Program and be approved by Viridian Advisors. Post approval, Viridian Advisors issues a Reward Code to the Prime Agent.
        - The Prime Agent develops a plan to track USDS utilization attributable to it using either on-chain or off-chain data.

    ◦ Long Term process:
        - The Prime Agent must first apply to the Integrator program and be approved by Operational GovOps pursuant to [A.2.3.8.1.2.1.1.2.2 - Long Term Process](6283379c-d871-40a9-a915-d716d7df5642). Post approval, Operational GovOps issues a Reward Code to the Prime Agent.
        - The Prime Agent develops a plan to track USDS utilization attributable to it using either on-chain or off-chain data.

###### A.2.3.8.1.2.3.1.3 - Required Primitive Inputs [Core]  <!-- UUID: 4d5482ad-7944-4073-8fbe-b9dbcd1a27a3 -->

The required Primitive Inputs for this process are defined herein and organized in sequential stages.

- Drafting of Initial Planning Document

    ◦ Create `Initial Planning Document`
        - Updated fields
            - `Status`
                ◦ New value: set to `Drafting`
            - `Integrator`
                ◦ New Value: set to Integrator Name
            - `Reward Code`
                ◦ New Value: set to Reward Code
            - `Tracking Methodology`
                ◦ New value: populate with details for tracking utilization
            - `Custom Instance Parameters`
                ◦ New Value: populate with details for any custom parameters
        - Responsible Party: Prime Agent Team
        - Trigger - Required Output: After Prime Agent's `Initial planning document` Status is set to `Drafting` 
- Initial Planning Document Triggered For GovOps review
    ◦ Edit `Initial Planning Document`
        - Updated fields
            - `Tracking Methodology`
                ◦ New value: updated content, as applicable
            - `Status`
                ◦ New value: set to `Ready for GovOps Review`
        - Responsible party: Prime Agent
        - Trigger - Required Output: After Prime Agent's `Initial planning document` Status is set to `Ready for GovOps review`.

###### A.2.3.8.1.2.3.1.4 - Required Outputs [Core]  <!-- UUID: 1ad17e84-8bde-4669-9967-9f67d1d3c603 -->

The documents herein specify the required outputs from this process.

###### A.2.3.8.1.2.3.1.4.1 - Sky Core Atlas Updates [Core]  <!-- UUID: bab05cb6-532f-41e0-8fba-203b1b92294b -->

The Sky Core Atlas is updated pursuant to the following requirements.

###### A.2.3.8.1.2.3.1.4.1.1 - Onboarding Integrators Active Data Update [Core]  <!-- UUID: 6857396f-f0ce-4471-8e48-ed5f06b86830 -->

[A.2.3.8.1.2.1.5.2.0.6.1 - List Of Onboarding Integrators](eb644108-94fc-430f-ae5a-e3294b9dd9be) is updated as follows:

- Updated fields
    ◦ `Onboarding Integrators/Integrator Name`
        - New value: set to the name of the Integrator
    ◦ `Integrator Name/Reward Code`
        - New value: set to Reward Code
- Responsible Party: Operational GovOps

###### A.2.3.8.1.2.3.1.4.2 - Agent Artifact Updates [Core]  <!-- UUID: 11161730-6568-445f-a250-ba5c67857390 -->

The Agent Artifact is updated pursuant to the following requirements. Each Output "set" is triggered following the completion of its respective Input stage, defined in [A.2.3.8.1.2.3.1.3 - Required Primitive Inputs](4d5482ad-7944-4073-8fbe-b9dbcd1a27a3). 

- After Prime Agent's `Initial planning document` Status is set to `Drafting`
    ◦ Create `Instance Configuration` Document for prospective Primitive Instance. The Instance Configuration Document contains a `Data Repository.`
        - Instance Status: (automatically inherits from `Primitive Hub Document`)
    ◦ Edit `Primitive Hub Document/In Progress Invocations Directory/Instance Name`
        - Updated fields:
            - Invocation Status:
                ◦ New value: set to `Planning`
            - Instance Configuration Document Location
                ◦ New value: link to `Instance Configuration Document` (created at Create `Instance Configuration` Document for prospective Primitive Instance. The Instance Configuration Document contains a `Data Repository.`)
    ◦ Responsible party: Operational GovOps [automated]
- After Prime Agent's `Initial planning document` Status is set to `Ready for GovOps review`.
    ◦ Edit `Primitive Hub Document/In Progress Invocations/Instance Name`
        - Updated fields:
            - Invocation Status:
                ◦ New value: set to `Pending GovOps review`
        - Responsible party: Operational GovOps [automated]
        - Trigger - Process: [A.2.3.8.1.2.3.2 - Process Definition For Operational GovOps Review](5fd265ef-17f0-4400-b06c-a6ce9fa87636).

###### A.2.3.8.1.2.3.2 - Process Definition For Operational GovOps Review [Core]  <!-- UUID: 5fd265ef-17f0-4400-b06c-a6ce9fa87636 -->

The documents herein define the process for Operational GovOps Review for an Invocation of the Distribution Reward Primitive.

###### A.2.3.8.1.2.3.2.1 - Process Initiation Logic [Core]  <!-- UUID: da868510-121f-442a-982e-8ab2d2149a25 -->

The process initiation logic is specified herein.

###### A.2.3.8.1.2.3.2.1.1 - Triggers [Core]  <!-- UUID: f89a41b2-973b-4eca-b463-e0e77bc719ef -->

Triggers are specified herein.

###### A.2.3.8.1.2.3.2.1.1.1 - Time-Based Triggers [Core]  <!-- UUID: d1d3de53-ad5a-40cb-9155-58db67a6340c -->

None.

###### A.2.3.8.1.2.3.2.1.1.2 - Document Update Triggers [Core]  <!-- UUID: fd211726-1576-4b0a-8489-6e76e83ee92b -->

This process is triggered by the Artifact Document Update specified at Edit `Primitive Hub Document/In Progress Invocations/Instance Name`.

###### A.2.3.8.1.2.3.2.1.2 - Dependencies [Core]  <!-- UUID: abb8f0ef-eae6-4af5-8a70-20630a33e7c9 -->

This process has no dependencies.

###### A.2.3.8.1.2.3.2.2 - Process Flow [Core]  <!-- UUID: ef743f33-32b0-4a51-af00-a9e35c2e1017 -->

The process flow is defined herein:

- Operational GovOps reviews the `Initial Planning Document` to ensure:

    ◦ Operational GovOps has the ability to operationalize the proposed tracking mechanism, and

    ◦ The proposed tracking mechanism accurately reflects USDS usage attributable to the actor and there is no possibility that rewards could be "double counted" (i.e. multiple actors being paid for the same USDS balance).

- Operational GovOps submits its feedback into the `Operational GovOps Review Document` (created at Create `Operational GovOps Review Document`.) along with suggested changes, if any.

- The Prime Agent incorporates feedback from Operational GovOps and edits its `Initial Planning Document` as needed.

###### A.2.3.8.1.2.3.2.3 - Required Primitive Inputs [Core]  <!-- UUID: 9c4653fa-6afe-4567-9e85-54c0a84b9311 -->

The following inputs must be submitted into the Primitive using the Powerhouse interface.

- Create `Operational GovOps Review Document`.
        -Updated fields
            - `Initial Planning Document`
                ◦ New Value: automatically links to respective Document
            - `Feedback Summary`
                ◦ New Value: GovOps populates with its review commentary and suggested changes that are agreed to by Agent and GovOps, if any.
            - Responsible party: Operational GovOps.

###### A.2.3.8.1.2.3.2.4 - Required Outputs [Core]  <!-- UUID: a7a3e2d3-54bd-4c0f-a222-505b5e14a5e4 -->

The documents herein specify the required outputs from this process.

###### A.2.3.8.1.2.3.2.4.1 - Sky Core Atlas Updates [Core]  <!-- UUID: 9a94a573-8a51-4b04-9704-d84dc0623bb8 -->

No Sky Core Atlas documents are updated as the output of this process.

###### A.2.3.8.1.2.3.2.4.2 - Agent Artifact Updates [Core]  <!-- UUID: ec050d61-1d48-453a-ac13-4cea23c68292 -->

The Agent Artifact is updated pursuant to the following requirements.

###### A.2.3.8.1.2.3.2.4.2.1 - Initial Planning Document Update [Core]  <!-- UUID: 66a07769-2de9-4b15-a439-4fc84b6a1575 -->

The Document is updated as follows.

- Updated fields
    ◦ `Tracking Methodology`
        - New Value: as applicable, update to reflect any changes agreed to between the Prime Agent and Operational GovOps
    ◦ Responsible Party: Operational GovOps

###### A.2.3.8.1.2.3.2.4.2.2 - Primitive Hub Document/In Progress Invocations Directory/Instance Name Update [Core]  <!-- UUID: 6f457b50-a98c-4516-9b37-932603a59627 -->

The Document is updated as follows.

- Updated fields
    ◦ Invocation Status
        - New value: set to `Proposal drafting in progress`
- Responsible Party: Operational GovOps [automated]
- Triggers: [A.2.3.8.1.2.3.3 - Process Definition For Artifact Update Draft](240e0e2c-64b6-4290-aa23-ec19eb2f6e59)

###### A.2.3.8.1.2.3.3 - Process Definition For Artifact Update Draft [Core]  <!-- UUID: 240e0e2c-64b6-4290-aa23-ec19eb2f6e59 -->

The documents herein define the process for preparing the Artifact Update Draft for an Invocation of the Distribution Reward Primitive.

###### A.2.3.8.1.2.3.3.1 - Process Initiation Logic [Core]  <!-- UUID: 9add3334-5779-4d23-bf5f-6c25cf9fcf9a -->

The process initiation logic is specified herein.

###### A.2.3.8.1.2.3.3.1.1 - Triggers [Core]  <!-- UUID: bdc8d447-a140-4580-b439-b3ac8deb5aac -->

Triggers are specified herein.

###### A.2.3.8.1.2.3.3.1.1.1 - Time-Based Triggers [Core]  <!-- UUID: e379a9d8-c0d2-4aa6-ab62-41a6767dc490 -->

None.

###### A.2.3.8.1.2.3.3.1.1.2 - Document Update Triggers [Core]  <!-- UUID: 94d06bae-9bc9-4e8f-a38d-4b879466873b -->

This process is triggered by the Document Update specified at [A.2.3.8.1.2.3.3.4.2.1 - Primitive Hub/In Progress Invocations Directory/Instance Name Update](b37c4266-2dd9-4cce-8b6b-cc35af2b94d9).

###### A.2.3.8.1.2.3.3.1.2 - Dependencies [Core]  <!-- UUID: a6f968d6-0e8c-4962-b982-43beffc602db -->

This process has no dependencies.

###### A.2.3.8.1.2.3.3.2 - Process Flow [Core]  <!-- UUID: ccb71126-1333-453c-aaeb-4359a8013f32 -->

The process flow is defined herein:

- The Prime Agent creates the `Artifact Edit Draft` Document and works to finalize its draft of the Artifact Edit per discussions with Operational GovOps.

- When draft is finalized, the Prime Agent triggers the creation of the `Artifact Edit Proposal`, which inherits content from the finalized `Artifact Edit Draft` Document.

- The Prime Agent submits the `Artifact Edit Proposal` Document to the Powerhouse system.

###### A.2.3.8.1.2.3.3.3 - Required Primitive Inputs [Core]  <!-- UUID: 6f4e7971-1813-4ff6-9e4f-5953c8cb54af -->

The required Primitive Inputs for this process are defined herein and implemented in sequential stages.

- Agent creates `Artifact Edit Draft` document; drafting in progress:
    ◦ Edit `Artifact Edit Draft`
        - Updated fields
            - Status
                ◦ New value: set to `In Progress`
            - Content
                ◦ New value: populate with drafted content

- Agent finalizes `Artifact Edit Draft`
    ◦ Edit `Artifact Edit Draft`
        - Updated fields
            - Status
                ◦ New value: set to `Draft Finalized`

- Powerhouse System Creates `Artifact Edit Proposal` Document
    ◦ Updated fields
        - Content
            - New value: Inherits data from Artifact Edit Draft content field.
    ◦ Responsible party: Operational GovOps [if not automated]

- Agent submits `Artifact Edit Proposal` Document to Powerhouse system
    ◦ Updated fields
        - Status:
            - New value: set to  `Pending Facilitator Review`
    ◦ Responsible party: Agent

###### A.2.3.8.1.2.3.3.4 - Required Outputs [Core]  <!-- UUID: c7ed27ce-d296-4a44-83c3-96bb1ed8976d -->

The documents herein specify the required outputs from this process.

###### A.2.3.8.1.2.3.3.4.1 - Sky Core Atlas Updates [Core]  <!-- UUID: 264273c8-7805-45ec-aa87-ebd08faf763d -->

No Sky Core Atlas documents are updated as the output of this process.

###### A.2.3.8.1.2.3.3.4.2 - Agent Artifact Updates [Core]  <!-- UUID: a3294ae2-3fd7-446a-a628-dbddd487931e -->

The Agent Artifact documents specified herein are updated as the output of this process.

###### A.2.3.8.1.2.3.3.4.2.1 - Primitive Hub/In Progress Invocations Directory/Instance Name Update [Core]  <!-- UUID: b37c4266-2dd9-4cce-8b6b-cc35af2b94d9 -->

The Document is updated as follows:

- Updated fields
    ◦ Invocation Status
        - New value: `Proposal Pending Facilitator Review`
- Responsible Party: Operational GovOps
- Triggers: [A.2.3.8.1.2.3.4 - Process Definition For Operational Facilitator Review](fd9aac63-00a0-4fc5-ad7c-8bb131322bd7).

###### A.2.3.8.1.2.3.4 - Process Definition For Operational Facilitator Review [Core]  <!-- UUID: fd9aac63-00a0-4fc5-ad7c-8bb131322bd7 -->

The documents herein define the process for Operational Facilitator Review for an Invocation of the Distribution Reward Primitive.

###### A.2.3.8.1.2.3.4.1 - Process Initiation Logic [Core]  <!-- UUID: 4e87663b-619e-46b6-a672-9bc81d11f4e7 -->

The process initiation logic is specified herein.

###### A.2.3.8.1.2.3.4.1.1 - Triggers [Core]  <!-- UUID: 48a12682-0218-4851-8a05-731ae7823b7b -->

Triggers are specified herein.

###### A.2.3.8.1.2.3.4.1.1.1 - Time-Based Triggers [Core]  <!-- UUID: 296a23ca-988b-4516-aa78-230ed17b0bbb -->

None.

###### A.2.3.8.1.2.3.4.1.1.2 - Document Update Triggers [Core]  <!-- UUID: bee5a2d9-1e98-4918-a77d-3e3607b51f0f -->

This process is triggered by the Document Update specified at [A.2.3.8.1.2.3.3.4.2.1 - Primitive Hub/In Progress Invocations Directory/Instance Name Update](b37c4266-2dd9-4cce-8b6b-cc35af2b94d9).

###### A.2.3.8.1.2.3.4.1.2 - Dependencies [Core]  <!-- UUID: 967572c4-ba29-4a98-ae05-e3698457d440 -->

This process has no dependencies.

###### A.2.3.8.1.2.3.4.2 - Process Flow [Core]  <!-- UUID: 67dce065-9fed-4c23-abf5-881371792796 -->

The process flow is defined herein.

- The Operational Facilitator reviews the `Artifact Edit Proposal` to ensure alignment with the Sky Core Atlas and the Agent Artifact.

- Where the Proposal is determined to be aligned, the Operational Facilitator updates the `Artifact Edit Proposal`  Document to reflect their approval and commentary, if applicable.

- Where the Proposal is determined to be misaligned, the Operational Facilitator updates the `Artifact Edit Proposal` document to reflect their rejection and commentary. Commentary is required where the Operational Facilitator rejects the proposal for misalignment.

###### A.2.3.8.1.2.3.4.3 - Required Primitive Inputs [Core]  <!-- UUID: 967f54c6-9a51-4225-a8fd-e366f7a3d91e -->

The required Primitive Inputs to this process are defined herein and organized as two mutually exclusive pathways. Once the Review outcome is determined by the Facilitator, the corresponding Pathway is followed to the exclusion of the other.

- Operational Facilitator Approves Proposal
    ◦ Edit `Artifact Edit Proposal`
        - Updated fields
            - `Operational Facilitator Review/Review Decision`
                ◦ New value: set to `Approved`
            - `Commentary`
                ◦ New value (optional): populate with reasoning for Approval
            - `Status`
                ◦ New value: set to `Proposal Approved by Facilitator` [automated]
        - Responsible party: Operational Facilitator
        - Trigger-Process: [A.2.3.8.1.2.3.5 - Process Definition For Offchain Vote](3170b9a1-d074-4cbd-bb81-ae1661bc0ed8) 

- Operational Facilitator Rejects proposal
    ◦ Edit `Artifact Edit Proposal`
        ◦ Updated fields
            - `Operational Facilitator Review/Review Decision`
                ◦ New value: set to `Rejected`
            - `Commentary`
                ◦ New value (required): populate with reasoning for Rejection
            - `Status`
                ◦ New value: set to `Proposal Rejected By Facilitator` [automated]
        ◦ Responsible party: Operational Facilitator

###### A.2.3.8.1.2.3.4.4 - Required Outputs [Core]  <!-- UUID: b63e78d1-112d-4d48-a647-a1e3fc2f54a5 -->

The documents herein specify the required outputs from this process, if any.

###### A.2.3.8.1.2.3.4.4.1 - Sky Core Atlas Updates [Core]  <!-- UUID: dfdf873a-c24a-4856-a3e9-717ea09dd9bb -->

No Sky Core Atlas documents are updated as the output of this process.

###### A.2.3.8.1.2.3.4.4.2 - Agent Artifact Updates [Core]  <!-- UUID: 9cb3ab72-37f5-4501-8661-a204d0747dd8 -->

No Agent Artifact documents are updated as the output of this process. The requirements specified in [A.2.3.8.1.2.3.4.3 - Required Primitive Inputs](967f54c6-9a51-4225-a8fd-e366f7a3d91e) fully complete the Process.

###### A.2.3.8.1.2.3.5 - Process Definition For Offchain Vote [Core]  <!-- UUID: 3170b9a1-d074-4cbd-bb81-ae1661bc0ed8 -->

The documents herein define the process for an Offchain Vote for an Invocation of the Distribution Reward Primitive.

###### A.2.3.8.1.2.3.5.1 - Process Initiation Logic [Core]  <!-- UUID: 3b38ec56-64c1-4093-82f0-fd5a162d549c -->

The process initiation logic is specified herein.

###### A.2.3.8.1.2.3.5.1.1 - Triggers [Core]  <!-- UUID: c743c744-a699-4236-b6d9-80563f789421 -->

Triggers are specified herein.

###### A.2.3.8.1.2.3.5.1.1.1 - Time-Based Triggers [Core]  <!-- UUID: 51f50be4-00f4-4023-8d43-dff42e8c7571 -->

None.

###### A.2.3.8.1.2.3.5.1.1.2 - Document Update Triggers [Core]  <!-- UUID: b43edb36-1255-4e9d-92e2-9e4435c7bb2f -->

This process is triggered by the Artifact Update specified at Operational Facilitator Approves Proposal.

###### A.2.3.8.1.2.3.5.1.2 - Dependencies [Core]  <!-- UUID: 174e41b1-0e93-491c-8da1-50c0845947c3 -->

This process has no dependencies.

###### A.2.3.8.1.2.3.5.2 - Process Flow [Core]  <!-- UUID: d0ceb4ed-8f65-45c6-808e-fca702dc2a62 -->

The process flow for this process is defined herein:

- Using the finalized `Atlas Edit Proposal` content, the Operational Facilitator sets up an offchain Snapshot vote.

- Prime Agent token holders vote on the proposal.

- After the voting concludes, the Operational Facilitator records the result of the vote in the Powerhouse system.

###### A.2.3.8.1.2.3.5.3 - Required Primitive Inputs [Core]  <!-- UUID: b593ff77-2c46-418d-a7b3-9730437ce804 -->

The required Primitive Inputs to this process are defined herein.

- After Facilitator prepares Snapshot vote:
    ◦ Edit `Artifact Edit Proposal` Document
        - Updated fields
            - Status
                ◦ New value: set to `Pending Poll`
            - Off-chain Snapshot
                ◦ New value: Populate with link to the official Snapshot page
        - Responsible party: Operational Facilitator

- Mutually Exclusive Input Pathways: The two Primitive Inputs below are mutually exclusive pathways. Once the vote concludes, the corresponding Pathway is followed to the exclusion of the other.

    ◦ Proposal Passes
        - Edit `Artifact Edit Proposal` Document
            - Update fields
                ◦ Status
                    - New value: set to `Poll Approved`
            - Responsible party: Operational Facilitator.
            - Trigger - Required Output: Proposal Passes

    ◦ Proposal Fails
        - Updated fields
            - Edit `Artifact Edit Proposal` Document
                ◦ Status
                    - New value: set to `Poll Rejected`
            - Responsible party: Operational Facilitator.
            - Trigger - Required Output: Proposal Fails

###### A.2.3.8.1.2.3.5.4 - Required Outputs [Core]  <!-- UUID: 1e95dff0-2a7f-461f-86f9-70433b888650 -->

The documents herein specify the required outputs from this process.

###### A.2.3.8.1.2.3.5.4.1 - Sky Core Atlas Updates [Core]  <!-- UUID: cc530c80-0c89-4c4a-b108-46a623f4f4c6 -->

No Sky Core Atlas documents are updated as the output of this process.

###### A.2.3.8.1.2.3.5.4.2 - Agent Artifact Updates [Core]  <!-- UUID: 1efa0fc5-5377-428f-a203-8c3c10dcc153 -->

The Agent Artifact documents specified herein are updated as the output of this process. The Output "sets" are mutually exclusive.

- Proposal Passes
    - Required Primitive Input Trigger: Proposal Passes see [A.2.3.8.1.2.3.5.3 - Required Primitive Inputs](b593ff77-2c46-418d-a7b3-9730437ce804)
    - Edit `Primitive Hub Document/In Progress Invocations Directory/Instance Name`
         -  Updated fields
            - Invocation Status
                - New value: set to `Proposal Approved`
         -  Responsible Party: Operational GovOps
         -  Trigger - Process:  [A.2.3.8.1.2.3.6 - Process Definition For Artifact Update](b3ed1e74-7ec2-4537-8e1d-2098dc17d984)

- Proposal Fails
    - Required Primitive Input Trigger: Proposal Fails see [A.2.3.8.1.2.3.5.3 - Required Primitive Inputs](b593ff77-2c46-418d-a7b3-9730437ce804)
    - Edit `Primitive Hub Document/In Progress Invocations Directory/Instance Name`
         -  Updated fields
            - Invocation Status
                - New value: set to `Proposal Rejected`
         -  Other Document Operations:
            - `Instance Configuration Document` is `Archived` in Primitive Hub Document/Hub Data Repository
         - Responsible Party: Operational GovOps

###### A.2.3.8.1.2.3.6 - Process Definition For Artifact Update [Core]  <!-- UUID: b3ed1e74-7ec2-4537-8e1d-2098dc17d984 -->

The documents herein define the Artifact Update process for an Invocation of the Distribution Reward Primitive.

###### A.2.3.8.1.2.3.6.1 - Process Initiation Logic [Core]  <!-- UUID: 005830a0-5845-4460-961a-9d5f15a722ab -->

The process initiation logic is specified herein.

###### A.2.3.8.1.2.3.6.1.1 - Triggers [Core]  <!-- UUID: 9e5fb847-18f1-4b86-989f-95ec770236b7 -->

Triggers are specified herein.

###### A.2.3.8.1.2.3.6.1.1.1 - Time-Based Triggers [Core]  <!-- UUID: 03ec388b-5e00-42da-a708-e2fd6a7d8775 -->

None.

###### A.2.3.8.1.2.3.6.1.1.2 - Document Update Triggers [Core]  <!-- UUID: 309ac677-8841-4821-aba5-6cf637b8e7a7 -->

This process is triggered by the Artifact update specified in Proposal passes.

###### A.2.3.8.1.2.3.6.1.2 - Dependencies [Core]  <!-- UUID: d7ec33fc-6c67-4632-80b2-1fab854699bc -->

This process has no dependencies.

###### A.2.3.8.1.2.3.6.2 - Process Flow [Core]  <!-- UUID: 3a23ed21-d9ac-4575-9c53-806fddb10f5c -->

The process flow is defined herein.

- Using the Powerhouse interface, the Operational Facilitator updates the Agent Artifact with the approved Proposal content.

###### A.2.3.8.1.2.3.6.3 - Required Primitive Inputs [Core]  <!-- UUID: 6eb0901b-d324-4124-b27e-5f5416264f37 -->

The following inputs must be submitted into the Primitive using the Powerhouse interface.

- Edit `Instance Configuration Document` to reflect ratified Primitive Instance.
    ◦ Updated fields
        - Parameters/Status - automatically inherits from `Primitive Hub Document`
        - Parameters/Reward Code
            - New Value: set to `Reward Code` value from approved Proposal
        - Parameters/Tracking Methodology
            - New Value: set to `Tracking Methodology` value from the approved Proposal
        - Parameters/Custom Instance Parameters
            - New Value: set to `Custom Instance Parameters` value from approved Proposal
        - Responsible Party: Operational GovOps [if not automated]

###### A.2.3.8.1.2.3.6.4 - Required Outputs [Core]  <!-- UUID: 231e3527-5534-42d4-b83e-0f99cb40bf76 -->

The documents herein specify the required outputs from this process.

###### A.2.3.8.1.2.3.6.4.1 - Sky Core Atlas Updates [Core]  <!-- UUID: 108174f5-b53d-4bc0-8576-172b27021121 -->

The Sky Core Documents specified herein are updated as the output of this process.

###### A.2.3.8.1.2.3.6.4.1.1 - Onboarding Integrators Active Data Update [Core]  <!-- UUID: 4287ecd9-5ba6-4646-b949-306b494a108c -->

[A.2.3.8.1.2.1.5.2.0.6.1 - List Of Onboarding Integrators](eb644108-94fc-430f-ae5a-e3294b9dd9be) is updated as follows:

- Updated fields
    ◦ `Onboarding Integrators`
        - New value: Delete the Integrator.
- Responsible Party: Operational GovOps
- Triggers: None

###### A.2.3.8.1.2.3.6.4.1.2 - Current Integrators Active Data Update [Core]  <!-- UUID: 1c0708d0-6388-4264-90f2-7a0d0b877012 -->

[**A.2.3.8.1.2.1.5.1.0.6.1 - List Of Current Integrators**](efbe7903-a76e-40f0-a440-56e463283157)** **is updated as follows:

- Updated fields
    ◦ `Current Integrators`
        - New value: set to the name of the Integrator from the approved Proposal
    ◦ `Reward Code`
        - New value: set to the Reward Code from the approved Proposal
    ◦ `Tracking Methodology`
        - New value: set to the tracking methodology from the approved Proposal
- Responsible Party: Operational GovOps
- Triggers: None

###### A.2.3.8.1.2.3.6.4.2 - Agent Artifact Updates [Core]  <!-- UUID: 8336c1ad-e182-4c91-b4f9-b5f743500457 -->

The Agent Artifact documents specified herein are updated as the output of this process.

###### A.2.3.8.1.2.3.6.4.2.1 - Instance Configuration Document Update [Core]  <!-- UUID: 3401c95d-3a9f-4af4-bc70-fb1be8f0f676 -->

The Document is updated as follows:

- Document Operations:
    ◦ Document is moved from `In Progress Invocations` to `Active Instances`
- Responsible Party: Operational Facilitator

###### A.2.3.8.1.2.3.6.4.2.2 - Primitive Hub Document/In Progress Invocations Directory/Instance Name Update [Core]  <!-- UUID: f5b8f596-5999-4ed8-a998-9c920bb86c14 -->

The Document  is updated as follows:

- Document Operations:
    ◦ Document is converted into `Active Instances Directory` schema and moved into that subtree
- Updated fields
    ◦ Instance Configuration Document location: link to `Instance Configuration Document` in `Active Instances` subtree
- Responsible Party: Operational Facilitator
- Trigger-Process: None.

###### A.2.3.8.1.2.4 - Instance Ongoing Management Protocol [Core]  <!-- UUID: 3af0e156-b5c0-493b-bd6f-80185072b7b1 -->

The documents herein define the process for the ongoing management of an Instance of the Distribution Reward Primitive.

###### A.2.3.8.1.2.4.1 - Routine Protocol [Core]  <!-- UUID: c2abdd22-fe0f-489e-b281-450e066db701 -->

The documents herein define the protocol for routine ongoing management of an Instance of the Distribution Reward Primitive.

###### A.2.3.8.1.2.4.1.1 - Process Definition For Reward Calculation By Operational Govops [Core]  <!-- UUID: 27229032-ddb6-41a5-a5d5-6168ccc3142f -->

The documents herein define the process for Distribution Reward Calculation by Operational GovOps. The Distribution Reward Calculation includes the calculation of the Fees for Unrewarded USDS Balances, the Fees for Rewarded USDS Balances, and the Prime Agent Management Fee.

###### A.2.3.8.1.2.4.1.1.1 - Process Initiation Logic [Core]  <!-- UUID: a0a60c30-1c73-4bb1-b4c3-92a5541ff4b2 -->

The process initiation logic is specified herein.

###### A.2.3.8.1.2.4.1.1.1.1 - Triggers [Core]  <!-- UUID: 7a9450db-0d90-4578-ad14-6a8308b2b4b8 -->

Triggers are specified herein.

###### A.2.3.8.1.2.4.1.1.1.1.1 - Time-Based Triggers [Core]  <!-- UUID: 3e14118d-b60b-49c4-a730-90eb3ad606a9 -->

This process is triggered on the 1st of every month for each Instance of the Distribution Reward Primitive with an Instance Status of `Active`.

###### A.2.3.8.1.2.4.1.1.1.1.2 - Document Update Triggers [Core]  <!-- UUID: 351bd87e-1795-4b00-ad05-2b9869394854 -->

None.

###### A.2.3.8.1.2.4.1.1.1.2 - Dependencies [Core]  <!-- UUID: dfd59dc4-365c-4718-833a-b859f00dff9b -->

This process has no dependencies.

###### A.2.3.8.1.2.4.1.1.2 - Process Flow [Core]  <!-- UUID: 70360ef3-14b5-4eaf-abc1-8c3ceb1596a1 -->

The process flow is defined herein:

- Operational GovOps calculates the eligible USDS and sUSDS balances using the Tracking Methodology specified in the Primitive Instance.

- Operational GovOps calculates the Distribution Reward due based on the USDS and sUSDS balances and the Distribution Reward formula for each.

- Operational GovOps updates the Powerhouse system with both the underlying data and their calculations.

###### A.2.3.8.1.2.4.1.1.3 - Required Primitive Inputs [Core]  <!-- UUID: 57921647-2a63-4d01-907b-131a50510d76 -->

The required Primitive Inputs to this process are specified herein.

- Edit `Distribution Reward Payments` Document (Active Data)
    ◦ Updated fields
        - Status
            - New value: set to `In Progress`
        - Underlying data
            - New value: populate with underlying data used to calculate the eligible USDS and sUSDS balances
        - Eligible USDS balance
            - New value: populate with calculated value
        - Eligible sUSDS balance
            - New value: populate with calculated value
        - Distribution Reward Due
            - New value: populate with calculated value.
    ◦ Responsible party: Operational GovOps.
    ◦ Trigger-Process: [A.2.3.8.1.2.4.1.2 - Process Definition For Reward Issuance From Operational Executor Agent Buffer](ddd65b02-3a2b-4478-a435-989324c2f1b8).

###### A.2.3.8.1.2.4.1.1.4 - Required Outputs [Core]  <!-- UUID: 082e5d05-9394-4b4a-8ef2-0e6d8110c2cc -->

The documents herein specify the required outputs from this process.

###### A.2.3.8.1.2.4.1.1.4.1 - Sky Core Atlas Updates [Core]  <!-- UUID: 34264a04-6a76-4bf0-9b32-283992d9364a -->

No Sky Core Atlas documents are updated as the output of this process.

###### A.2.3.8.1.2.4.1.1.4.2 - Agent Artifact Updates [Core]  <!-- UUID: f3ba519f-0d2f-4565-80be-3c095fc49b75 -->

No Agent Artifact documents are updated as the output of this process. The requirements specified [A.2.3.8.1.2.4.1.1.3 - Required Primitive Inputs](57921647-2a63-4d01-907b-131a50510d76) fully complete the Process.

###### A.2.3.8.1.2.4.1.2 - Process Definition For Reward Issuance From Operational Executor Agent Buffer [Core]  <!-- UUID: ddd65b02-3a2b-4478-a435-989324c2f1b8 -->

The documents herein define the process for Distribution Reward issuance from the Operational Executor Agent Buffer as part of ongoing management of an Instance of the Distribution Reward Primitive.

###### A.2.3.8.1.2.4.1.2.1 - Process Initiation Logic [Core]  <!-- UUID: a24bf9e6-3805-4a12-a277-ade2e24e0d77 -->

The process initiation logic is specified herein.

###### A.2.3.8.1.2.4.1.2.1.1 - Triggers [Core]  <!-- UUID: 18123d66-7a54-40dd-a4a7-389f83658247 -->

Triggers are specified herein.

###### A.2.3.8.1.2.4.1.2.1.1.1 - Time-Based Triggers [Core]  <!-- UUID: aa6d4d8e-1b6a-41d6-b5f8-29dde7d5a55a -->

None.

###### A.2.3.8.1.2.4.1.2.1.1.2 - Document Update Triggers [Core]  <!-- UUID: a66e1d9d-f113-4e83-8a17-77ce1724c2c9 -->

This process is triggered by the Required Primitive Inputs specified in Edit Distribution Reward Payments Document (Active Data).

###### A.2.3.8.1.2.4.1.2.1.2 - Dependencies [Core]  <!-- UUID: 3741afa3-1593-4ca5-b90c-186f499b111b -->

This process has no dependencies.

###### A.2.3.8.1.2.4.1.2.2 - Process Flow [Core]  <!-- UUID: 3373c13d-907d-420b-9ad8-3cf6b4645359 -->

The process flow is defined herein.

- Operational GovOps makes the payment to the reward address specified in the Primitive Instance from the Operational Executor Agent Buffer.

- Operational GovOps updates the Powerhouse system with the transaction details.

###### A.2.3.8.1.2.4.1.2.3 - Required Primitive Inputs [Core]  <!-- UUID: 63ba8de2-55ed-4df5-9e11-016a006cf828 -->

The required Primitive Inputs to this process are specified herein.

- Edit `Distribution Reward Payments` Document (Active Data)
    ◦ Updated fields
        - Status
            - New value: set to `Paid`
        - Transaction Details/Amount Paid
            - New value: populate with amount paid
        - Transaction Details/Tx hash
            - New value: populate with transaction hash
    ◦ Responsible Party: Operational GovOps
    ◦ Trigger - Process: [A.2.3.8.1.2.4.1.3 - Process Definition For Settlement Cycle And Core GovOps Review](dfd65786-e4be-4dad-9e34-cd6235a30a4f).

###### A.2.3.8.1.2.4.1.2.4 - Required Outputs [Core]  <!-- UUID: f33e0dee-b8e8-4d93-b56e-624dec274739 -->

The documents herein specify the required outputs from this process.

###### A.2.3.8.1.2.4.1.2.4.1 - Sky Core Atlas Updates [Core]  <!-- UUID: 810220a0-0694-4174-b438-6fb0a4b98299 -->

No Sky Core Atlas documents are updated as the output of this process.

###### A.2.3.8.1.2.4.1.2.4.2 - Agent Artifact Updates [Core]  <!-- UUID: ede7410d-a632-4209-ae79-7e3ba730cef1 -->

No Agent Artifact documents are updated as the output of this process. The requirements specified in [A.2.3.8.1.2.4.1.2.3 - Required Primitive Inputs](63ba8de2-55ed-4df5-9e11-016a006cf828) fully complete the process.

###### A.2.3.8.1.2.4.1.3 - Process Definition For Settlement Cycle And Core GovOps Review [Core]  <!-- UUID: dfd65786-e4be-4dad-9e34-cd6235a30a4f -->

The documents herein define the process for the Distribution Reward Settlement Cycle and Core GovOps review as part of ongoing management of an Instance of the Distribution Reward Primitive.

###### A.2.3.8.1.2.4.1.3.1 - Process Initiation Logic [Core]  <!-- UUID: e0495e9f-5dbd-4191-b52d-b87c6067d19a -->

The process initiation logic is specified herein.

###### A.2.3.8.1.2.4.1.3.1.1 - Triggers [Core]  <!-- UUID: 82b72cd2-b012-4865-9266-bcc35d644ec2 -->

Triggers are specified herein.

###### A.2.3.8.1.2.4.1.3.1.1.1 - Time-Based Triggers [Core]  <!-- UUID: 97fba609-d197-43dc-a6e1-72c6b2c48519 -->

This process is triggered at the beginning of every calendar quarter.

###### A.2.3.8.1.2.4.1.3.1.1.2 - Document Update Triggers [Core]  <!-- UUID: c96dd69d-2be3-451e-8551-a17de1c81579 -->

None.

###### A.2.3.8.1.2.4.1.3.1.2 - Dependencies [Core]  <!-- UUID: db7ad152-ee64-4185-b224-ad9ad7ec1093 -->

This process has no dependencies.

###### A.2.3.8.1.2.4.1.3.2 - Process Flow [Core]  <!-- UUID: 8b8308fd-e1ac-431c-8fe1-8e824ba7e978 -->

The process flow is defined herein.

- Core GovOps reviews Distribution Rewards calculations, including underlying data and calculation of balances and rewards due.

- Once Core GovOps has completed review, they update Powerhouse system to indicate that they confirm the accuracy of the Distribution Reward amounts.

###### A.2.3.8.1.2.4.1.3.3 - Required Primitive Inputs [Core]  <!-- UUID: b55afaef-db92-4bbf-8d80-258d5849ef1c -->

The required Primitive Inputs to this process are specified herein and are mutually exclusive pathways.

- Core GovOps Confirms Accuracy of Payment
    ◦ Edit `Distribution Reward Payments` Active Data Document
        - Updated fields
            - Core GovOps Review/Confirmation
                ◦ New value: populate with Yes
            - Core GovOps Review/Commentary
                ◦ New value (optional): populate with reasoning
        - Responsible party: Core GovOps
        - Trigger - Process: [A.2.3.8.1.2.4.1.3.4.1 - Sky Core Atlas Updates](cca17fe9-3dc9-48ce-be26-39a1625b3690) 

- Core GovOps Finds Inaccurate Payment
    ◦ Edit `Distribution Reward Payments` Active Data Document
        - Updated fields
            - Core GovOps Review/Confirmation
                ◦ New value: populate with No
            - Core GovOps Review/Commentary
                ◦ New value (required): populate with reasoning
        - Responsible party: Core GovOps
        - Trigger - Process: Payment Inaccuracy Previously Found By Core GovOps

###### A.2.3.8.1.2.4.1.3.4 - Required Outputs [Core]  <!-- UUID: 7cb3c11b-7356-4967-b232-6667b66b6f51 -->

The documents herein specify the required outputs from this process.

###### A.2.3.8.1.2.4.1.3.4.1 - Sky Core Atlas Updates [Core]  <!-- UUID: cca17fe9-3dc9-48ce-be26-39a1625b3690 -->

The Sky Core Atlas documents specified herein are updated as the output of this process.

- Payment Accuracy Previously Confirmed By Core GovOps
    ◦ The document [A.2.3.8.1.2.1.6.1.0.6.1 - Sky Core Distribution Reward Reimbursement Amounts](169eb312-ed63-4a83-9f5d-43b621c0705e) in the Sky Core Atlas is updated as follows:
        - Updated Fields
            - Status
                ◦ New value: populate with `Pending Payment`
            - Confirmed Reimbursement Due
                ◦ New value: populate with total Reimbursement amount
            - Reward Period
                ◦ New Value: populate with reward period
            - Operational Executor Agent
                ◦ New value: Populate with name of Operational Executor Agent
            - Prime Agent
                ◦ New value: Populate with name of Prime Agent.
        - Responsible Party: Core GovOps
        - Triggers: [A.2.3.8.1.2.4.1.4 - Process Definition For Executive Vote Reimbursement](59259360-a288-4412-a39a-da3991c60f8f) 
- Payment Inaccuracy Previously Found By Core GovOps
    ◦ TBD

###### A.2.3.8.1.2.4.1.3.4.2 - Agent Artifact Updates [Core]  <!-- UUID: 300fca05-66b1-4f31-966a-d26168ded7c3 -->

No Agent Artifact documents are updated as the output of this process.

###### A.2.3.8.1.2.4.1.4 - Process Definition For Executive Vote Reimbursement [Core]  <!-- UUID: 59259360-a288-4412-a39a-da3991c60f8f -->

The documents herein define the process for Distribution Reward Executive Vote reimbursement as part of ongoing management of an Instance of the Distribution Reward Primitive.

###### A.2.3.8.1.2.4.1.4.1 - Process Initiation Logic [Core]  <!-- UUID: f7bc89b8-424f-4f6a-8f1b-e173ca22f2ce -->

The process initiation logic is specified herein.

###### A.2.3.8.1.2.4.1.4.1.1 - Triggers [Core]  <!-- UUID: 14d233e1-0e8e-4dd5-915a-89f2b94f6e18 -->

Triggers are specified herein.

###### A.2.3.8.1.2.4.1.4.1.1.1 - Time-Based Triggers [Core]  <!-- UUID: b61d8b1d-5a03-41ba-9bc7-49e1e876b855 -->

None.

###### A.2.3.8.1.2.4.1.4.1.1.2 - Document Update Triggers [Core]  <!-- UUID: c298f200-2ac8-4fc3-9d02-e05f4cf2f42f -->

This process is triggered by the Document Update specified in **`Sky Core Distribution Reward Reimbursement`** **Active Data Document Update**.

###### A.2.3.8.1.2.4.1.4.1.2 - Dependencies [Core]  <!-- UUID: ae1c6021-2790-43ce-9d9b-fe8a17a64b60 -->

This process has no dependencies.

###### A.2.3.8.1.2.4.1.4.2 - Process Flow [Core]  <!-- UUID: ffa519f8-71f9-4285-892f-49e79f8ed0de -->

The process flow is defined herein:

- Core GovOps includes the Distribution Reward reimbursement in the next standard Executive Vote.

- After the Executive Vote passes, Core GovOps updates the Powerhouse system with the transaction details.

###### A.2.3.8.1.2.4.1.4.3 - Required Primitive Inputs [Core]  <!-- UUID: 6b90e3a1-48ce-4ac2-852e-00a8e4edf152 -->

The required Primitive Inputs to this process are specified herein and organized as sequential stages.

- Core GovOps adds reimbursement to Executive Vote
    ◦ Edit `Sky Core Distribution Reward Reimbursement Amounts`
        - Updated fields
            - Executive Vote Settlement/Executive Vote
                ◦ New value: links to proposal
            - Status
                ◦ New value: set to `Added to Executive Vote`

- After Executive Vote passes, Core GovOps updates Powerhouse system
    ◦ Edit `Sky Core Distribution Reward Reimbursement Amounts`
        - Updated fields
            - Executive Vote Settlement / Transaction Details/ Amount Paid
                ◦ New value: populate with amount paid to reimburse Operational Executor Agent Buffer
            - Executive Vote Settlement / Transaction Details / Tx Hash
                ◦ New value: Populate with transaction hash
            - Status
                ◦ New value: set to `Completed`

###### A.2.3.8.1.2.4.1.4.4 - Required Outputs [Core]  <!-- UUID: d14fff67-fd16-443b-9d32-763b052dce8b -->

The documents herein specify the required outputs from this process.

###### A.2.3.8.1.2.4.1.4.4.1 - Sky Core Atlas Updates [Core]  <!-- UUID: 7daf5881-434b-403e-b443-7bbfa0ce0534 -->

The Sky Core Atlas documents specified herein are updated as the output of this process.

###### A.2.3.8.1.2.4.1.4.4.1.1 - Sky Core Distribution Reward Reimbursement Active Data Update [Core]  <!-- UUID: 0c619a26-b9a6-495a-b7e6-a4a5c79c2da6 -->

The Document in the Sky Core Atlas is updated as follows:

- Updated fields
    ◦ Status
        - New value: set to `Paid`
    ◦ Responsible Party: Core GovOps
    ◦ Trigger-Process: None

###### A.2.3.8.1.2.4.1.4.4.2 - Agent Artifact Updates [Core]  <!-- UUID: 594d3b57-107d-44bc-a1bf-3f1291b8cccb -->

No Agent Artifact documents are updated as the output of this process.

###### A.2.3.8.1.2.4.2 - Non-Routine Protocol [Core]  <!-- UUID: e852bd1a-b257-4de9-b25b-63a5492ab720 -->

The documents herein define the protocol for non-routine ongoing management of an Instance of the Distribution Reward Primitive.

###### A.2.3.8.1.2.4.3 - Emergency Protocol [Core]  <!-- UUID: 81b89dda-558c-438e-8ba4-b75a977b8fd3 -->

The documents herein define the protocol for handling emergency situations in the ongoing management of an Instance of the Distribution Reward Primitive.

#### A.2.3.8.2 - Integration Boost Primitive [Core]  <!-- UUID: 73577399-62e4-4a83-ae11-64ef7e7b7f20 -->

The documents herein govern the Integration Boost Primitive.

##### A.2.3.8.2.1 - Introduction [Core]  <!-- UUID: 84b4b5c7-7125-4f8e-815d-72b3be20a8e9 -->

The documents herein provide an introduction to the Integration Boost Primitive.

###### A.2.3.8.2.1.1 - Purpose [Core]  <!-- UUID: a9751ac4-b292-4c43-a5e5-168df9f0e41e -->

The Integration Boost Primitive provides a low complexity version of the Sky Savings Rate to integration partners that hold USDS or lending markets that integrate USDS.

###### A.2.3.8.2.1.2 - Allowed Number Of Instances [Core]  <!-- UUID: 7853b196-73d9-4662-a4aa-f057aa64280c -->

Multiple instances of the Integration Boost Primitive are allowed. Each instance corresponds to an Integration Boost program.

###### A.2.3.8.2.1.3 - Multi-Instance Coordinator Document [Core]  <!-- UUID: 71c3bf8e-9c5c-447d-afb8-d6ca66acf45f -->

An Agent Artifact that has more than one active instance of the Integration Boost Primitive is not required to have a `Multi-Instance Coordinator Document`, since each Instance can be managed independently.

##### A.2.3.8.2.2 - Global Specification [Core]  <!-- UUID: eecfa6ad-3419-411e-b25a-1ccde2d6484b -->

The requirements herein apply universally across all possible deployments of the Integration Boost Primitive by Prime Agents. They include the steps that Agents must take to deploy the Primitive, including Global Activation of the Primitive, Instance Invocation, and ongoing management of the Primitive Instance(s).

###### A.2.3.8.2.2.1 - Base Elements [Core]  <!-- UUID: c398b383-3752-4534-aec6-4cd8e7292119 -->

The documents herein define the base elements of the Integration Boost Primitive.

###### A.2.3.8.2.2.1.1 - Integration Boost Partners [Core]  <!-- UUID: 31cb3b86-0125-4a04-996f-634b75b6cea2 -->

The Integration Boost is provided to DeFi protocol partners that allow users to deposit USDS balances. Sky makes payments to Integration Boost partners equal to the Sky Savings Rate times the Unrewarded USDS balances in their protocol. The expectation is that the Integration Boost Partner will pass these Integration Boost Payments along to their users, thus providing USDS users with the equivalent of the Sky Savings Rate.

Integration Boost partners are part of the Integrator Program as defined in [A.2.3.8.1.2.1.1 - Integrator Program](37c38f07-b5a0-40df-939c-a54330ea3c7b). 

Current and onboarding Integrators are recorded in [A.2.3.8.1.2.1.5 - Current And Onboarding Integrators](f3952cc5-cde2-46b9-b575-034dda83570b).

###### A.2.3.8.2.2.1.1.1 - No Obligation To Pass Through Integration Boost Payments [Core]  <!-- UUID: dc0bc012-2313-4eea-b898-2ebd97c2a59a -->

Integration Boost partners are under no obligation to pass through any portion of Integration Boost payments to their users. Nevertheless, the expectation is that most partners will pass through Integration Boost payments to remain competitive with other protocols.

###### A.2.3.8.2.2.1.2 - Data Submission [Core]  <!-- UUID: 756b466e-2bc0-43af-957f-d827593f5fe2 -->

The documents herein specify data submission requirements related to the Integrator Program.

###### A.2.3.8.2.2.1.2.1 - Data Verifiability Requirement [Core]  <!-- UUID: 6a2ec8d3-0403-46a9-8c96-3a9c86a59792 -->

Integration Boost Partners must submit net deposit data in such a form that the data can be verified by Sky using on-chain data. In the short term, the Core Council Risk Advisor calculates the net deposit data based on on-chain events and makes it available to Operational GovOps through an API endpoint. The API endpoint is [https://info-sky.blockanalitica.com/api/v1/incentivized-pools/](https://info-sky.blockanalitica.com/api/v1/incentivized-pools/) for Integration Boost Partners on Ethereum and [https://info-sky.blockanalitica.com/api/v1/solana-incentives/](https://info-sky.blockanalitica.com/api/v1/solana-incentives/) on Solana. In the long term, Operational GovOps assumes responsibility for ensuring that the data submission meets the on-chain verifiability requirement; this is done as part of their review of Invocations of the Integration Boost Primitive.

###### A.2.3.8.2.2.1.2.2 - Data Submission Responsible Party [Core]  <!-- UUID: 079abfa8-583a-4a95-a2d6-7fe50a1dd2dd -->

Integration Boost Partners must also identify a responsible party that will submit the net deposit data. In the near term, this is the Core Council Risk Advisor. In the long term, this may be the Integration Boost Partner, a third party contractor, or the Prime Agent or Operational GovOps themselves if they agree to do so.

###### A.2.3.8.2.2.1.2.3 - Data Submission Frequency [Core]  <!-- UUID: a26ea73f-ab67-4e02-93cd-b43d22a6e63c -->

Data is calculated on a weekly basis from Monday to Sunday for payment the following Monday. Failure to submit data on time will result in a delay of payment of the Integration Boost until the following week.

###### A.2.3.8.2.2.1.3 - Distribution [Core]  <!-- UUID: 3b3914d0-eb7b-4a49-bbca-5f6237a4a8ac -->

The documents herein define base elements of the Integration Boost Primitive related to the distribution of the Integration Boost.

###### A.2.3.8.2.2.1.3.1 - Cadence [Core]  <!-- UUID: 181954b6-d22c-4605-bffa-b5d964fbb10d -->

The Cadence is the frequency at which the Integration Boost is calculated and distributed. There are only three options available for the Reward Cadence: (1) weekly, (2) biweekly, or (3) monthly.

###### A.2.3.8.2.2.1.3.2 - Treasury Management [Core]  <!-- UUID: e27f2332-1072-4b61-84ab-efe6f2ca056e -->

The documents herein define the treasury management process.

###### A.2.3.8.2.2.1.3.2.1 - Near Term Process [Core]  <!-- UUID: 4ab621b4-ef8e-4b01-a6aa-9296601033c5 -->

In the short term, the Support Facilitators directly pay Integration Boost recipients from Integration Boost wallets. The balance of these wallets on the Ethereum Mainnet may be topped up to 3 million USDS, although the balance of Integration Boost wallets across blockchains may exceed that amount. The funding is subject to an Executive Vote. The addresses of these wallets are:

- Ethereum (ETH) - `0xD6891d1DFFDA6B0B1aF3524018a1eE2E608785F7`
- Solana (SOL) - `7Gf8AqAtmYkkVhQbbJr18RxVUuoGjA8ZEw3Af4NauyaY`
- Solana Hot Wallet - `BKT2JR5wRWsXQBxrht1LbbbKtgUkz3sJdaBY8UzgRJPL`

###### A.2.3.8.2.2.1.3.2.2 - Long Term Process [Core]  <!-- UUID: 787276c9-728b-491f-84d6-c1303fe72986 -->

In the long term, Operational GovOps calculates the Integration Boost for each occurrence of the specified Cadence. Operational GovOps then pays the Integration Boost recipient from its Buffer. Later, Sky Core reimburses the Operational Agent Buffer for the amount paid as part of the Settlement Cycle. This minimizes the role of Sky Core in Integration Boost payments and emphasizes the primary role of the Operational Executor Agent, acting through Operational GovOps, in implementing the Sky Primitives. The process is specified in further detail in [A.2.3.8.2.2.4.1 - Routine Protocol](04864587-25ef-4179-b237-4dd0a23485a4).

###### A.2.3.8.2.2.1.3.3 - Payment Errors [Core]  <!-- UUID: 8d19b08f-d10e-4db2-9e21-03e5021bdaec -->

If it is discovered that previous Integration Boost calculations were made erroneously, underpayments are resolved retroactively. In cases where an Integrator was overpaid, the Prime Agent associated with the Integrator must reimburse Sky the overpayment amount and can use future Integration Boost payments that the Integrator earns to reimburse itself.

###### A.2.3.8.2.2.1.4 - Distribution Rewards [Core]  <!-- UUID: d71a7b9c-3d0e-4383-9671-098bead326c1 -->

Net USDS balances in a DeFi protocol that is receiving an Integration Boost are also eligible for the Distribution Reward.

###### A.2.3.8.2.2.1.4.1 - Reporting Of Net USDS Balances Is Valid Tracking Methodology [Core]  <!-- UUID: a4ca2e70-d013-4c54-8e17-1d6f352ddbc0 -->

The methodology used to report net USDS balances in the protocol for the Integration Boost is itself an acceptable Tracking Methodology for purposes of the Accessibility Reward.

###### A.2.3.8.2.2.1.4.2 - No Double Payments [Core]  <!-- UUID: 5828a3a0-243d-48a5-b537-297015a0c5f5 -->

Distribution Reward may only be paid on net USDS balances of an Integration Boost partner to the extent that a Distribution Reward is not already being paid on those balances.

###### A.2.3.8.2.2.1.4.3 - Prime Agent May Choose Whether To Share Distribution Reward With Integration Boost Partner [Core]  <!-- UUID: c27d41eb-61f4-4daa-a9c3-b463fa840f60 -->

Prime Agents may choose whether to share Distribution Reward payments with Integration Boost Partners.

###### A.2.3.8.2.2.1.5 - Integration Boost Reimbursement [Core]  <!-- UUID: 63ff5ae5-4a50-4d44-b7e4-526608c44598 -->

The documents herein specify the Integration Boost reimbursement.

###### A.2.3.8.2.2.1.5.1 - Sky Core Integration Boost Reimbursement [Active Data Controller]  <!-- UUID: 7ed013c9-f7ac-4459-8675-8bbd398d5133 -->

The Integration Boost reimbursement payments are defined as Active Data in [A.2.3.8.2.2.1.5.1.0.6.1 - Sky Core Integration Boost Reimbursement Amounts](8cbff90b-5633-427e-91da-0fb775812535). 
 
The Active Data is updated as follows:
- The Responsible Party is Core GovOps.
- The Update Process must follow the protocol for ‘Direct Edit’.

###### A.2.3.8.2.2.1.5.1.0.6.1 - Sky Core Integration Boost Reimbursement Amounts [Active Data]  <!-- UUID: 8cbff90b-5633-427e-91da-0fb775812535 -->

The current Sky Core Integration Boost Reimbursement Amounts are:

###### A.2.3.8.2.2.2 - Global Activation [Core]  <!-- UUID: 4ad2a180-10bd-443d-ba5b-3e46f2b5cf52 -->

An Agent who intends to deploy the Integration Boost Primitive must first Globally Activate it.

###### A.2.3.8.2.2.2.1 - Process Initiation Logic [Core]  <!-- UUID: b68f9009-e002-4d92-bcb6-c0aeca9239a5 -->

The process initiation logic is specified herein.

###### A.2.3.8.2.2.2.1.1 - Triggers [Core]  <!-- UUID: ea3fd0be-411c-44e4-9539-2c88000110b5 -->

Triggers are specified herein.

###### A.2.3.8.2.2.2.1.1.1 - Time-Based Triggers [Core]  <!-- UUID: 7457b041-e037-43fa-aee9-107bacdb3acb -->

None.

###### A.2.3.8.2.2.2.1.1.2 - Document Update Triggers [Core]  <!-- UUID: a007505e-aa58-40f5-bf83-1ded2aa87588 -->

None.

###### A.2.3.8.2.2.2.1.2 - Dependencies [Core]  <!-- UUID: befbf1d8-aa4e-4326-9536-6620754cc96b -->

See [A.2.3.1.2.4 - Changing A Primitive’s Global Activation Status](51cfca28-c8de-457a-abc4-8ce1f64abb91) for constraints on when an Agent can Globally Activate this Primitive.

###### A.2.3.8.2.2.2.2 - Process Flow [Core]  <!-- UUID: 163b998a-50fe-4bbe-872c-748f526f7604 -->

The Prime Agent uses the Powerhouse interface to Globally Activate (toggle on) the Integration Boost Primitive.

###### A.2.3.8.2.2.2.3 - Required Primitive Inputs [Core]  <!-- UUID: 5e673229-0130-4b2c-94ce-f8597babd9c1 -->

The following inputs must be submitted into the Primitive using the Powerhouse interface:

- **Create** `Primitive Hub Document`
    ◦ Updated Field: Global Activation Status
        - New Value: set to `Activated`

###### A.2.3.8.2.2.2.4 - Required Outputs [Core]  <!-- UUID: 9a9b56f4-eef8-4d31-af06-3b6d5ba4cb60 -->

The documents herein specify the required outputs from this process.

###### A.2.3.8.2.2.2.4.1 - Sky Core Atlas Updates [Core]  <!-- UUID: 74f88b57-beef-4cae-a2a6-fafd74812e5c -->

No Sky Core Atlas documents are updated as the output of this process.

###### A.2.3.8.2.2.2.4.2 - Agent Artifact Updates [Core]  <!-- UUID: 35c38264-03ec-4485-9de6-2ff368981066 -->

No Agent Artifact documents are updated as the output of this process. The requirements specified in [A.2.3.8.2.2.2.3 - Required Primitive Inputs](5e673229-0130-4b2c-94ce-f8597babd9c1) fully complete the Process.

###### A.2.3.8.2.2.3 - Instance Invocation Protocol [Core]  <!-- UUID: a1dc075e-6c36-4375-89ff-fe9bb2c7a2fa -->

After fulfilling the requirements for Global Activation, an Agent can Invoke its first Instance of the Integration Boost Primitive by following the sequential process specified herein. Subsequent Invocations of the Primitive must adhere to the same requirements defined below.

###### A.2.3.8.2.2.3.1 - Process Definition For Initial Opportunity Identification And Planning [Core]  <!-- UUID: a14cea92-f114-4cc8-abfe-77b202e3c1f7 -->

The documents herein specify the process definition for initial opportunity identification and planning.

###### A.2.3.8.2.2.3.1.1 - Process Initiation Logic [Core]  <!-- UUID: 2645e2f0-2624-4fd0-bdc7-2eb09fe28498 -->

The process initiation logic is specified herein.

###### A.2.3.8.2.2.3.1.1.1 - Triggers [Core]  <!-- UUID: 32cc16f9-2d59-4722-b56a-7f9eae661b57 -->

Triggers are specified herein.

###### A.2.3.8.2.2.3.1.1.1.1 - Time-Based Triggers [Core]  <!-- UUID: e06ee9c9-72a5-47ac-8a20-400b3615994a -->

None.

###### A.2.3.8.2.2.3.1.1.1.2 - Document Update Triggers [Core]  <!-- UUID: def2ad89-c78b-4662-a2c3-5a889dbbd722 -->

None.

###### A.2.3.8.2.2.3.1.1.2 - Dependencies [Core]  <!-- UUID: 85a0d037-6b82-4435-aa6d-2d8b481c8f60 -->

This process is dependent on a Prime Agent Globally Activating the Integration Boost Primitive pursuant to [A.2.3.8.2.2.2 - Global Activation](4ad2a180-10bd-443d-ba5b-3e46f2b5cf52).

###### A.2.3.8.2.2.3.1.2 - Process Flow [Core]  <!-- UUID: 179cb7a5-60ee-4fa0-bc22-d70d4a15c575 -->

The process flow is defined herein.

- The Prime Agent identifies a DeFi protocol or market where an Integration Boost would drive adoption. The Prime Agent estimates the potential earnings from the Distribution Reward associated with the incremental USDS usage versus the operational cost of funding the Sky Savings Rate payouts.

- The Prime Agent and the prospective Integration Boost partner discuss (1) the proposed Integration Boost cadence and (2) whether and how the protocol operator also receives a portion of the Distribution Reward.

###### A.2.3.8.2.2.3.1.3 - Required Primitive Inputs [Core]  <!-- UUID: b91d0eb6-fa86-486c-8350-4564bdb5af09 -->

The required Primitive Inputs for this process are defined herein and organized in sequential stages.

- Drafting of Initial Planning Document

    ◦ Create `Initial Planning Document`
        - Updated fields
            - `Status`
                ◦ New value: set to `Drafting`
            - `Integration Partner Name`
                ◦ New Value: set to Integration Partner name
            - `Integration Partner Reward Address`
                ◦ New Value: set to Integration Partner reward address
            - `Integration Partner Chain`
                ◦ New Value: set to Integration Partner chain
            - `Integration Boost Cadence`
                ◦ New Value: set to Integration Boost cadence
            - `Integration Boost Data Submission Format`
                ◦ New Value: populate with details for format of data submission
            - `Integration Boost Data Submission Responsible Actor`
                ◦ New Value: set to Actor responsible for data submission
            - `Integration Boost Savings Rate Adjustment Strategy`
                ◦ New Value: populate with details for handling adjustments to Sky Savings Rate
            - `Custom Instance Parameters`
                ◦ New Value: populate with details for any custom parameters
        - Responsible Party: Prime Agent Team
        - Trigger - Required Output: After Prime Agent's `Initial planning document` Status is set to `Drafting` 

- Initial Planning Document triggered for GovOps review

    ◦ Edit `Initial Planning Document`
        - Updated fields
            - `Integration Boost Savings Rate Adjustment Strategy`
                ◦ New value: updated content, as applicable
            - `Status`
                ◦ New value: set to `Ready for GovOps Review`
        - Responsible party: Prime Agent
        - Trigger - Required Output: After Prime Agent's `Initial planning document` Status is set to `Ready for GovOps review`.

###### A.2.3.8.2.2.3.1.4 - Required Outputs [Core]  <!-- UUID: c0e07df6-d6b9-4268-95a6-f0f42877a639 -->

The documents herein specify the required outputs from this process.

###### A.2.3.8.2.2.3.1.4.1 - Sky Core Atlas Updates [Core]  <!-- UUID: 991aaf4f-3d85-41c3-b0c3-d1cf3a84ec0d -->

The Sky Core Atlas is updated pursuant to the following requirements.

###### A.2.3.8.2.2.3.1.4.1.1 - Onboarding Integrators Active Data Update [Core]  <!-- UUID: a227491c-903f-4571-aad0-b76422a5ea7f -->

[A.2.3.8.1.2.1.5.2.0.6.1 - List Of Onboarding Integrators](eb644108-94fc-430f-ae5a-e3294b9dd9be) is updated as follows:

- Updated fields
    ◦ `Onboarding Integrators/Integrator Name`
        - New value: set to the name of the Integrator
- Responsible Party: Operational GovOps

###### A.2.3.8.2.2.3.1.4.2 - Agent Artifact Updates [Core]  <!-- UUID: d86e5f9f-7b1c-4605-9253-4281a6bdbc13 -->

The Agent Artifact is updated pursuant to the following requirements. Each Output "set" is triggered following the completion of its respective Input stage, which latter is defined in [A.2.3.8.2.2.3.1.3 - Required Primitive Inputs](b91d0eb6-fa86-486c-8350-4564bdb5af09). 

- After Prime Agent's `Initial planning document` Status is set to `Drafting`
    ◦ Create `Instance Configuration` Document for prospective Primitive Instance. The Instance Configuration Document contains a `Data Repository`.
        - Instance Status: (automatically inherits from `Primitive Hub Document`)
    ◦ Edit `Primitive Hub Document/In Progress Invocations Directory/Instance Name`
        - Updated fields:
            - Invocation Status:
                ◦ New value: set to `Planning`
            - Instance Configuration Document Location
                ◦ New value: link to `Instance Configuration Document` (created at Create `Instance Configuration` Document for prospective Primitive Instance. The Instance Configuration Document contains a `Data Repository`.)
    ◦ Responsible party: Operational GovOps [automated]

- After Prime Agent's `Initial planning document` Status is set to `Ready for GovOps review`.
    ◦ Edit `Primitive Hub Document/In Progress Invocations/Instance Name`
        - Updated fields:
            - Invocation Status:
                ◦ New value: set to `Pending GovOps review`
        - Responsible party: Operational GovOps [ automated]
        - Trigger - Process: [A.2.3.8.2.2.3.2 - Process Definition for Operational GovOps Review](38c54d2b-715b-433d-a9ff-af5cbecc89a2).

###### A.2.3.8.2.2.3.2 - Process Definition for Operational GovOps Review [Core]  <!-- UUID: 38c54d2b-715b-433d-a9ff-af5cbecc89a2 -->

The documents herein define the process for Operational GovOps Review for an Invocation of the Integration Boost Primitive.

###### A.2.3.8.2.2.3.2.1 - Process Initiation Logic [Core]  <!-- UUID: ef37ff82-5639-4b5a-88b3-04cc4a4539cb -->

The process initiation logic is specified herein.

###### A.2.3.8.2.2.3.2.1.1 - Triggers [Core]  <!-- UUID: cb905fcc-6834-42a4-a0e8-534e600fad7e -->

Triggers are specified herein.

###### A.2.3.8.2.2.3.2.1.1.1 - Time-Based Triggers [Core]  <!-- UUID: ff9674e1-174c-4365-ba27-4af0aa10539e -->

None.

###### A.2.3.8.2.2.3.2.1.1.2 - Document Update Triggers [Core]  <!-- UUID: 4290c4b4-5c4d-4de5-bcbe-7d4d6db8b755 -->

This process is triggered by the Artifact Update specified at Edit `Primitive Hub Document/In Progress Invocations/Instance Name`.

###### A.2.3.8.2.2.3.2.1.2 - Dependencies [Core]  <!-- UUID: 921d945d-5e36-4ffd-8c30-447aeca18045 -->

This process has no dependencies.

###### A.2.3.8.2.2.3.2.2 - Process Flow [Core]  <!-- UUID: 0eba9704-14c9-4be3-ab41-62129ff9f162 -->

The process flow is defined herein:

- Operational GovOps reviews the `Initial Planning Document` to ensure:
    ◦ The submitted data can be verified using on-chain data;
    ◦ the Savings Rate Adjustment Strategy ensures that the payment on USDS balances equals the Sky Savings Rate, and
    ◦ the submitted data accurately reflects USDS deposits in the Integration Partner protocol and there is no possibility that rewards could be "double counted" (i.e. multiple actors being paid for the same USDS balance).

- Operational GovOps submits its feedback into the `Operational GovOps Review Document` (created at Create `Operational GovOps Review Document`) along with suggested changes, if any.

- The Prime Agent incorporates feedback from Operational GovOps and edits its `Initial Planning Document` as needed.

###### A.2.3.8.2.2.3.2.3 - Required Primitive Inputs [Core]  <!-- UUID: 1eafc42a-1fd2-4f96-988c-8dc37c1ab317 -->

The following inputs must be submitted into the Primitive using the Powerhouse interface.

- Create `Operational GovOps Review Document`
    ◦ Updated fields
        - `Initial Planning Document`
            - New Value: automatically links to respective Document
        - `Feedback Summary`
            - New Value: GovOps populates with its review commentary and suggested changes that are agreed to by Agent and GovOps, if any.
        - Responsible party: Operational GovOps.

###### A.2.3.8.2.2.3.2.4 - Required Outputs [Core]  <!-- UUID: 0bce1c09-ba85-418f-8cf7-0f51c8fa0584 -->

The documents herein specify the required outputs from this process.

###### A.2.3.8.2.2.3.2.4.1 - Sky Core Atlas Updates [Core]  <!-- UUID: 689a6ce6-0091-4e6a-b634-27ade6064e6b -->

No Sky Core Atlas documents are updated as the output of this process.

###### A.2.3.8.2.2.3.2.4.2 - Agent Artifact Updates [Core]  <!-- UUID: 22166d2b-40bc-4094-a3d8-fce46699a905 -->

The Agent Artifact is updated pursuant to the following requirements.

###### A.2.3.8.2.2.3.2.4.2.1 - Initial Planning Document Update [Core]  <!-- UUID: ddcfe438-e322-425b-82c6-3bba3ce33823 -->

The Document is updated as follows.

- Updated fields
    ◦ `Integration Boost Savings Rate Adjustment Strategy`
        - New Value: as applicable, update to reflect any changes agreed to between the Prime Agent and Operational GovOps
    ◦ `Integration Boost Data Submission Format`
        - New Value: as applicable, update to reflect any changes agreed to between the Prime Agent and Operational GovOps
    ◦ Responsible Party: Operational GovOps

###### A.2.3.8.2.2.3.2.4.2.2 - Primitive Hub Document Update [Core]  <!-- UUID: 09ddd2c5-3768-4538-b979-629e1b369299 -->

The Document is updated as follows.

- Updated fields
    ◦ Active instances/Instance name/Instance status -
        - New value: set to `Proposal drafting in progress`
- Responsible Party: Operational GovOps [automated]
- Triggers: [A.2.3.8.2.2.3.3 - Process Definition for Artifact Update Draft](6a8b5e8b-cca6-48be-b543-6db468f83ebb).

###### A.2.3.8.2.2.3.3 - Process Definition for Artifact Update Draft [Core]  <!-- UUID: 6a8b5e8b-cca6-48be-b543-6db468f83ebb -->

The documents herein define the process for preparing the Artifact Update Draft for an Invocation of the Integration Boost Primitive.

###### A.2.3.8.2.2.3.3.1 - Process Initiation Logic [Core]  <!-- UUID: cc3d967c-ec99-4c9c-a874-c42b8412791d -->

The process initiation logic is specified herein.

###### A.2.3.8.2.2.3.3.1.1 - Triggers [Core]  <!-- UUID: 428d6e85-5c6d-4469-9bc8-e1a127427ac0 -->

Triggers are specified herein.

###### A.2.3.8.2.2.3.3.1.1.1 - Time-Based Triggers [Core]  <!-- UUID: 42848ad7-ad2e-402f-8ec5-cf6ee991c46c -->

None.

###### A.2.3.8.2.2.3.3.1.1.2 - Document Update Triggers [Core]  <!-- UUID: 98b5465e-add9-4ae0-a02e-1c5be6006410 -->

This process is triggered by the Document Update specified at [A.2.3.8.2.2.3.2.4.2.2 - Primitive Hub Document Update](09ddd2c5-3768-4538-b979-629e1b369299).

###### A.2.3.8.2.2.3.3.1.2 - Dependencies [Core]  <!-- UUID: a616c3f6-b252-4d85-996a-019dea9f01e7 -->

This process has no dependencies.

###### A.2.3.8.2.2.3.3.2 - Process Flow [Core]  <!-- UUID: c860168e-b88e-4d2a-ad0b-388288d1e0cb -->

The process flow is defined herein:

- The Prime Agent creates the `Artifact Edit Draft` Document and works to finalize its draft of the Artifact Edit per discussions with Operational GovOps.

- When draft is finalized, the Prime Agent triggers the creation of the `Artifact Edit Proposal`, which inherits content from the finalized `Artifact Edit Draft` Document.

- The Prime Agent submits the `Artifact Edit Proposal` Document to the Powerhouse system.

###### A.2.3.8.2.2.3.3.3 - Required Primitive Inputs [Core]  <!-- UUID: 01214a59-5119-4c77-ad41-c9d3dd72a517 -->

The required Primitive Inputs for this process are defined herein and implemented in sequential stages.

- Agent creates `Artifact Edit Draft` document; drafting in progress

    ◦ Edit `Artifact Edit Draft`
        - Updated fields
            - Status
                ◦ New value: set to `In Progress`
            - Content
                ◦ New value: populate with drafted content

- Agent finalizes `Artifact Edit Draft`
    ◦ Edit `Artifact Edit Draft`
        - Updated fields
            - Status
                ◦ New value: set to `Draft Finalized`

- Powerhouse System Creates `Artifact Edit Proposal` Document
    ◦ Updated fields
        - Content
            - New value: Inherits data from `Artifact Edit Draft` Document’s Content field.
    ◦ Responsible party: Operational GovOps [if not automated]

- Agent submits `Artifact Edit Proposal` Document to Powerhouse system
    ◦ Updated fields
        - Status:
            - New value: set to  `Pending Facilitator Review`
    ◦ Responsible Party: Agent

###### A.2.3.8.2.2.3.3.4 - Required Outputs [Core]  <!-- UUID: bea2c790-2359-4bb7-8744-3f43deb05d26 -->

The documents herein specify the required outputs from this process.

###### A.2.3.8.2.2.3.3.4.1 - Sky Core Atlas Updates [Core]  <!-- UUID: 7e4e6528-b8a7-4aff-8d98-3cc3279c4f28 -->

No Sky Core Atlas documents are updated as the output of this process.

###### A.2.3.8.2.2.3.3.4.2 - Agent Artifact Updates [Core]  <!-- UUID: f654be61-baa0-4d5e-8d66-a9d8b3d5b277 -->

The Agent Artifact documents specified herein are updated as the output of this process.

###### A.2.3.8.2.2.3.3.4.2.1 - Primitive Hub Document Update [Core]  <!-- UUID: e7fc7c2e-b6fc-4e0f-ae10-debb54124e8e -->

The Document in the Agent Artifact is updated as follows:

- Updated fields
    ◦ Active Instances/Instance Name/Instance Status
        - New value: `Proposal Pending Facilitator Review`
- Responsible Party: Operational GovOps
- Triggers: [A.2.3.8.2.2.3.4 - Process Definition for Operational Facilitator Review](2d1d83ea-2a90-4c34-93ea-5bea390f3f62).

###### A.2.3.8.2.2.3.4 - Process Definition for Operational Facilitator Review [Core]  <!-- UUID: 2d1d83ea-2a90-4c34-93ea-5bea390f3f62 -->

The documents herein define the process for Operational Facilitator Review for an Invocation of the Integration Boost Primitive.

###### A.2.3.8.2.2.3.4.1 - Process Initiation Logic [Core]  <!-- UUID: 53016a06-1989-49af-8629-8cac254ef771 -->

The process initiation logic is specified herein.

###### A.2.3.8.2.2.3.4.1.1 - Triggers [Core]  <!-- UUID: 9fa7d744-2f7d-4fb5-81e2-0b348eb01bb6 -->

Triggers are specified herein.

###### A.2.3.8.2.2.3.4.1.1.1 - Time-Based Triggers [Core]  <!-- UUID: c3b16255-ecdc-4d42-9345-945ede629203 -->

None.

###### A.2.3.8.2.2.3.4.1.1.2 - Document Update Triggers [Core]  <!-- UUID: 555a08a4-e028-44bd-9ba2-91e4bbf61644 -->

This process is triggered by the Document Update specified at [A.2.3.8.2.2.3.2.4.2.2 - Primitive Hub Document Update](09ddd2c5-3768-4538-b979-629e1b369299).

###### A.2.3.8.2.2.3.4.1.2 - Dependencies [Core]  <!-- UUID: f19c7277-65b4-4755-8756-fb0a242ba6a2 -->

This process has no dependencies.

###### A.2.3.8.2.2.3.4.2 - Process Flow [Core]  <!-- UUID: 1b0c0956-1890-405f-b27b-22399b04526c -->

The process flow is defined herein.

- The Operational Facilitator reviews the `Artifact Edit Proposal` to ensure alignment with the Sky Core Atlas and the Agent Artifact.

- Where the Proposal is determined to be aligned, the Operational Facilitator updates the `Artifact Edit Proposal`  Document to reflect their approval and commentary, if any.

- Where the Proposal is determined to be misaligned, the Operational Facilitator updates the `Artifact Edit Proposal` document to reflect their rejection and commentary. Commentary is required where the Operational Facilitator rejects the proposal for misalignment.

###### A.2.3.8.2.2.3.4.3 - Required Primitive Inputs [Core]  <!-- UUID: 7f991abf-3395-4f92-82e1-88e991ebd97a -->

The required Primitive Inputs to this process are defined herein and organized as two mutually exclusive pathways. Once the Review outcome is determined by the Facilitator, the corresponding Pathway is followed to the exclusion of the other.

- Operational Facilitator Approves Proposal
    ◦ Edit `Artifact Edit Proposal`
        - Updated fields
            - `Operational Facilitator Review/Review Decision`
                ◦ New value: set to `Approved`
            - `Commentary`
                ◦ New value (optional): populate with reasoning for Approval
            - `Status`
                ◦ New value: set to `Proposal Approved by Facilitator` [automated]
        - Responsible party: Operational Facilitator
        - Trigger-Process: [A.2.3.8.2.2.3.5 - Process Definition for Offchain Vote](24fa76f6-4728-4f1d-97ff-fd7e72dac2ac).
 
- Operational Facilitator Rejects Proposal
    ◦ Edit `Artifact Edit Proposal`
        - Updated fields
            - `Operational Facilitator Review/Review Decision`
                ◦ New value: set to `Rejected`
            - `Commentary`
                ◦ New value (required): populate with reasoning for Rejection
            - `Status`
                ◦ New value: set to `Proposal Rejected By Facilitator` [automated]
        - Responsible party: Operational Facilitator

###### A.2.3.8.2.2.3.4.4 - Required Outputs [Core]  <!-- UUID: c7436489-4aac-47cb-be2d-31774bd7ee99 -->

The documents herein specify the required outputs from this process, if any.

###### A.2.3.8.2.2.3.4.4.1 - Sky Core Atlas Updates [Core]  <!-- UUID: d7e64cf2-9f1a-4057-8395-fc1eca5c3059 -->

No Sky Core Atlas documents are updated as the output of this process.

###### A.2.3.8.2.2.3.4.4.2 - Agent Artifact Updates [Core]  <!-- UUID: d5cce836-259e-48df-ba77-89d58d1476cc -->

No Agent Artifact documents are updated as the output of this process. The requirements specified in [A.2.3.8.2.2.3.4.3 - Required Primitive Inputs](7f991abf-3395-4f92-82e1-88e991ebd97a) fully complete the Process.

###### A.2.3.8.2.2.3.5 - Process Definition for Offchain Vote [Core]  <!-- UUID: 24fa76f6-4728-4f1d-97ff-fd7e72dac2ac -->

The documents herein define the process for an Offchain Vote for an Invocation of the Integration Boost Primitive.

###### A.2.3.8.2.2.3.5.1 - Process Initiation Logic [Core]  <!-- UUID: e5c0a813-e8d6-4687-a1ac-c9abbd7bb29f -->

The process initiation logic is specified herein.

###### A.2.3.8.2.2.3.5.1.1 - Triggers [Core]  <!-- UUID: c5db0c30-6a19-492c-9389-926ffcbbca06 -->

Triggers are specified herein.

###### A.2.3.8.2.2.3.5.1.1.1 - Time-Based Triggers [Core]  <!-- UUID: c6ad2b62-8f38-41cd-987f-f771f1a53e38 -->

None.

###### A.2.3.8.2.2.3.5.1.1.2 - Document Update Triggers [Core]  <!-- UUID: bac65a98-2e36-471a-8d3b-68d207ede4e2 -->

This process is triggered by the Artifact Update specified at Operational Facilitator Approves Proposal.

###### A.2.3.8.2.2.3.5.1.2 - Dependencies [Core]  <!-- UUID: bfdafaa4-e8bb-499b-99e6-f748d86cc569 -->

This process has no dependencies.

###### A.2.3.8.2.2.3.5.2 - Process Flow [Core]  <!-- UUID: 185d7f3b-9612-42ef-bde7-c9a64ad3ceab -->

The process flow for this process is defined herein:

- Using the finalized `Atlas Edit Proposal` content, the Operational Facilitator sets up an offchain Snapshot vote.

- Prime Agent token holders vote on the proposal.

- After the voting concludes, the Operational Facilitator records the result of the vote in the Powerhouse system.

###### A.2.3.8.2.2.3.5.3 - Required Primitive Inputs [Core]  <!-- UUID: d247fec5-a19d-4307-94de-a2cbcc368d64 -->

The required Primitive Inputs to this process are defined herein.

- After Facilitator prepares Snapshot vote:
    ◦ Edit `Artifact Edit Proposal` Document
        - Updated fields
            - Status
                ◦ New value: set to `Pending Poll`
            - Off-chain Snapshot
                ◦ New value: Populate with link to the official Snapshot page
        - Responsible party: Operational Facilitator

- Mutually Exclusive Input Pathways: The two Primitive Inputs below are mutually exclusive pathways. Once the vote concludes, the corresponding Pathway is followed to the exclusion of the other.

    ◦ Proposal Passes
        - Edit `Artifact Edit Proposal` Document
            - Update fields
                ◦ Status
                    - New value: set to `Poll Approved`
            - Responsible party: Operational Facilitator.
            - Trigger - Required Output: Proposal passes

    ◦ Proposal Fails
        - Updated fields
            - Edit `Artifact Edit Proposal` Document
                ◦ Status
                    - New value: set to `Poll Rejected`
            - Responsible party: Operational Facilitator.
            - Trigger - Required Output: Proposal fails

###### A.2.3.8.2.2.3.5.4 - Required Outputs [Core]  <!-- UUID: bae40b55-4f53-4992-a872-228fd3d87671 -->

The documents herein specify the required outputs from this process.

###### A.2.3.8.2.2.3.5.4.1 - Sky Core Atlas Updates [Core]  <!-- UUID: 43a3722c-97d0-4389-9d3b-4ac24901d365 -->

No Sky Core Atlas documents are updated as the output of this process.

###### A.2.3.8.2.2.3.5.4.2 - Agent Artifact Updates [Core]  <!-- UUID: adfb66a3-4f73-4fcc-bfa2-f5126503187c -->

The Agent Artifact documents specified herein are updated as the output of this process. The Output "sets" are mutually exclusive. 

- Proposal passes
    ◦ Required Primitive Input Trigger: Proposal Passes 
    ◦ **Edit** `Primitive Hub Document`
        - Fields Updated
            - Active instances/instance name/instance status - set to `Approved`
        - Responsible Party: Operational GovOps
        - Trigger - Process: [A.2.3.8.2.2.3.6 - Process Definition for Artifact Update](182ca3dc-108f-4941-ae2e-eb01c345125b). 

- Proposal fails
    ◦ Required Primitive Input Trigger: Proposal Fails 
    ◦ **Edit** `Primitive Hub Document`
        - Fields Updated
            - Active instances/instance name/instance status - set to `Rejected`
        - Other Document Operations:
            - `Instance Configuration Document` is `Archived` in Primitive Hub Document/Data Repository
        - Responsible Party: Operational GovOps

###### A.2.3.8.2.2.3.6 - Process Definition for Artifact Update [Core]  <!-- UUID: 182ca3dc-108f-4941-ae2e-eb01c345125b -->

The documents herein define the Artifact Update process for an Invocation of the Integration Boost Primitive.

###### A.2.3.8.2.2.3.6.1 - Process Initiation Logic [Core]  <!-- UUID: 59306024-9642-4f4c-891e-dc515e1eff8e -->

The process initiation logic is specified herein.

###### A.2.3.8.2.2.3.6.1.1 - Triggers [Core]  <!-- UUID: 7ff087ca-2b81-45e2-98e9-08fd184722bc -->

Triggers are specified herein.

###### A.2.3.8.2.2.3.6.1.1.1 - Time-Based Triggers [Core]  <!-- UUID: 95379a19-4115-4a94-a525-67ea27ccab85 -->

None.

###### A.2.3.8.2.2.3.6.1.1.2 - Document Update Triggers [Core]  <!-- UUID: 97e2c2b5-f17b-46a4-9e01-9b782429bd39 -->

This process is triggered by the Artifact update specified in Proposal passes.

###### A.2.3.8.2.2.3.6.1.2 - Dependencies [Core]  <!-- UUID: 1c0ce5c0-df9a-417e-a3d4-2b09e96787f6 -->

This process has no dependencies.

###### A.2.3.8.2.2.3.6.2 - Process Flow [Core]  <!-- UUID: 48863e96-796e-4953-b811-cbbfdd294098 -->

The process flow is defined herein.

- Using the Powerhouse interface, the Operational Facilitator updates the Agent Artifact with the approved Proposal content.

###### A.2.3.8.2.2.3.6.3 - Required Primitive Inputs [Core]  <!-- UUID: 51ca2399-8c7f-4c2a-843a-c85f6c670d13 -->

The following inputs must be submitted into the Primitive using the Powerhouse interface.

- Edit `Instance Configuration Document` to reflect ratified Primitive Instance.
    ◦ Updated fields
        - Parameters/Status - automatically inherits from `Primitive Hub Document`
        - Parameters/Integration Partner Name
            - New Value: set to `Integration Partner Name` value from approved Proposal
        - Parameters/Integration Partner Reward Address
            - New Value: set to `Integration Partner Reward Address` value from approved Proposal
        - Parameters/Integration Partner Chain
            - New Value: set to `Integration Partner Chain` value from approved Proposal
        - Parameters/Integration Boost Cadence
            - New Value: set to `Integration Boost Cadence` value from approved Proposal
        - Parameters/Integration Boost Data Submission Format
            - New Value: set to `Integration Boost Data Submission Format` value from approved Proposal
        - Parameters/Integration Boost Data Submission Responsible Actor
            - New Value: set to `Integration Boost Data Submission Responsible Actor` value from approved Proposal
        - Parameters/Integration Boost Savings Rate Adjustment Strategy
            - New Value: set to `Integration Boost Savings Rate Adjustment Strategy` value from approved Proposal
        - Parameters/Custom Instance Parameters
            - New Value: set to `Custom Instance Parameters` value from approved Proposal
        -  Responsible party: Operational GovOps [if not automated]

###### A.2.3.8.2.2.3.6.4 - Required Outputs [Core]  <!-- UUID: bd74388f-69d8-48fc-bab8-522f1b3b5806 -->

The documents herein specify the required outputs from this process.

###### A.2.3.8.2.2.3.6.4.1 - Sky Core Atlas Updates [Core]  <!-- UUID: 221cde4c-acb8-46c9-866b-7878fc6e5646 -->

The Sky Core Documents specified herein are updated as the output of this process.

###### A.2.3.8.2.2.3.6.4.1.1 - Onboarding Integrators Active Data Update [Core]  <!-- UUID: 847092ba-eb97-47ee-a121-6c8e505bc480 -->

[A.2.3.8.1.2.1.5.2.0.6.1 - List Of Onboarding Integrators](eb644108-94fc-430f-ae5a-e3294b9dd9be) is updated as follows:

- Updated fields
    ◦ `Onboarding Integrators`
        - New value: Delete the Integrator.
- Responsible Party: Operational GovOps
- Triggers: None

###### A.2.3.8.2.2.3.6.4.1.2 - Current Integrators Active Data Update [Core]  <!-- UUID: 1b03bc85-a7f4-4cc5-be41-d13a16b8c379 -->

[A.2.3.8.1.2.1.5.1.0.6.1 - List Of Current Integrators](efbe7903-a76e-40f0-a440-56e463283157) is updated as follows:

- Updated fields
    ◦ `Current Integrators`
        - New value: set to the name of the Integrator from the approved Proposal
    ◦ `Reward Code`
        - New value: set to the Reward Code from the approved Proposal
    ◦ `Tracking Methodology`
        - New value: set to the tracking methodology from the approved Proposal
- Responsible Party: Operational GovOps
- Triggers: None

###### A.2.3.8.2.2.3.6.4.2 - Agent Artifact Updates [Core]  <!-- UUID: 1ba7ea74-00a7-4e45-9fd4-d5222e40746b -->

The Agent Artifact documents specified herein are updated as the output of this process.

###### A.2.3.8.2.2.3.6.4.2.1 - Primitive Hub Document Update [Core]  <!-- UUID: f4323202-b7ef-437b-9667-226dea4f9dce -->

The Document in the Agent Artifact is updated as follows:

- Required Primitive Input Trigger: Proposal passes
- Updated fields
    ◦ Active Instances/Instance Name/Instance Status
        - New value: `Active`
    ◦ Instance Location: [links to `Instance Configuration Document` subtree]
- Responsible Party: Operational Facilitator
- Trigger-Process: None.

###### A.2.3.8.2.2.4 - Instance Ongoing Management Protocol [Core]  <!-- UUID: 805381e5-89e7-4fb9-bda7-a97e84b531ba -->

The documents herein define the process for the ongoing management of an Instance of the Integration Boost Primitive.

###### A.2.3.8.2.2.4.1 - Routine Protocol [Core]  <!-- UUID: 04864587-25ef-4179-b237-4dd0a23485a4 -->

The documents herein define the routine process for ongoing management of an Instance of the Integration Boost Primitive.

###### A.2.3.8.2.2.4.1.1 - Process Definition For Integration Boost Calculation By Operational GovOps [Core]  <!-- UUID: 780719e8-ea6d-4ae1-b519-34d03be483df -->

The documents herein define the process for Integration Boost Calculation by Operational GovOps.

###### A.2.3.8.2.2.4.1.1.1 - Process Initiation Logic [Core]  <!-- UUID: 0930f2b1-38ae-415e-85e6-bf96c7bcb0cb -->

The process initiation logic is specified herein.

###### A.2.3.8.2.2.4.1.1.1.1 - Triggers [Core]  <!-- UUID: 52fc6ecc-d3c2-4c6e-babe-2a3bb0e10f22 -->

Triggers are specified herein.

###### A.2.3.8.2.2.4.1.1.1.1.1 - Time-Based Triggers [Core]  <!-- UUID: 56e6b01b-5f00-4385-9876-951f3160cb70 -->

This process is triggered at the end of each occurrence of the Cadence for each Instance of the Integration Boost Primitive with an Instance Status of `Active`.

###### A.2.3.8.2.2.4.1.1.1.1.2 - Document Update Triggers [Core]  <!-- UUID: fa1e98b5-18f4-4e9a-b008-50fb2906e35a -->

None.

###### A.2.3.8.2.2.4.1.1.1.2 - Dependencies [Core]  <!-- UUID: f8991663-df3f-49ea-9c96-d7c0f09d8ee8 -->

This process has no dependencies.

###### A.2.3.8.2.2.4.1.1.2 - Process Flow [Core]  <!-- UUID: fa744d67-6609-4b94-9126-dade273d3d4d -->

The process flow is defined herein:

- At the end of each Integration Boost period, the data provider submits the net USDS deposit data to Powerhouse.

- Operational GovOps verifies this data by checking on-chain balances and confirms that there are no discrepancies.

- Operational GovOps then calculates the payout based on the net USDS deposit data and the Sky Savings Rate.

###### A.2.3.8.2.2.4.1.1.3 - Required Primitive Inputs [Core]  <!-- UUID: 4c84f0a6-0d4d-4718-a7c4-04fa29fadfcc -->

The required Primitive Inputs to this process are specified herein.

- Edit `Integration Boost Payments` Document (Active Data)
    ◦ Updated fields
        - Status
            - New value: set to `In Progress`
        - Underlying data
            - New value: populate with underlying data used to calculate the net deposits
        - Net deposits
            - New value: populate with calculated value
        - Integration Boost payment due
            - New value: populate with calculated value.
    ◦ Responsible party: Operational GovOps.
    ◦ Trigger-Process: [A.2.3.8.2.2.4.1.2 - Process Definition For Integration Boost Payment Issuance From Operational Executor Agent Buffer](16474cb5-8af4-4f11-b0c1-2c00f292cc2b).

###### A.2.3.8.2.2.4.1.1.4 - Required Outputs [Core]  <!-- UUID: 08dd7788-9265-46f3-bc91-3215218bc69f -->

The documents herein specify the required outputs from this process.

###### A.2.3.8.2.2.4.1.1.4.1 - Sky Core Atlas Updates [Core]  <!-- UUID: 273db3f1-9da3-4ef9-a5a0-31d537a62bbd -->

No Sky Core Atlas documents are updated as the output of this process.

###### A.2.3.8.2.2.4.1.1.4.2 - Agent Artifact Updates [Core]  <!-- UUID: b785cb0c-1ebb-438d-a5c4-c385e7446977 -->

No Agent Artifact documents are updated as the output of this process. The requirements specified [A.2.3.8.2.2.4.1.1.3 - Required Primitive Inputs](4c84f0a6-0d4d-4718-a7c4-04fa29fadfcc) fully complete the Process.

###### A.2.3.8.2.2.4.1.2 - Process Definition For Integration Boost Payment Issuance From Operational Executor Agent Buffer [Core]  <!-- UUID: 16474cb5-8af4-4f11-b0c1-2c00f292cc2b -->

The documents herein define the process for Integration Boost payment from the Operational Executor Agent Buffer.

###### A.2.3.8.2.2.4.1.2.1 - Process Initiation Logic [Core]  <!-- UUID: c12533a4-9e4c-4618-a02b-cd33178db95b -->

The process initiation logic is specified herein.

###### A.2.3.8.2.2.4.1.2.1.1 - Triggers [Core]  <!-- UUID: fd914a13-4bc6-4bfe-a809-a440d1acd1fa -->

Triggers are specified herein.

###### A.2.3.8.2.2.4.1.2.1.1.1 - Time-Based Triggers [Core]  <!-- UUID: 9c5455f3-5f3b-484d-a253-62e417d7779c -->

None.

###### A.2.3.8.2.2.4.1.2.1.1.2 - Document Update Triggers [Core]  <!-- UUID: 358d4696-47d3-41a2-a34c-33e47487d3bb -->

This process is triggered by the Required Primitive Inputs specified in Edit Integration Boost Payments Document (Active Data).

###### A.2.3.8.2.2.4.1.2.1.2 - Dependencies [Core]  <!-- UUID: 5cae5183-8c36-4d19-8db6-d6145b282fe6 -->

This process has no dependencies.

###### A.2.3.8.2.2.4.1.2.2 - Process Flow [Core]  <!-- UUID: f894a7d2-8ef7-4130-8955-5a939f6eb535 -->

The process flow is defined herein.

- Operational GovOps makes the payment to the reward address specified in the Primitive Instance from the Operational Executor Agent Buffer.

- Operational GovOps updates the Powerhouse system with the transaction details.

###### A.2.3.8.2.2.4.1.2.3 - Required Primitive Inputs [Core]  <!-- UUID: 862aff47-67fc-4b7f-bc16-b45b7edd9e83 -->

The required Primitive Inputs to this process are specified herein.

- Edit `Integration Boost Payments` Document (Active Data)
    ◦ Updated fields
        -  Status
            - New value: set to `Paid`
        - Transaction Details/Amount Paid
            - New value: populate with amount paid
        - Transaction Details/Tx hash
            - New value: populate with transaction hash
    ◦ Responsible Party: Operational GovOps
    ◦ Trigger - Process: [A.2.3.8.2.2.4.1.3 - Process Definition For Settlement Cycle And Core GovOps Review](d9c13a1a-aa81-483a-bc72-453d27980717).

###### A.2.3.8.2.2.4.1.2.4 - Required Outputs [Core]  <!-- UUID: baa296a6-7b9c-4134-b6a2-648d8a24a9bc -->

The documents herein specify the required outputs from this process.

###### A.2.3.8.2.2.4.1.2.4.1 - Sky Core Atlas Updates [Core]  <!-- UUID: 7e7e516a-64d4-48fa-b138-11924474b48d -->

No Sky Core Atlas documents are updated as the output of this process.

###### A.2.3.8.2.2.4.1.2.4.2 - Agent Artifact Updates [Core]  <!-- UUID: f1e0fb16-7f7d-4b91-8a21-e87e21a92979 -->

No Agent Artifact documents are updated as the output of this process. The requirements specified in [A.2.3.8.2.2.4.1.2.3 - Required Primitive Inputs](862aff47-67fc-4b7f-bc16-b45b7edd9e83) fully complete the process.

###### A.2.3.8.2.2.4.1.3 - Process Definition For Settlement Cycle And Core GovOps Review [Core]  <!-- UUID: d9c13a1a-aa81-483a-bc72-453d27980717 -->

The documents herein define the process for the Integration Boost Settlement Cycle and Core GovOps review as part of ongoing management of an Instance of the Integration Boost Primitive.

###### A.2.3.8.2.2.4.1.3.1 - Process Initiation Logic [Core]  <!-- UUID: 0f8e3d69-eeb9-4ab7-9976-ad7fd93b9fb0 -->

The process initiation logic is specified herein.

###### A.2.3.8.2.2.4.1.3.1.1 - Triggers [Core]  <!-- UUID: 7ba12eff-207b-4060-9a3e-8db1908cf982 -->

Triggers are specified herein.

###### A.2.3.8.2.2.4.1.3.1.1.1 - Time-Based Triggers [Core]  <!-- UUID: 44fb9520-c7e6-4a6a-8362-6c3a7b9fa765 -->

This process is triggered at the beginning of every calendar quarter.

###### A.2.3.8.2.2.4.1.3.1.1.2 - Document Update Triggers [Core]  <!-- UUID: 30152570-8af2-4e2a-bab2-9dbb871a00f4 -->

None.

###### A.2.3.8.2.2.4.1.3.1.2 - Dependencies [Core]  <!-- UUID: 8f3b3d8b-57cb-4ecf-a264-7818cd01d9b2 -->

This process has no dependencies.

###### A.2.3.8.2.2.4.1.3.2 - Process Flow [Core]  <!-- UUID: 841497f9-b592-4365-8221-3bdbb82b8d4a -->

The process flow is defined herein.

- Core GovOps reviews Integration Boost calculations, including underlying data and calculation of balances and rewards due.

- Once Core GovOps has completed review, they update Powerhouse system to indicate that they confirm the accuracy of the Integration Boost amounts.

###### A.2.3.8.2.2.4.1.3.3 - Required Primitive Inputs [Core]  <!-- UUID: ebbfa305-4d56-45f4-8d06-180dc02cbb2f -->

The required Primitive Inputs to this process are specified herein.

- Edit `Integration Boost Payments` Active Data Document
    ◦ Updated field
        - Core GovOps Review/Confirmation
            - New value: populate with yes or no.
        - Core GovOps Review/Commentary
            - New value: populate with reasoning (required if confirmation value is `No`)
    ◦ Responsible party: Core GovOps

###### A.2.3.8.2.2.4.1.3.4 - Required Outputs [Core]  <!-- UUID: 5a0f038c-c710-4889-882a-a0cb040577a3 -->

The documents herein specify the required outputs from this process.

###### A.2.3.8.2.2.4.1.3.4.1 - Sky Core Atlas Updates [Core]  <!-- UUID: 1f50ce0e-76f8-4436-820f-363bcf8fc017 -->

The Sky Core Atlas documents specified herein are updated as the output of this process.

###### A.2.3.8.2.2.4.1.3.4.1.1 - Sky Core Integration Boost Reimbursement Active Data Document Update [Core]  <!-- UUID: 0f50e796-9486-42cd-a98d-b284f8340307 -->

The document in the Sky Core Atlas is updated as follows:

- Updated Fields
    ◦ Status
        - New value: populate with `Pending Payment`
    ◦ Confirmed Reimbursement Due
        - New value: populate with total Reimbursement amount
    ◦ Reward Period
        - New Value: populate with reward period
    ◦ Operational Executor Agent
        - New value: Populate with name of Operational Executor Agent
    ◦ Prime Agent
        - New value: Populate with name of Prime Agent.
- Responsible Party: Core GovOps
- Triggers: [A.2.3.8.2.2.4.1.4 - Process Definition For Executive Vote Reimbursement](c40a0708-12e4-46da-89d7-0e5a3a839455).

###### A.2.3.8.2.2.4.1.3.4.2 - Agent Artifact Updates [Core]  <!-- UUID: 43aedc35-e90a-48ca-a0fc-346ced2bea0b -->

No Agent Artifact documents are updated as the output of this process.

###### A.2.3.8.2.2.4.1.4 - Process Definition For Executive Vote Reimbursement [Core]  <!-- UUID: c40a0708-12e4-46da-89d7-0e5a3a839455 -->

The documents herein define the process for Integration Boost Executive Vote reimbursement as part of ongoing management of an Instance of the Integration Boost Primitive.

###### A.2.3.8.2.2.4.1.4.1 - Process Initiation Logic [Core]  <!-- UUID: 6dac32e6-593c-44db-908b-9075c8dd68ca -->

The process initiation logic is specified herein.

###### A.2.3.8.2.2.4.1.4.1.1 - Triggers [Core]  <!-- UUID: dea4f41d-b36b-421f-be80-3f495532ab7a -->

Triggers are specified herein.

###### A.2.3.8.2.2.4.1.4.1.1.1 - Time-Based Triggers [Core]  <!-- UUID: fa1aab6f-61a8-493f-b282-6a0e3f64ce29 -->

None.

###### A.2.3.8.2.2.4.1.4.1.1.2 - Document Update Triggers [Core]  <!-- UUID: ee6adeb0-b3e5-4d0f-8d1a-b9fdc1510074 -->

This process is triggered by the Document Update specified in [A.2.3.8.2.2.4.1.3.4.1.1 - Sky Core Integration Boost Reimbursement Active Data Document Update](0f50e796-9486-42cd-a98d-b284f8340307).

###### A.2.3.8.2.2.4.1.4.1.2 - Dependencies [Core]  <!-- UUID: 10cb9c97-e21b-4ad2-af48-eb2fa577aded -->

This process has no dependencies.

###### A.2.3.8.2.2.4.1.4.2 - Process Flow [Core]  <!-- UUID: 9cb825c8-871f-47b7-9918-e48fe2a34d26 -->

The process flow is defined herein:

- Core GovOps includes the Integration Boost reimbursement in the next standard Executive Vote.

- After the Executive Vote passes, Core GovOps updates the Powerhouse system with the transaction details.

###### A.2.3.8.2.2.4.1.4.3 - Required Primitive Inputs [Core]  <!-- UUID: f54de74a-4208-4878-8049-3184ab3f9a0d -->

The required Primitive Inputs to this process are specified herein and organized as sequential stages.

- Core GovOps adds reimbursement to Executive Vote
    ◦ Edit `Sky Core Integration Boost Reimbursement Amounts` 
        -  Updated fields
            - Executive Vote Settlement/Executive Vote
                ◦ New value: links to proposal
            - Status
                ◦ New value: set to `Added to Executive Vote`

- After Executive Vote passes, Core GovOps updates Powerhouse system
    ◦ Edit `Sky Core Integration Boost Reimbursement Amounts`
        -  Updated fields
            - Executive Vote Settlement / Transaction Details/ Amount Paid
                ◦ New value: populate with amount paid to reimburse Operational Executor Agent Buffer.
            - Executive Vote Settlement / Transaction Details / Tx Hash
                ◦ New value: Populate with transaction hash
            - Status
                ◦ New value: set to `Completed`

###### A.2.3.8.2.2.4.1.4.4 - Required Outputs [Core]  <!-- UUID: 8d00d8df-f970-4b2e-8da9-3b9fe2af9e2b -->

The documents herein specify the required outputs from this process.

###### A.2.3.8.2.2.4.1.4.4.1 - Sky Core Atlas Updates [Core]  <!-- UUID: 9478c3d6-ce1d-4c73-a479-9127b5c245e1 -->

The Sky Core Atlas documents specified herein are updated as the output of this process.

###### A.2.3.8.2.2.4.1.4.4.1.1 - Sky Core Integration Boost Reimbursement Active Data Document Update [Core]  <!-- UUID: 0ab76a83-ca8d-4ebf-83c1-b7e7dced0970 -->

The Document in the Sky Core Atlas is updated as follows:

- Updated fields
    ◦ Status
        - New value: set to `Paid`
    ◦ Responsible Party: Core GovOps
    ◦ Trigger-Process: None

###### A.2.3.8.2.2.4.1.4.4.2 - Agent Artifact Updates [Core]  <!-- UUID: 39aba7ed-95ff-4247-acb7-61032649b218 -->

No Agent Artifact documents are updated as the output of this process.

###### A.2.3.8.2.2.4.2 - Non-Routine Protocol [Core]  <!-- UUID: 9cdac621-4677-4c79-8372-68e0a778c27d -->

The documents herein define processes for handling non-routine situations in the ongoing management of an Instance of the Integration Boost Primitive.

###### A.2.3.8.2.2.4.3 - Emergency Protocol [Core]  <!-- UUID: 0bbeab5f-ca17-463a-a9a4-9ab588347a0c -->

The documents herein define processes for handling emergency situations in the ongoing management of an Instance of the Integration Boost Primitive.

#### A.2.3.8.3 - Pioneer Chain Primitive [Core]  <!-- UUID: 4c7be4c6-44b5-407a-94ae-3d7ca7e8039c -->

The documents herein govern the Pioneer Chain Primitive.

##### A.2.3.8.3.1 - Introduction [Core]  <!-- UUID: 4aab68fd-0e8c-4781-b6f6-f94a89cb22fa -->

The documents herein provide an introduction to the Pioneer Chain Primitive.

###### A.2.3.8.3.1.1 - Pioneer Prime Requirements [Core]  <!-- UUID: 219459b3-8333-4e9a-9b79-55e0c20d6dbb -->

Pioneer Primes must be designated by the official team or foundation of the Pioneer Chain, they must be created for the specific purpose of being a Pioneer Prime from their genesis moment, and it is only possible for a Pioneer Chain to have Pioneer Prime once, and for a Pioneer Prime to have the Pioneer Prime status with a single blockchain, once.

###### A.2.3.8.3.1.2 - Pioneer Prime Designation Process [Core]  <!-- UUID: d6d16076-da22-43f1-a303-627af41b486c -->

In order to be confirmed as a Pioneer Prime, a Prime Agent must provide written proof to Operational GovOps that it has been provisionally designated as such by the official team or foundation of the relevant Pioneer Chain. Following a check by Operational GovOps to ensure that the Prime Agent has not been a Pioneer Prime previously and that the Pioneer Chain has not had a Pioneer Prime before, Operational GovOps will add the new Pioneer Prime to the list of Active Pioneer Primes. See [A.2.3.8.3.1.2.1.0.6.1 - List of Active Pioneer Primes](f2ecf6a4-4d5f-4443-b25c-3bd10b1af82e).

###### A.2.3.8.3.1.2.1 - Active Pioneer Primes [Active Data Controller]  <!-- UUID: 65fc0b79-8827-403d-80ee-9f74a6be1069 -->

Active Pioneer Primes are Prime Agents who have been designated by the official team or foundation of the Pioneer Chain and confirmed as Pioneer Primes by Operational GovOps. The list of Current Pioneer Primes is defined as Active Data in [A.2.3.8.3.1.2.1.0.6.1 - List of Active Pioneer Primes](f2ecf6a4-4d5f-4443-b25c-3bd10b1af82e). 

The Active Data is updated as follows:
- The Responsible Party is Operational GovOps.
- The Update Process must follow the protocol for ‘Direct Edit’.

###### A.2.3.8.3.1.2.1.0.6.1 - List of Active Pioneer Primes [Active Data]  <!-- UUID: f2ecf6a4-4d5f-4443-b25c-3bd10b1af82e -->

The current Active Pioneer Primes are:

◦ Keel

###### A.2.3.8.3.1.3 - Pioneer Prime Benefits [Core]  <!-- UUID: f0d5ab5e-bf35-4a9d-a73f-d82baac6e604 -->

Pioneer Primes gain benefits and responsibilities related to the general adoption of USDS on the Pioneer Chain, and this benefit comes in two forms.

First, during the Pioneer Phase, the Pioneer Prime counts as having tagged, for the purposes of calculating the Distribution Reward, all USDS and sUSDS accounts and balances on the Pioneer Chain that have not been tagged by another Prime. At the end of the Pioneer Phase, all untagged USDS accounts and balances are one-time tagged by the Pioneer Prime, and this tag will remain normally for the following ten (10) years unless tagged by a different Prime, or retagged.

Second, during the Pioneer Phase, all Unrewarded USDS bridged to the Pioneer Chain counts towards Pioneer Incentive payments, see [A.2.3.8.3.1.4 - Pioneer Incentive Pool](04edac33-19d5-4a87-a8ab-945a0cd57771).

###### A.2.3.8.3.1.3.1 - Pioneer Phase [Core]  <!-- UUID: 0c7b0644-68d4-441d-8221-88382a6515e4 -->

For purposes of [A.2.3.8.3.1.3 - Pioneer Prime Benefits](f0d5ab5e-bf35-4a9d-a73f-d82baac6e604), the Pioneer Phase is a period beginning on the date that a Prime Agent satisfies the Pioneer Prime Requirements specified in [A.2.3.8.3.1.1 - Pioneer Prime Requirements](219459b3-8333-4e9a-9b79-55e0c20d6dbb) and ending three (3) years thereafter.

###### A.2.3.8.3.1.4 - Pioneer Incentive Pool [Core]  <!-- UUID: 04edac33-19d5-4a87-a8ab-945a0cd57771 -->

All Pioneer Incentive payments are paid through the Monthly Settlement Cycle. Each Monthly Settlement Cycle, an amount of funds equivalent to the Sky Savings Rate multiplied by the balance of Unrewarded USDS is paid into a separate account controlled by the Pioneer Prime (the "Pioneer Incentive Pool"). 80% of the funds going to the Pioneer Incentive Pool are not the property of the Pioneer Primes and must instead be used as incentives to promote general adoption of USDS on the Pioneer Chain. This must provide general benefit for the sake of growing USDS activity on the Pioneer Chain and cannot be biased towards benefiting the Pioneer Prime. The remaining 20% of the funds going to the Pioneer Incentive Pool may be retained by the Pioneer Prime as income.

###### A.2.3.8.3.1.4.1 - Pre-Pioneer Incentive Pool [Core]  <!-- UUID: 15e14f25-8d56-4699-ac37-0cef4f0503c5 -->

A Pre-Pioneer Incentive Pool is a temporary, chain-specific incentive mechanism designed to bootstrap USDS adoption on a new blockchain before a formal Pioneer Prime is established for that chain. It allows a designated Agent to direct incentive payments to ecosystem partners on that specific chain. The Pre-Pioneer Incentive Pool may operate under distinct rules that differ from the standard Pioneer Incentive Pool, which rules will be specified in an Ecosystem Accord between the respective Agent and Sky Core. A Pre-Pioneer Incentive Pool serves as a transitional phase until the conditions for a formal Pioneer Incentive Pool are met. See [A.2.3.8.3.1.4 - Pioneer Incentive Pool](04edac33-19d5-4a87-a8ab-945a0cd57771).

### A.2.3.9 - Supply Side Stablecoin Primitives [Section]  <!-- UUID: d1142876-33c2-4e21-9339-d8711525d46f -->

Supply Side Stablecoin Primitives are Sky Primitives focused on capital allocation and risk management.

#### A.2.3.9.1 - Allocation System Primitive [Core]  <!-- UUID: 9db14ab7-bb4b-4751-8084-843bd4359f2a -->

The Allocation System Primitive is the base mechanism that enables Prime Agents to put up Risk Capital to deploy USDS collateral into different opportunities that provide risk-adjusted return, by borrowing at the Base Rate from Sky, and following Asset Liability Management restrictions on the liquidity of deployed assets.

##### A.2.3.9.1.1 - Allocation System Process Definition [Core]  <!-- UUID: 823a12c3-45d2-438a-b061-46ecd09cdca8 -->

The documents herein define the process for initial setup and ongoing management of an Allocation Instance (alternatively referred to as "conduits") as part of the Allocation System Primitive.

###### A.2.3.9.1.1.1 - Base Elements [Core]  <!-- UUID: 39f3ceee-2e0b-41b2-ad62-85cac3895cb0 -->

The documents herein define base elements of the Allocation System Primitive.

###### A.2.3.9.1.1.1.1 - Sky Direct Exposures [Core]  <!-- UUID: b3fb8653-8503-4a9e-81b2-5e9f49ad6703 -->

Sky Direct Exposures are exposures that are held directly by Sky but implemented through the Allocation System of a Prime Agent. The documents herein define the rules for Sky Direct Exposures.

###### A.2.3.9.1.1.1.1.1 - Designation Process [Core]  <!-- UUID: 3161489a-11bd-4dea-b676-09d0cce45ae9 -->

Sky Direct Exposures are designated by the Core Facilitator in consultation with the Core Council Risk Advisor via posts to the Sky Forum under the "Sky Core" category. Sky Direct Exposures are recorded in [A.2.3.9.1.1.1.1.2.0.6.1 - List Of Current Sky Direct Exposures](5f368e33-7a82-4244-a9ba-f285193ec043) and must specify the asset that is being designated as a Sky Direct Exposure and the Prime Agent responsible for implementing the exposure.

###### A.2.3.9.1.1.1.1.2 - Current Sky Direct Exposures [Active Data Controller]  <!-- UUID: 1c0410e4-fe36-4a01-8b82-8ea74f67fbec -->

The list of current Sky Direct Exposures is defined as Active Data in [A.2.3.9.1.1.1.1.2.0.6.1 - List Of Current Sky Direct Exposures](5f368e33-7a82-4244-a9ba-f285193ec043). 

The Active Data is updated as follows:
- The Responsible Party is the Core Facilitator.
- The Update Process must follow the protocol for ‘Direct Edit’.

###### A.2.3.9.1.1.1.1.2.0.6.1 - List Of Current Sky Direct Exposures [Active Data]  <!-- UUID: 5f368e33-7a82-4244-a9ba-f285193ec043 -->

The current Sky Direct Exposures are:
    
- Treasury Bills - Investments by Grove in BUIDL, JTRSY, and USTB on Ethereum Mainnet
- Collateralized Loan Obligations - Investments by Grove in JAAA on Ethereum Mainnet
- Peg Stability Modules - Investments by Spark or Grove in USDC in Peg Stability Modules on blockchains other than Ethereum Mainnet
- Curve Pools - Investments by Spark in USDT in sUSDS/USDT Curve pools

###### A.2.3.9.1.1.1.1.3 - Parameters For Sky Direct Exposures [Core]  <!-- UUID: cbd64e6c-547b-4b8d-a0cb-b605f780aef1 -->

The Core Facilitator sets the following parameters for Sky Direct Exposures in consultation with the Core Council Risk Advisor:

- Rate limits; and

- Aggregate exposure limits.

The Core Facilitator must post the initial values for these parameters and any updates to them to the Sky Forum under the "Sky Core" category. The values for the parameters for Sky Direct Exposures are set by the Core Facilitator and supersede any values for these parameters specified in the Risk Framework.

###### A.2.3.9.1.1.1.1.3.1 - Treatment Of Exposures In Excess Of Aggregate Exposure Limit [Core]  <!-- UUID: 8bd63c6b-b9ad-46e3-beb0-77c4a47bcd6d -->

Any investments in assets that would otherwise qualify as Sky Direct Exposures by a Prime Agent in excess of the aggregate exposure limit are not Sky Direct Exposures and are subject to the customary requirements pursuant to [A.2.5 - Sky Core Monthly Settlement Cycle](6f8d5065-d6ff-4add-9a28-eadeffa7ed1a) and [A.3.2 - Risk Capital](55999acf-75fe-4adf-8584-9746ef50d3e4).

###### A.2.3.9.1.1.1.1.4 - Revenue Sharing For Sky Direct Exposures [Core]  <!-- UUID: 07e0f716-ce23-4394-a5f4-bee537713f48 -->

Because Sky Direct Exposures are held by Sky rather than the Prime Agent implementing the exposure through its Allocation System, Prime Agents are not required to pay the Agent Credit Line Borrow Rate with respect to funds borrowed to finance Sky Direct Exposures. All yield on Sky Direct Exposures is also due exclusively to Sky and is not retained by the Prime Agent. This is implemented as an adjustment to the Monthly Settlement Cycle.

###### A.2.3.9.1.1.1.1.5 - No Risk Capital Requirements With Respect To Sky Direct Exposures [Core]  <!-- UUID: b683953e-d9b0-4e15-a405-978ef1854870 -->

Because Sky Direct Exposures are held by Sky rather than the Prime Agent implementing the exposure through its Allocation System, Prime Agents are not required to hold any Risk Capital with respect to Sky Direct Exposures.

###### A.2.3.9.1.1.1.1.6 - No Actively Stabilizing Collateral Requirements With Respect To Sky Direct Exposures [Core]  <!-- UUID: bfb8013f-9226-4426-84bf-4b0e03b44107 -->

Because Sky Direct Exposures are held by Sky rather than the Prime Agent implementing the exposure through its Allocation System, Prime Agents are not required to hold any Actively Stabilizing Collateral with respect to Sky Direct Exposures. Sky Direct Exposures also do not count towards satisfying a Prime Agent’s Actively Stabilizing Collateral requirements.

###### A.2.3.9.1.1.1.2 - Liquidity Layer Parameter Definitions [Core]  <!-- UUID: a8a3e54d-980e-435d-9e08-0e5775af9aa3 -->

The documents herein define common parameters of implementations of the Allocation System based on the Spark Liquidity Layer, including the Grove Liquidity Layer.

###### A.2.3.9.1.1.1.2.1 - Rate Limiter [Core]  <!-- UUID: a578830d-18f0-451c-8ff0-4a66094650ae -->

Rate Limiter refers to the overall mechanism or system that limits the volume of token movements over time, implemented via the `RateLimits` contracts. The Rate Limiter manages multiple rate limits and enforces constraints on controller operations to prevent rapid asset drainage and mitigate risks from compromised relayers or other attacks. This ensures that the maximum amount of tokens processed within a specific time period stays within safe bounds. The `RateLimits` contracts and their addresses for each chain can be found in the Allocation System Primitive for a Prime, under ALM Contracts.

###### A.2.3.9.1.1.1.2.2 - Rate Limits [Core]  <!-- UUID: 8efb0a11-b798-48eb-af19-f65b38f039b5 -->

Rate limits set the maximum allowable amount of tokens that can be processed for specific operations within a given time period. Each rate limit contains the rate limit data: `maxAmount`, `slope`, `lastAmount` and `lastUpdated`.  The current rate limit is calculated using the formula:

`currentRateLimit = min(slope * (block.timestamp - lastUpdated) + lastAmount, maxAmount)`.

The rate limit data `maxAmount` and `slope` are configurable parameters that are set and modified by Governance. The rate limit data `lastAmount` and `lastUpdated` are internal state data dynamically tracked by the Rate Limiter to perform its calculations.

Rate limits set caps on the rate of allocation to a given Instance, they do not act as a limit on the total amount that may be allocated to that Instance.

###### A.2.3.9.1.1.1.2.2.1 - MaxAmount [Core]  <!-- UUID: 8b5f1ffd-9dfd-4aa0-8fc2-638a79d9fadb -->

`maxAmount` sets a hard cap on the level of allocation to an Instance at any given time. It sets the absolute rate limit regardless of how much time has passed since the last allocation. For example, if `maxAmount` is set to 1,000,000 tokens, the rate limit will increase over time at the rate determined by the `slope` until it reaches 1,000,000 tokens, at this point the rate limit will stop increasing, but it will resume increasing once an allocation to the Instance has been made.

###### A.2.3.9.1.1.1.2.2.2 - Slope [Core]  <!-- UUID: ae8674bc-44ac-4b95-b5df-c6322a1d6e9a -->

`slope` is the linear refill rate of a rate limiter’s allowance over time. It defines how quickly the capacity to perform additional inflow or outflow accrues after prior consumption. For example, if the slope is set to 1,000,000 tokens per day (converted to per second for on-chain execution), the rate limit will recover at that rate until it reaches the maxAmount.

###### A.2.3.9.1.1.1.2.2.3 - LastUpdated [Core]  <!-- UUID: 8d0419a4-50c5-4a7b-b68e-84d8c9243694 -->

`lastUpdated` is the timestamp when the rate limit was last updated, serving as the reference point for calculating time-elapsed refills in the formula.

###### A.2.3.9.1.1.1.2.2.4 - LastAmount [Core]  <!-- UUID: 02918cfc-5d10-41bc-bb8a-0be9df76cbac -->

`lastAmount` is the remaining allowance available at the last update, used to compute the current rate limit by adding accrued capacity.

###### A.2.3.9.1.1.1.2.3 - Inflow Rate Limits [Core]  <!-- UUID: d59a233c-11b9-4140-b15f-51df37475fd8 -->

Inflow rate limits constrain the rate at which allocated liquidity can increase into a scope. "Inflow" means movements that raise exposure or capital allocated to an Instance or market, such as depositing, minting, or rebalancing into a position.

###### A.2.3.9.1.1.1.2.4 - Outflow Rate Limits [Core]  <!-- UUID: e50fd86a-ffa4-4387-b212-420730a8d171 -->

Outflow Rate Limits constrain the rate at which allocated liquidity can be withdrawn or exposure reduced from a scope. "Outflow" means movements that lower exposure or capital allocated to an Instance or market, such as withdrawals, redemptions, or unwind operations.

Outflow limits are often configured more permissively to prioritize safety and fast exits. When outflow limits are "unlimited," the rate limits contract simply does not apply a cap in that direction.

###### A.2.3.9.1.1.1.2.5 - Rate Limit IDs [Core]  <!-- UUID: b95b3bd8-d316-43d5-af56-df38d557aea3 -->

A `Rate Limit ID` is a bytes32 key that uniquely identifies a rate limit. Rate Limit IDs allow the system to maintain independent allowance state for each relevant transaction.

###### A.2.3.9.1.1.1.2.6 - MaxSlippage [Core]  <!-- UUID: 7c6da187-7d17-42ae-8c64-8d828ee83ea7 -->

`maxSlippage` is a configurable parameter that sets the maximum allowed price impact or deviation from expected output when executing trades or liquidity operations in a pool. `maxslippage` is expressed as a decimal and must be a non-zero value. This protects against excessive price impact during volatile market conditions.

###### A.2.3.9.1.1.2 - Allocation Instance Setup Process Definition [Core]  <!-- UUID: f47513f6-34e4-40a4-b7ff-8d68d75070be -->

The documents herein define the process for setting up an Allocation Instance as part of the Allocation System Primitive.

###### A.2.3.9.1.1.2.1 - Real World Agreements And Planning [Core]  <!-- UUID: eeeeb5ff-3f11-4857-a3da-ad354569f833 -->

The documents herein define the preliminary, off-chain human coordination stage of setting up an Allocation Instance.

###### A.2.3.9.1.1.2.1.1 - Initial Concept And Feasibility Discussions [Core]  <!-- UUID: b60b170f-9e8c-4577-a046-313039ff25ba -->

The Prime Agent identifies a yield opportunity on a target chain that can exceed the Base Rate. The Prime Agent estimates Required Risk Capital (RRC) and Asset Liability Management requirements associated with the opportunity and evaluates options for fulfilling them. The Prime Agent also considers exchange and bridging costs, if applicable. Based on this, the Prime Agent develops a net yield target for the opportunity factoring in all of these costs. The output of this step is an internal meeting note summarizing the idea as well as estimates of Required Risk Capital, Asset Liability Management, and exchange / bridging costs.

###### A.2.3.9.1.1.2.1.2 - Preliminary Required Risk Capital and Asset Liability Management Arrangement [Core]  <!-- UUID: 8d3b553c-440d-4c67-b661-37ab1edc1c58 -->

If necessary, the Prime Agent reaches out to other Prime Agents that could provide Junior Risk Capital (JRC) / Senior Risk Capital (SRC) or assume Asset Liability Management obligations. The Prime Agent negotiates with these other Prime Agents and documents these potential deals. The output of this step is an informal confirmation of JRC/SRC and Asset Liability Management transfer details.

###### A.2.3.9.1.1.2.1.3 - Prime Agent Preparation Of Capital And Operational Plan [Core]  <!-- UUID: 4aa05a21-86d6-451e-a1b1-2afd1107edba -->

The Capital and Operational Plan ("C&O Plan") articulates the Prime Agent’s strategy for a proposed new Allocation Instance or a modification to an existing Instance. In addition to articulating the Instance’s strategic objectives and operational parameters, the C&O Plan includes a pro-forma Required Risk Capital (RRC) estimate and a strategy for ensuring sufficient Total Risk Capital (TRC) coverage. 

The C&O Plan is the major input into the Artifact Edit Proposal that codifies the new or modified Instance. Following the approval of such a proposal by Prime governance, the details and commitments outlined in the C&O Plan are formally integrated into the respective Instance Configuration Document of the Prime Agent’s Artifact.

###### A.2.3.9.1.1.2.1.3.1 - Pro-Forma Instance RRC Estimate [Core]  <!-- UUID: c3b53ee8-328a-4a79-8afe-ac0de99d8706 -->

As a critical component of the Capital & Operational Plan, the Prime Agent must prepare an initial pro-forma Instance Required Risk Capital (RRC) estimate. This estimate serves as the basis for the Prime’s capital planning prior to the availability of official RRC figures from Sky Core. The estimate must strictly adhere to the implementation of RRC-models defined in [A.3.2 - Risk Capital](55999acf-75fe-4adf-8584-9746ef50d3e4).

###### A.2.3.9.1.1.2.1.3.2 - Notional Total Risk Capital (TRC) Coverage Strategy [Core]  <!-- UUID: a30447be-5214-4398-82aa-7306eeabd6f5 -->

As a critical component of the Capital & Operational Plan, the Prime Agent must articulate its strategy for ensuring its Total Risk Capital (TRC) adequately covers the pro-forma Instance RRC of a new or modified Instance and the resulting impact on its Aggregate RRC.

The Prime’s notional TRC coverage strategy must outline how this new Instance’s RRC will be notionally accounted for or supported by the Prime’s overall TRC pool. If the Prime’s current TRC is not sufficient to cover its estimated increased Aggregate RRC, the strategy should outline the Prime Agent’s intended steps for acquiring additional JRC/SRC.

For instance, this risk-capital acquisition strategy could involve:
    
1. Renting Junior Risk Capital (JRC)    
◦ Sourcing Prime-External Junior Risk Capital (SEJRC) by renting it from other Primes through Ecosystem Accords.    
◦ Sourcing Tokenized External Junior Risk Capital (TEJRC) from external capital providers.
    
2. Sourcing Senior Risk Capital (SRC):    
◦ Originating SRC through the Sky monthly auction.    
◦ Renting OSRC from other Primes through Ecosystem Accords.
    
3. Increasing Internal Junior Risk Capital (IJRC): A Prime might have plans to bolster its own IJRC through retained earnings or other internal means.
    
4. Decreasing exposure in an existing Instance(s) to lower Aggregate RRC.

The Prime’s capital-acquisition strategy should indicate how the Prime will remain in compliance with all relevant Atlas rules, such as sourcing ratios that constrain how much Senior Risk Capital can be "enabled" or counted toward a Prime’s Aggregate RRC. See [A.3.2.1.2.3 - Total Risk Capital Sourcing Ratios](9e99b084-f15a-4f60-b831-d6c0bd9aec04).

###### A.2.3.9.1.1.2.1.3.3 - Additional Elements Of Capital And Operational Plan [Core]  <!-- UUID: a156b120-8b27-4a31-95fe-4154205ca102 -->

The Capital & Operational Plan includes the following additional elements:
    
◦ Operational Parameters: defines the Instance’s target chain(s), protocols, initial capital, maximum deposit sizes, and any other parameters that underpin the pro-forma RRC calculation.    

◦ Data Submission Protocol: defines how yields, Required Risk Capital usage, ALM costs, exchange data, etc. will be reported and audited.    

◦ Emergency Procedures: defines mechanisms to be triggered if security or risk capital thresholds are breached, such as a kill switch or partial freeze.    

◦ Asset Liability Management (ALM) Strategy: details if the Prime will meet its ALM requirements through its own direct asset management or by transferring its obligations to another Prime Agent via the ASC Rental Primitive. If the latter, the C&O Plan must reference the governing Ecosystem Accord and its key terms.    

◦ Performance-based Adjustments: define the conditions or KPIs that allow adjustments to Instance deposit caps or yield expansions without requiring a formal Artifact edit.

###### A.2.3.9.1.1.2.1.4 - Preliminary Informal Check With Operational GovOps [Core]  <!-- UUID: e7d3d696-e2d0-4d4b-b4d6-c7a0c47b7cc6 -->

The Prime Agent presents the Capital and Operational Plan for the Allocation Instance to Operational GovOps, including any associated JRC/SRC and Asset Liability Management arrangements. Operational GovOps reviews and either provides an informal greenlight or requests modifications to the Plan. The output of this step is Operational GovOps approval to proceed with a request to revise the C&O Plan, as applicable.

###### A.2.3.9.1.1.2.2 - Instance Codification and Validation [Core]  <!-- UUID: 410c84be-ab41-4444-a7cb-1c19a0448948 -->

The documents herein define how agreements to set up an Allocation Instance are codified and validated in the Powerhouse system and how governance votes happen.

###### A.2.3.9.1.1.2.2.1 - Agent Inputs [Core]  <!-- UUID: 7a36f228-0438-43da-ae5f-a43af70c0121 -->

The Prime Agent drafts an update to the Prime Agent Artifact adding the Allocation Instance to the list of active Allocation Instances and including the information specified in [A.2.3.9.1.2.6 - List Of Allocation Instances](e4975062-6d19-438b-a5d5-cfc1a7fd8cb9). The Prime Agent submits the draft to the Powerhouse system. The output of this step is a draft Prime Agent Artifact update in the Powerhouse system.

###### A.2.3.9.1.1.2.2.2 - Validation And Off-Chain Vote [Core]  <!-- UUID: dbae3918-75f7-469d-b623-8faa5ea7aa70 -->

The Operational Executor Facilitator reviews the proposal to ensure that it is complete and aligned with the Atlas. The Operational Executor Facilitator then initiates an off-chain snapshot vote, following the quorum and majority rules in the Prime Agent Artifact. When complete, the result of the vote is recorded in the Powerhouse system. The output of this step is the snapshot vote result recorded in the Powerhouse system.

###### A.2.3.9.1.1.2.2.3 - Official Update of Artifact [Core]  <!-- UUID: 2b1612b8-480c-49b3-a304-6a6f593340de -->

If the Allocation Instance is successfully approved, the Operational Executor Facilitator finalizes and publishes the update to the Prime Agent Artifact, making it effective in the Atlas. The output of this step is an updated Prime Agent Artifact with the new Allocation Instance. 

Once a new Instance is deployed, its data is integrated into risk-capital monitoring systems and its RRC will be officially determined and tracked via the Sky Core RRC Dashboard/API. See [A.2.3.9.1.1.3.2.1.1 - Sky Core Required Risk Capital (RRC) Dashboard And API](4eac2c9e-2718-4881-a3f1-ed10fb3f4d13). This official RRC figure supersedes the Prime-prepared pro-forma RRC.

###### A.2.3.9.1.1.2.3 - Instance Setup Deployments [Core]  <!-- UUID: 3766cb8c-ab6c-41af-9465-b8dea76d0532 -->

The documents herein define how the deployment of an Allocation Instance is executed on-chain. In the short-term, an Allocation Instance may also be deployed using the process for Interim Deployments specified in [A.1.9.2.3.2.2.2 - Interim Deployments](9b3edbbf-89d1-42da-a9c3-18f858f8471f).

The Prime Agent must subsequently prepare a pro-forma Required Risk Capital estimate, which must be approved by the Core Council Risk Advisor, before the parameters of the Instance can be updated for normal operation.

###### A.2.3.9.1.1.2.3.1 - Conduit Development And Testing [Core]  <!-- UUID: 6899a722-3d1a-4bd1-80f2-f36be91bbab0 -->

Once formally validated, the Prime Agent implements the new Allocation Instance based on the specifications in the Prime Agent Artifact. Operational GovOps must test the Allocation Instance with minimal funds from the Prime Agent’s Central Allocation Buffer, verifying deposit / withdrawal logic, slippage constraints, and oracle checks. If this testing is successful Operational GovOps confirms that the Allocation Instance satisfies all risk constraints specified in the Prime Agent Artifact. The output of this step is validated contracts for the Allocation Instance and a green light to proceed with a scaled deployment.

###### A.2.3.9.1.1.2.3.2 - Initial Deployment and Required Risk Capital / Asset Liability Management Execution [Core]  <!-- UUID: 648bcae7-9723-4282-81fe-fcc77fd6f90e -->

The Prime Agent finalizes JRC/SRC and Asset Liability Management Arrangements. Operational GovOps records these arrangements in the Powerhouse interface. If Operational GovOps is charged with operationalizing an Instance, it deploys funds from the Prime Agent’s Operational Buffer into the Allocation Instance, performing any necessary DEX exchanges. See [A.2.3.9.1.1.3.1 - Operationalization Of Allocation Instances](989512c2-4fa1-46b8-947c-00e3c0b56024). In doing so, Operational GovOps follows instructions in the Agent Artifact regarding the amount of capital to deploy and slippage tolerances. The output of this step is a fully deployed Allocation Instance conforming to Risk Capital and Asset Liability Management requirements.

###### A.2.3.9.1.1.3 - Allocation Instance Ongoing Management [Core]  <!-- UUID: 2db14aa7-ccfa-42f7-82a8-118048574d4c -->

The documents herein define the process for managing an Allocation Instance as part of the Allocation System Primitive.

###### A.2.3.9.1.1.3.1 - Operationalization Of Allocation Instances [Core]  <!-- UUID: 989512c2-4fa1-46b8-947c-00e3c0b56024 -->

Prime Agent teams may choose to directly operationalize their Allocation System Primitive Instances ("Instances") using internal, proprietary strategies that are not defined in their Artifacts. Alternatively, Prime Agents may elect to have the Instances operationalized by their Operational Executor Agent. This constitutes an exception to the general rule that Operational Executor Agents operationalize all Sky Primitives on behalf of Prime Agents. See [A.1.13.3.4 - Agent Role Delineation](fdf32ca5-5e2e-481e-9047-4d1599547216). 

For Prime Agent teams that operationalize their Instances, they will be required to formulate KPIs for their proprietary strategies; should an Instance under-perform these KPIs, Operational GovOps is authorized to step in and operationalize the Instance(s) via a back-up strategy that is defined in the Agent Artifact. Additional logic on this point will be defined in a future iteration of the Atlas.

###### A.2.3.9.1.1.3.2 - Requirements And Infrastructure For Risk Capital And Asset Liability Management [Core]  <!-- UUID: 13eb2346-07e5-48b6-9740-ce60a20146ab -->

The documents herein define Risk Capital and Asset Liability Management requirements and infrastructure.

###### A.2.3.9.1.1.3.2.1 - Risk Capital Management [Core]  <!-- UUID: 1c5fb5bb-ec03-478c-89b7-4017d935276e -->

The documents herein detail the obligations, processes, standards and infrastructure related to risk-capital management.

###### A.2.3.9.1.1.3.2.1.1 - Sky Core Required Risk Capital (RRC) Dashboard And API [Core]  <!-- UUID: 4eac2c9e-2718-4881-a3f1-ed10fb3f4d13 -->

The Sky Core Required Risk Capital (RRC) Dashboard and its associated API serve as the official system for determining and disseminating RRC figures for Prime Agents and their Allocation System Primitive Instances.

Prior to the full operational deployment of the Powerhouse system, Prime Agents must utilize the Sky Core RRC Dashboard/API as the authoritative source for their official Instance Total RRCs and Aggregate RRC. Data from these sources is to be used for all internal TRC management,  required reporting and compliance assessments.

The Sky Core RRC Dashboard is located at [https://sphere.blockanalitica.com/rrc](https://sphere.blockanalitica.com/rrc). The Sky Core RRC API is located at [https://sphere-api.blockanalitica.com/rrc/](https://sphere-api.blockanalitica.com/rrc/).

###### A.2.3.9.1.1.3.2.1.1.1 - Role and Functionality of the RRC Dashboard and API [Core]  <!-- UUID: f7da0f56-00f5-4bcf-bd31-b77c284c7992 -->

The RRC Dashboard provides a user interface for Prime Agents to view their official RRC figures. The RRC API allows Prime Agents to programmatically access this same data for integration into their internal TRC management systems. Both the Dashboard and API provide the following key information:
    
◦ Instance Total RRC: For each specific Allocation System Primitive Instance, the system displays its Instance Total RRC. This figure is the sum of all applicable risk-specific RRC calculations for that Instance, including:
        ◦ Instance Financial RRC ([A.3.2.1.1.4 - Instance Financial RRC](ba1d5c0e-399f-47a6-b5d4-b3f5477d5787)) 
        ◦ Instance Smart Contract RRC ([A.3.2.1.1.5 - Instance Smart Contract RRC](4b4ea578-28b4-481c-9abd-d34c5a4f383c))  
        ◦ Instance Administrative RRC ([A.3.2.1.1.6 - Instance Administrative RRC](c2b60f0d-6555-463c-9ad3-2a9746be77c5)) 

The models for certain risk-factors are still currently under development. See [A.2.3.9.1.1.3.2.1.1.2 - Interim Notice Regarding RRC Dashboard/API Coverage](18243e7a-5b62-459d-83fb-e50b9df05f9d). 
    
◦ Aggregate RRC: For each Prime Agent, the system displays its Aggregate RRC, which is the sum of all its Instance Total RRCs. This is the figure against which a Prime Agent’s Total Risk Capital (TRC) adequacy is assessed.

###### A.2.3.9.1.1.3.2.1.1.2 - Interim Notice Regarding RRC Dashboard/API Coverage [Core]  <!-- UUID: 18243e7a-5b62-459d-83fb-e50b9df05f9d -->

Some Allocation System Instances displayed on the RRC Dashboard concern asset types whose risk models have not yet been fully developed. See [A.3.2.1.1.4.3 - Financial Risk Models](2af9fa64-ab25-4017-920c-f1c07dff4c06). An active Instance’s respective Instance Configuration Document will specify its `RRC Framework Full Implementation` status as either `Covered` or `Pending`.

###### A.2.3.9.1.1.3.2.1.2 - Primes’ Total Risk Capital (TRC) Management [Core]  <!-- UUID: 3af8a3a2-25e5-44b3-87a4-7df1f2712685 -->

Prime Agent teams are responsible for managing their Total Risk Capital (TRC) to continuously meet their Aggregate Required Risk Capital (RRC). The accounting of TRC considers all on-chain holdings and any off-chain agreements, encumbrances, or conditions that may affect the immediate availability or eligibility of capital for RRC coverage. For a definition of Total Risk Capital, see [A.3.2.1.2.1 - Total Risk Capital Definition](6f6b25d6-f73c-4733-ba37-12a0a411433c).

The documents herein define requirements and standards for a Prime Agent’s internal TRC management systems.

###### A.2.3.9.1.1.3.2.1.2.1 - Objective of Prime TRC Management [Core]  <!-- UUID: 9a8120c4-0a5b-426f-97a5-283c708413f5 -->

To comply with Atlas risk capital requirements, Prime Agent teams must establish, maintain, and operate an internal system for TRC management. A Prime Agent’s internal TRC management system should enable proactive operational risk management. This entails ongoing capital adequacy assessment and strategic capital allocation planning for current and future Allocation System Primitive Instances, including the ability to perform scenario analyses for potential deployments or market stresses.

Prime Agents’ internal TRC management systems should enable them to maintain continuous sufficiency of the Prime Agent’s held TRC against its official Aggregate RRC. This requires real-time or near real-time comparison and internal alerting mechanisms to prevent and address potential shortfalls.
Primes must ensure that their internal TRC management systems maintain comprehensive, verifiable internal records of all TRC components, related transactions, and compliance activities to support internal governance and external verification processes, such as the submission of TRC Reports to Core GovOps. See [A.2.3.9.1.1.3.2.1.2.3 - Primes’ TRC Report](41ca2085-d71b-47e5-8b1a-b183b6e2b6fc).

###### A.2.3.9.1.1.3.2.1.2.2 - Minimum Capabilities of Prime TRC Management Systems [Core]  <!-- UUID: d034533f-9b6f-411c-8b60-3bccb374765f -->

A Prime Agent’s internal TRC management system should possess the following capabilities to meet the objectives outlined in [A.2.3.9.1.1.3.2.1.2.1 - Objective of Prime TRC Management](9a8120c4-0a5b-426f-97a5-283c708413f5). 
    
1. Prime Agents’ internal TRC management systems should enable compliant sourcing and tracking of all TRC components, including Internal Junior Risk Capital (IJRC), Prime-External Junior Risk Capital (SEJRC), Tokenized External Junior Risk Capital (TEJRC), and Originated Senior Risk Capital (OSRC). Compliance in this context includes strict adherence to eligibility criteria and capital-sourcing ratios (e.g., External Per Internal, Senior Per Junior) as defined in the Atlas. See [A.3.2.1.2.3 - Total Risk Capital Sourcing Ratios](9e99b084-f15a-4f60-b831-d6c0bd9aec04). 

The system must provide real-time or near real-time tracking of all held Total Risk Capital (TRC) components. This includes, for each TRC component:
        ◦ Accurate valuation of the assets comprising each component.
        ◦ Clear identification of the source of each component (e.g., Prime’s own SubProxy for IJRC, specific Ecosystem Accord references for rented SEJRC or OSRC, TEJRC encumbrance details, OSRC origination details).
        ◦ Verification of each TRC component’s eligibility status according to Atlas rules. This includes tracking whether capital is "enabled" or "active" for RRC coverage purposes (e.g., based on Ecosystem Accord status, compliance with sourcing ratios, etc.).
        ◦ Distinction between capital directly held by the Prime Agent and capital that is encumbered (e.g., SEJRC where the lending Prime retains custody but the capital is contractually committed).
    
2. Prime Agents’ internal TRC management systems should enable dynamic-state accounting. The system must account for TRC components that are in dynamic, pending, or off-chain states, as these can impact the true risk capital available to a Prime Agent. This includes:
        ◦ Pending transactions such as SEJRC or OSRC rental Ecosystem Accords that have been committed to by the parties, but not yet codified in the Atlas.
        ◦ Capital in transit, e.g., assets that are committed to be IJRC, but currently moving between chains via bridges or locked in Cross-Chain Transfer Protocol (CCTP) messages awaiting finality.
        ◦ Operational expenditures funded by TRC components (typically IJRC), such as blockchain transaction fees, oracle service fees, audit costs, and other operational overhead that reduces available risk capital. The system should track these expenditures in real-time or near real-time.
        ◦ Any off-chain factors that could impair the immediate deployability or availability of TRC components.
    
3. Prime Agents’ internal TRC management systems should enable continuous capital adequacy monitoring. The system must enable the near real-time comparison of the Prime Agent’s internally tracked and calculated TRC against its official Aggregate RRC, as obtained from the Sky Core RRC Dashboard/API. See [A.2.3.9.1.1.3.2.1.1 - Sky Core Required Risk Capital (RRC) Dashboard And API](4eac2c9e-2718-4881-a3f1-ed10fb3f4d13). This core functionality is essential for the Prime Agent to proactively monitor its capital adequacy, identify potential or actual TRC shortfalls, and make timely operational and capital management decisions to maintain compliance.
    
4. Prime Agents’ internal TRC management systems should define a RRC-incident (e.g., TRC shortfall) response protocol. The system should enable internal alerting mechanisms that detect when a Prime Agent’s TRC approaches predefined internal buffer thresholds relative to its Aggregate RRC. See [A.3.2.2.7.2.1.1.1 - Encumbrance Ratio](5435f680-aaaa-461a-bcae-4056bb8964d9). The system should also detect an actual shortfall where the Prime Agent’s held TRC falls below its Aggregate RRC.
Furthermore, Prime Agent teams should establish and document internal processes for responding to such alerts. Such internal processes should include: 1) internal escalation and assessment of the shortfall’s cause and magnitude; 2) formulation of potential responses or corrective actions, which may include sourcing additional TRC, reducing risk-weighted exposures, or other measures; 3) internal decision-making framework for the evaluation of potential responses and selection of the most appropriate one; and 4) notifying any pertinent parties (Operational GovOps) as needed for the purpose of planning or implementing follow-up action.

Prime Agent teams’ internal decision-making framework may consider the economic trade-offs of various actions, including the strategic acceptance of penalties for a TRC shortfall where such an approach is determined to be economically advantageous compared to immediate rebalancing (e.g., avoiding excessive transaction costs or market impact).

###### A.2.3.9.1.1.3.2.1.2.3 - Primes’ TRC Report [Core]  <!-- UUID: 41ca2085-d71b-47e5-8b1a-b183b6e2b6fc -->

Prime Agents are required to submit periodic Total Risk Capital (TRC) Reports to provide an accurate and verifiable attestation of their TRC composition and adherence to capital requirements.

###### A.2.3.9.1.1.3.2.1.2.3.1 - Mandate and Rationale [Core]  <!-- UUID: 7e95efa7-e409-48dc-9b5a-96edce54bf31 -->

Prime Agents are required to periodically submit TRC Reports to Core GovOps. This report serves a dual purpose. It provides a verifiable snapshot of the Prime Agent's TRC composition and key capital ratios as of the end of the reporting period; and second, it provides a formal attestation regarding the Prime Agent's maintenance of TRC at or above its dynamically changing Aggregate Required Risk Capital (RRC) throughout the entire reporting period. See [A.3.2.1.1.2 - Aggregate RRC](6aed5cc1-9671-4b73-88a9-fdd86ac93ece). 

This comprehensive reporting, encompassing both an end-of-period statement and disclosures of any intra-period events affecting TRC, is essential. On-chain data alone (such as that captured by the planned OVRC system) cannot definitively prove the full eligibility and unimpaired availability of a Prime Agent's capital position for continuous RRC coverage, nor can it capture all off-chain factors. These factors include, but are not limited to, whether assets are subject to Prime-initiated off-chain contractual pledges, if the economic value or redeemability of its bridged assets is compromised by issues with their originating bridge, or if its assets are encumbered by derivative structures or other off-chain commitments that would impair their immediate use at any point during the period.

The TRC Report serves as an important basis for Core GovOps’  verification procedures. This entails: 1) reconciling reported end-of-period TRC components against the Sky Atlas, on-chain data, and other relevant sources to validate the period-end capital position and adherence to Atlas-defined capital requirements; and 2) reviewing Prime Agents’ attestations and disclosures regarding its TRC management and any material events throughout the reporting period to assess continuous compliance with its dynamically changing Aggregate RRC. The outcome of this validation is a critical input for the monthly settlement cycles, which latter includes the determination and retroactive application of penalties for any identified discrepancies or violations of capital requirements during the period.

The long-term vision is for the Powerhouse system to enable the automation of TRC data aggregation and verification. The Powerhouse system will have capabilities such as directly querying Prime Agent SubProxy accounts for IJRC assets, programmatically accessing and interpreting Ecosystem Accords recorded in the Atlas, interfacing with TEJRC and OSRC smart contract systems, and automatically applying Atlas-defined eligibility rules. See [A.2.3.9.1.1.3.2.1.3.1 - Continuous Monitoring Of On-chain Verifiable Risk Capital (OVRC)](8048bdf0-84b7-4546-8f1a-98b62d073c84). Even in this advanced state, the TRC Report, or a similar form of periodic attestation, may remain necessary to cover elements of TRC verification that are not fully able to be automated or require explicit Prime Agent declaration.

###### A.2.3.9.1.1.3.2.1.2.3.2 - TRC Report Contents [Core]  <!-- UUID: 4887e971-be6c-4f98-9137-7cdec3ed0fa0 -->

The Total Risk Capital (TRC) Report submitted by a Prime Agent must provide an accurate and verifiable breakdown of all TRC components held by the Prime Agent as of the end of the specified reporting period. The TRC Report should include the following essential information:
    
◦ Aggregate TRC Value As of End of Period: The total declared value in USD of all eligible TRC components held by the Prime Agent as of the end of the reporting period.
    
◦ Detailed Breakdown of TRC Components As of End of Period: For each category of TRC held, the report must detail the following values as of the end of the reporting period:
        ◦ Internal Junior Risk Capital (IJRC): The total amount of IJRC, a breakdown of its constituent asset types, and their respective values in USD.
        ◦ Prime-External Junior Risk Capital (SEJRC): The total amount of SEJRC. For each portion of SEJRC sourced from another Prime Agent, the report must include the amount in USD, the identifier of the counterparty Prime Agent, the expiry date of the arrangement, and a direct reference to the Ecosystem Accord that governs the SEJRC arrangement.
        ◦ Tokenized External Junior Risk Capital (TEJRC): The total amount of TEJRC. For each TEJRC source, the report must include the amount in USD, the identifier of the TEJRC smart contract or facility and any relevant encumbrance identifier.
        ◦ Originated Senior Risk Capital (OSRC): The total amount of OSRC. The report must specify the amount originated directly by the Prime Agent from the Total Senior Risk Capital (TSRC) pool and any amount of OSRC rented from other Prime Agents. For any rented OSRC, the report must include the amount in USD, the identifier of the counterparty Prime Agent, the expiry date, and a direct reference to the pertinent Ecosystem Accord.
        ◦ Key Ratio Inputs and Computed Totals (Prime Internal Calculation) As Of End Of Period:  Based on the component values reported above (as of the end of the reporting period), the report must include key figures used in and resulting from the Prime Agent's internal capital adequacy calculations. These figures reflect the capital structure and ratios as of the end of the reporting period and include:
            - Internal Junior Risk Capital (IJRC)
            - External Junior Risk Capital (EJRC) generated via External Per Internal Ratio (Prime External Junior Risk Capital + Tokenized External Junior Risk Capital sourced via the EPI ratio still carries Senior Per Junior or SPJ capacity)
            - EJRC-via-SPJ (sourced by spending SPJ capacity; zero-SPJ-capacity thereafter)
            - Enabled Senior Risk Capital (SRC)
            - Total Senior Per Junior capacity
                ◦ Allocation of SPJ capacity to 1) enable SRC; or to 2) source EJRC
            - Prime-computed eligible Total Risk Capital (IJRC + EJRC-via-EPI + EJRC-via-SPJ + enabled SRC)
            - Official Aggregate RRC
            - Capital buffer = TRC – Aggregate RRC
            - Effective ratios
                ◦ EPI = EJRC-via-EPI ÷ IJRC
                ◦ SPJ utilisation:
                    ◦ enabled SRC ÷ total SPJ capacity
                    ◦ EJRC-via-SPJ ÷ total SPJ capacity    
◦ Dynamic Period Attestation and Disclosures: In addition to the end-of-period snapshot figures, the TRC Report must include an Attestation from the Prime Agent confirming it maintained TRC at or above its Aggregate RRC at all times throughout the entire reporting period. In addition, the TRC Report must include disclosure of any events, Prime-initiated off-chain contractual obligations, impairments to the value or redeemability of held assets (such as RWA backing or bridged asset viability), encumbrances, or other conditions that occurred at any point during the reporting period which materially affected its TRC, even if such conditions were temporary or not continuously visible to on-chain monitoring systems. This disclosure must include the nature of the event/condition, its precise timing and duration, and its quantified impact on the Prime Agent's TRC.

###### A.2.3.9.1.1.3.2.1.3 - Sky Core TRC Monitoring And Verification Infrastructure [Core]  <!-- UUID: 18d692ce-7a5d-47a7-ada9-dc73abd87987 -->

The documents herein define infrastructure for TRC monitoring and verification.

###### A.2.3.9.1.1.3.2.1.3.1 - Continuous Monitoring Of On-chain Verifiable Risk Capital (OVRC) [Core]  <!-- UUID: 8048bdf0-84b7-4546-8f1a-98b62d073c84 -->

An autonomous monitoring system must be designed and implemented to enable continuous tracking of Prime Agents’ on-chain verifiable risk-capital components in near real-time. The on-chain, verifiable risk-capital components that can be tracked by such a monitoring system in real time are termed "On-chain Verifiable Risk Capital" (OVRC).

OVRC is not necessarily equivalent to Total Risk Capital (TRC).  A Prime Agent’s actual TRC cannot be determined definitively without accounting for off-chain agreements, encumbrances or other relevant conditions affecting capital eligibility or availability, which conditions must be disclosed in the TRC Reports submitted by Prime Agents. See [A.2.3.9.1.1.3.2.1.2.3 - Primes’ TRC Report](41ca2085-d71b-47e5-8b1a-b183b6e2b6fc). 

Where the OVRC of a Prime Agent is less than its Aggregate RRC, the shortfall will be logged and penalty accrual will commence on a pro-rata, per-second basis for the duration and magnitude of the observed shortfall, according to the penalty schedule defined in the Atlas. Thus, this on-chain monitoring system serves as an interim penalty ledger.

###### A.2.3.9.1.1.3.2.1.3.2 - Validation of TRC Report In General [Core]  <!-- UUID: 482fc286-9969-40cc-b3c9-6233ecbb659c -->

Prime Agents are required to submit periodic Total Risk Capital (TRC) Reports to Core GovOps. See [A.2.3.9.1.1.3.2.1.2.3 - Primes’ TRC Report](41ca2085-d71b-47e5-8b1a-b183b6e2b6fc). The protocol for validation of Primes’ TRC reports is defined in the documents herein.

###### A.2.3.9.1.1.3.2.1.3.2.1 - Core GovOps TRC Report Validation Process [Core]  <!-- UUID: 1ac3e606-f1c7-4a20-a9b6-a425920e98d3 -->

Core GovOps receives TRC Reports from Primes on a regular basis and must perform the following validation process.

Core GovOps verifies against the Atlas any Ecosystem Accord referenced in the TRC Report for sourced Prime-External Junior Risk Capital (SEJRC) or rented Originated Senior Risk Capital (OSRC). This includes confirming the existence, current validity, and terms of such Accords as formally recorded within the Atlas.

Core GovOps validates the Prime Agent's reported IJRC by reconciling the reported IJRC amount and its constituent asset composition against the actual on-chain state of the Prime Agent’s designated SubProxy account. This involves direct on-chain verification of asset balances. Core GovOps verifies that all assets reported as IJRC and held within the SubProxy account meet the definition of "eligible assets" for IJRC as defined by the Atlas. See [A.3.2.1.2.2.1.1.1 - Internal Junior Risk Capital (IJRC)](8728abee-0dc5-449b-b4c2-78698da16f10). 

For reported Tokenized External Junior Risk Capital (TEJRC) and Originated Senior Risk Capital directly originated by the Prime, Core GovOps validates the reported amounts and statuses by cross-referencing data from the relevant smart contract systems. This may involve querying TEJRC pool contracts, OSRC auction records, and other on-chain infrastructure to confirm the existence, ownership, and eligibility of these capital components.

Core GovOps reviews all attestations and disclosures made by the Prime Agent in the TRC Report. This review focuses on understanding the Prime Agent's TRC compliance with Aggregate RRC throughout the entire reporting period. This assessment is critical for identifying intra-period shortfalls that might not be visible to on-chain monitoring systems or reflected in the end-of-period snapshot alone. The assessment process may include requiring the Prime Agent to provide supplementary documentation, verifiable evidence, or independent third-party confirmations for material off-chain claims or attestations concerning intra-period events; and/or cross-referencing disclosed off-chain information with relevant on-chain indicators or transactions that might corroborate or contradict the attestations.

Finally, Core GovOps independently calculates and verifies the Prime Agent's compliance with all Atlas-defined capital sourcing ratios (e.g., External Per Internal (EPI), Senior Per Junior (SPJ)).

###### A.2.3.9.1.1.3.2.1.3.3 - Finalized Determination Of TRC Position And Penalties [Core]  <!-- UUID: 36f3e675-d372-4d25-a50f-f0ba84a36273 -->

After reaching a definitive accounting of Prime Agents’ capital position and TRC adequacy, penalties are finalized by Core GovOps. This involves reconciling the interim penalty ledger (derived from the OVRC system) with the definitive TRC history, which incorporates all validated information from the TRC Report including any intra-period shortfalls.
    
1. If the validated TRC Report indicates that the Prime Agent's TRC was below its Aggregate RRC during the reporting period, and this actual shortfall was more severe than, or not detected by, the OVRC monitoring system, then penalties will be finalized as follows: if the OVRC system had already accrued penalties, these will be adjusted upwards to match the actual shortfall; if the OVRC system had not detected a shortfall, penalties will be assessed and applied retroactively based on the full duration and magnitude of the actual shortfall.
    
2. If the validated TRC Report confirms that TRC shortfalls were identical in duration and magnitude to those logged by the OVRC monitoring system throughout the reporting period: the penalties accrued in the interim penalty ledger will be confirmed and finalized.
    
3. If the validated TRC Report confirms that TRC was higher than a misleading OVRC reading during a specific portion of the reporting period which led to an erroneously logged penalty: Core GovOps will adjust or void the penalty accordingly.

###### A.2.3.9.1.1.3.2.1.4 - Risk-Capital Incident Response [Core]  <!-- UUID: 12b7d480-68a0-4493-9534-d6915f86c112 -->

Where a Prime Agent’s Allocation System Instances are operationalized by its Operational Executor Agent, the management of and response to Required Risk Capital (RRC)-related incidents requires a defined framework within each Prime Agent's Artifact (the Multi-Instance Coordinator Document for the Allocation System Primitive) and its associated Executor Accord.

While the Prime Agent's strategic team ("Prime Team") determines the specific rectification strategy for an RRC incident—considering its holistic portfolio, prevailing market conditions, and the potential for strategic acceptance of penalties—this discretion is exercised subject to the authority of Sky Core to impose penalties and take corrective measures, up to and including the conservatorship of a Prime Agent, to protect the ecosystem and make any losses whole.

This document will be developed further in a future iteration of the Atlas.

###### A.2.3.9.1.1.3.2.1.5 - Instance Operational Conformance [Core]  <!-- UUID: 1ec5f16f-194d-4163-b1ba-5c196ffa554b -->

Operational deviation from Artifact specifications can render an Instance’s RRC, and thus the Prime’s Aggregate RRC, invalid. Prime Agents must therefore ensure that each Allocation System Instance adheres to its respective Instance Configuration Document. Whether a Prime self-operationalizes its Allocation System or contracts with an Operational Executor Agent, its Agent Artifact must define processes for monitoring for, and addressing deviations of, Instance operational conformance. This document will be developed further in a future iteration of the Atlas.

###### A.2.3.9.1.1.3.2.2 - Asset Liability Management [Core]  <!-- UUID: ed10830e-6b17-4117-8ab4-5ea388b518bb -->

Requirements and infrastructure related to Asset Liability Management shall be defined in a future iteration of the Atlas.

###### A.2.3.9.1.1.3.3 - Allocation Instance Adjustments, Scaling, And Settlement [Core]  <!-- UUID: 93bfb0f9-d662-467d-b8bc-ef585e5b081e -->

On an ongoing basis, the Prime Agent team or Operational GovOps operates the Allocation Instance, scaling exposure up and down. Any change to the Allocation Instance outside of the limits specified in the Prime Agent Artifact or requiring judgment on the part of Operational GovOps (where the Allocation System Instance is operationalized by the Operational Executor Agent) requires a new vote of Prime Agent token holders. See [A.2.3.9.1.1.3.3.1 - Modification Of Existing Instances](c1b5708c-e88f-45e0-92e1-b76e68b34f13). As part of monthly and quarterly settlement cycles, Core GovOps reviews yields and obligations, applying penalties retroactively for any previously undisclosed violations. In the event of any such violations, Operational GovOps may be required to take escalatory steps based on the fallback strategy in the Prime Agent Artifact.

###### A.2.3.9.1.1.3.3.1 - Modification Of Existing Instances [Core]  <!-- UUID: c1b5708c-e88f-45e0-92e1-b76e68b34f13 -->

When a Prime Agent wishes to modify an existing Allocation System Primitive Instance in a manner that cannot be accommodated by the existing operational parameters defined in its Agent Artifact, the Prime Agent must initiate an Artifact Edit Proposal process as detailed herein.

###### A.2.3.9.1.1.3.3.1.1 - Conditions Requiring Artifact Edit Proposal [Core]  <!-- UUID: 3db4c73f-f480-4da4-9af3-8ecedd89e166 -->

An Artifact Edit Proposal is mandatory for an Instance modification under the following conditions:

1. a desired modification to the Instance's operational parameters falls outside the pre-defined operational ranges codified in the respective Instance Configuration Document or other applicable Artifact Documents; or

2. a desired modification, even if notionally within defined ranges in the Artifact, is determined by Operational GovOps to materially alter the Instance's risk profile in a way that could invalidate the underlying Capital and Operational Plan and, consequently, the premises driving the current Required Risk Capital (RRC) for that Instance. Operational GovOps retains the discretion to require an Artifact Edit Proposal if a proposed change, regardless of its fit within existing operational ranges, is determined to pose a material change to the assessed risk.

###### A.2.3.9.1.1.3.3.1.2 - Revision of Capital and Operational Plan for Instance Modification [Core]  <!-- UUID: 235a7317-ef29-48ed-a37f-5892108f8dc8 -->

Prior to submitting an Artifact Edit Proposal for an Instance modification, the Prime Agent must revise the Capital and Operational Plan (C&O Plan) associated with that Instance to reflect the desired new state.

The revised Capital and Operational Plan for an Instance modification must include the following information:
    
1. Updates to the Instance's strategy and operational parameters;
    
2. A new pro-forma Required Risk Capital (RRC) estimate specifically calculated to reflect the Instance's proposed modified state;  and
    
3. A revised notional Total Risk Capital (TRC) coverage strategy, detailing how the Prime Agent will manage any changes to the Instance RRC and the consequential impact on its Aggregate RRC, including plans for acquiring additional JRC or SRC if necessary.

###### A.2.3.9.1.1.3.3.1.3 - Governance Process for Instance Modification [Core]  <!-- UUID: aee1d848-eee8-4590-a596-1884efcb474a -->

The Prime Agent's revised Capital and Operational Plan forms the core of the Artifact Edit Proposal for the Instance modification. This proposal must be submitted to the Operational Executor Facilitator for review. The Facilitator assesses the proposal for completeness and general alignment. Following this review, the proposal is subjected to the Prime Agent's governance process for approval to edit the Agent Artifact, typically involving a token holder vote as defined in the Prime Agent's Root Edit Primitive.

###### A.2.3.9.1.1.3.3.1.4 - Post-Approval Integration and RRC Update [Core]  <!-- UUID: e3a00c33-9da7-4fa9-80ff-55d3a70100fa -->

If the Artifact Edit Proposal for the Instance modification is approved through the Prime Agent's governance process, the relevant content from the revised Capital and Operational Plan is formally integrated into the respective Instance Configuration Document within the Prime Agent's Artifact. Once the modified Instance is operational under its new, approved parameters and its data is integrated into the ecosystem's monitoring systems, its adjusted Required Risk Capital (RRC) will be officially determined and tracked via the Sky Core RRC Dashboard/API. This official RRC figure then supersedes the Prime-prepared pro-forma RRC that was part of the modification proposal.

##### A.2.3.9.1.2 - Allocation System Input Requirements [Core]  <!-- UUID: b6ccdee2-a5e4-4d63-9af5-60b8163673af -->

The documents herein define the required inputs for a valid Invocation of the Allocation System Primitive. If any input is noncompliant or omitted, the Primitive will be invalidated and the Allocation Instance deployment will not move forward.

###### A.2.3.9.1.2.1 - Global Activation Status [Core]  <!-- UUID: 5a9cf81d-19dd-4f75-9ddc-be35c6b5cfb5 -->

The Allocation System Primitive must be Globally Activated.

###### A.2.3.9.1.2.2 - Core Allocation Vault Address [Core]  <!-- UUID: 4655b643-b03f-49b7-a474-493c3e059b62 -->

The Prime Agent Artifact must specify the address of the Prime Agent’s Core Allocation Vault.

###### A.2.3.9.1.2.3 - Core Allocation Buffer Address [Core]  <!-- UUID: 2cdb447e-ebf5-4e57-a722-181178fbe80f -->

The Prime Agent Artifact must specify the address of the Prime Agent’s Core Allocation Buffer.

###### A.2.3.9.1.2.4 - Allocation System Core Security Parameters [Core]  <!-- UUID: 9c5e2e23-7756-4856-951b-0bcbecaa867d -->

The Prime Agent Artifact must specify the rate limiters for the Allocation Vault and Core Allocation Buffer, including the address and parameters for each.

###### A.2.3.9.1.2.5 - Capital Faucet [Core]  <!-- UUID: 4b8cf927-d5e3-4e5b-8626-62523fb286be -->

The Prime Agent Artifact must specify the address of the Prime Agent’s Capital Faucet and its rate limits.

###### A.2.3.9.1.2.6 - List Of Allocation Instances [Core]  <!-- UUID: e4975062-6d19-438b-a5d5-cfc1a7fd8cb9 -->

If the Allocation System Primitive is Activated, then the Prime Agent Artifact must list each active Allocation Instance, grouped by blockchain. For each blockchain, the Prime Agent Artifact must specify: (1) the name of the blockchain, (2) the bridging mechanism for the blockchain, if any, (3) the allocation buffer on the blockchain, and (4) the Allocation Instances on the blockchain. For each Allocation Instance, the Prime Agent Artifact must contain the information specified herein.

###### A.2.3.9.1.2.6.1 - Required Allocation Instance Parameters [Core]  <!-- UUID: 6ad0fdb4-bd11-4d5a-a436-0d106873e0ec -->

For each Allocation Instance, the Prime Agent Artifact must specify: (1) the name of the Allocation Instance, (2) the address of the Allocation Instance, (3) the rate limit of the conduit for inflows and outflows, (4) any other technical parameters of the Allocation Instance (e.g. maximum slippage, oracles used), (5) data submission protocols, and (6) specification of emergency measures that can be used by Operational GovOps if Required Risk Capital or Asset Liability Management obligations are breached.

###### A.2.3.9.1.2.6.2 - Required Allocation Instance Allocation Strategy [Core]  <!-- UUID: 0e4a5264-1365-4e5c-9be4-dac85ed6b46b -->

For each Allocation Instance, the Prime Agent Artifact must specify the strategy documents contained herein. These strategy documents must describe in detail how the Allocation Instance should be operated so that the Operational Executor Agent that the Prime Agent has contracted with can operate the Allocation Instance without further input from the Prime Agent or having to make "judgment calls". To the extent that the Prime Agent’s strategy cuts across different Allocation Instances, the Prime Agent may include a single set of strategy documents covering all Allocation Instances.

###### A.2.3.9.1.2.6.2.1 - Required Allocation Instance Asset Liability Management Strategy [Core]  <!-- UUID: 3f48dff7-3bf1-44d2-a92f-531ce42be318 -->

The allocation strategy for each Allocation Instance should specify how Operational GovOps should adjust the amount of funds allocated to the Conduit based on performance, market conditions, or other factors. It should also specify limits to the amount by which the allocation can be adjusted before a vote of Prime Agent token holders is required.

###### A.2.3.9.1.2.6.2.2 - Required Allocation Conduit Asset Liability Management Strategy [Core]  <!-- UUID: 2cdd38d7-7f85-411b-854e-5768d564c275 -->

The asset liability management strategy for each Allocation Instance must specify what steps Operational GovOps should take to ensure that the Prime Agent continues to satisfy its Asset Liability Management obligations as the amount of funds allocated to the Conduit changes.

###### A.2.3.9.1.2.6.2.3 - Required Allocation Instance Fallback Strategy [Core]  <!-- UUID: 4363d9c4-afb3-44d1-a72a-9edbd40d415e -->

The fallback strategy for each Allocation Instance must specify how Operational GovOps should determine when an emergency situation is occurring regarding the Allocation Instance and what actions it should take to protect the Prime Agent from losses associated with the Allocation Instance. The fallback strategy must include emergency measures for Operational GovOps to reduce exposure to, drain, and ultimately shut down the Allocation Instance if Required Risk Capital or Asset Liability Management obligations are breached.

#### A.2.3.9.2 - Junior Risk Capital Rental Primitive [Core]  <!-- UUID: d8086dc0-7e77-4c6b-98c7-5fc41337a1ce -->

The Junior Risk Capital Rental Primitive is a mechanism enabling Prime Agents to rapidly rent Junior Risk Capital from each other, ensuring that capital gets deployed to where the best opportunities are.

#### A.2.3.9.3 - Asset Liability Management Rental Primitive [Core]  <!-- UUID: bd1f1ce5-6c31-42fc-a2aa-694acf5eb08c -->

The Asset Liability Management Rental Primitive is a mechanism enabling Prime Agents to trade Asset Liability Management obligations between each other, providing more flexibility in how capital is deployed through the Allocation System and reducing duplicate work.

### A.2.3.10 - Core Governance Primitives [Section]  <!-- UUID: 6fa54611-c744-4b9d-897d-b2a20e9cae5d -->

Core Governance Primitives allow Prime Agents to earn incentives for maintaining and securing Sky Governance frontends as well as borrow from the Smart Burn Engine.

#### A.2.3.10.1 - Core Governance Reward Primitive [Core]  <!-- UUID: b22d1c08-042a-4466-94fe-9d28951e4d4a -->

The Core Governance Reward Primitive is a reward that Sky pays to Prime Agents that provide SKY holders with secure access to the core Sky Governance features, ensuring that the Governance Security of Sky is maintained over time.

## A.2.4 - Treasury Management [Article]  <!-- UUID: 6c0af059-5d33-4e2b-90f1-1606957b8f85 -->

The Sky Treasury Management Function defines how all Net Revenue of the Sky Protocol is distributed among various downstream functions or buffers. This ensures that all necessary functions are adequately funded, allowing all actors to focus on growing the ecosystem in a positive sum way.

### A.2.4.1 - Treasury Management [Section]  <!-- UUID: 9bd2f02c-8111-4431-9b3a-46d3695af1e1 -->

The documents herein define the Sky Treasury Management Function.

#### A.2.4.1.1 - Integration With Monthly Settlement Cycle [Core]  <!-- UUID: 6e187fc0-6e5a-4384-b0b6-cdfd87a7d400 -->

The Sky Treasury Management Function is synchronized with the Monthly Settlement Cycle. See [A.2.5 - Sky Core Monthly Settlement Cycle](6f8d5065-d6ff-4add-9a28-eadeffa7ed1a). At the conclusion of each MSC, the Net Revenue of the Sky Protocol for the preceding month is calculated and allocated according to the waterfall process defined in [A.2.4.1.2 - Allocation Steps](7932c8f3-ce44-49ea-adc4-f6391c621c6e).

#### A.2.4.1.2 - Allocation Steps [Core]  <!-- UUID: 7932c8f3-ce44-49ea-adc4-f6391c621c6e -->

The documents herein define the allocation steps of the Sky Treasury Management Function. The process is divided into steps beginning with Net Revenue. These steps form a "waterfall" with each previous step needing to be fully funded before any funds can be allocated to later steps.

##### A.2.4.1.2.1 - Step 0: Net Revenue [Core]  <!-- UUID: c09435ff-d876-442a-899c-ad494175500b -->

The sole function of Step 0 is to establish the Net Revenue of the Sky Protocol. It performs no allocations to downstream functions or buffers, unlike subsequent steps for which this Net Revenue serves as the input.

All items of Income and Expense are recognized on a "cash basis" based on when USDS/DAI enter or leave the Sky Surplus Buffer, Core Council Buffer, or Aligned Delegates Buffer.

###### A.2.4.1.2.1.1 - Net Revenue [Core]  <!-- UUID: bddce7bf-c568-444b-b196-e15a99016696 -->

Net Revenue is equal to Income minus Expenses. Income is defined in [A.2.4.1.2.1.2 - Income](a0fab275-399d-41ad-a9b0-411d3e5ea5c9). Expenses are defined in [A.2.4.1.2.1.3 - Expenses](88e3c367-fe30-4d59-8ba1-eddc0d88a0ea). Income and Expenses are defined such that Net Revenue must always be positive

###### A.2.4.1.2.1.2 - Income [Core]  <!-- UUID: a0fab275-399d-41ad-a9b0-411d3e5ea5c9 -->

The documents herein define each of the components of the Income of the Sky Protocol. These components are added together to arrive at total Income.

###### A.2.4.1.2.1.2.1 - Stability Fees From Base Rate [Core]  <!-- UUID: 13d342a7-e9cf-4fb2-afc1-a1dd36c47054 -->

Stability Fees are the fees that Sky Core charges Prime Agents to borrow from Sky. See [A.3.1.2.1 - Base Rate](228f9955-6bba-4252-a101-5529e7a300b9). Sky Core’s legacy ALM infrastructure is currently being transferred to Prime Agents; during this transition period and until this transfer is fully complete, income generated from the Sky Core Collateral Portfolio contributes to net revenue. See [A.3.3.1.4 - Application To Sky Core](6e050b66-0bc8-43f1-b32d-2220c9df466b).

###### A.2.4.1.2.1.2.2 - Internal Senior Risk Capital Income [Core]  <!-- UUID: 02b5422a-093d-4e21-86ff-5cfcd5af8ed5 -->

Internal Senior Risk Capital income is the revenue attributed to Sky from the total payments made by Primes for Originated Senior Risk Capital (OSRC). ISRC itself comprises surplus capital allocated from designated buffers funded by the Sky Treasury Management Function. While Primes pay a single clearing price for their OSRC based on the monthly Origination Process, the total revenue received by Sky is subsequently allocated proportionally, with the portion corresponding to ISRC's share of the Total Senior Risk Capital (TSRC) pool designated as ISRC Income. See [A.2.4.1.3 - Sourcing Of Internal Senior Risk Capital From Surplus Buffers](ac7a6636-acbc-40c9-abc1-4543c0beb300).

###### A.2.4.1.2.1.2.3 - External Senior Risk Capital Fees [Core]  <!-- UUID: f01ce2f4-6bbe-4d70-8b22-edb80d8fb624 -->

External Senior Risk Capital Fees are levied by Sky and calculated as 5% of the net interest earnings generated by the External Senior Risk Capital (ESRC) pool each Monthly Settlement Cycle. These earnings represent the portion of the total revenue from Primes' Originated Senior Risk Capital (OSRC) payments that is attributed proportionally to ESRC, based on its contribution to the Total Senior Risk Capital (TSRC) pool for that cycle. This 5% fee is deducted before the remaining ESRC earnings contribute to the srUSDS conversion rate. See [A.3.2.2.4.2.3.3.2 - ESRC Earnings Fee](559f6fb6-daf6-41b2-9882-53a91aaf132f).

###### A.2.4.1.2.1.2.4 - Agent Upkeep Fees [Core]  <!-- UUID: c650b38c-aa7c-42b4-94ed-6320238b0264 -->

Agent Upkeep Fees are fees paid by Agents to contribute to the long-term sustainability of the Sky Ecosystem. See [A.2.3.6 - Ecosystem Upkeep Primitives](25673fd2-76cb-4c4d-8ec6-8c489207bcfc).

###### A.2.4.1.2.1.2.5 - Agent Creation Fees [Core]  <!-- UUID: 1b1c9cc0-e410-4bb3-aa37-c639ca392dd7 -->

Agent Creation Fees are one-time payments collected from founding teams when establishing new Prime Agents. See [A.2.3.3.1.2 - Creation Fee](708ad6b6-8e4a-46b3-9848-523d00a57420).

###### A.2.4.1.2.1.2.6 - Other Income [Core]  <!-- UUID: 493207c9-a5fb-4f0b-a042-eaf33854c710 -->

Other Income includes all sources of income of the Sky Protocol not identified in the other subdocuments of [A.2.4.1.2.1.2 - Income](a0fab275-399d-41ad-a9b0-411d3e5ea5c9), including, without limitation, the sources of income specified in the documents herein.

###### A.2.4.1.2.1.2.6.1 - Sky Core Vault Income [Core]  <!-- UUID: 58162399-3271-47b1-884f-865c773fb89e -->

Sky Core Vault Income is all income from Sky Core Vaults, including, without limitation, liquidation penalties. Sky Core Vaults include, without limitation, (1) all Sky Core Vaults specified in [A.3.7.1.1.1 - Vault Types](64971463-0650-4462-b9c4-1eecb704fa1a) and (2) the Sky Core Vault associated with SKY-Backed Borrowing (see [A.4.4.1.3 - SKY-Backed Borrowing](264b1787-cd75-4d28-9c14-c7d5a724eba7)).

###### A.2.4.1.2.1.2.6.2 - LitePSM Income [Core]  <!-- UUID: 0f13c157-d696-425c-8819-d1bcfcb7a50b -->

LitePSM Income is all income from the LitePSM.

###### A.2.4.1.2.1.3 - Expenses [Core]  <!-- UUID: 88e3c367-fe30-4d59-8ba1-eddc0d88a0ea -->

The documents herein define each of the components of Expenses. These components are added together to arrive at total Expenses.

###### A.2.4.1.2.1.3.1 - Sky Savings Rate Paid To sUSDS Holders [Core]  <!-- UUID: e6b86b0e-163d-4be4-928d-a81dd6700d57 -->

The Sky Savings Rate is the interest expense paid to sUSDS holders on their balances. It also includes all other savings-related expenses (other than those paid through the Integration Boost), such as the Dai Savings Rate expense and interest on stUSDS.

###### A.2.4.1.2.1.3.2 - Sky Savings Rate Paid Through Integration Boost [Core]  <!-- UUID: feb95aa7-e1b1-4ba8-a9a5-f99b5a21477e -->

The Integration Boost provides the equivalent of the Sky Savings Rate to users of decentralized finance protocols who hold USDS balances. See [A.2.3.8.2 - Integration Boost Primitive](73577399-62e4-4a83-ae11-64ef7e7b7f20).

###### A.2.4.1.2.1.3.3 - Distribution Rewards [Core]  <!-- UUID: 2177f303-a0a7-4807-b815-d17aa76a264e -->

The Distribution Reward is paid to Prime Agents and third-party partners that drive adoption of USDS. See [A.2.3.8.1 - Distribution Reward Primitive](e632c38f-3e4e-4c7e-acfd-b6ec45a422e6).

###### A.2.4.1.2.1.3.4 - Reimbursement Rewards [Core]  <!-- UUID: 3aa5b01e-6661-4b01-b32c-ea7b02fbedcb -->

Reimbursement Rewards are paid to Prime Agents to reimburse them for the costs of building common infrastructure used by the entire Sky Ecosystem, such as Token SkyLink deployments.

###### A.2.4.1.2.1.3.5 - Pioneer Rewards [Core]  <!-- UUID: 33c56bad-c422-48f4-bcca-dc8794c6a0da -->

Pioneer Rewards are paid to Pioneer Primes as specified in [A.2.3.8.3.1.4 - Pioneer Incentive Pool](04edac33-19d5-4a87-a8ab-945a0cd57771).

##### A.2.4.1.2.2 - Step 1: Security And Stability Maintenance [Core]  <!-- UUID: 324e9d22-70fe-4e44-82ab-118815f5c42e -->

All of the Net Revenue from Step 0 ([A.2.4.1.2.1.1 - Net Revenue](bddce7bf-c568-444b-b196-e15a99016696)) becomes Step 1 Capital. 10% of Step 1 Capital is allocated for security and stability maintenance as specified in the documents herein. The remaining 90% of Step 1 Capital becomes Step 2 Capital and is allocated as specified in [A.2.4.1.2.3 - Step 2: High Activity Staking Rewards](b560829c-f8ea-4e44-a96f-a0d51d9f437b).

###### A.2.4.1.2.2.1 - Core Executor Budget [Core]  <!-- UUID: fbd3df2a-f476-431e-881e-8fb18ed0458c -->

Up to 5% of Step 1 Capital is allocated to the Core Executor Budget. This budget funds active Core Executor Agents responsible for the continuous improvement of the Atlas, including the risk management framework and other critical components.

###### A.2.4.1.2.2.1.1 - Voluntary Reduction By Core Executor Agents [Core]  <!-- UUID: e8e8759c-5e43-411b-b07d-3d4e173ba742 -->

The Core Executor Agents may agree to voluntarily reduce their budget below 5% when applying for a Core Executor Slot in order to increase their chances of being elected to a Core Executor Slot. To the extent that Core Executor Agents reduce their budget, Step 2 Capital is increased by a corresponding amount. The mechanism by which Core Executor Agents are elected will be specified in a future iteration of the Atlas.

###### A.2.4.1.2.2.2 - Core Executor Reward [Core]  <!-- UUID: c5b70fe8-ba96-45b9-b0bd-48c108e37c64 -->

Up to 3% of Step 1 Capital is allocated to Core Executor Agents whose terms have ended in the last four (4) years. This incentivizes Core Executor Agents to increase the long term profitability of the Sky Ecosystem during their Core Executor Slot terms, as the Core Executor Reward is a percentage of future Net Revenue.

###### A.2.4.1.2.2.3 - Aligned Delegates [Core]  <!-- UUID: 07fb6ac1-0727-4c8e-a0b3-10b5becdbe4d -->

Up to 1% of Step 1 Capital is allocated to Aligned Delegates.

###### A.2.4.1.2.2.3.1 - Voluntary Reduction By Aligned Delegates [Core]  <!-- UUID: 0ba59921-e125-45a2-aa6c-7ec55fba7911 -->

Aligned Delegates may agree to voluntarily reduce their compensation in order to incentivize SKY holders to delegate to them. To the extent that Aligned Delegates reduce their compensation, Step 2 Capital is increased by a corresponding amount. The mechanism by which Aligned Delegates may agree to reduce their compensation will be specified in a future iteration of the Atlas.

###### A.2.4.1.2.2.4 - Governance Accessibility Rewards Paid To Integrators [Core]  <!-- UUID: 6c215fd3-61c1-4ee5-b326-a180fe0fc768 -->

0.5% of Step 1 Capital is allocated to frontends and other Integrators that facilitate accessible governance, following security and information standards specified in the Atlas. These standards will be specified in a future iteration of the Atlas. See [A.2.3.10.1 - Core Governance Reward Primitive](b22d1c08-042a-4466-94fe-9d28951e4d4a).

###### A.2.4.1.2.2.5 - Governance Accessibility Rewards Paid To Prime Agents [Core]  <!-- UUID: e7fd952e-5298-4928-82ea-992f18bea319 -->

0.5% of Step 1 Capital is allocated to Prime Agents that manage the rewards for Governance Integrators, incentivizing the active participation of Prime Agents. See [A.2.4.1.2.2.4 - Governance Accessibility Rewards Paid To Integrators](6c215fd3-61c1-4ee5-b326-a180fe0fc768).

##### A.2.4.1.2.3 - Step 2: High Activity Staking Rewards [Core]  <!-- UUID: b560829c-f8ea-4e44-a96f-a0d51d9f437b -->

5% of the Step 2 Capital is allocated to High Activity Staking Rewards ("HASR") as specified in the documents herein. The remaining 95% of Step 2 Capital becomes Step 3 Capital.

###### A.2.4.1.2.3.1 - Purpose [Core]  <!-- UUID: e0aa549a-f430-4e5a-bec1-170894b8dce4 -->

High Activity Staking Rewards provide a boosted staking reward to SKY stakers that delegate their SKY through compliant Governance Accessibility frontends and provide feedback to their delegates every three (3) months. This ensures that there is a minimum amount of SKY that is always actively following current events and governance to detect potential misalignment or buildup of hidden risks.

###### A.2.4.1.2.3.2 - Funding Of High Activity Staking Rewards Buffer [Core]  <!-- UUID: a7b1f2b2-b0c7-4440-8f83-b2bf496be2df -->

5% of the Step 2 Capital is allocated to funding the High Activity Staking Rewards Buffer (HASRB) linearly over the course of the month. Funds from the High Activity Staking Rewards Buffer are then paid out to Governance Accessibility Integrators as specified in [A.2.4.1.2.3.3 - Payout From High Activity Staking Rewards Buffer](6e857f3d-1e5c-4a47-943d-439b1d0d87ea). Governance Accessibility Integrators are in turn responsible for distributing those funds to High Activity Stakers as specified in [A.2.4.1.2.3.4 - High Activity Staker Qualification](8e83f80f-5606-41a7-bc90-d79df38b55fe).

###### A.2.4.1.2.3.3 - Payout From High Activity Staking Rewards Buffer [Core]  <!-- UUID: 6e857f3d-1e5c-4a47-943d-439b1d0d87ea -->

The High Activity Staking Rewards distribution occurs linearly over the course of each month. The total amount distributed equals the lesser of 1) 5% of Step 2 Capital, or 2) 15% of the current High Activity Staking Rewards Buffer, with a minimum floor of 5% of HASRB. 

In periods of high profitability, funds build up in the High Activity Staking Rewards Buffer. Then in periods of low profitability these funds are paid out from the High Activity Staking Rewards Buffer, ensuring that there is a continued incentive for active involvement in governance even in periods of low profitability to maintain security.

###### A.2.4.1.2.3.4 - High Activity Staker Qualification [Core]  <!-- UUID: 8e83f80f-5606-41a7-bc90-d79df38b55fe -->

To qualify as High Activity Stakers, SKY stakers must satisfy two criteria as specified in the documents herein.

###### A.2.4.1.2.3.4.1 - High Activity Stakers Must Stake Through Compliant Governance Accessibility Frontend [Core]  <!-- UUID: 38ff7f6d-de6b-429c-bed7-d1be1f256d37 -->

High Activity Stakers must stake through Governance Accessibility frontends that comply with security and information standards specified in the Atlas.

###### A.2.4.1.2.3.4.2 - High Activity Stakers Must Continuously Provide Input On Executor Agents [Core]  <!-- UUID: ca697069-146e-4391-831f-50f05dbff24b -->

High Activity Stakers must continuously provide input on the work of Executor Agents. In this way High Activity Stakers monitor the performance of Executor Agents just as Executor Agents monitor the performance of Prime Agents.

###### A.2.4.1.2.3.4.2.1 - Input Methods [Core]  <!-- UUID: e5e0b4cd-fefd-4677-8e65-7482498add30 -->

The methods for High Activity Stakers to provide their input will be specified in a future iteration of the Atlas, but may for instance include filling out AI generated questionnaires or other easily measurable and easy to complete tasks. The Core Executor Agents must continuously improve these input methods.

##### A.2.4.1.2.4 - Step 3: Stability Capital Retention [Core]  <!-- UUID: 5ece5d43-8d6c-41ab-9b90-b8778f325909 -->

A percentage of the Step 3 Capital equal to the Stability Capital Retention ("SCR") is allocated to funding the Stability Capital Buffer. The remaining percentage becomes Step 4 Capital.

###### A.2.4.1.2.4.1 - Stability Capital Buffer [Core]  <!-- UUID: 9655da22-1940-481f-a8fc-e202ab09b7b8 -->

The Stability Capital Buffer is the surplus of the Sky Protocol that is able to be the final absorber of losses in the case of unsuccessful liquidation of failed Prime Agents. See [A.3.5.1 - Surplus Buffer](9782cdc5-c274-45c2-bf4a-690f22c6a294).

###### A.2.4.1.2.4.2 - Stability Capital Retention [Core]  <!-- UUID: 6bb2c75a-ff51-4846-9d99-c0456b2d8cf8 -->

The Stability Capital Retention (`SCR`) is calculated according to the following formula:

`SCR = (1 - ((SCB / TS) / TSCB)) * RF`.

Where:
◦ SCB = Current Stability Capital Buffer,
◦ TS = Total USDS supply,
◦ TSCB = Target Stability Capital Buffer,
◦ RF = Retention Factor.

This formula dynamically adjusts capital retention based on the current buffer status:
1. When SCB/TS equals TSCB (buffer at target), SCR equals zero.
2. When SCB/TS is below TSCB, SCR increases proportionally to the shortfall.
3. The maximum possible retention is capped by the Retention Factor (RF).

This ensures that capital retention automatically scales with urgency - the further the Stability Capital Buffer falls below its target percentage of total supply, the greater the portion of capital retained.

The parameters for calculating the `SCR` are further defined in the documents herein.

###### A.2.4.1.2.4.2.1 - Current Stability Capital Buffer [Core]  <!-- UUID: 119eb3d9-6b14-42aa-86a6-e1ba2275c912 -->

The Current Stability Capital Buffer (`SCB`) is the current level of the Stability Capital Buffer.

###### A.2.4.1.2.4.2.2 - Total USDS Supply [Core]  <!-- UUID: e95c6308-c620-45af-be27-7bac5ad12889 -->

The total USDS Supply (`TS`) is the total supply of USDS.

###### A.2.4.1.2.4.2.3 - Target Stability Capital Buffer [Core]  <!-- UUID: eda13fef-866d-4b0f-955c-06105ba86d86 -->

The Target Stability Capital Buffer (`TSCB`) is the Target level of the Stability Capital Buffer, expressed as a percentage of the total supply of USDS. It is calculated according to the following formula:

`TCSB = 0.75% + (TS * 1.4e-14)`.

The `TSCB` cannot exceed 5%.

This formula begins with a Target Stability Capital Buffer of 0.75% and gradually increases this as the Total USDS Supply increases, reflecting the fact that a greater capital buffer is required as USDS becomes more systemically important.

For example, with USDS Supply of 8 billion, the Target Stability Capital Buffer would be approximately 0.76%.

###### A.2.4.1.2.4.2.4 - Retention Factor [Core]  <!-- UUID: 14646a34-1c61-4927-98df-a429e7293be2 -->

The Retention Factor is a factor representing how aggressively capital should be retained to fund the Stability Capital Buffer. It is calculated according to the following formula:

`RF = 25% + (TS * 1.6e-13)`.

The `RF` cannot exceed 75%.

The Retention Factor starts at 25% and scales upward with Total USDS Supply, recognizing that capital accumulation becomes more critical as USDS gains in systemic importance.

For example, with USDS Supply of 8 billion, the Retention Factor would be approximately 26%.

##### A.2.4.1.2.5 - Step 4: Smart Burn And Standard Activity Staking Rewards [Core]  <!-- UUID: 99d40e56-7433-4abd-9674-7783627feec0 -->

Any remaining funds in Step 4 Capital are allocated as specified in the documents herein.

###### A.2.4.1.2.5.1 - Smart Burn Buffer [Core]  <!-- UUID: c2a0ca01-ffea-46ee-8077-e46e0510d097 -->

80% of Step 4 Capital is allocated to the Smart Burn Buffer, as specified in the documents herein.

###### A.2.4.1.2.5.1.1 - Purpose [Core]  <!-- UUID: e95b1080-5b70-4941-9025-0269ae2680fb -->

The Smart Burn Engine uses the Smart Burn Buffer to buy and burn SKY using an intelligent algorithm, buying more when the price is low and retaining capital when the price is high to buy later at favorable prices.

###### A.2.4.1.2.5.1.2 - Usage Of Smart Burn Buffer [Core]  <!-- UUID: 7295761a-e72b-4b32-9345-b229b46566d1 -->

The Smart Burn Engine only buys and burns SKY when the Market Capitalization (`MC`) is below the Target Market Capitalization (`TMC`). The percentage of the Smart Burn Buffer (`Burn Rate`) that is used to buy and burn SKY each Monthly Settlement Cycle is calculated according to the following formula:

`Burn Rate = (1 - MC / TMC) * 50%`.

The parameters for calculating the `Burn Rate` are defined in the documents herein.

Conceptually, this formula buys more SKY the further the Market Capitalization is below the Target Market Capitalization.

###### A.2.4.1.2.5.1.2.1 - Target Market Capitalization [Core]  <!-- UUID: 86b0554d-4f34-412f-9519-448e9602aa2e -->

The Target Market Capitalization (`TMC`) is calculated according to the following formula:

`TMC = 8.5 + (200 * growth_rate) * annual_profits`.

The `growth_rate` is the three (3) year moving average historical growth rate of Net Revenue, and `annual_profits` is the one (1) year moving average of Net Revenue.

Conceptually, this formula calculates a target price based on the current earnings of the Sky Protocol and a price to earnings ratio, where the price to earnings ratio is a function of how quickly the Sky Protocol is growing.

###### A.2.4.1.2.5.1.2.1.1 - Continuous Improvement [Core]  <!-- UUID: 194d3ec8-3cb7-48ec-9ab4-5d2cd98c80a7 -->

The Core Executor Agents must continuously improve the Target Market Capitalization formula so that the Smart Burn Engine becomes more efficient over time.

###### A.2.4.1.2.5.1.2.2 - Market Capitalization [Core]  <!-- UUID: 59ea0f2f-5fb6-48fb-87cd-e43d50bc110b -->

The Market Capitalization is the current market capitalization of Sky. It is calculated by multiplying the price of SKY by the total supply of SKY, treating each MKR on an as-converted basis based on the conversion ratio of 24,000 SKY to 1 MKR.

###### A.2.4.1.2.5.2 - Standard Activity Staking Rewards [Core]  <!-- UUID: 67fcd852-0de4-4a16-af84-adce61bf54bd -->

20% of Step 4 Capital is allocated to the Standard Activity Staking Rewards Buffer, as specified in the documents herein.

###### A.2.4.1.2.5.2.1 - Purpose [Core]  <!-- UUID: 46e90503-0b49-4b29-b3e5-93c8fa5907ea -->

Standard Activity Staking Rewards (SASR) provide rewards to users who contribute to security by staking and delegating their SKY votes at least once.

###### A.2.4.1.2.5.2.2 - Payout From Standard Activity Staking Rewards Buffer [Core]  <!-- UUID: e288b944-759e-4d30-8db7-b59de7b5f912 -->

The Standard Activity Staking Reward Distribution occurs linearly over the course of each month. The monthly payout from the Standard Activity Staking Rewards Buffer (SASRB) is equal to the lesser of (1) 20% of Step 4 Capital, or (2) 15% of the SASRB, with a minimum floor of 5% of the SASRB.

In periods of high profitability, funds build up in the Standard Activity Staking Rewards Buffer. Then in periods of low profitability these funds are paid out from the Standard Activity Staking Rewards Buffer, ensuring that there is a continued incentive for involvement in governance even in periods of low profitability to maintain security.

###### A.2.4.1.2.5.2.3 - Standard Activity Staker Qualification [Core]  <!-- UUID: a22d900a-d15c-41f0-af90-eec23112dcb6 -->

SKY that is both staked and delegated to an Aligned Delegate will qualify for Standard Activity Staking Rewards.

#### A.2.4.1.3 - Sourcing Of Internal Senior Risk Capital From Surplus Buffers [Core]  <!-- UUID: ac7a6636-acbc-40c9-abc1-4543c0beb300 -->

Internal Senior Risk Capital (ISRC) consists of a portion of the excess capital of the Sky Protocol that is reinvested in providing Senior Risk Capital to Prime Agents. ISRC is sourced from the various Buffers defined in [A.2.4.1.2 - Allocation Steps](7932c8f3-ce44-49ea-adc4-f6391c621c6e), according to the specifications of the subdocuments below.

##### A.2.4.1.3.1 - USDS in High Activity Staking Rewards Buffer [Core]  <!-- UUID: d161c882-9c51-4acd-8b9c-8e9503cdabb4 -->

All USDS in the High Activity Staking Rewards Buffer is used for Internal Senior Risk Capital.

##### A.2.4.1.3.2 - USDS In Standard Activity Staking Rewards Buffer [Core]  <!-- UUID: 039337f5-1c23-4081-9277-f8a2973fba1d -->

All USDS in the Standard Activity Staking Rewards Buffer is used for Internal Senior Risk Capital.

##### A.2.4.1.3.3 - USDS In Smart Burn Buffer [Core]  <!-- UUID: d023d8e7-9df2-41f4-996f-9465f4fb0cf2 -->

All USDS in the Smart Burn Buffer is used for Internal Senior Risk Capital.

##### A.2.4.1.3.4 - USDS In Stability Capital Buffer Above Target [Core]  <!-- UUID: b601b750-476d-4d3d-a9f8-7bd1c5a9541a -->

All USDS in the Stability Capital Buffer above the Stability Capital Buffer Target is used for Internal Senior Risk Capital. Since this capital is already above the optimal target to absorb risk it can be redirected to a more efficient use.

##### A.2.4.1.3.5 - USDS In Stability Capital Buffer Below Target [Core]  <!-- UUID: 9d13741d-236f-4c34-b437-cf422e3a39f4 -->

One third of the USDS in the Stability Capital Buffer below the Stability Capital Buffer Target is also used for Internal Senior Risk Capital. This ensures that there is always some Internal Senior Risk Capital to drive the growth of the ecosystem.

#### A.2.4.1.4 - Short Term Transitionary Measures [Core]  <!-- UUID: a0186d71-d5f6-4643-a5c5-8fcf6c2625f8 -->

As a short-term transitionary measure, the net revenue of the Sky Protocol is currently allocated through the allocation steps defined above with the modifications specified in the documents herein.

##### A.2.4.1.4.1 - Allocation Of Step 1 Capital [Core]  <!-- UUID: 76eab64d-a5ba-4f3c-a295-bde0e444d0df -->

In the short term, 21% of Step 1 Capital is allocated as specified in the documents herein. The remaining 79% of Step 1 Capital becomes Step 4 Capital and is allocated as specified in [A.2.4.1.4.2 - Allocation Of Step 4 Capital](04bd9df4-275e-4520-83a6-d634aa605fe3).

###### A.2.4.1.4.1.1 - Allocation To Core Council Buffer [Core]  <!-- UUID: c46c7059-4ec1-4966-8382-d9e2e851d616 -->

20% of Step 1 Capital is allocated to the Core Council Buffer, as specified in the documents herein.

###### A.2.4.1.4.1.1.1 - Core Council Buffer [Core]  <!-- UUID: 8b6781d7-f35c-4ffe-b8ed-299fa98e3da7 -->

The Core Council Buffer is a multisig used to transfer funds on behalf of the Core Council.

###### A.2.4.1.4.1.1.1.1 - Core Council Buffer Multisig Address [Core]  <!-- UUID: af082bd0-fdcd-4ec1-980a-7fce50e77ed1 -->

The address of the Core Council Buffer Multisig on the Ethereum Mainnet is `0x210CFcF53d1f9648C1c4dcaEE677f0Cb06914364`.

###### A.2.4.1.4.1.1.1.2 - Core Council Buffer Multisig Required Number Of Signers [Core]  <!-- UUID: 7f9cc28d-75af-4fe0-b090-8c85cda9656a -->

The Core Council Buffer Multisig has a 4/6 signing requirement.

###### A.2.4.1.4.1.1.1.3 - Core Council Buffer Multisig Signers [Core]  <!-- UUID: 5aeba17d-3869-447d-adcd-8c55f41afc01 -->

The signers of the Core Council Buffer Multisig are two (2) addresses controlled by the Core Facilitator, two (2) addresses controlled by Core GovOps, one (1) address controlled by Operational GovOps Amatsu, and one (1) address controlled by Operational GovOps Soter Labs.

###### A.2.4.1.4.1.1.1.4 - Core Council Buffer Multisig Usage Standards [Core]  <!-- UUID: dc6474f6-d285-4e1e-9902-406def4b72be -->

The signers must use the Core Council Buffer Multisig to disburse funds on behalf of the Core Council.

###### A.2.4.1.4.1.1.1.5 - Core Council Buffer Multisig Modification [Core]  <!-- UUID: a56fe3ee-c11a-4df0-9cc3-677688c5563d -->

The signers can change the signers of the Core Council Buffer Multisig so long as:

- there are exactly six (6) signers;

- a majority of signers are required to execute transactions; and

- two (2) signers are controlled by the Core Facilitator, two (2) signers are controlled by Core GovOps, one (1) signer is controlled by Operational GovOps Amatsu, and one (1) signer is controlled by Operational GovOps Soter Labs.

###### A.2.4.1.4.1.1.1.6 - Consolidation Of Funds Into Core Council Buffer [Core]  <!-- UUID: d283c5a0-3f66-4aaf-ac31-dbe0ae41b846 -->

All funds in Legacy Accounts (see [A.2.4.1.4.1.1.1.6.1 - Legacy Accounts](555f0942-4fe1-49a0-b295-9bb72580f6bb)) must be consolidated into the Core Council Buffer as specified in the documents herein.

###### A.2.4.1.4.1.1.1.6.1 - Legacy Accounts [Core]  <!-- UUID: 555f0942-4fe1-49a0-b295-9bb72580f6bb -->

Legacy Accounts are all accounts controlled by Sky Core, with the exception of the Core Council Buffer and Aligned Delegates Buffer (see [A.2.4.1.4.1.2 - Allocation To Aligned Delegates Buffer](2a9bcfb1-4dad-4baf-a09a-e9264b3d17bb)). This includes, without limitation:

- the Distribution Reward Controller Wallet (see [A.2.3.8.1.2.1.4.3.1 - Near-Term Process](05fb732b-de55-4886-81a7-7c5d4c13d2d2));

- the Integration Boost Wallets (see [A.2.3.8.2.2.1.3.2.1 - Near Term Process](4ab621b4-ef8e-4b01-a6aa-9296601033c5)); and

- the Sky Ecosystem Liquidity Bootstrapping Budget (see [A.5.5.1.1 - Sky Ecosystem Liquidity Bootstrapping](cd4ae79c-0e34-4388-8ac2-41d7677bd955)).

###### A.2.4.1.4.1.1.1.6.2 - Ecosystem Actors Must Consolidate All Funds From Legacy Accounts Into Core Council Buffer [Core]  <!-- UUID: 19ceb562-691d-4593-b294-09ca8698648d -->

Relevant Ecosystem Actors must take all necessary actions to transfer all funds from Legacy Accounts into the Core Council Buffer.

###### A.2.4.1.4.1.1.1.6.3 - Core Council Buffer Replaces Legacy Accounts [Core]  <!-- UUID: 6341523f-cdff-410b-98d2-4a31ba871eaf -->

All funds that would otherwise be transferred into or out of Legacy Accounts must instead be transferred into or out of the Core Council Buffer.

###### A.2.4.1.4.1.1.1.6.4 - Follow-Up Actions [Core]  <!-- UUID: bb82058f-ad10-464c-b009-fb2dfa772263 -->

Core GovOps must propose a subsequent Atlas Edit Proposal removing all references to Legacy Accounts from the Atlas and replacing them with the Core Council Buffer.

###### A.2.4.1.4.1.2 - Allocation To Aligned Delegates Buffer [Core]  <!-- UUID: 2a9bcfb1-4dad-4baf-a09a-e9264b3d17bb -->

1% of Step 1 Capital is allocated to the Aligned Delegates Buffer, as specified in the documents herein.

###### A.2.4.1.4.1.2.1 - Aligned Delegates Buffer [Core]  <!-- UUID: 05fa5c41-26ca-4c25-94dd-834ef72c318a -->

The Aligned Delegates Buffer is a multisig controlled by the Core Facilitator and Core GovOps to transfer funds to Aligned Delegates.

###### A.2.4.1.4.1.2.1.1 - Aligned Delegates Buffer Multisig Address [Core]  <!-- UUID: 744ffdce-188e-403a-a0f4-532a27879cf5 -->

The address of the Aligned Delegates Buffer Multisig on the Ethereum Mainnet is `0x37FC5d447c8c54326C62b697f674c93eaD2A93A3`.

###### A.2.4.1.4.1.2.1.2 - Aligned Delegates Buffer Multisig Required Number Of Signers [Core]  <!-- UUID: b3672c98-07ca-488f-8a26-461bf8d14aae -->

The Aligned Delegates Buffer Multisig has a 3/4 signing requirement.

###### A.2.4.1.4.1.2.1.3 - Aligned Delegates Buffer Multisig Signers [Core]  <!-- UUID: f0652394-ec87-4b08-abed-e15fd0799ab1 -->

The signers of the Aligned Delegates Buffer Multisig are two (2) addresses controlled by the Core Facilitator and two (2) addresses controlled by Core GovOps.

###### A.2.4.1.4.1.2.1.4 - Aligned Delegates Buffer Multisig Usage Standards [Core]  <!-- UUID: 3ce8a599-f70b-4dad-9d71-a69d812c4ea8 -->

The Core Facilitator and Core GovOps must use the Aligned Delegates Buffer Multisig to disburse funds to Aligned Delegates.

###### A.2.4.1.4.1.2.1.5 - Aligned Delegates Buffer Multisig Modification [Core]  <!-- UUID: b8b38333-2763-47e1-9e34-0b37c750201a -->

The Core Facilitator and Core GovOps can change the signers of the Aligned Delegates Buffer Multisig so long as:

- there are at least four (4) signers;

- a majority of signers are required to execute transactions; and

- an equal number of signers are controlled by the Core Facilitator and Core GovOps.

##### A.2.4.1.4.2 - Allocation Of Step 4 Capital [Core]  <!-- UUID: 04bd9df4-275e-4520-83a6-d634aa605fe3 -->

In the short term, Step 4 Capital is allocated as specified in the documents herein.

###### A.2.4.1.4.2.1 - Allocation To SKY Buybacks [Core]  <!-- UUID: b9f2fd14-bc43-4bdd-94aa-2a5defefa97d -->

300,000 USDS per day of Step 4 Capital is allocated to SKY buybacks.

###### A.2.4.1.4.2.2 - Allocation To Surplus Buffer [Core]  <!-- UUID: e2eae80f-ca25-4fab-880a-3a55ca1aa16d -->

Any remaining Step 4 Capital is allocated to the Surplus Buffer.

##### A.2.4.1.4.3 - Implementation [Core]  <!-- UUID: b0a59548-b94e-4cdf-961c-7e2d5dbe5983 -->

The allocations specified in [A.2.4.1.4.1 - Allocation Of Step 1 Capital](76eab64d-a5ba-4f3c-a295-bde0e444d0df) are effective retroactive to September 1, 2025. The next available Executive Vote must include these allocations for the period from September 1, 2025 to September 30, 2025. The amounts to be transferred are 3,876,387 USDS to the Core Council Buffer and 193,820 USDS to the Aligned Delegates Buffer.

## A.2.5 - Sky Core Monthly Settlement Cycle [Article]  <!-- UUID: 6f8d5065-d6ff-4add-9a28-eadeffa7ed1a -->

This Article governs the Sky Core Monthly Settlement Cycle (MSC), a recurring process that synchronizes core financial operations, governance functions, and risk management activities across the ecosystem.

### A.2.5.1 - Monthly Settlement Cycle Overview [Section]  <!-- UUID: e0d89c66-5bab-402e-82a2-6270f1bcac07 -->

The documents herein define the Monthly Settlement Cycle (MSC), a standardized, system-wide process executed at the end of each calendar month.

#### A.2.5.1.1 - Operational Processes [Core]  <!-- UUID: 7f43aea7-9b81-48ef-b3ce-fdfae7e8a551 -->

The Monthly Settlement Cycle (MSC) synchronizes several key operational processes across the ecosystem, including:
    
1. Sky Protocol’s net revenue from the previous month is calculated and allocated through the steps of the Treasury Management Function. See [A.2.4 - Treasury Management](6c0af059-5d33-4e2b-90f1-1606957b8f85). 
   
2. The monthly Senior Risk Capital (SRC) origination process is settled: the clearing price is established, costs are deducted from winning Prime Agents’ accounts, and their accounts are credited with Originated SRC (OSRC) for the upcoming month. See [A.3.2.2.4.3.5 - Settlement Of Origination](fff0112a-58dd-4041-97f9-7baf113b4e70). 
    
3. Queued conversions between USDS and srUSDS within the SRC system are processed. See [A.3.2.2.4.2.2 - Deposit And Redemption Queues](38a99586-4a13-4ce3-8b2f-cee025e0c390). 
    
4. Pioneer Incentive Pools are funded with an amount equivalent to the Sky Savings Rate multiplied by the balance of Unrewarded USDS. See [A.2.3.8.3 - Pioneer Chain Primitive](4c7be4c6-44b5-407a-94ae-3d7ca7e8039c). 
    
5. The Smart Burn Buffer's burning operation occurs synchronously with each Monthly Settlement Cycle. At each cycle, the system calculates the appropriate Burn Rate based on current market conditions and executes the burn operation, if applicable, according to the formula specified in the Atlas. See [A.2.4.1.2.5.1.2 - Usage Of Smart Burn Buffer](7295761a-e72b-4b32-9345-b229b46566d1). 
    
6. Critical Core GovOps functions related to the operationalization of Sky Primitives are executed, including payment/reimbursement processing, compliance monitoring, and the calculation and application of retroactive penalties.

#### A.2.5.1.2 - Implementation [Core]  <!-- UUID: 75473c4b-69ba-4e6b-bbf6-2c926732364c -->

The documents herein define the initial implementation of the Monthly Settlement Cycle. This initial implementation of the Monthly Settlement Cycle does not include the Senior Risk Capital System, which is still being developed, and funds continue to be allocated through the modified Treasury Management Function. See [A.2.4.1.4 - Short Term Transitionary Measures](a0186d71-d5f6-4643-a5c5-8fcf6c2625f8).

##### A.2.5.1.2.1 - Process Definition [Core]  <!-- UUID: dd25aba4-7b77-469e-beb2-feaaedbbf143 -->

The documents herein define the initial process for performing the Monthly Settlement Cycle. The calculations to be performed as part of the Monthly Settlement Cycle are defined in [A.2.5.1.2.2 - Implementation Stages](cf1d76c1-fc9f-499d-866f-265276e421f0). This process definition specifies who performs the calculations and how funds are ultimately paid out.

###### A.2.5.1.2.1.1 - Forum Post By Core GovOps [Core]  <!-- UUID: 5122086f-a067-4898-bcd2-bfba4ca3d795 -->

By the end of each month, Core GovOps creates a post on the Sky Forum to organize all communications regarding the Monthly Settlement Cycle for that month (the "Monthly Settlement Cycle Post"). The post must be made under the "Sky Core" category using the `monthly-settlement-cycle` tag.

###### A.2.5.1.2.1.2 - Calculations By Operational Executor Agents And Core Council Risk Advisor [Core]  <!-- UUID: e9f6226e-656c-4290-a329-d745f45323ba -->

Within seven (7) calendar days of the end of each month, each Operational Executor Agent and the Core Council Risk Advisor replies to the Monthly Settlement Cycle Post with their calculation of the net amounts due to or from Prime Agents as specified in the documents herein.

###### A.2.5.1.2.1.2.1 - Initial Calculation By Operational Executor Agent [Core]  <!-- UUID: 7f209f46-72c6-42f7-a7ad-898190ff4e6f -->

Within seven (7) calendar days of the end of each month, each Operational Executor Agent replies to the Monthly Settlement Cycle Post with a calculation of the net amounts due to or from the Prime Agents that it has an Executor Accord with (the "Initial Calculation"). The Initial Calculation must contain reasonable supporting detail. The required contents of the Initial Calculation will be further specified in a future iteration of the Atlas.

###### A.2.5.1.2.1.2.1.1 - Demand Side Stablecoin Primitive Recipients [Core]  <!-- UUID: f62602a6-1c1a-44d4-9c9f-a903ce433330 -->

For each Prime Agent, the Initial Calculation must specify whether payments with respect to Demand Side Stablecoin Primitives (see [A.2.3.8 - Demand Side Stablecoin Primitives](26415305-432d-423b-9553-3f325279712d)) have already been made by the Operational Executor Agent, and thus should be reimbursed to the Operational Executor Agent instead of being paid to the Prime Agent.

###### A.2.5.1.2.1.2.2 - Independent Calculation By Core Council Risk Advisor On Behalf Of Core Council [Core]  <!-- UUID: 8be8ae66-2453-4d7d-8880-ffaba36bdb7e -->

Within seven (7) calendar days of the end of each month, the Core Council Risk Advisor replies to the Monthly Settlement Cycle Post with their own independent calculation of the net amounts due to or from each Prime Agent (the "Independent Calculation"). The Independent Calculation must contain reasonable supporting detail. The required contents of the Independent Calculation will be further specified in a future iteration of the Atlas.

###### A.2.5.1.2.1.3 - Final Calculation By Core GovOps [Core]  <!-- UUID: 9de89bf3-9051-44f1-9ec0-d362ee4d4b38 -->

Within twelve (12) calendar days of the end of each month, Core GovOps replies to the Monthly Settlement Cycle Post with the final calculation of the net amounts due to or from each Prime Agent (the "Final Calculation"). If there are any Disputed Amounts (see [A.2.5.1.2.1.3.2 - Disputed Amount](4ddda7cd-9942-4f60-9555-6b3f16770334)), then Core GovOps must resolve them. Core GovOps must work with the relevant Operational Executor Agent, relevant Prime Agents, and the Core Council Risk Advisor to reach a mutually acceptable resolution and may consult other parties to the extent it deems advisable.

Core GovOps makes the final decision in resolving differences between the Initial Calculation and the Independent Calculation. The Final Calculation must specify the Final Amount and contain reasonable supporting detail. The required contents of the Final Calculation will be further specified in a future iteration of the Atlas.

###### A.2.5.1.2.1.3.1 - Agreed Amount [Core]  <!-- UUID: 8669ef42-d55b-4be8-839e-646b4ff17e4c -->

The net amount due to or from a Prime Agent in an Initial Calculation is an Agreed Amount if the absolute value of the percentage difference between the amounts in the Initial Calculation and the Independent Calculation is less than or equal to the Allowed Deviation (see [A.2.5.1.2.1.3.3 - Allowed Deviation](2e471685-fec5-4306-8747-a50dbbdd5c70)). The net amount due to or from a Prime Agent in an Independent Calculation is also an Agreed Amount if there is no Initial Calculation.

###### A.2.5.1.2.1.3.2 - Disputed Amount [Core]  <!-- UUID: 4ddda7cd-9942-4f60-9555-6b3f16770334 -->

The net amount due to or from a Prime Agent in an Initial Calculation is a Disputed Amount if it is not an Agreed Amount.

###### A.2.5.1.2.1.3.3 - Allowed Deviation [Core]  <!-- UUID: 2e471685-fec5-4306-8747-a50dbbdd5c70 -->

The Allowed Deviation is the maximum allowed deviation, on a percentage basis, between the net amount due to or from a Prime Agent in the Initial Calculation and Independent Calculation before resolution of these differences is required. It recognizes that if the Initial Calculation and Independent Calculation are truly developed independently then differences in methodology are likely to result in small deviations.

###### A.2.5.1.2.1.3.3.1 - Allowed Deviation Current Value [Core]  <!-- UUID: 0d2f4cb2-815a-4b0c-9bca-3a0d2635effc -->

The current value of the Allowed Deviation is 1%.

###### A.2.5.1.2.1.3.4 - Final Amount [Core]  <!-- UUID: c20c38fe-c952-4e75-86fe-d6b561f7f436 -->

The net amount due to or from a Prime Agent in a Final Calculation is a Final Amount.

###### A.2.5.1.2.1.3.5 - Disputes By Prime Agents [Core]  <!-- UUID: c204b363-7cc0-4e40-a7dc-68de57358cf9 -->

A Prime Agent may dispute the calculation of the net amount due to or from it (a "Dispute Notice"). The Dispute Notice must be posted as a reply to the Monthly Settlement Cycle Post within five (5) calendar days of the posting of the Initial Calculation or Independent Calculation being disputed. The Dispute Notice must specify the errors in the Initial Calculation or Independent Calculation and the Prime’s own calculation of the net amount due to or from it. The required contents of the Dispute Notice will be further specified in a future iteration of the Atlas.

Core GovOps may at its discretion resolve the differences between the calculations using the process specified in [A.2.5.1.2.1.3 - Final Calculation By Core GovOps](9de89bf3-9051-44f1-9ec0-d362ee4d4b38). Alternatively, Core GovOps may elect to determine the correct amount and true up any differences in the next Monthly Settlement Cycle as specified in [A.2.5.1.2.1.5 - True Up In Subsequent Monthly Settlement Cycle](de1592f5-dbce-46de-913f-6ec9589d36e8). In either case Core GovOps must post its decision as a reply to the Dispute Notice.

###### A.2.5.1.2.1.4 - Settlement Through Sky Core Executive Vote [Core]  <!-- UUID: 0d561ea6-8689-459c-85eb-7c861553e116 -->

When Core GovOps has posted the Final Calculation then the Core Facilitator must include payments of these amounts in the next Sky Core Executive Vote as specified herein.

###### A.2.5.1.2.1.4.1 - Payment Of Amounts Due To Prime Agents [Core]  <!-- UUID: 1816e5eb-3cf1-427f-b831-8eeb9408887c -->

Amounts due to Prime Agents, excluding reimbursements made to Operational Executor Agents (see [A.2.5.1.2.1.4.3 - Reimbursement Of Payments Made By Operational Executor Agents](07c5cfd2-d68a-40d6-873d-b82cea9a92be)), are transferred from the Sky Surplus Buffer to the Prime SubProxy Account through an Executive Vote.

###### A.2.5.1.2.1.4.2 - Collection Of Amounts Due From Prime Agents [Core]  <!-- UUID: 6e3d5198-fdb5-47dd-b632-4c71a313a1a6 -->

Amounts due from Prime Agents, excluding reimbursements made to Operational Executor Agents (see [A.2.5.1.2.1.4.3 - Reimbursement Of Payments Made By Operational Executor Agents](07c5cfd2-d68a-40d6-873d-b82cea9a92be)) are settled in a way that is equivalent to a transfer from the Prime to the Sky Surplus Buffer through actions included in an Executive Vote.

###### A.2.5.1.2.1.4.3 - Reimbursement Of Payments Made By Operational Executor Agents [Core]  <!-- UUID: 07c5cfd2-d68a-40d6-873d-b82cea9a92be -->

Reimbursements of payments already made by the Operational Executor Agent with respect to Demand Side Stablecoin Primitives (see [A.2.3.8 - Demand Side Stablecoin Primitives](26415305-432d-423b-9553-3f325279712d)) are transferred to the Operational Executor Agent’s Buffer through an Executive Vote.

###### A.2.5.1.2.1.4.3.1 - Reimbursement To Distribution Reward Wallet And Integration Boost Wallets [Core]  <!-- UUID: 1eeb6c15-d112-438c-9269-4c4cbc823df1 -->

On an interim basis, Distribution Reward reimbursements may also be made to the Distribution Reward Controller Wallet (see [A.2.3.8.1.2.1.4.3.1 - Near-Term Process](05fb732b-de55-4886-81a7-7c5d4c13d2d2)) at the request of an Operational Executor Agent. Similarly, Integration Boost reimbursements may also be made to the Integration Boost Wallet (see [A.2.3.8.2.2.1.3.2.1 - Near Term Process](4ab621b4-ef8e-4b01-a6aa-9296601033c5)) at the request of an Operational Executor Agent.

###### A.2.5.1.2.1.5 - True Up In Subsequent Monthly Settlement Cycle [Core]  <!-- UUID: de1592f5-dbce-46de-913f-6ec9589d36e8 -->

If the amounts of any payments included in the Sky Core Executive Vote (see [A.2.5.1.2.1.4 - Settlement Through Sky Core Executive Vote](0d561ea6-8689-459c-85eb-7c861553e116)) are subsequently determined to be incorrect, adjustments are included in the next Monthly Settlement Cycle to ensure that each party pays the amount it owes or receives the amount to which it is entitled.

Core GovOps must prepare a statement specifying the errors, the correct amounts, and the adjustments needed (the "Correction Calculation"). The Correction Calculation must be posted to the Sky Forum under the "Sky Core" category with the `monthly-settlement-cycle` tag. The required contents of the Correction Calculation will be further specified in a future iteration of the Atlas.

###### A.2.5.1.2.1.6 - Interim Measures [Core]  <!-- UUID: f2401c5e-0fea-4a50-ab0b-3e03fc413dbb -->

The documents herein define interim exceptions to the process definition for the Monthly Settlement Cycle.

###### A.2.5.1.2.1.6.1 - Scope Of July / August 2025 Monthly Settlement Cycle [Core]  <!-- UUID: bfc3548d-5ad1-4327-a54a-ddd4549c5fdc -->

The initial Monthly Settlement Cycle conducted in September 2025 will be for the two month period from July 1, 2025 to August 31, 2025.

###### A.2.5.1.2.1.6.2 - Process For July / August 2025 Monthly Settlement Cycle [Core]  <!-- UUID: 146d3d9c-7f8a-4dc4-b6b3-349bab4279bb -->

For the initial Monthly Settlement Cycle conducted in September 2025, the Initial Calculation prepared by Operational Executor Agent Amatsu will only include calculations related to Demand Side Stablecoin Primitives (see [A.2.3.8 - Demand Side Stablecoin Primitives](26415305-432d-423b-9553-3f325279712d)). The Independent Calculation prepared by the Core Council Risk Advisor on behalf of the Core Council will be prepared normally. The calculations related to Demand Side Stablecoin Primitives will be subject to the normal resolution process defined in [A.2.5.1.2.1.3 - Final Calculation By Core GovOps](9de89bf3-9051-44f1-9ec0-d362ee4d4b38). For all other calculations, the amounts in the Independent Calculation will be treated as Agreed Amounts. The Initial Calculation and the Independent Calculation will be posted to the Sky Forum by September 10, 2025.

###### A.2.5.1.2.1.6.3 - Process For September 2025 Monthly Settlement Cycle [Core]  <!-- UUID: 8e8ff62f-c6c5-4094-afd1-2cedcf482df6 -->

For the Monthly Settlement Cycle conducted in October 2025, the Initial Calculation prepared by Operational Executor Agent Amatsu will only include calculations related to Spark. The Independent Calculation prepared by the Core Council Risk Advisor on behalf of the Core Council will be prepared normally. The calculations related to Spark will be subject to the normal resolution process defined in [A.2.5.1.2.1.3 - Final Calculation By Core GovOps](9de89bf3-9051-44f1-9ec0-d362ee4d4b38). For all other calculations, the amounts in the Independent Calculation will be treated as Agreed Amounts.

###### A.2.5.1.2.1.6.4 - Process For November / December 2025 Monthly Settlement Cycle [Core]  <!-- UUID: 5aa66a15-d59c-4f66-9d80-96583698f24d -->

There will be no Monthly Settlement Cycle conducted in December 2025. Instead, the Monthly Settlement Cycle conducted in January 2026 will be for the two-month period from November 1, 2025 to December 31, 2025.

For the Monthly Settlement Cycle conducted in January 2026, the Independent Calculation prepared by the Core Council Risk Advisor on behalf of the Core Council will only include calculations related to Spark. The Initial Calculation prepared by Operational Executor Agent Amatsu will be prepared normally. The calculations related to Spark will be subject to the normal resolution process defined in [A.2.5.1.2.1.3 - Final Calculation By Core GovOps](9de89bf3-9051-44f1-9ec0-d362ee4d4b38). For all other calculations, the amounts in the Initial Calculation will be treated as Agreed Amounts.

##### A.2.5.1.2.2 - Implementation Stages [Core]  <!-- UUID: cf1d76c1-fc9f-499d-866f-265276e421f0 -->

The initial implementation of the Monthly Settlement Cycle will occur in three stages as specified in the documents herein.

###### A.2.5.1.2.2.1 - Stage 1 [Core]  <!-- UUID: efb30fa0-99b1-43bd-bdfd-219cf897c44f -->

The documents herein define Stage 1 of the implementation of the Monthly Settlement Cycle.

###### A.2.5.1.2.2.1.1 - Stage 1 Simplified Profit And Loss Calculation [Core]  <!-- UUID: 65bd404f-0fd4-4ae9-9860-2c6e37731fef -->

In Stage 1 of the implementation of the Monthly Settlement Cycle, the net amount due from each Prime to Sky will be calculated using a Simplified Profit And Loss Calculation as specified in the documents herein.

###### A.2.5.1.2.2.1.1.1 - Amount Due From Sky To Primes With Respect To Demand Side Primitives And Agent Rate [Core]  <!-- UUID: 33d1b516-d347-4d44-9af6-95f25e8a8d8c -->

The amount due from Sky to each Prime with respect to Demand Side Primitives and the Agent Rate is calculated as specified in the documents herein.

###### A.2.5.1.2.2.1.1.1.1 - Amount Due From Sky To Primes With Respect To Distribution Reward [Core]  <!-- UUID: 0b2165cb-c10d-474b-ad55-544821ac29c3 -->

The amount due from Sky to a Prime in a month with respect to the Distribution Reward is the amount earned by the Prime with respect to all USDS and sUSDS balances marked with the Prime’s reward codes. See [A.2.3.8.1 - Distribution Reward Primitive](e632c38f-3e4e-4c7e-acfd-b6ec45a422e6). This includes any Bonus Distribution Reward. See [A.2.9.2.2.2.3.2 - 2025 Bonus](7ca440d3-03fb-4fba-81a8-d2118dc47aa6).

###### A.2.5.1.2.2.1.1.1.2 - Amount Due From Sky To Primes With Respect To Agent Rate [Core]  <!-- UUID: aeb1d633-d6e2-46ef-9f55-bcb0a16a2e63 -->

The amount due from Sky to a Prime in a month with respect to the Agent Rate is calculated as specified in [A.3.1.2.3 - Agent Rate](012c953b-c522-4ea3-939b-3282af4e1d7e).

###### A.2.5.1.2.2.1.1.1.3 - Amount Due From Sky To Primes With Respect To Distribution Reward And Agent Rate [Core]  <!-- UUID: cef16014-05db-4b21-a5a2-20e62aaca027 -->

The amount due from Sky to a Prime in a month with respect to the Distribution Reward and the Agent Rate is the sum of the amounts specified in [A.2.5.1.2.2.1.1.1.1 - Amount Due From Sky To Primes With Respect To Distribution Reward](0b2165cb-c10d-474b-ad55-544821ac29c3) and [A.2.5.1.2.2.1.1.1.2 - Amount Due From Sky To Primes With Respect To Agent Rate](aeb1d633-d6e2-46ef-9f55-bcb0a16a2e63).

###### A.2.5.1.2.2.1.1.2 - Amount Due From Prime To Sky With Respect To Supply Side Primitives [Core]  <!-- UUID: e98ddd17-a8c3-4523-8464-cc41247c66e8 -->

The amount due from each Prime to Sky with respect to Supply Side Primitives is calculated as specified in the documents herein.

###### A.2.5.1.2.2.1.1.2.1 - Step 1: Calculate Total Allocation System Revenue [Core]  <!-- UUID: fd3ea856-dbef-4fe0-a662-82a58d33d9c0 -->

First, Total Allocation System Revenue is calculated for each Prime for the month. Total Allocation System Revenue for a Prime in a month is the sum of Instance Revenue for each Active Instance of the Allocation System Primitive that the Prime has deployed.

###### A.2.5.1.2.2.1.1.2.1.1 - Instance Revenue [Core]  <!-- UUID: 90acccd5-d7b4-4c03-9ce2-471dc3e82c98 -->

Instance Revenue for an Allocation System Instance for a month is all earnings from that Instance.

###### A.2.5.1.2.2.1.1.2.2 - Step 2: Calculate Total Allocation System Profit [Core]  <!-- UUID: 1eaa2350-e354-4000-baa6-be250853bddc -->

Second, Total Allocation System Profit is calculated for each Prime for the month. Total Allocation System Profit for a Prime in a month is the sum of Instance Profit for each Active Instance of the Allocation System Primitive that the Prime has deployed.

###### A.2.5.1.2.2.1.1.2.2.1 - Instance Profit [Core]  <!-- UUID: 9974c452-216b-45c0-8a1d-621816b8da2a -->

Instance Profit for an Allocation System Instance is equal to the greater of (1) Instance Revenue (see [A.2.5.1.2.2.1.1.2.1.1 - Instance Revenue](90acccd5-d7b4-4c03-9ce2-471dc3e82c98)) minus Instance Expenses (see [A.2.5.1.2.2.1.1.2.2.1.1 - Instance Expense](6cbe7181-419f-4a7b-a659-85972d5100a3)) and (2) zero.

###### A.2.5.1.2.2.1.1.2.2.1.1 - Instance Expense [Core]  <!-- UUID: 6cbe7181-419f-4a7b-a659-85972d5100a3 -->

Instance Expense for an Allocation System Instance for a month is the interest expense on the funds from Sky’s Collateral Portfolio invested in the Instance. It is calculated on a per block basis based on the amount invested from Sky’s Collateral Portfolio and the Agent Credit Line Borrow Rate.

###### A.2.5.1.2.2.1.1.2.3 - Step 3: Calculate Adjusted Allocation System Profit [Core]  <!-- UUID: a9427e1a-77ae-473b-aafd-b4216fcd615c -->

Third, Adjusted Allocation System Profit is calculated for each Prime for the month. Adjusted Allocation System Profit for a Prime in a month is Total Allocation System Profit minus the Distortion Penalty (see [A.2.5.1.2.2.1.1.2.3.1 - Distortion Penalty](2a021208-c964-440f-b491-3c9e034f2d22)) and the Low Yield Actively Stabilizing Collateral Penalty (see [A.2.5.1.2.2.1.1.2.3.2 - Low Yield Actively Stabilizing Collateral Penalty](631e7c75-375f-4298-9d85-b17cb2eb019f)).

###### A.2.5.1.2.2.1.1.2.3.1 - Distortion Penalty [Core]  <!-- UUID: 2a021208-c964-440f-b491-3c9e034f2d22 -->

The Distortion Penalty is a discretionary penalty designed to mitigate the potential misalignment caused by the asymmetric nature of the Simplified Profit And Loss Calculation, where Primes earn profits on Allocation System Instances that earn more than the Agent Credit Line Borrow Rate but do not suffer losses when Instances earn less than the Agent Credit Line Borrow Rate.

The Core Executor Agents, in consultation with the Core Council Risk Advisor, may assess a penalty of up to 100% of Total Allocation System Profit (see [A.2.5.1.2.2.1.1.2.2 - Step 2: Calculate Total Allocation System Profit](1eaa2350-e354-4000-baa6-be250853bddc)) if it determines that a Prime’s decisions were distorted by this incentive structure.

###### A.2.5.1.2.2.1.1.2.3.2 - Low Yield Actively Stabilizing Collateral Penalty [Core]  <!-- UUID: 631e7c75-375f-4298-9d85-b17cb2eb019f -->

The Low Yield Actively Stabilizing Collateral Penalty is a formulaic penalty designed to prevent Primes from holding excessive amounts of low yield Actively Stabilizing Collateral.

The penalty, as a percentage of the Total Allocation System Profit, is the lesser of (1) ten times the Excess Low Yield Actively Stabilizing Collateral Percentage and (2) 100%.

###### A.2.5.1.2.2.1.1.2.3.2.1 - Excess Low Yield Actively Stabilizing Collateral Percentage [Core]  <!-- UUID: 5e78fb21-1208-442f-b215-3babcd69fd69 -->

The Excess Low Yield Actively Stabilizing Collateral Percentage for a Prime is equal to the excess of (1) its Low Yield Actively Stabilizing Collateral (see [A.2.5.1.2.2.1.1.2.3.2 - Low Yield Actively Stabilizing Collateral Penalty](631e7c75-375f-4298-9d85-b17cb2eb019f)) as a percentage of its Collateral Portfolio above (2) its Minimum Actively Stabilizing Collateral (see [A.3.3.2.2 - Minimum Actively Stabilizing Collateral](475fe222-9e4a-4e9d-9be6-a7a424ce02f8)) as a percentage of its Collateral Portfolio.

###### A.2.5.1.2.2.1.1.2.3.2.1.1 - Low Yield Actively Stabilizing Collateral [Core]  <!-- UUID: 858b2ee0-89b8-4505-8324-f3cd315de40c -->

Low Yield Actively Stabilizing Collateral is Actively Stabilizing Collateral (see [A.3.3.2.2.1.1 - Resting Actively Stabilizing Collateral](0e17b35a-c830-4695-b63c-5ef58b249d3f)) that earns less than the Agent Credit Line Borrow Rate.

###### A.2.5.1.2.2.1.1.2.4 - Step 4: Calculate Amount Due To Sky With Respect To Supply Side Primitives [Core]  <!-- UUID: 2617edae-6c22-4d7c-8e14-353bfced35f2 -->

Fourth, the amount due to Sky with respect to Supply Side Primitives is calculated for each Prime for the month. The amount due to Sky with respect to Supply Side Primitives is Total Allocation System Revenue (see [A.2.5.1.2.2.1.1.2.1 - Step 1: Calculate Total Allocation System Revenue](fd3ea856-dbef-4fe0-a662-82a58d33d9c0)) minus Adjusted Allocation System Profit (see [A.2.5.1.2.2.1.1.2.3 - Step 3: Calculate Adjusted Allocation System Profit](a9427e1a-77ae-473b-aafd-b4216fcd615c)).

###### A.2.5.1.2.2.1.1.3 - Settlement [Core]  <!-- UUID: 6dcd7515-3398-443a-9377-99e0c3cd0174 -->

The amounts due from Sky to each Prime with respect to Demand Side Primitives and the Agent Rate (see [A.2.5.1.2.2.1.1.1 - Amount Due From Sky To Primes With Respect To Demand Side Primitives And Agent Rate](33d1b516-d347-4d44-9af6-95f25e8a8d8c)) and the amounts due from each Prime to Sky with respect to Supply Side Primitives (see [A.2.5.1.2.2.1.1.2 - Amount Due From Prime To Sky With Respect To Supply Side Primitives](e98ddd17-a8c3-4523-8464-cc41247c66e8)) are settled as specified in [A.2.5.1.2.1.4 - Settlement Through Sky Core Executive Vote](0d561ea6-8689-459c-85eb-7c861553e116).

###### A.2.5.1.2.2.1.1.4 - Exceptions [Core]  <!-- UUID: db06608a-303d-4b35-864a-f7aad38fcb06 -->

The documents herein define exceptions to the Simplified Profit And Loss Calculation for specific assets held by certain Prime Agents.

###### A.2.5.1.2.2.1.1.4.1 - USDT Held By Spark [Core]  <!-- UUID: 34893b77-2cce-4753-9ce4-2b8ab1f951bb -->

Spark pays the Agent Credit Line Borrow Rate with respect to funds borrowed by Spark to invest in USDT and held in SparkLend. Spark thus realizes the full profit and loss associated with these investments.

###### A.2.5.1.2.2.1.1.4.2 - pyUSD Held By Spark [Core]  <!-- UUID: 8619f00f-84e2-4951-86c4-08876d8a6f6a -->

Spark pays the Agent Credit Line Borrow Rate with respect to funds borrowed by Spark to invest in pyUSD and held in SparkLend or Spark’s ALM Proxy. Spark thus realizes the full profit and loss associated with these investments.

###### A.2.5.1.2.2.1.2 - Stage 1 Timing [Core]  <!-- UUID: ff3aa296-34eb-4783-904f-4510fa0c6c37 -->

Stage 1 is currently expected to be implemented in the August 21, 2025 Executive Vote for the period from July 1, 2025 to July 31, 2025.

###### A.2.5.1.2.2.1.3 - Stage 1 Actions [Core]  <!-- UUID: f87c520a-3324-46a7-ac4e-9c7de2a2af0a -->

The actions specified herein must be completed to achieve Stage 1 implementation of the Monthly Settlement Cycle.

###### A.2.5.1.2.2.1.3.1 - Reduction Of Prime Allocator Vault Stability Fees [Core]  <!-- UUID: 48ec2b03-0885-45d9-b5f6-22267414f587 -->

The Stability Fees for each Prime Allocator Vault must be reduced to zero so that value is transferred from Primes to Sky Core exclusively through Executive Votes. The Core Executor Agents, in consultation with the Core Council Risk Advisor, is directed to use the Stability Parameter Bounded External Access Module to reduce the Stability Fee for each Prime Allocator Vault to zero. See [A.3.7.1.2.3 - Allocator Vault Parameters](6ab6bd12-93d3-419f-96e2-a7f79bfe1afa).

###### A.2.5.1.2.2.1.3.2 - Automation Of Simplified Profit And Loss Calculation [Core]  <!-- UUID: 1782eeb8-8c6f-4b34-beea-7ab140057324 -->

The Core Council Risk Advisor must develop tooling to allow the net amount due from each Prime to Sky each month under the Simplified Profit And Loss Calculation to be computed automatically.

###### A.2.5.1.2.2.2 - Stage 2 [Core]  <!-- UUID: 74bdfafe-e3c7-4670-a8bd-c337f1ad1e49 -->

The documents herein define Stage 2 of the implementation of the Monthly Settlement Cycle.

###### A.2.5.1.2.2.2.1 - Stage 2 Virtual Base Rate [Core]  <!-- UUID: c1fc89f4-b30f-4da1-93c6-822839fed783 -->

In Stage 2 of the implementation of the Monthly Settlement Cycle, the net amount due from each Prime to Sky is calculated as specified in the Atlas without the use of the Simplified Profit And Loss Calculation. However, interest under the Base Rate does not accrue in real time onchain and is instead calculated offchain and paid through Executive Votes as part of the Monthly Settlement Cycle. This is known as the Virtual Base Rate as these calculations occur offchain.

###### A.2.5.1.2.2.2.2 - Stage 2 Timing [Core]  <!-- UUID: ceb3c433-d73f-4c58-bac9-e79b44e66fcf -->

Stage 2 will be implemented in the December 2025 Monthly Settlement Cycle for the period from November 1, 2025 to November 30, 2025. If there is no December 2025 Monthly Settlement Cycle, then Stage 2 will be implemented in the January 2026 Monthly Settlement Cycle for the period from November 1, 2025 to December 31, 2025.

###### A.2.5.1.2.2.2.3 - Stage 2 Actions [Core]  <!-- UUID: b8c86fb3-2ba4-4c53-a509-81d022dffd20 -->

The actions specified herein must be completed to achieve Stage 2 implementation of the Monthly Settlement Cycle.

###### A.2.5.1.2.2.2.3.1 - Automation Of Monthly Settlement Cycle Calculation Including Virtual Base Rate [Core]  <!-- UUID: d98d3753-4230-4ad8-a1e7-7b1fd7e3b679 -->

The Core Council Risk Advisor must develop automated tooling for calculating the net amount due from each Prime to Sky each month, incorporating the Virtual Base Rate.

###### A.2.5.1.2.2.3 - Stage 3 [Core]  <!-- UUID: 1f9811fa-a759-4cd9-b7e1-aa0cc51174ed -->

The documents herein define Stage 3 of the implementation of the Monthly Settlement Cycle.

###### A.2.5.1.2.2.3.1 - Stage 3 Onchain Base Rate [Core]  <!-- UUID: eebbcd6d-2cbe-47cb-89c5-f119cf4eda08 -->

In Stage 3 of the implementation of the Monthly Settlement Cycle, the net amount due from each Prime to Sky is calculated as specified in the Atlas without the use of the Simplified Profit And Loss Calculation. In Stage 3, interest from the Base Rate accrues onchain to the Allocator Vault of each Prime. Thus, in Stage 3 Executive Votes are only required to pay down accrued interest on Allocator Vaults, as necessary, and settle other amounts due to and from Primes.

###### A.2.5.1.2.2.3.2 - Stage 3 Timing [Core]  <!-- UUID: cf7ed710-0302-4169-af70-34194269e184 -->

The timing for Stage 3 implementation of the Monthly Settlement Cycle will be specified in a future iteration of the Atlas.

###### A.2.5.1.2.2.3.3 - Stage 3 Actions [Core]  <!-- UUID: 42dc70f1-1353-40f8-90c3-cbbac317b26f -->

The actions specified herein must be completed to achieve Stage 3 implementation of the Monthly Settlement Cycle.

###### A.2.5.1.2.2.3.3.1 - Integration Of Base Rate Into Allocator Vaults [Core]  <!-- UUID: 2eb1b10f-e959-42ad-87db-2556e7fc7581 -->

Allocator Vaults must be updated to accrue interest in real time based on the Base Rate.

###### A.2.5.1.2.2.3.3.2 - Automation Of Monthly Settlement Cycle Based On Base Rate [Core]  <!-- UUID: 50b52e7e-2f79-4a7a-b887-cda85bc77cd7 -->

The Core Council Risk Advisor must update the tooling specified in [A.2.5.1.2.2.2.3.1 - Automation Of Monthly Settlement Cycle Calculation Including Virtual Base Rate](d98d3753-4230-4ad8-a1e7-7b1fd7e3b679) to reflect the onchain accrual of the Base Rate.

## A.2.6 - Agent Incubation [Article]  <!-- UUID: bb0c23c6-5123-4c35-ac84-fcb018a72cda -->

This Article governs the incubation of Agents. It defines the necessary infrastructure and processes to ensure Agents are maximally supported to generate as much value as possible for the Sky Ecosystem.

### A.2.6.1 - Support For Agents [Section]  <!-- UUID: a28b1bca-adac-493d-a052-40e36c97e670 -->

This Section defines elements and infrastructure to support Agents.

## A.2.7 - Ecosystem Actor Incubation [Article]  <!-- UUID: b09e86b1-0e95-4111-b141-7a980eeaef08 -->

This Article governs the incubation of new Ecosystem Actors to support the Sky Ecosystem.

### A.2.7.1 - Ecosystem Actor Incubation [Section]  <!-- UUID: 0016dcac-6cf0-4e66-ae6f-112f40eb9767 -->

The Support Scope is responsible for incubating Ecosystem Actors. This Section defines the elements to support this objective.

#### A.2.7.1.1 - Incubating Ecosystem Actors [Core]  <!-- UUID: 0239db13-482e-4a91-b173-ee31569dbb4c -->

Incubating Ecosystem Actors are Ecosystem Actors that are being developed to support the Sky Protocol or its current and future Agents. Sky Governance can assign these actors projects that benefit the Sky Protocol or incubating Agents, such as solutions for branding, marketing, user acquisition; referral marketing and revenue share systems; smart contract development; and protocol development.

#### A.2.7.1.2 - Currently Incubating Ecosystem Actors Template [Core]  <!-- UUID: 3af47ea8-d85b-4bd8-9339-ab053ed7a21a -->

The list of Incubating Ecosystem Actors must follow this template for each recorded Incubating Ecosystem Actor:

- **.x:** [Incubating Ecosystem Actor name and short description]

- **.1:** [Budget information]

- **.2:** [Deliverables and focus areas]

- **.3:** [Team information, including headcount grouped by skill sets]

## A.2.8 - Ecosystem Communication Channels [Article]  <!-- UUID: a520fea9-c2b7-4fda-a2b0-254b76504bc0 -->

This Article regulates the unified communication infrastructure for governance ecosystem communication. This infrastructure must include channels for inter-Agent and Ecosystem Actor interaction.

### A.2.8.1 - Ecosystem Communication Channels [Section]  <!-- UUID: 7574b64b-ccf8-427f-9c32-fa7a1b222f73 -->

The Support Scope maintains the overall unified communication infrastructure used for governance ecosystem communication. This Section defines key elements and infrastructure supporting this objective.

#### A.2.8.1.1 - Communications Infrastructure [Core]  <!-- UUID: 14e381be-b1bb-4b87-a533-212bd135cf27 -->

The Core Facilitator is tasked with maintaining an ecosystem-wide communications infrastructure to enable Agent participants and Ecosystem Actors to interact with each other and discuss the Sky Ecosystem.

##### A.2.8.1.1.1 - Forum [Core]  <!-- UUID: ec33a431-9aa0-443e-9f0c-d0ab0aacfae6 -->

The communications infrastructure must include an ecosystem Forum devoted to discussions on Agent-related business proposals, partnerships and interactions, as well as casual conversation for the broader Sky Ecosystem.

##### A.2.8.1.1.2 - Chatroom [Core]  <!-- UUID: a596136b-a805-420b-be77-bf249e41ada4 -->

The communications infrastructure must include a chatroom for broad discussion related to Agents, Ecosystem Actors and Sky. As an initial bootstrapping measure, the Core Facilitator can use Discord.

#### A.2.8.1.2 - Moderation [Core]  <!-- UUID: be3da4c5-6882-4694-9ccd-3fa7c5f6e09a -->

The documents herein define the moderation policies and responsible moderators for Sky's communication channels.

##### A.2.8.1.2.1 - Moderation Policies [Core]  <!-- UUID: 236ecf52-bd7f-4170-9cc5-f5b25f5ba3d4 -->

The documents herein define the moderation policies applicable to Ecosystem Communication Channels.

###### A.2.8.1.2.1.1 - General Requirements [Core]  <!-- UUID: 63701dcb-d885-4f81-a67b-71f5bf67bde8 -->

This document defines the requirements generally applicable to all Ecosystem Communication Channels.

Responsible moderators are granted the prerogative to ban users from the communication channels for which they are responsible when they deem users to be acting in a misaligned fashion. Misalignment can include maliciously exploiting the communication channel or disrupting its efficient functioning through improper use or antisocial behavior.

However, unless egregiously misaligned or disrupting behavior takes place, responsible moderators should err on the side of charity and issue a public warning for users who engage in bad behavior before resorting to banning them. Egregiously misaligned or disrupting behavior includes spamming, flooding, threatening, or using inappropriate or abusive language.

Only the Core Facilitator may ban a user from the Sky Forum when doing so would operationally block an ongoing governance process (e.g. the user has submitted an otherwise eligible governance proposal).

###### A.2.8.1.2.1.1.1 - Public Communication Of Bans [Core]  <!-- UUID: d18821e4-cee6-41d0-91fb-b5bb963b2594 -->

The documents herein define the requirements regarding public communication of bans. The Sky Forum is subject to special requirements that are defined in [A.2.8.1.2.1.1.1.1 - Sky Forum-Specific Requirements](a3e4d767-56d1-4b1f-8ade-b733bca4244f). Requirements applicable to all other Ecosystem Communication Channels are defined in [A.2.8.1.2.1.1.1.2 - Requirements Applicable To All Other Channels](d64ffda4-097c-47f8-b497-f20e7456b7fa).

###### A.2.8.1.2.1.1.1.1 - Sky Forum-Specific Requirements [Core]  <!-- UUID: a3e4d767-56d1-4b1f-8ade-b733bca4244f -->

For the Sky Forum, the Core Facilitator must publicly communicate the ban and the reasons for banning a user if the ban interrupts the users' exercise of a governance process.

In all other cases involving the Sky Forum, responsible moderators may exercise their best judgment in determining whether to publicly communicate a ban and the reasons for a ban. In doing so, the responsible moderators should consider the importance of transparency and community awareness as well as whether the banned user has engaged in egregiously misaligned and disrupting behavior. In every case, the moderators must still use the built-in forum functionality to register the ban reason for every banned user so that all forum users can see it when visiting the forum profile of the banned user.

If it is assessed that a public communication is necessary, the Core Facilitator is responsible for writing and publishing it.

###### A.2.8.1.2.1.1.1.2 - Requirements Applicable To All Other Channels [Core]  <!-- UUID: d64ffda4-097c-47f8-b497-f20e7456b7fa -->

For all Ecosystem Communication Channels other than the Sky Forum, the responsible moderators may exercise their discretion in determining whether to publicly communicate a ban and the reasons for the ban.

###### A.2.8.1.2.1.1.2 - Use Of Automated Tools [Core]  <!-- UUID: 76247105-be57-4eac-9eb4-793947a43d67 -->

Responsible moderators may use automated tools, including AI and bots, to help fulfill their moderation responsibilities. The responsible moderators retain responsibility for ensuring that these tools conform to moderation policies and must establish a process through which automated decisions can be reviewed by the responsible moderators.

###### A.2.8.1.2.1.1.3 - Unbanning [Core]  <!-- UUID: 4d4a1d9a-c8c7-4c2b-aaec-33e382790d52 -->

Bannings are by default permanent. However, Ranked Delegates can propose the unbanning of users by publishing a forum post that states the handle(s) of the user(s) whose unbanning they request and the rationale for their unbanning. The forum post must tag the Core Facilitator, who will in turn prepare a binary Weekly Cycle Governance Poll to be published on the Voting Portal as soon as reasonably possible. The outcome of the Governance Poll is binding.

Where identity can be proven, the ban on unbanned users will be lifted across all communication channels.

###### A.2.8.1.2.1.1.4 - Intrinsic Limitations [Core]  <!-- UUID: 9e2d25b0-227c-4f08-a466-c99dc7243d92 -->

Given the digital nature of these communication channels and the consequent practical unenforceability of permanent bannings, responsible moderators are expected to have to deal with recurring banned users under new aliases. Responsible moderators must exercise best judgement when suspecting a user to be a banned user under a different guise and when assessing whether they pose a risk of recidivism.

##### A.2.8.1.2.2 - List of Responsible Moderators [Core]  <!-- UUID: 1f76a652-0958-4165-8183-51c9eaccdbaa -->

The responsible moderators for each communication channel are:

- Sky Forum - The Core Facilitator

- Sky and Sky Builder Discord - The Core Facilitator and Ecosystem Actor TechOps Services

- Sky X / Twitter Account - Ecosystem Actor Maker Growth

- MakerDAO Subreddit - Ecosystem Actor Maker Growth

#### A.2.8.1.3 - Communications Infrastructure Budget [Core]  <!-- UUID: 72d16b65-95cf-4cff-a2f4-71ce92019f84 -->

The ecosystem communication infrastructure budget is 0 USDS per quarter.

## A.2.9 - Ecosystem Accords [Article]  <!-- UUID: 104c3543-ce94-4a2f-9968-57f1ee858085 -->

This Article governs Ecosystem Accords, agreements between actors in the Sky Ecosystem that are enforceable by Sky Governance.

### A.2.9.1 - Dispute Resolution [Section]  <!-- UUID: f4d827e9-bf60-4180-a1d0-446af1245365 -->

This Section defines the process for resolving disputes regarding Ecosystem Accords.

#### A.2.9.1.1 - Dispute Resolution By Core Council [Core]  <!-- UUID: 82a04a56-8cc9-4adf-9714-da246d541371 -->

Disputes regarding Ecosystem Accords are resolved by the Core Council as specified in the documents herein.

##### A.2.9.1.1.1 - Roles [Core]  <!-- UUID: 4973a9b8-66f1-4486-829e-6c9464b9407c -->

The documents herein define the respective roles of Core GovOps and the Core Facilitator in resolving disputes.

###### A.2.9.1.1.1.1 - Role Of Core GovOps [Core]  <!-- UUID: 59ca12d1-a25c-4974-90d9-ccf7dae184f3 -->

Core GovOps manages the overall dispute resolution process, including establishing communication channels for dispute resolution, communicating with the parties, and gathering and analyzing information relating to the dispute.

###### A.2.9.1.1.1.2 - Role Of Core Facilitator [Core]  <!-- UUID: cf7e0654-f9a6-45e4-9984-14387067cb17 -->

The Core Facilitator decides how the dispute is ultimately resolved. The Core Facilitator is isolated from the parties to maintain impartiality. The Core Facilitator exclusively reviews the information prepared by Core GovOps and delivers a decision to Core GovOps, which communicates it to the parties.

##### A.2.9.1.1.2 - Process Definition [Core]  <!-- UUID: 6151ee33-ff22-4bda-955b-f3731ab9b522 -->

The documents herein define the process for resolving disputes.

###### A.2.9.1.1.2.1 - Dispute Intake [Core]  <!-- UUID: 8bf58bdf-4a6f-4e8b-9829-7e375719ad4a -->

The documents herein define the process for dispute intake for dispute resolution.

###### A.2.9.1.1.2.1.1 - Formal Request For Dispute Resolution [Core]  <!-- UUID: 3f43d965-56e4-4153-a59a-00329e3b00e5 -->

The dispute resolution process begins with an actor in the Sky Ecosystem requesting formal dispute resolution from Core GovOps.

###### A.2.9.1.1.2.1.2 - Preliminary Determination Of Reasonableness By Core GovOps [Core]  <!-- UUID: c2f9e098-b0f5-44ae-b44d-a9481707b787 -->

After receiving the request for dispute resolution, Core GovOps makes a brief preliminary determination regarding whether the request is reasonable (i.e. not vexatious or frivolous), within three (3) working days.

###### A.2.9.1.1.2.1.3 - Handling Of Unreasonable Requests [Core]  <!-- UUID: 7765da19-eae7-4b76-b9e0-155b251be3c7 -->

If Core GovOps determines that the request for dispute resolution is not reasonable, it will inform the actor who submitted the request accordingly, providing their reasons. In this case, there is no further action.

###### A.2.9.1.1.2.1.4 - Handling Of Reasonable Requests [Core]  <!-- UUID: f26cc457-75eb-4b42-9ac0-55fe3d6fcb43 -->

If Core GovOps makes a determination that the request is reasonable, then Core GovOps formally begins the dispute resolution process by notifying all relevant parties that the process is about to begin. The notifications to each party will outline the process to be followed, including relevant steps and timeframes that the party should be aware of.

###### A.2.9.1.1.2.2 - Presentation Of Arguments [Core]  <!-- UUID: f08ccecb-88cc-4d28-8a62-8be9f3b8d19b -->

The documents herein define the process for the presentation of arguments for dispute resolution.

###### A.2.9.1.1.2.2.1 - Statement Of Problem [Core]  <!-- UUID: 550f5cfb-0f3d-4b05-8e86-80315d4f135a -->

The party that initiated the dispute resolution process has five (5) working days from the formal initiation of the process to submit a Statement of Problem, laying out the facts they consider relevant to the dispute and the issues related to the Atlas as they see them.

###### A.2.9.1.1.2.2.2 - Statement Of Response [Core]  <!-- UUID: a1e21e2a-be88-4041-9204-0c2936e693d7 -->

Core GovOps provides the Statement of Problem to the other party/parties. They have five (5) working days to submit a Statement of Response, which sets out their perspective on the relevant facts and issues in the dispute.

###### A.2.9.1.1.2.2.3 - Statement Of Rebuttal [Core]  <!-- UUID: cedc6a69-da33-421a-a090-2cae2f0e7185 -->

Core GovOps provides the Statement of Response to the party that initiated the dispute resolution process. They have three (3) working days to submit a Statement of Rebuttal.

###### A.2.9.1.1.2.3 - Decision [Core]  <!-- UUID: 262a79a0-c5be-4721-ab27-ba7ba45776c5 -->

The documents herein define the decision process for dispute resolution.

###### A.2.9.1.1.2.3.1 - Analysis By Core GovOps [Core]  <!-- UUID: 5594d477-159c-4baf-86dd-3d5f0c1d857b -->

Core GovOps prepares a confidential analysis of the dispute for the Core Facilitator. This analysis must include a summary of all relevant facts as far as it is possible to ascertain, clear identification of any areas of factual ambiguity or disagreement between the parties, a structured presentation of the arguments in favor of each party, and a recommendation if Core GovOps believes one conclusion is clearly supported by the facts.

###### A.2.9.1.1.2.3.2 - Adjudication By Core Facilitator [Core]  <!-- UUID: 056774ab-b584-4f37-90f4-9c17b79ddfb3 -->

The Core Facilitator reviews the analysis prepared by Core GovOps along with the arguments presented by the parties and reaches a decision within three (3) working days.

The Core Facilitator must draft a decision setting out relevant facts and the core reasoning of their decision. In doing so, the Core Facilitator is free to adopt arguments presented by the parties, by Core GovOps, or to advance their own analysis.

###### A.2.9.1.1.2.3.3 - Release Of Decision [Core]  <!-- UUID: c172684d-9564-40f9-8d47-82d736a3d876 -->

The Core Facilitator communicates their decision to Core GovOps. Core GovOps communicates the decision to all related parties.

###### A.2.9.1.1.2.3.4 - Publication Of Decision [Core]  <!-- UUID: 5e4b0330-1469-4fb0-9622-6bf32b8c6afa -->

The Core Facilitator publishes the decision on the Sky Forum and updates the [A.2.9.1.2.0.6.1 - Dispute Resolutions](c48614bb-6f51-4de7-97bd-ef1fed968d72) Active Data document in the Atlas, redacting any confidential information as needed.

#### A.2.9.1.2 - Dispute Resolution Recording [Active Data Controller]  <!-- UUID: e6384df7-246b-4240-93e8-01bf903e072d -->

Resolutions of disputes involving Ecosystem Accords are defined as Active Data in [A.2.9.1.2.0.6.1 - Dispute Resolutions](c48614bb-6f51-4de7-97bd-ef1fed968d72).

The Active Data is updated as follows:    
◦ The Responsible Party is the Core Facilitator.    
◦ The Update Process must follow the protocol for ‘Direct Edit’.

##### A.2.9.1.2.0.6.1 - Dispute Resolutions [Active Data]  <!-- UUID: c48614bb-6f51-4de7-97bd-ef1fed968d72 -->

The resolutions of disputes regarding Ecosystem Accords are:

- **Dispute Between Spark And Grove Regarding Effective Date Of Their Ecosystem Accord** (September 2, 2025) - [Facilitator Decision on Grove/Spark Dispute](https://forum.sky.money/t/facilitator-decision-on-grove-spark-dispute/27141)

### A.2.9.2 - Active Ecosystem Accords [Section]  <!-- UUID: be46648d-a154-480a-b202-81fd1ac735d2 -->

The subdocuments herein record currently active Ecosystem Accords.

#### A.2.9.2.1 - Ecosystem Accord 1: Grove And Spark Agents [Core]  <!-- UUID: 9ca40096-937e-431e-af50-9ecd50c0d0a8 -->

The subdocuments herein record the terms of agreement between Grove and Spark as agreed in Ecosystem Accord 1.

##### A.2.9.2.1.1 - Accord Key Details [Core]  <!-- UUID: 4512c23a-2b01-4a38-ad02-9a016e1d0c54 -->

The subdocuments herein set out the key details of Ecosystem Accord 1, such as parties to the agreement and the duration of the Accord.

###### A.2.9.2.1.1.1 - Parties To The Accord [Core]  <!-- UUID: 817d9d87-9659-43b5-80ce-8f68b592a625 -->

The Grove and Spark Agents are the parties to Ecosystem Accord 1. These parties are also referred to as Grove and Spark, respectively, in the terms of this Accord.

###### A.2.9.2.1.1.2 - Duration Of The Accord [Core]  <!-- UUID: c2fe6ab2-bec3-48d3-b4b1-9f93cd97f693 -->

The duration of Ecosystem Accord 1 is six (6) months, commencing from May 29, 2025.

##### A.2.9.2.1.2 - Accord Substantive Terms [Core]  <!-- UUID: a20cefff-cd64-4c01-93e0-052915759938 -->

The subdocuments herein set out the substantive terms of Ecosystem Accord 1.

###### A.2.9.2.1.2.1 - Revenue Share [Core]  <!-- UUID: 25743b88-dead-47fe-bd81-b709e69f5949 -->

Grove and Spark agree to a bilateral revenue share, up to 40% maximum with JRC rental, see [A.2.3.9.2 - Junior Risk Capital Rental Primitive](d8086dc0-7e77-4c6b-98c7-5fc41337a1ce).

###### A.2.9.2.1.2.1.1 - Revenue Share Definition [Core]  <!-- UUID: 66089224-1a28-475f-9276-ed2bd956e48e -->

Each Agent retains the right to force the other Prime Agent to do revenue sharing up to 40% by providing that Prime with rented JRC. Sharing is done on the net revenue after deducting the cost to Sky. This is only considered on the spread earned on USDS debt, including any subsidy amounts.

###### A.2.9.2.1.2.2 - Grove Agent Exclusivity [Core]  <!-- UUID: 76d646ca-be88-47e5-b9c6-943155fe2fb1 -->

Grove exclusivity includes Real World Assets (RWAs), which exclusivity does not extend to Treasuries used for ASC purposes or stablecoin liquidity provisioning.

###### A.2.9.2.1.2.3 - Spark Agent Exclusivity [Core]  <!-- UUID: e979e76f-e970-45de-bddb-38c86ac3c007 -->

Spark Agent exclusivity includes Maple, cryptocurrency OTC lending, and Established DeFi Lending Protocols, as defined in [A.2.9.2.1.2.3.1 - Established DeFi Lending Protocol Definition](0d74de1b-bb46-4286-bcbf-d260d1204465).

###### A.2.9.2.1.2.3.1 - Established DeFi Lending Protocol Definition [Core]  <!-- UUID: 0d74de1b-bb46-4286-bcbf-d260d1204465 -->

Established DeFi Lending Protocols are defined as DeFi lending protocols deployed six months ago or earlier.

###### A.2.9.2.1.2.4 - Right Of First Refusal [Core]  <!-- UUID: 8d64aa84-ae79-4bde-ae94-5dd7c18d3019 -->

Grove provides the Spark Agent with a right of first refusal for DeFi opportunities on unclaimed chains and new protocols, including bootstrapping incentive programs.

###### A.2.9.2.1.2.4.1 - DeFi Opportunities Right of First Refusal Duration [Core]  <!-- UUID: 0db1525d-bcce-469a-b414-65b41669432d -->

Grove provides the Spark Agent a right of first refusal for pursuing cross-chain bootstrapping opportunities, which lasts four weeks after notification by Grove. If Spark does not wish to deploy SparkLend or provide capital to the protocol in question, Grove retains the right to pursue the opportunity pending security and risk assessments of the target protocol. Upon written notification from Grove of a new DeFi opportunity via a communications channel mutually agreed by the parties, Spark has four weeks to decide whether it wants to deploy SparkLend or lend to the target chain and protocol. If Spark opts not to do so by the end of the four-week period, Grove is permitted to pursue the opportunity.

_Example:__ A lending protocol (i.e. Aave, Euler, Morpho, etc) plans on deploying on blockchain X. Grove provides written notification to Spark about the potential new deployment. Spark evaluates the opportunity and decides there are better opportunities to pursue. The opportunity reverts to Grove after Spark’s refusal; or, if Spark does not issue a formal refusal, the opportunity reverts to Grove after four weeks._

###### A.2.9.2.1.2.4.2 - DeFi Opportunities Complementary Deployments [Core]  <!-- UUID: 41ad5689-6679-4129-a24d-aa50334e1f26 -->

Grove and Spark may combine efforts if there is a large enough cross-chain opportunity. For example, Grove may deploy stablecoin liquidity on a target chain and Spark may deploy a SparkLend instance. In this case, complementary efforts are made to mutually benefit the cross-chain deployment, with significant economic benefits received by both parties. This chain would also serve as a new distribution channel for Spark, Grove, and Sky products.

###### A.2.9.2.1.2.5 - ASC Provision [Core]  <!-- UUID: 72bad98d-007c-4247-98ba-daeb1c8130b4 -->

Grove retains the right to deploy into repo lending protocols to meet ASC requirements. Deposits must be capped at the lower of either 10% of protocol USDC deposits or the Minimum Actively Stabilizing Collateral, as defined in [A.3.3.2.2 - Minimum Actively Stabilizing Collateral](475fe222-9e4a-4e9d-9be6-a7a424ce02f8). The Spark Agent retains the right to use the PSM for ASC, provided it covers the cost to Grove.

###### A.2.9.2.1.2.6 - Treasuries Provision [Core]  <!-- UUID: 11ad7c74-6163-452c-acf0-a70af3396d03 -->

The Spark Agent retains the right to deploy into tokenized US Treasury Bills to meet ASC requirements.

###### A.2.9.2.1.2.7 - Basis Trade Products [Core]  <!-- UUID: d1a4398c-aa95-462b-a212-d2afc047477b -->

Basis trade products are available to both Grove and Spark.

###### A.2.9.2.1.2.8 - Grand Prix Airdrops [Core]  <!-- UUID: 784feda7-d69e-4ed3-97c3-95b70314b44e -->

Grove receives any airdrops from the Grand Prix.

###### A.2.9.2.1.2.9 - USDe and sUSDe Revenue Share [Core]  <!-- UUID: 56589ad5-4e8e-4af9-926a-fadca7bfa0e3 -->

Spark and Grove agree to share revenue from USDe and sUSDe as specified in the subdocuments herein.

###### A.2.9.2.1.2.9.1 - Revenue Share [Core]  <!-- UUID: 7d16afc8-0eb4-40db-81aa-915a7f052859 -->

Spark and Grove will share 50% of all revenue and expenses associated with Spark’s Allocation System investments in USDe and sUSDe. Revenue includes (1) protocol yield on the amount deployed into these assets, (2) any OTC or negotiated arrangements, payments, or incentives, and (3) manual payments or rebates related to withdrawal activity. Expenses include all costs associated with Spark’s investment in USDe and sUSDe, including mint / burn fees, swap fees, and costs of borrowing funds from Sky.

###### A.2.9.2.1.2.9.2 - Risk Capital Share [Core]  <!-- UUID: ac648f96-3b0d-46c6-9501-a3a88da26961 -->

Grove agrees to rent to Spark 50% of the Required Risk Capital associated with Spark’s investments in USDe and sUSDe as a Junior Risk Capital Rental. See [A.2.3.9.2 - Junior Risk Capital Rental Primitive](d8086dc0-7e77-4c6b-98c7-5fc41337a1ce).

###### A.2.9.2.1.2.9.2.1 - Implementation [Core]  <!-- UUID: 2bb81311-e501-4d0d-b403-f4c619463538 -->

Spark and Grove expressly intend that Grove shares in 50% of the risks of Spark’s investment in USDe and sUSDe and not in the risk of any other investments by Spark.

To the extent that USDe or sUSDe investments experience losses and Spark is allocated a greater than 50% share of those losses relative to Grove under the TIP JRC mechanism (see [A.3.2.1.2.2.1.2.1 - Initial Loss Absorption By "Tip JRC"](6c33bcf5-c29d-48ca-9ee5-e37dcdeb0630)), Grove will transfer funds to Spark so that Grove and Spark each bear 50% of the losses that occur.

To the extent that Spark experiences losses on investments other than USDe or sUSDe and a portion of those losses is allocated to the Junior Risk Capital rented from Grove, Spark shall reimburse Grove for those losses.

###### A.2.9.2.1.2.9.3 - Term [Core]  <!-- UUID: a768dda1-1075-4762-a904-c523687cbe6c -->

This revenue share shall be effective retroactively, dated back to the launch of Spark’s allocation into USDe and sUSDe beginning the week of July 14, 2025.
It shall remain in effect until one of the following conditions is met, whichever occurs first:
    
1. Grove begins to allocate capital to USDe or sUSDe directly; or    
2. Spark or Grove terminates the revenue share, with reasonable advance notice to the other party.

Any changes to the structure or scope of this arrangement will be discussed transparently and approved by both Spark and Grove.

#### A.2.9.2.2 - Prime Program [Core]  <!-- UUID: aa3b8e65-0ded-48c2-9c40-812debf99f32 -->

The subdocuments herein record the terms of agreement between Sky, Grove, and Spark as agreed in Ecosystem Accord 2.

##### A.2.9.2.2.1 - Accord Key Details [Core]  <!-- UUID: a9f4941d-9d07-4191-a8c6-f1cb25a067cc -->

The subdocuments herein set out the key details of Ecosystem Accord 2, such as parties to the agreement and the duration of the Accord.

###### A.2.9.2.2.1.1 - Parties To The Accord [Core]  <!-- UUID: fea17abc-79b6-4b49-81c0-258b303eafe9 -->

The parties to Ecosystem Accord 2 are Sky, Spark, Grove, and Moonbow, as defined in the subdocuments herein.

###### A.2.9.2.2.1.1.1 - Sky Details [Core]  <!-- UUID: 2916297b-e460-409b-85e1-6e1b6d431b98 -->

The party ‘Sky’ comprises Sky Core.

###### A.2.9.2.2.1.1.2 - Spark Details [Core]  <!-- UUID: d40acd19-773c-479f-837a-0291c8b9fcde -->

The party ‘Spark’ comprises the Spark Prime Agent, Spark Foundation, and Phoenix Labs.

###### A.2.9.2.2.1.1.3 - Grove Details [Core]  <!-- UUID: ccc2c16a-68a6-4182-a1a4-4f666a8bce2f -->

The party ‘Grove’ comprises the Grove Prime Agent, and Grove Foundation.

###### A.2.9.2.2.1.1.4 - Moonbow Details [Core]  <!-- UUID: eb3b0811-8b84-4216-ae3e-ac2181935204 -->

The party ‘Moonbow’ is the entity owning relevant intellectual property.

###### A.2.9.2.2.1.2 - Duration Of The Accord [Core]  <!-- UUID: f68cf0ec-47bb-45d7-80a8-3b28f9e8dd1c -->

The duration of Ecosystem Accord 2 is indefinite, commencing from May 29, 2025.

##### A.2.9.2.2.2 - Accord Substantive Terms [Core]  <!-- UUID: ffb7dab9-a276-4968-ab49-f5783250120a -->

The subdocuments herein set out the substantive terms of Ecosystem Accord 2.

###### A.2.9.2.2.2.1 - Tokenomics [Core]  <!-- UUID: ed0308bf-4a87-4c7c-b05e-3a4d46b68a13 -->

The subdocuments herein set out agreed terms with respect to tokenomics.

###### A.2.9.2.2.2.1.1 - Total Token Supply [Core]  <!-- UUID: 63684d7c-09f4-48ab-9daa-f3bb0aac6f28 -->

The total token supply of each of the SPK and GROVE tokens shall be 10,000,000,000 (ten billion).

###### A.2.9.2.2.2.1.2 - Token Allocations [Core]  <!-- UUID: cfac7e47-d20e-4b52-8d25-9ec418bd2c96 -->

Specific token allocations are defined in the subdocuments herein.

###### A.2.9.2.2.2.1.2.1 - Grove Prime Treasury [Core]  <!-- UUID: 9d7a2d3f-3079-4d3b-be89-e06966aec07c -->

3,000,000,000 GROVE tokens are allocated to the Grove Prime Treasury (Grove’s SubProxy), with an option to further increase this allocation by 5% (500,000,000 tokens). The additional 5% will be distributed to relevant stakeholders / users from Sky’s allocation of GROVE tokens, but that distribution will happen from Grove’s SubProxy. This distribution plan must be approved by Sky before the transfer.

###### A.2.9.2.2.2.1.2.2 - Sky Retained Tokens And Reward Pools [Core]  <!-- UUID: fb447af6-1581-4711-b73c-dc2e8d65e843 -->

Sky retains 7,000,000,000 GROVE tokens and 6,500,000,000 SPK tokens, distributing these as token rewards over a 10-year period according to the schedules outlined below.

###### A.2.9.2.2.2.1.2.2.1 - Grove Token Reward Distribution Schedule [Core]  <!-- UUID: 5b43f4d8-9728-411c-92c7-a7ebaf368ca0 -->

Sky will distribute GROVE tokens annually, per the following schedule:  
  
| Year | Tokens for USDS Users | Tokens for Staking Users | Total           |  
|------|------------------------|---------------------------|-----------------|  
| 1    | 1,225,000,000          | 525,000,000               | 1,750,000,000   |  
| 2    | 1,225,000,000          | 525,000,000               | 1,750,000,000   |  
| 3    | 612,500,000            | 262,500,000               | 875,000,000     |  
| 4    | 612,500,000            | 262,500,000               | 875,000,000     |  
| 5    | 306,250,000            | 131,250,000               | 437,500,000     |  
| 6    | 306,250,000            | 131,250,000               | 437,500,000     |  
| 7    | 153,125,000            | 65,625,000                | 218,750,000     |  
| 8    | 153,125,000            | 65,625,000                | 218,750,000     |  
| 9    | 153,125,000            | 65,625,000                | 218,750,000     |  
| 10   | 153,125,000            | 65,625,000                | 218,750,000     |  
| Total| 4,900,000,000          | 2,100,000,000             | 7,000,000,000   |

###### A.2.9.2.2.2.1.2.2.2 - Spark Token Reward Distribution Schedule [Core]  <!-- UUID: 1f412288-af14-4aab-84e9-79f2e0c39100 -->

Sky will distribute SPK tokens annually, per the following schedule:  
  
| Year | Tokens for USDS Users | Tokens for Staking Users | Total           |  
|------|------------------------|---------------------------|-----------------|  
| 1    | 1,137,500,000          | 487,500,000               | 1,625,000,000   |  
| 2    | 1,137,500,000          | 487,500,000               | 1,625,000,000   |  
| 3    | 568,750,000            | 243,750,000               | 812,500,000     |  
| 4    | 568,750,000            | 243,750,000               | 812,500,000     |  
| 5    | 284,375,000            | 121,875,000               | 406,250,000     |  
| 6    | 284,375,000            | 121,875,000               | 406,250,000     |  
| 7    | 142,187,500            | 60,937,500                | 203,125,000     |  
| 8    | 142,187,500            | 60,937,500                | 203,125,000     |  
| 9    | 142,187,500            | 60,937,500                | 203,125,000     |  
| 10   | 142,187,500            | 60,937,500                | 203,125,000     |  
| Total| 4,550,000,000          | 1,950,000,000             | 6,500,000,000   |

###### A.2.9.2.2.2.1.3 - Transfer Limit [Core]  <!-- UUID: da03bcb0-734a-4d36-ab0e-e42a43e23d8a -->

A maximum of 1,000,000,000 tokens can be transferred by Spark and Grove to their respective Foundations in the first year for the purpose of rewarding contributors, and 500,000,000 tokens per year thereafter for the purpose of rewarding contributors.

###### A.2.9.2.2.2.1.4 - Prime Token Generation Event [Core]  <!-- UUID: c00b9dad-06d6-4e91-bfb2-7f5afa0bc47e -->

The respective Prime Foundations for Spark and Grove, or one of their subsidiaries or affiliate companies, will conduct the token generation event. In the token generation event, the Agent tokens will be split and sent to the Prime SubProxy and Sky Proxy. In this process, Sky will receive a universal override over the Prime Agent Token in question.

###### A.2.9.2.2.2.1.5 - Minimum Float [Core]  <!-- UUID: 3918317d-50e8-4095-a0c6-22536291a6b5 -->

For each of Spark and Grove, a minimum of 10% of the total token supply must be in circulation (float) within a year, and maintain that float afterward. If the float goes below the 10% threshold, the Prime Agent might have 1 natural year to get the float back to 10% or above. If the float falls below 10%, Sky will mint additional Prime Agent tokens until the 10% threshold is reached. Newly minted tokens would be farmed and the revenue from farming would be returned to the Prime Agent, net of a penalty for needing to trigger the minimum float.

###### A.2.9.2.2.2.2 - Borrowing Capacity And Mechanism [Core]  <!-- UUID: 2c6034e7-d716-4d36-8063-d893c23fc34a -->

The subdocuments herein set out agreed terms with respect to borrowing capacity and the borrow rate mechanism.

###### A.2.9.2.2.2.2.1 - Subsidized Borrowing [Core]  <!-- UUID: 552e7b01-c2d0-4658-ac49-2c74e230aeac -->

Both Spark and Grove are entitled to borrow up to 1,000,000,000 USDS from Sky at a subsidized rate for an initial period of 2 years, beginning January 1, 2026. This subsidized rate is set out in [A.2.9.2.2.2.2.2 - Borrow Rate Mechanism](f97cc4c7-d0d5-47fc-9f86-c00824ae6d7f).

###### A.2.9.2.2.2.2.2 - Borrow Rate Mechanism [Core]  <!-- UUID: f97cc4c7-d0d5-47fc-9f86-c00824ae6d7f -->

The borrow rate subsidy for Spark and Grove will be calculated according to the formula: `t-bill_rate + ((base_rate - t-bill_rate) * T/24)`, where T represents elapsed months and is a counter that increases monthly over the 2-year period.

###### A.2.9.2.2.2.2.3 - Base Rate [Core]  <!-- UUID: fd39df25-6093-49ae-be12-36df34754612 -->

The Base Rate will be dynamic and aligned with the SSR (Sky Savings Rate).

###### A.2.9.2.2.2.2.4 - Minimum Borrowing Threshold for Grant Eligibility [Core]  <!-- UUID: 23b21d6f-ad66-42ff-9e9f-c5bd5da6e8d4 -->

Primes, including Spark and Grove, must each maintain a minimum borrowing of 1,000,000,000 USDS from Sky at all times to remain eligible for the full monthly reimbursement grant. If the amount borrowed falls below this threshold, the reimbursement grant will be proportionately slashed. This grant will cover the difference between the borrowing Base Rate and the T-bill rate. Spark and Grove can borrow amounts exceeding the 1,000,000,000 USDS limit at the prevailing Base Rate.

###### A.2.9.2.2.2.2.5 - Borrowing Above Subsidized Limit [Core]  <!-- UUID: c04dcedd-5e17-412f-8a71-55a76c29b80d -->

Spark and Grove can borrow amounts exceeding the 1,000,000,000 USDS limit at the prevailing Base Rate.

###### A.2.9.2.2.2.2.6 - Recourse [Core]  <!-- UUID: daf0ea35-23cb-4550-88f9-7da59027d262 -->

Sky’s recourse for bad debt consists of (1) minting Prime Agent tokens; (2) terminating a Prime’s right to further borrowing; and (3) activation of the Resolution Mechanism which includes, without limitation, the authority to suspend all protocol operations, seize or reallocate all of the Prime assets, override or disable smart contract functions, initiate managed restructuring, or execute full and permanent liquidation of the affected sub-protocol and all of its assets, in order to contain risk and preserve the stability and solvency of the broader ecosystem.

###### A.2.9.2.2.2.3 - Accessibility Reward [Core]  <!-- UUID: 85b8e871-2d42-4a85-a887-c33d860bed64 -->

The subdocuments herein set out agreed terms with respect to the Accessibility Reward.

###### A.2.9.2.2.2.3.1 - Distribution Reward Rate [Core]  <!-- UUID: 8e3cde6b-3b8b-4e9a-b9a0-8c24d84881f6 -->

The standard Distribution Reward rate is set at 0.2%.

###### A.2.9.2.2.2.3.2 - 2025 Bonus [Core]  <!-- UUID: 7ca440d3-03fb-4fba-81a8-d2118dc47aa6 -->

An additional 0.4% Distribution Reward bonus will apply during the calendar year 2025 (ending December 31, 2025). This bonus is strictly limited to the Prime and does not extend to the Prime Foundation. The bonus is subject to the limitation specified in [A.2.9.2.2.2.3.2.1 - Bonus Limitation](6996e6c9-b936-4680-855f-b9717572082d).

###### A.2.9.2.2.2.3.2.1 - Bonus Limitation [Core]  <!-- UUID: 6996e6c9-b936-4680-855f-b9717572082d -->

USDS and sUSDS balances held by the Prime itself are not eligible for the Distribution Reward bonus specified in [A.2.9.2.2.2.3.2 - 2025 Bonus](7ca440d3-03fb-4fba-81a8-d2118dc47aa6).

###### A.2.9.2.2.2.3.3 - Sky Spread [Core]  <!-- UUID: 5e3e9338-221a-461a-96f9-01e0665ab6a4 -->

A fixed margin of 0.1% (Sky Spread) forms part of the overall differential between the Savings Rate and the Base Rate, representing the premium earned by Sky for facilitating the ecosystem’s financing. The total spread between the Savings Rate and the Base Rate is therefore 0.3%.

###### A.2.9.2.2.2.4 - Double Distribution Upkeep To Sky [Core]  <!-- UUID: dba4e6ec-4a62-4909-857d-f4d7cb359255 -->

The subdocuments herein set out agreed terms with respect to distributions to Sky.

###### A.2.9.2.2.2.4.1 - Distribution Requirement [Core]  <!-- UUID: d3dd498e-fddd-4000-9fc2-10263ebc85cd -->

To ensure continuous ecosystem support over the period of years 10 to 30, Prime Agents must distribute either 0.5% of the market capitalization of their token per year, if distributed in tokens; or 0.6% of their market capitalization of their token per year if paid in stablecoins as a fee. These amounts include both the Standard Annual Upkeep Payment as set out in [A.2.9.2.2.2.4.2.1 - Standard Annual Upkeep Payment](5366c204-9fde-41b1-a8a4-ab6920c28b01) and the Additional Incremental Upkeep Payment as set out in[ ](https://atlas-axis.notion.site/Additional-Incremental-Upkeep-Payment-Core-If-a-Star-Agent-elects-not-to-distribute-certain-fund-1fdf2ff08d73802c804adcf401e7d66f#1fdf2ff08d73814ba4ffc4c497133102)[A.2.9.2.2.2.4.2.2 - Additional Incremental Upkeep Payment](2e7346bb-68bb-4441-8ff9-0fc17f7433f1).

###### A.2.9.2.2.2.4.2 - Distribution Structure [Core]  <!-- UUID: eb52fb46-f477-4bf1-afd3-7e4e13f19e8a -->

To ensure continued ecosystem support, Primes, including Spark and Grove, are required to make annual upkeep payments to Sky, calculated based on retained funds as set out in the subdocuments herein.

###### A.2.9.2.2.2.4.2.1 - Standard Annual Upkeep Payment [Core]  <!-- UUID: 5366c204-9fde-41b1-a8a4-ab6920c28b01 -->

All Prime Agents will pay a standard annual upkeep payment of 25 basis points (bps) (0.25%) per year. This standard upkeep payment applies permanently and is separate from any additional payments explained below.

###### A.2.9.2.2.2.4.2.2 - Additional Incremental Upkeep Payment [Core]  <!-- UUID: 2e7346bb-68bb-4441-8ff9-0fc17f7433f1 -->

If a Prime Agent elects not to distribute certain funds to Sky, but instead retains those funds in its treasury, the Prime incurs an additional incremental upkeep payment. The incremental payment is calculated based on the total retained funds at the rate of 2.5 basis points (bps) (0.025%) per year per $1 million retained, if the payment is made in tokens. If the payment is made in cash (USD) rather than tokens, the incremental payment increases by 20%. This results in a rate of 3 basis points (bps) (0.03%) per year per $1 million retained.

###### A.2.9.2.2.2.5 - Genesis Capital Allocation [Core]  <!-- UUID: 23149a25-19a1-4d8f-b4ce-ea4b2adc2e21 -->

The subdocuments herein set out agreed terms with respect to genesis capital allocations.

###### A.2.9.2.2.2.5.1 - Spark Initial Allocation [Core]  <!-- UUID: a339b1d7-34a9-40bd-b452-a86e149f07f7 -->

The Initial Allocation for Spark is 25,000,000 USDS.

###### A.2.9.2.2.2.5.2 - Grove Initial Allocation [Core]  <!-- UUID: 062fdb39-464e-4a5b-a44f-3462d2d38be5 -->

The Initial Allocation for Grove is 25,000,000 USDS.

###### A.2.9.2.2.2.5.3 - Initial Allocation Distribution [Core]  <!-- UUID: 6b8fc0e6-ee0b-4a48-a096-2ccb06f64e3f -->

The Initial Allocation is distributed in USDS to each Prime SubProxy (i.e. the Spark SubProxy and Grove SubProxy). Both Grove and Spark elected to distribute 5% of the total token supply over a period of 20 years, lasting from year 10 to year 30, and will receive USDS 25,000,000 each.

###### A.2.9.2.2.2.5.4 - Initial Allocation Mechanism [Core]  <!-- UUID: eedd0309-b11b-459e-a966-13b16e961ccc -->

Shortly after the Agent Token launch, an Atlas Edit Proposal submitted to Sky Governance will allow the respective founding teams of Spark and Grove to propose an initial cash grant to their respective Prime Foundation. Sky Governance must consent to this initial cash grant via approving the Sky Atlas modification.

###### A.2.9.2.2.2.5.4.1 - Initial Cash Grant To Spark Foundation [Core]  <!-- UUID: 9daea2fa-0fef-48a7-8633-fa33081236da -->

The founding team of Spark has proposed a cash grant of 800,000 USDS per month to the Spark Foundation from Spark’s Genesis Capital Allocation for a three (3) month period, beginning at the time of the Genesis Capital Allocation. The purpose of the grant is to enable Spark Foundation to fulfill its purpose of promoting the growth and development of Spark. This funding will support essential activities such as engineering efforts, community engagement, research, infrastructure, and administrative operations.

Sky Governance hereby consents to this cash grant. The first month’s transfer must be made to the Spark Foundation immediately after the transfer of the Genesis Capital Allocation. See [A.2.9.2.2.2.8.2.1 - Transfer Of Genesis Capital Allocation To Spark SubProxy](e3ec99ec-54c9-4fe7-8104-aee20c57ec57). Transfers for subsequent months will be made proportionally in Spark Spells included in Sky Executive Votes unless otherwise agreed by Sky and Spark.

###### A.2.9.2.2.2.5.5 - Subsequent Allocation Mechanism [Core]  <!-- UUID: aea8a2d8-2203-4123-8c09-17b2bb8427c1 -->

After the initial cash grant (see [A.2.9.2.2.2.5.4 - Initial Allocation Mechanism](eedd0309-b11b-459e-a966-13b16e961ccc)) but before the SPK or GROVE token is decentralized enough to allow meaningful governance by token holders, the respective founding teams may propose subsequent cash grants to their Prime Foundations. Sky must consent to each subsequent cash grant via approving the Sky Atlas modification.

###### A.2.9.2.2.2.5.5.1 - Subsequent Cash Grant To Spark Foundation [Core]  <!-- UUID: ecccb062-23a5-449b-a916-e37049a1162e -->

The founding team of Spark has proposed a cash grant of 1,100,000 USDS per month to the Spark Foundation from Spark’s Prime Treasury for a three (3) month period, beginning on October 1, 2025. The purpose of this grant is to enable Spark Foundation to fulfill its purpose of promoting the growth and development of Spark. This funding will support essential activities such as engineering and product development, community engagement and growth initiatives, research and governance contributions, infrastructure and operational maintenance, and administrative operations.

Sky Governance hereby consents to this cash grant. The transfer for October must be made to the Spark Foundation in a Spark Spell included in the October 2, 2025 Executive Vote. Transfers for subsequent months will be made proportionally in Spark Spells included in Sky Executive Votes unless otherwise agreed by Sky and Spark.

###### A.2.9.2.2.2.5.6 - Genesis Capital Backstop [Core]  <!-- UUID: 20e8467f-561c-4020-bd26-e6c1601fb64d -->

Each genesis capital allocation is subject to the Genesis Capital Backstop (see [A.3.7.1.5 - Genesis Capital Backstop](a9965d58-8cda-49fc-8a7f-f8cc2e0d6b98)).

###### A.2.9.2.2.2.6 - Intellectual Property [Core]  <!-- UUID: d276499a-2447-4dfb-a62b-4212c3d4b071 -->

The subdocuments herein set out agreed terms with respect to intellectual property.

###### A.2.9.2.2.2.6.1 - License Agreements [Core]  <!-- UUID: bfd79c66-ba55-46d2-a844-eaf8ef44d6d7 -->

Each Prime Foundation (i.e. the Spark Foundation and Grove Foundation) must sign a license agreement with Moonbow for all relevant intellectual property. This license agreement must contain the following terms:

- Worldwide, commercial, exclusive license, revocable for material breach (immediate revocation in severe cases, 30-day notice for non-severe cases).
- Royalty-free.
- Perpetual term, subject to termination provisions.
- Sublicensing allowed in specified cases without approval; any other sublicenses allowed only with Moonbow's explicit approval (not to be unreasonably withheld).
- Licensee responsible for IP protection and enforcement; license agreement to define specific requirements.
- Quarterly/annual reporting requirements on fraud cases and brand protection actions.
- Moonbow's right to audit (at Moonbow's cost).
- All improvements/developments belong to Moonbow.
- Monetary penalties for IP violations shall be explicitly defined in the full licensing agreement, with specific thresholds for triggering penalties to be mutually agreed and stipulated therein.
- Customary mutual indemnification and limitation of liability provisions.
- Mandatory arbitration except in case of injunctive relief.
- Other customary terms, conditions, representations and warranties.

###### A.2.9.2.2.2.6.2 - Open Source Protocol Code [Core]  <!-- UUID: fa90cec7-7b65-4798-a376-00cd8454bc0c -->

All components of code that form part of the Prime Protocols (i.e. Spark and Grove) will be open source.

###### A.2.9.2.2.2.6.3 - Financial Strategies [Core]  <!-- UUID: eb550b0a-3ffc-4a86-b8fe-9cc1f60f2a7e -->

The financial strategies implemented by the Prime Foundations (i.e. the Spark Foundation and Grove Foundation) will be closed source. Operational specifics are further defined in the subdocuments herein.

###### A.2.9.2.2.2.6.3.1 - Role Of Prime Foundation [Core]  <!-- UUID: ec0b206a-bf87-4ca8-aa7f-aa4ca1bc80f8 -->

The Prime Foundation (i.e. the Spark Foundation and Grove Foundation) will retain ownership of the code and strategies that determine how capital is allocated for its Prime. They will contract with the Development Company for the development and execution of the strategies.

###### A.2.9.2.2.2.6.3.2 - Role Of Development Company [Core]  <!-- UUID: d88e4c91-cce4-4f95-a989-ea876ccdf99b -->

The Development Company for each Prime Agent will execute the strategy and relay the results to the Operational Executor Agent.

###### A.2.9.2.2.2.6.3.3 - Role Of Operational Executor Agent [Core]  <!-- UUID: b0fc4a02-f41c-4556-b3f5-84d262ca00f2 -->

The relevant Operational Executor Agent, which is already engaged to the Prime in question, will conduct a principled compatibility analysis to ensure the strategy aligns with the Sky Atlas and the relevant Prime Artifact. Once validated, the Operational Executor Agent executes the capital allocation in question.

###### A.2.9.2.2.2.6.3.4 - Prime Tokenholder Governance Rights [Core]  <!-- UUID: 63717bcd-4696-4104-a368-eac839a7ba2b -->

To ensure accountability, Prime token holders will retain governance rights, including the ability to revoke the Operational Executor Agent’s Executor Accord through a vote if necessary.

###### A.2.9.2.2.2.7 - Peg Stability Module Management And Ownership [Core]  <!-- UUID: 63922aed-a1e4-43f2-a4a7-437b80ea6711 -->

The subdocuments herein set out agreed terms with respect to the Peg Stability Module (PSM).

###### A.2.9.2.2.2.7.1 - Current and Future Control [Core]  <!-- UUID: b66f99ce-af91-4b32-a37a-fb26d16b57c4 -->

The subdocuments herein set out details about the current control and oversight of the PSM, including the transition to ownership by Grove.

###### A.2.9.2.2.2.7.1.1 - Current Control (Until 2026) [Core]  <!-- UUID: 815fc554-c019-49b1-8b97-9eb62082cb5b -->

The Peg Stability Module (PSM) remains directly managed and controlled by Sky until the full deployment and operationalization of the Actively Stabilizing Collateral (ASC) system. Sky retains responsibility for setting debt ceilings, determining liquidity levels, and overseeing asset management activities within the PSM during this period.

###### A.2.9.2.2.2.7.1.2 - Transition to Grove (2025) [Core]  <!-- UUID: 08896aa0-140a-4289-9027-1772a0109a35 -->

Beginning in 2025, Grove shall assume operational and accounting ownership of the PSM, incorporating the PSM’s assets into its total value locked (TVL). Sky maintains active oversight and retains final control over strategic and operational decision-making within the PSM until full ASC implementation occurs.

###### A.2.9.2.2.2.7.2 - Operational Responsibilities [Core]  <!-- UUID: 704ccd85-e80e-478f-ab73-23d775968ca7 -->

The subdocuments herein set out details about operational responsibilities relating to the PSM.

###### A.2.9.2.2.2.7.2.1 - Base Rate Obligation [Core]  <!-- UUID: ff46baec-15da-4bf7-be18-e145f1809cf6 -->

Grove will be required to pay the Base Rate on all assets within the PSM. The Base Rate is dynamic and will align with the SSR (Sky Savings Rate), expected to fluctuate between the Aave and Ethena rates. See [A.2.9.2.2.2.2.3 - Base Rate](fd39df25-6093-49ae-be12-36df34754612).

###### A.2.9.2.2.2.7.2.2 - Yield on USDC [Core]  <!-- UUID: 223a695c-addd-443a-bfed-b136eeb2eddc -->

Grove shall earn yield through Coinbase Custody on USDC holdings within the PSM, enabling potential positive carry depending upon the spread between custody yield and the Base Rate.

###### A.2.9.2.2.2.7.2.3 - Economic Rationale [Core]  <!-- UUID: b1831dee-c95f-4872-98e0-2e49f3591bf9 -->

Grove will pay the Base Rate on the PSM for the purpose of meeting ASC requirements, if there are no better alternatives available. Unlike other alternatives, USDC in the PSM will have no capital requirement. If other, better options for ASC are available, Grove should empty the PSM and allocate the assets to those options. It is anticipated that other protocols will also be willing to rent ASC "points", potentially allowing for the management of ASC needs across several Prime Agents for a profit.

###### A.2.9.2.2.2.7.3 - Future Transition and Long-Term Vision [Core]  <!-- UUID: 1a26a561-1f03-4d83-81df-3dedc9688597 -->

The subdocuments herein set out agreed terms with respect to the future transition and long-term vision for the PSM.

###### A.2.9.2.2.2.7.3.1 - Short Term (2025-2026) [Core]  <!-- UUID: 54bd8ca5-d078-4b1e-9f0a-e843fe13e5c0 -->

The PSM will remain a central liquidity hub for stablecoin deployment. Grove will manage the PSM, paying the Base Rate while earning USDC yield, under Sky oversight until full ASC implementation. PSM assets will count toward Grove's TVL, enhancing its economic standing and collateral efficiency.

###### A.2.9.2.2.2.7.3.2 - Long Term (Post-2026) [Core]  <!-- UUID: 4478d3b2-f8bc-400f-b6da-3bb43684e94d -->

The PSM's role will diminish as the ASC system becomes the primary liquidity management tool. Grove can wind down the PSM entirely if ASC requirements are fulfilled through other mechanisms (e.g., Uniswap positions, Curve pools). If ASC obligations rise significantly, PSM usage will increase, but as the system matures, its relevance will gradually decline.

###### A.2.9.2.2.2.7.4 - Implications for Grove [Core]  <!-- UUID: 3215686b-a770-484d-9602-6ee9d84c0e44 -->

The subdocuments herein set out implications of the PSM terms with respect to Grove.

###### A.2.9.2.2.2.7.4.1 - Positive Carry And Liquidity Balancing [Core]  <!-- UUID: 9ed13fe5-7b07-4222-93ff-640880a976e2 -->

Grove can generate positive carry if the USDC yield exceeds the Base Rate. If the Base Rate rises significantly, the PSM may become costly, requiring liquidity balancing.

###### A.2.9.2.2.2.7.4.2 - Capital Efficiency [Core]  <!-- UUID: 207d4658-b6f4-4937-853c-b5d23cff3c89 -->

Grove can deploy USDC in high-yield strategies while retaining enough ASC to meet requirements. Aave USDC (aUSDC) and Curve LP positions are likely alternatives to direct PSM usage, albeit potentially with higher JRC requirements.

###### A.2.9.2.2.2.7.4.3 - Risk Management [Core]  <!-- UUID: 00aa264d-4fe6-41a1-91ea-014a2a520001 -->

The PSM serves as a capital buffer, enabling Grove to scale liquidity massively without additional credit enhancement. As ASC obligations fluctuate, the PSM will act as a dynamic backstop, ensuring resilience during periods of high demand.

###### A.2.9.2.2.2.8 - Token Launch Penalty, Capital Transfer, And Income Generation [Core]  <!-- UUID: 2df67c30-1644-4455-a3e4-f3047c4c49ae -->

The subdocuments herein set out agreed terms with respect to a token launch penalty, capital transfer, and income generation.

###### A.2.9.2.2.2.8.1 - Token Launch Penalty [Core]  <!-- UUID: 5a62cc3f-4337-4770-a4d1-8a9b3d158b3f -->

If either Spark or Grove (each, a "Prime") does not complete its Prime Token Generation Event ("TGE") by July 1, 2025, a penalty of thirty percent (30%) will apply. This penalty will be calculated on the income (as defined in [A.2.9.2.2.2.8.6 - Income Definition](fa48f7be-3c7d-4390-8b39-4fdfe9aa06ae)) the Prime is receiving or is meant to receive (including revenue that has accrued but has not been transferred) until the TGE occurs. 

The penalty shall be deducted from the Genesis Capital Allocation at the time of the Capital Transfer. If the Prime has already received its Genesis Capital Allocation, then the 30% penalty is paid as part of the Monthly Settlement Cycle. See [A.2.5.1.2.2.1.1.3 - Settlement](6dcd7515-3398-443a-9377-99e0c3cd0174).

###### A.2.9.2.2.2.8.2 - Transfer Of Capital Funds [Core]  <!-- UUID: 760c4258-50f7-4334-af21-888759194e64 -->

The transfer of the Genesis Capital Allocation to each Prime SubProxy (i.e. the Spark SubProxy and Grove SubProxy) shall occur once funding from the Surplus Buffer is approved. This condition ensures that capital deployment is aligned with the successful launch of the Prime’s token and the commencement of its independent operations. Any penalties applied under [A.2.9.2.2.2.8.1 - Token Launch Penalty](5a62cc3f-4337-4770-a4d1-8a9b3d158b3f) shall be deducted from the Capital Allocation at the time of transfer.

###### A.2.9.2.2.2.8.2.1 - Transfer Of Genesis Capital Allocation To Spark SubProxy [Core]  <!-- UUID: e3ec99ec-54c9-4fe7-8104-aee20c57ec57 -->

The transfer of 20.6 million USDS from the Surplus Buffer to the Spark SubProxy for the Genesis Capital Allocation must be included in the June 26, 2025 Executive Vote. This action is authorized to proceed directly to an Executive Vote without a prior Governance Poll.

This amount reflects that 4.4 million USDS of pre-TGE expenses were paid by Sky as specified in [A.2.9.2.2.2.8.4 - Treatment of Expenses Paid By Sky Pre-TGE](f3672ca1-b305-4e16-86f0-3dc3267073bb). This includes 2 million USDS transferred from the Sky Ecosystem Liquidity Bootstrapping Budget to Spark to provide liquidity to market makers and 2.4 million USDS transferred from the Ecosystem Liquidity Bootstrapping Budget to Spark to provide liquidity to exchanges. See [A.2.9.2.2.2.8.4.1 - Transfer From Liquidity Bootstrapping Budget To Spark For Market Makers](66abd123-f5cd-4d1a-bf75-2e5f468eae16) and [A.2.9.2.2.2.8.4.2 - Transfer From Liquidity Bootstrapping Budget To Spark For Exchanges](1d7924cd-8105-458f-a959-92f302b971d4).

No penalties were applied under [A.2.9.2.2.2.8.1 - Token Launch Penalty](5a62cc3f-4337-4770-a4d1-8a9b3d158b3f).

###### A.2.9.2.2.2.8.3 - Cessation Of MKR and SKY Token Flow [Core]  <!-- UUID: 91c1a218-ea12-4b75-ad71-efc4d1060e58 -->

Upon the commencement of Income Generation (as defined in [A.2.9.2.2.2.8.6 - Income Definition](fa48f7be-3c7d-4390-8b39-4fdfe9aa06ae)) by a Prime, any existing or previously agreed-upon allocation or distribution of MKR or SKY tokens from Sky to that Prime shall immediately cease. The intent is for the Primes to transition to financial self-sufficiency upon the initiation of their respective income-generating activities. Furthermore, any token vesting to the Prime Foundation will be reduced by 50% until the TGE occurs.  Prior to the TGE, Primes agree to share with Sky the Prime Agent Token vesting schedules and lock-ups for their teams to ensure they align with the principles of long-term commitment to the Prime.

###### A.2.9.2.2.2.8.4 - Treatment of Expenses Paid By Sky Pre-TGE [Core]  <!-- UUID: f3672ca1-b305-4e16-86f0-3dc3267073bb -->

Any operational or other expenses incurred by a Prime and paid directly by Sky after July 1, 2025 shall be treated as an advance against the Prime’s Genesis Capital Allocation. The total amount of such expenses shall be documented and shall be deducted from the Prime’s allocated capital funds at the time of the Capital Transfer (as outlined in [A.2.9.2.2.2.8.2 - Transfer Of Capital Funds](760c4258-50f7-4334-af21-888759194e64)).

###### A.2.9.2.2.2.8.4.1 - Transfer From Liquidity Bootstrapping Budget To Spark For Market Makers [Core]  <!-- UUID: 66abd123-f5cd-4d1a-bf75-2e5f468eae16 -->

Sky has transferred 2 million USDS from the Sky Ecosystem Liquidity Bootstrapping Budget to Spark to provide liquidity to market makers (see [A.5.5.1.1 - Sky Ecosystem Liquidity Bootstrapping](cd4ae79c-0e34-4388-8ac2-41d7677bd955)). This amount shall be treated as an advance against Spark’s Genesis Capital Allocation and deducted from Spark’s allocated capital funds at the time of the Capital Transfer.

###### A.2.9.2.2.2.8.4.2 - Transfer From Liquidity Bootstrapping Budget To Spark For Exchanges [Core]  <!-- UUID: 1d7924cd-8105-458f-a959-92f302b971d4 -->

Sky has transferred 2.4 million USDS from the Sky Ecosystem Liquidity Bootstrapping Budget to Spark to provide liquidity to exchanges (see [A.5.5.1.1 - Sky Ecosystem Liquidity Bootstrapping](cd4ae79c-0e34-4388-8ac2-41d7677bd955)). This amount shall be treated as an advance against Spark’s Genesis Capital Allocation and deducted from Spark’s allocated capital funds at the time of the Capital Transfer.

###### A.2.9.2.2.2.8.5 - Income Generation And Pre-TGE Credit [Core]  <!-- UUID: 3ae9fa89-97e6-46ac-9b8b-ecb77a10574f -->

"Income Generation" shall be deemed to commence on July 1, 2025. From that date until the Prime’s TGE, seventy percent (70%) of any income generated by the Prime’s activities shall be credited to its capital account (net of any expenses paid by Sky as per [A.2.9.2.2.2.8.4 - Treatment of Expenses Paid By Sky Pre-TGE](f3672ca1-b305-4e16-86f0-3dc3267073bb)), subject to any penalties.

###### A.2.9.2.2.2.8.6 - Income Definition [Core]  <!-- UUID: fa48f7be-3c7d-4390-8b39-4fdfe9aa06ae -->

"Income" means all revenues or fees received or accrued by the applicable Prime after July 1, 2025, including: (i) Distribution Rewards (see [A.2.9.2.2.2.3.1 - Distribution Reward Rate](8e3cde6b-3b8b-4e9a-b9a0-8c24d84881f6)), (ii) Distribution Reward Bonus for 2025 (see [A.2.9.2.2.2.3.2 - 2025 Bonus](7ca440d3-03fb-4fba-81a8-d2118dc47aa6)), (iii) any Platform Fees charged to users, and (iv) Real World Asset fees charged to users, including any origination, servicing, or related charges, and (v) the blended cost of allocation spread between Junior and Senior Risk Capital.

#### A.2.9.2.3 - Ecosystem Accord 3: Sky And Keel [Core]  <!-- UUID: 63a88b08-e6cd-48bf-9cec-64ce7e42ae0e -->

The subdocuments herein record the terms of agreement between Sky and Keel as agreed in Ecosystem Accord 3.

##### A.2.9.2.3.1 - Accord Key Details [Core]  <!-- UUID: 40a876f3-e0bb-4bdf-a980-ffa38d9f46d7 -->

The subdocuments herein set out the key details of Ecosystem Accord 3, such as parties to the agreement and the duration of the Accord.

###### A.2.9.2.3.1.1 - Parties To The Accord [Core]  <!-- UUID: 0577460f-3f87-44ea-b39b-a614e7507338 -->

The parties to Ecosystem Accord 3 are Sky and Keel, as defined in the subdocuments herein.

###### A.2.9.2.3.1.1.1 - Sky Details [Core]  <!-- UUID: 7042cc09-20d7-4a83-a0f0-c718cdc489f2 -->

The party ‘Sky’ comprises Sky Core.

###### A.2.9.2.3.1.1.2 - Keel Details [Core]  <!-- UUID: 2e888dad-7700-450a-be85-49d7405e3541 -->

The party ‘Keel’ comprises the Keel Prime Agent, Keel Foundation, and Matariki Labs.

###### A.2.9.2.3.1.2 - Duration Of The Accord [Core]  <!-- UUID: d936e118-89d8-4be7-9fcd-dd4d4334b26d -->

The duration of Ecosystem Accord 3 is indefinite, commencing from June 23, 2025.

##### A.2.9.2.3.2 - Accord Substantive Terms [Core]  <!-- UUID: ff6f7572-716f-4959-b312-a5ebf1547134 -->

The subdocuments herein set out the substantive terms of Ecosystem Accord 3.

###### A.2.9.2.3.2.1 - Transfer From Liquidity Bootstrapping Budget To Keel [Core]  <!-- UUID: a0b2e17d-1483-40d0-a771-f12c1b42a0a9 -->

Sky has transferred 500,000 USDS from the Sky Ecosystem Liquidity Bootstrapping Budget to Keel to provide liquidity to decentralized finance protocols on Solana (see [A.5.5.1.1 - Sky Ecosystem Liquidity Bootstrapping](cd4ae79c-0e34-4388-8ac2-41d7677bd955)). This amount shall be treated as an advance against Keel’s Genesis Capital Allocation and deducted from Keel’s allocated capital funds at the time of the Capital Transfer.

The transfer must be made to a multisig controlled by Keel’s Operational Executor Agent and the multisig must have the ability to withdraw the liquidity provided to decentralized finance protocols at any time. The address of the multisig on Solana is `6cTVPDJ8WR1XGxdgnjzhpYKRqcv78T4Nqt95DY8dvMmn`.

###### A.2.9.2.3.2.1.1 - Use Of Funds For Keel Development Expenses [Core]  <!-- UUID: 4109ab2b-e1ae-43bb-8f96-d1cb07f98a5c -->

Keel may also use the funds specified in [A.2.9.2.3.2.1 - Transfer From Liquidity Bootstrapping Budget To Keel](a0b2e17d-1483-40d0-a771-f12c1b42a0a9) to fund development expenses at its discretion.

If Keel elects to use funds in this way, it shall notify its Operational Executor Agent of the amount to be used for development expenses. The Operational Executor Agent will then withdraw the liquidity from the decentralized finance protocols, if necessary, and transfer it to an account designated by Keel.

###### A.2.9.2.3.2.2 - Pre-Pioneer Incentive Pool [Core]  <!-- UUID: c929aef7-1b81-4693-8fd8-3d75e62882af -->

Keel is eligible for a Pre-Pioneer Incentive Pool. See [A.2.3.8.3.1.4.1 - Pre-Pioneer Incentive Pool](15e14f25-8d56-4699-ac37-0cef4f0503c5). 

The Pre-Pioneer Incentive Pool is calculated on a monthly basis as (1) the Sky Savings Rate multiplied by all USDS balances on Solana, less (2) all Integration Boost payments made to partners on Solana.
Payments are made on a monthly basis from the Integration Boost wallets specified in [A.2.3.8.2.2.1.3.2.1 - Near Term Process](4ab621b4-ef8e-4b01-a6aa-9296601033c5) to a Pre-Pioneer Incentive Pool wallet controlled by Keel’s Operational Executor Agent. The address of the Pre-Pioneer Incentive Pool wallet on Solana is `8JmDPG5BFQ6gpUPJV9xBixYJLqTKCSNotkXksTmNsQfj`.

Funds from the Pre-Pioneer Incentive Pool wallet may be used to incentivize partners on Solana to promote USDS adoption as directed by Keel. Funds from the Pre-Pioneer Incentive Pool may not be transferred to Keel’s SubProxy Account, Keel Foundation, or Matariki Labs.

#### A.2.9.2.4 - Ecosystem Accord 4: Sky And Obex [Core]  <!-- UUID: 6bddc5aa-ac80-43d8-b8c8-8cde14e896df -->

The subdocuments herein record the terms of agreement between Sky and Obex as agreed in Ecosystem Accord 4.

##### A.2.9.2.4.1 - Accord Key Details [Core]  <!-- UUID: b82be738-892e-4d55-a42f-84fc1fdf3064 -->

The subdocuments herein set out the key details of Ecosystem Accord 4, such as parties to the agreement and the duration of the Accord.

###### A.2.9.2.4.1.1 - Parties To The Accord [Core]  <!-- UUID: 2cd5a1de-89d0-47d0-b671-87d8fec45766 -->

The parties to Ecosystem Accord 4 are Sky and Obex, as defined in the subdocuments herein.

###### A.2.9.2.4.1.1.1 - Sky Details [Core]  <!-- UUID: acb3e4c8-5edb-4ff0-bf47-e0a770cc08e7 -->

The party ‘Sky’ comprises Sky Core.

###### A.2.9.2.4.1.1.2 - Obex Details [Core]  <!-- UUID: 665a712a-d211-4a7a-b4c9-a8bad61b3f9c -->

The party ‘Obex’ comprises the Obex Prime Agent, Obex Foundation, and Rubicon.

###### A.2.9.2.4.1.2 - Duration Of The Accord [Core]  <!-- UUID: 90e40d2a-3baa-411f-9512-b7cf61762a75 -->

The duration of Ecosystem Accord 4 is indefinite, commencing from November 13, 2025.

##### A.2.9.2.4.2 - Accord Substantive Terms [Core]  <!-- UUID: ec71c718-4a93-4cd7-8324-11d00110bbd3 -->

The subdocuments herein set out the substantive terms of Ecosystem Accord 4. Additional detail regarding the substantive terms of Ecosystem Accord 4 will be specified in a future iteration of the Atlas, as agreed by the Parties to the Accord.

###### A.2.9.2.4.2.1 - Genesis Capital Allocation [Core]  <!-- UUID: b9e591ad-fd43-42fa-9262-aa9589c79ea3 -->

The subdocuments herein set out agreed terms with respect to Genesis Capital Allocation.

###### A.2.9.2.4.2.1.1 - Obex Initial Allocation [Core]  <!-- UUID: a15698be-8723-4bab-9b25-f393deec41e2 -->

The Initial Allocation for Obex is 21,000,000 USDS.

###### A.2.9.2.4.2.1.2 - Initial Allocation Distribution [Core]  <!-- UUID: 2ace92dc-2a09-4d9e-9bae-9ea4da1b2f38 -->

The Initial Allocation is distributed in USDS to the Obex SubProxy.

###### A.2.9.2.4.2.1.2.1 - Transfer Of Genesis Capital Allocation To Obex SubProxy [Core]  <!-- UUID: c39702fb-bb6a-43c7-b208-18ddd279b1d3 -->

The transfer of 21,000,000 USDS from the Surplus Buffer to the Obex SubProxy for the Genesis Capital Allocation must be included in the November 13, 2025 Executive Vote. This action is authorized to proceed directly to an Executive Vote without a prior Governance Poll.

#### A.2.9.2.5 - Ecosystem Accord 5: Sky And Core Council Executor Agent 1 [Core]  <!-- UUID: a5ab4947-0492-4069-8048-777a46bda48c -->

The subdocuments herein record the terms of agreement between Sky and Core Council Executor Agent 1 as agreed in Ecosystem Accord 5.

##### A.2.9.2.5.1 - Accord Key Details [Core]  <!-- UUID: dcebaf4b-7ade-4d85-8d57-cb69b517661e -->

The subdocuments herein set out the key details of Ecosystem Accord 5, such as parties to the agreement and the duration of the Accord.

###### A.2.9.2.5.1.1 - Parties To The Accord [Core]  <!-- UUID: a122d268-5a49-44d5-b6ef-d30ef9834f60 -->

The parties to Ecosystem Accord 5 are Sky and Core Council Executor Agent 1, as defined in the subdocuments herein.

###### A.2.9.2.5.1.1.1 - Sky Details [Core]  <!-- UUID: 9f0d7d1b-a969-4151-9bb8-8edfc7dee478 -->

The party ‘Sky’ comprises Sky Core.

###### A.2.9.2.5.1.1.2 - Core Council Executor Agent 1 Details [Core]  <!-- UUID: faf48381-9d1d-471d-87c0-b929ca1d3eb0 -->

The party ‘Core Council Executor Agent 1’ comprises the Core Council Executor Agent 1 Executor Agent, Core Council Executor Agent 1 Foundation, and Core Council Executor Agent 1 Development Company.

###### A.2.9.2.5.1.2 - Duration Of The Accord [Core]  <!-- UUID: 75f51fec-9b23-4465-9130-0412534eed50 -->

The duration of Ecosystem Accord 5 is indefinite, commencing from December 11, 2025.

##### A.2.9.2.5.2 - Accord Substantive Terms [Core]  <!-- UUID: 52af6863-02c0-46b3-bbb4-edfeb1fb0a58 -->

The subdocuments herein set out the substantive terms of Ecosystem Accord 5. Additional detail regarding the substantive terms of Ecosystem Accord 5 will be specified in a future iteration of the Atlas, as agreed by the Parties to the Accord.

###### A.2.9.2.5.2.1 - Role As Core Executor Agent [Core]  <!-- UUID: 04771dab-4548-4974-9298-e4dba3600f44 -->

Core Council Executor Agent 1 will serve as the first Core Executor Agent and must carry out the responsibilities of the Core Council. See [A.0.1.1.46 - Core Council](5a03a0c4-a47a-409c-9b23-52ac93e63d45).

###### A.2.9.2.5.2.2 - Genesis Capital Allocation [Core]  <!-- UUID: 469cfffe-9912-4f80-ac72-089a294c6710 -->

To effect the Genesis Capitalization of Core Council Executor Agent 1, Sky Core shall directly transfer (1) 20,000,000 USDS to the Core Council Executor Agent 1 SubProxy and (2) 5,000,000 USDS to the Core Council Buffer (see [A.2.4.1.4.1.1.1 - Core Council Buffer](8b6781d7-f35c-4ffe-b8ed-299fa98e3da7)). The 5,000,000 USDS transfer constitutes part of Core Council Executor Agent 1’s Genesis Capital Allocation, deposited directly to its operational payment account.

###### A.2.9.2.5.2.2.1 - Core Council Executor Agent 1 SubProxy Address [Core]  <!-- UUID: ecfd2fd6-5da3-41a8-af02-a70e6b3eaabb -->

The address of Core Council Executor Agent 1’s SubProxy Account will be specified in the Technical Scope Forum Post for the deployment of the SubProxy Account.

###### A.2.9.2.5.2.2.2 - Use Of Genesis Capital [Core]  <!-- UUID: f4c090e9-1fce-4225-8271-e64c442099c7 -->

The Genesis Capital Allocation will be used to fund the Core Council Executor Agent 1; the incubating Operational Executor Agents; and broader Core operational expenses, including technical infrastructure, spell crafting, risk work, and spell audits.

###### A.2.9.2.5.2.3 - Funding Of Core Council Buffer [Core]  <!-- UUID: 966e8f26-c92f-4015-ab88-b8aaebcaa553 -->

The Core Council Executor Agents holding seats on the Core Council maintain operational authority over the Core Council Buffer, consistent with their mandate to operationalize Sky Core.

Core Council Executor Agent 1 may capitalize the Core Council Buffer from its Genesis Capital allocation to ensure adequate liquidity for operational payments prior to its establishment of dedicated payment infrastructure.

Expenses paid through the Core Council Buffer shall be recorded as operational expenses of Core Council Executor Agent 1, whether funded by the Genesis Capital Allocation deposited directly to the Core Council Buffer or by subsequent transfers from the Core Council Executor Agent 1 SubProxy prior to the establishment of independent payment infrastructure.

### A.2.9.0.3.1 - Business Activities - Element Annotation [Annotation]  <!-- UUID: 31df7e2b-184f-428c-9c4f-23fd8054c5d3 -->

The element "business activities" refers to the commercial activities, transactions, and interactions that Ecosystem Actors perform within the ecosystem. These may include, but are not limited to, service delivery, product development, collaboration, and information exchange.

### A.2.9.0.3.2 - Ecosystem - Element Annotation [Annotation]  <!-- UUID: ed6d46b7-01bc-4b3f-a951-e75c3f40351a -->

The element "Ecosystem" in the phrase "Ecosystem Accords" should be understood as the collaborative network in which multiple stakeholders (referred to as "Ecosystem Actors") interact to conduct business operations benefiting Sky.

## A.2.10 - Legal Resilience [Article]  <!-- UUID: ac707ae4-65da-4cf9-8a34-8b9304cd9a95 -->

This Article governs the Resilience Fund and defines infrastructure and processes to support legal risk management and legal governance.

### A.2.10.1 - Legal Resilience [Section]  <!-- UUID: 2abdcb34-3863-40d9-8dd1-52516cb1fa96 -->

This Section manages the Resilience Fund (also "RF") and other infrastructure for legal risk management and legal governance.

#### A.2.10.1.1 - Legal Defense Resources [Core]  <!-- UUID: 8f2eb896-4736-4649-a054-1c76dae64dc6 -->

This document defines the resources available for legal defense. Over time, it can include both Sky Governance-controlled assets and external third-party resources and may be used to cover additional risks.

##### A.2.10.1.1.1 - Resilience Fund [Core]  <!-- UUID: ccd36a29-af79-4994-93b4-b07d150b0366 -->

The Resilience Fund (RF) is a self-insurance instrument fully controlled by Sky Governance, which will cover legal defense expenses in case of legal or regulatory action against Sky or active participants in the Sky Ecosystem. The RF will be the primary source for direct legal defense funding. The conditions of use are defined in [A.2.10.1.1.1.4.2 - Resilience Fund Claim Management Process](9ab8fdf3-939c-4096-a0b9-9d9486d5a339).

###### A.2.10.1.1.1.1 - Resilience Fund Budget [Core]  <!-- UUID: 43c65f87-9de3-42ce-ab1c-e9bf420b6920 -->

The budget of the Resilience Fund is defined in [A.2.10.1.1.1.1.1 - Resilience Fund Current Budget](aa1e93e5-8fc0-4e12-ad9d-8bb9f6cd8956). The Support Facilitator can propose to pay out the budget manually through a Weekly Governance Cycle, according to the rules related to claims described in this Section. The Support Facilitator can propose modifications to the document cited above through the Weekly Governance Cycle.

###### A.2.10.1.1.1.1.1 - Resilience Fund Current Budget [Core]  <!-- UUID: aa1e93e5-8fc0-4e12-ad9d-8bb9f6cd8956 -->

The current active budget for the Resilience Fund is: 5,000,000 USDS per year, with the full amount available at the start of each calendar year.

###### A.2.10.1.1.1.1.2 - Resilience Fund Transition Funding [Core]  <!-- UUID: cbcfc2ff-d26a-4e2d-896d-273ed2eb8a94 -->

Legal defense expenses directly related to Sky may be temporarily financed using the resources of the Resilience Fund. However, a separate Claim Protocol and Standard Operational Protocol must be developed to govern cases where Sky is the target of a legal or regulatory action.

###### A.2.10.1.1.1.1.2.0.3.1 - Separate Claim Protocol And Standard Operational Protocol - Element Annotation [Annotation]  <!-- UUID: b1cbe4dd-1df7-461f-b6dd-315d899f922c -->

The element refers to a separate set of procedures to be applied where Sky is the target of a legal or regulatory action. These separate procedures have not yet been defined. Once defined and ratified, they will be detailed in [A.2.10.1.1.4 - Legal Defense Standard Operational Protocols](bd82af2f-6617-4d4e-8acb-e23c7d2c904b). The Resilience Technical Committee must assist in elaborating this ruleset.

###### A.2.10.1.1.1.2 - Resilience Fund Technical Committee [Core]  <!-- UUID: 469a7e0b-0ded-45cf-9911-06723bf0cfd4 -->

The Resilience Technical Committee is a group of Ecosystem Actors authorized by Sky to provide operational support such as onboarding new beneficiaries to the RF, approving quotes, and assessing claims to be supported by the RF. Additional operational support includes providing general advice on the further development of the fund, amendments to the claim procedure, resilience measures and other risk-management topics.

###### A.2.10.1.1.1.2.1 - Resilience Fund Technical Committee Selection And Compensation [Core]  <!-- UUID: 71352327-3ea8-4a47-ae7e-5ccff35d5763 -->

The Support Facilitator selects the members of the Resilience Technical Committee and manages payments for their services on a project basis. The associated budget is defined in  [A.2.10.1.1.1.1.1 - Resilience Fund Current Budget](aa1e93e5-8fc0-4e12-ad9d-8bb9f6cd8956).

###### A.2.10.1.1.1.2.2 - Resilience Fund Technical Committee Member Requirements [Core]  <!-- UUID: ad242c8e-81e3-4590-b034-722b3767b9d2 -->

The individual members of the Resilience Technical Committee who are directly involved in providing operational services on behalf of Sky must fulfill the requirements defined in the subdocuments herein.

###### A.2.10.1.1.1.2.2.1 - Resilience Fund Technical Committee Member Skill Set Requirement [Core]  <!-- UUID: 524ad7de-c3ee-4c5f-8c92-a5fdbb4aa29b -->

Members of the Resilience Technical Committee must have relevant experience or current employment in the legal industry, or with a world-leading insurance broker, insurance company, or risk management firm.

###### A.2.10.1.1.1.2.2.2 - Resilience Fund Technical Committee Member Experience Requirement [Core]  <!-- UUID: d931273b-cdcb-40d3-97a5-d4bafcd38981 -->

Members of the Resilience Technical Committee must have at least three (3) years of experience managing self-insurance instruments or experience in legal or regulatory risk analysis.

###### A.2.10.1.1.1.2.2.3 - Resilience Fund Technical Committee Member Professional Degree Requirement [Core]  <!-- UUID: 19e4c5ce-1a9c-4df4-b8e7-5e22d27450b6 -->

Members of the Resilience Technical Committee must have a law, management, risk, or insurance professional degree.

###### A.2.10.1.1.1.2.2.4 - Resilience Fund Technical Committee Member No Conflicts Requirement [Core]  <!-- UUID: a7d9166a-6ac6-4592-a67c-19f1a59f9355 -->

Members of the Resilience Technical Committee must not be involved in any business activity outside Sky or in any role within Sky that could result in a conflict of interest, either directly or indirectly.

###### A.2.10.1.1.1.2.2.5 - Resilience Fund Technical Committee Member Technology Experience Requirement [Core]  <!-- UUID: 9f1b0abd-9000-4df7-8aa4-82a7234608ac -->

Members of the Resilience Technical Committee must have at least three (3) years of experience in the cryptocurrency, DeFi, Web3, or emerging technology sectors.

###### A.2.10.1.1.1.2.3 - Resilience Fund Technical Committee Current Membership [Active Data Controller]  <!-- UUID: ab894e9e-b423-404b-8488-3d0578bbde28 -->

Approved Resilience Technical Committee members are defined as Active Data in [A.2.10.1.1.1.2.3.0.6.1 - Resilience Fund Technical Committee List Of Current Members](10b0e0aa-0338-40d7-b1e6-a29442c206e6).

The Active Data is updated as follows:

- The Responsible Party is the Support Facilitators.

- The Update Process must follow the protocol for ‘Direct Edit’.

###### A.2.10.1.1.1.2.3.0.6.1 - Resilience Fund Technical Committee List Of Current Members [Active Data]  <!-- UUID: 10b0e0aa-0338-40d7-b1e6-a29442c206e6 -->

List of active Resilience Technical Committee Members:

- Gallagher

###### A.2.10.1.1.1.3 - Resilience Fund Policy [Core]  <!-- UUID: bf8f69ef-6e55-47be-9203-02036a7f8c0d -->

This provision and its subdocuments will govern the conditions and terms of use of the Resilience Fund.

###### A.2.10.1.1.1.3.1 - Resilience Fund Policy Loss Events [Core]  <!-- UUID: 9cb0c1c3-269b-433b-ac03-de4b0bec43fb -->

The Resilience Process covers legal defense or legal representation expenses incurred by a participant of the Sky Ecosystem when they are the defendant or respondent in a legal or regulatory action ("The Loss Event"). There must be a direct relationship between the legal or regulatory action and the Beneficiary’s activity at Sky.

A (non-exhaustive) list of legal or regulatory actions that may qualify is:

- Official requirements, or communications, from a regulatory body, governmental authority, or a court

- Subpoenas

- Lawsuit

- Writs

###### A.2.10.1.1.1.3.2 - Resilience Fund Policy Exclusions [Core]  <!-- UUID: b6f8e9a3-8e56-41fd-b760-a81834d4e214 -->

The cases specified in the following subelements will generally be excluded from coverage by the legal defense process:

- Prior or pending claims

- Claims between persons involved in the Sky Ecosystem

- Loss covered by other insurance

- Willful criminal offenses, fraud, or dishonesty

- Conflict of interest

###### A.2.10.1.1.1.3.3 - Resilience Fund Policy Beneficiaries [Core]  <!-- UUID: 8b3a5bf0-ac9a-4142-8fc6-dfcab8c385e9 -->

Eligible beneficiaries of the Resilience Fund are persons who fulfill the following requirements:

a) act on their own behalf OR b) act on behalf of a legal entity OR c) act on behalf of a collective AND have one of the following roles:

Previous Structure:
- Recognized Delegates
- Core Unit Facilitators
- Core Unit Contributors
- Dai Foundation Board Members

Current Structure:
- Active SKY or Agent token holders that participate regularly in governance (e.g., voting, writing proposals)
- Alignment Conservers 
◦ Aligned Delegates (ADs)
- Scope Facilitators
- The Guardian ([A.2.10.1.1.3 - The Guardian](0f808bde-fc68-4bda-bc6d-049c6aaaab1b)) or actors that fulfill an equivalent role.

###### A.2.10.1.1.1.3.3.1 - No Acquired Right Or Claim For Resilience Fund Policy Beneficiaries [Core]  <!-- UUID: 5b88e18f-dadc-47b2-af7c-e9ff8039d39e -->

Persons qualified as beneficiaries do not have any acquired right or claim. The claim decision process is described in [A.2.10.1.1.1.4 - Resilience Fund Processes And Principles](06aed112-2636-4478-b2c8-037808adc475), and the payout of a claim is subject to the approval of the Resilience Technical Committee (at their sole and absolute discretion) and further contingent on a SKY vote endorsing payment of the claim.

###### A.2.10.1.1.1.3.4 - Resilience Fund Policy Geographic Coverage [Core]  <!-- UUID: 3b1f2fc4-3d6c-445b-806b-1dbae77d8ad1 -->

Geographical coverage is worldwide.

###### A.2.10.1.1.1.3.5 - Resilience Fund Policy Effective Date [Core]  <!-- UUID: 9de7d51b-32f3-4746-b97d-9eb75a189cb6 -->

A Beneficiary’s eligibility for coverage under this Artifact will start after ratification of MIP106: 2023-03-27. ("Effective Date") and expire twenty-four (24) months after cessation of their role as a Beneficiary.

###### A.2.10.1.1.1.3.6 - Resilience Fund Policy Base Of Coverage [Core]  <!-- UUID: 9204cca6-3e91-4a34-b8be-fa6135d41f24 -->

Coverage is "Claims made". This means the Loss Event ([A.2.10.1.1.1.3.1 - Resilience Fund Policy Loss Events](9cb0c1c3-269b-433b-ac03-de4b0bec43fb)) must occur after the Effective Date ([A.2.10.1.1.1.3.5 - Resilience Fund Policy Effective Date](9de7d51b-32f3-4746-b97d-9eb75a189cb6)).

The facts and circumstances that originated the Loss Event may have occurred in the past for a maximum period of up to twenty-four (24) months before the date representing the later of (a) the Effective Date and (b) the date the Beneficiary is first eligible for coverage under this Artifact (the "Retroactivity Period").

###### A.2.10.1.1.1.4 - Resilience Fund Processes And Principles [Core]  <!-- UUID: 06aed112-2636-4478-b2c8-037808adc475 -->

Overview of the related processes and principles:

- Application process

- Claim management process

- Caps and Exclusions

- Refund of amounts to the Resilience Fund

###### A.2.10.1.1.1.4.1 - Resilience Fund Application Process [Core]  <!-- UUID: 7ee909ce-ae6d-4886-a0ea-c3017eb00bcd -->

The Resilience Fund application process is defined in the subdocuments of this document.

###### A.2.10.1.1.1.4.1.1 - Resilience Fund Proof Of Eligibility [Core]  <!-- UUID: c14521ea-e2fa-4853-a5af-64f4c96a526a -->

To become recognized as a Beneficiary, an Applicant must first select an Ethereum address that is linked to their activity at Sky ("Proof of Eligibility" or "POE"). Each Beneficiary type will have specific Proofs of Eligibility that are suitable for their role.

Valid PoE:

- Address set as owner and used to sign transactions from Sky multisigs, such as Core Unit operational wallets, auditor wallets or SPFs (old structure), or a Facilitator multisig (Endgame Structure)

    ◦ PoE valid for former Core Unit Contributors, Core Unit Facilitators, and Scope Facilitators.

- Address that voted directly or through delegation in at least ten Governance Polls or Executive Votes.

    ◦ PoE valid for active MKR or SKY holders, former Recognized Delegates (old structure), and Aligned Delegates (new structure)

- Address that received compensation from Sky, with the following conditions:

    ◦ at least six (6) payouts spread over at least six (6) months in Dai or USDS OR

    ◦ Dai or USDS DssVest stream spanning at least six (6) months OR

    ◦ 3 MKR or SKY payouts spread over at least three (3) months OR

    ◦ MKR or SKY DssVest stream spanning at least three (3) months
    ◦ PoE valid for former Core Unit Contributors and Facilitators

- Address that holds >1 MKR or >24,000 SKY

- Attestation

    ◦ If no PoE is available, a verified Beneficiary must attest eligibility on behalf of the applicant.

    ◦ This PoE will be used exceptionally if no other Proof is available and will be assessed individually by the Resilience Fund Technical Committee.

###### A.2.10.1.1.1.4.1.2 - Resilience Fund Proof Of Eligibility Template [Core]  <!-- UUID: a457da07-943a-4d98-8153-db7b0eb55fe2 -->

Applications for the Resilience Fund must follow this template:

- .x: [Application RF]

- .x.1: [PoE]

- .x.2: [Active Period]

- .x.3: [Relevant Executive Proposal: Governance decision ratified by a governance vote]

- .x4: [Signature hash]

###### A.2.10.1.1.1.4.1.3 - Resilience Fund Proof Of Eligibility Digital Signature [Core]  <!-- UUID: c83e0e76-f5b2-43f1-9bef-14c6571e72e2 -->

The Applicant for the Resilience Fund must additionally sign an application message from the Ethereum Address (Digital Signature) used as PoE [A.2.10.1.1.1.4.1.1 - Resilience Fund Proof Of Eligibility](c14521ea-e2fa-4853-a5af-64f4c96a526a).

###### A.2.10.1.1.1.4.1.4 - Application Resilience Fund Application Terms And Conditions [Core]  <!-- UUID: 0e430890-6911-4d22-98e7-f46eecb1ac24 -->

By signing this message, the Applicant accepts and agrees:

- To comply with the terms and rules of [A.2.10 - Legal Resilience](ac707ae4-65da-4cf9-8a34-8b9304cd9a95) (the "Legal Resilience Fund Terms").

- That participation in the program is opt-in and voluntary and can be waived anytime by the Beneficiary.

- The Legal Resilience Fund Terms can be amended at any time through the established governance processes.

- That being registered as Beneficiary does not give rise to any right, benefit, entitlement, or claim, nor creates an obligation on any party to pay the Beneficiary.

Additionally, the Beneficiary declares that:

- No situation currently involves or appears to involve a conflict of interest, and any emerging potential conflict of interest shall be disclosed as soon as it happens.

- Any role change in Sky or termination of active engagement will be immediately communicated to the Resilience Technical Committee.

The Resilience Technical Committee will elaborate a user-friendly onboarding manual for the RF.

###### A.2.10.1.1.1.4.1.5 - Resilience Fund Application Confirmation [Core]  <!-- UUID: 12bfa6fd-df07-4222-858c-11ae6b75509d -->

The Applicant for the Resilience Fund will additionally send an encrypted message to the Resilience Technical Committee Member in charge of the onboarding process to confirm the application.

###### A.2.10.1.1.1.4.1.6 - Resilience Fund Approval Process And Verifiability [Core]  <!-- UUID: 980b1bb1-3282-48ec-aff7-54107a580bf5 -->

PoEs rely on a governance decision that was ratified by an Executive Vote.

The Resilience Technical Committee Member must identify this governance decision by verifying the spell that enacted the Executive Vote ratifying the respective governance decision. This spell contains the hash of the respective Executive Vote. Exceptional circumstances where no direct governance decision is available or difficult to assert will be handled case by case.

The Resilience Technical Committee Member will confirm the onboarding decision via an encrypted message to the Applicant.

###### A.2.10.1.1.1.4.2 - Resilience Fund Claim Management Process [Core]  <!-- UUID: 9ab8fdf3-939c-4096-a0b9-9d9486d5a339 -->

Overview of the claim management processes:

- Legal Counsel Pre-approval

- Claim approval / Advance Payment

- Reimbursement

###### A.2.10.1.1.1.4.2.1 - Resilience Fund Legal Counsel And Quote Pre-Approval [Core]  <!-- UUID: 49ecea76-a16d-4135-88db-ccd554866715 -->

The first step in the claim management process is to approve the Legal Counsel to undertake legal defense or representation and the quote presented to commence legal work. The Beneficiary must present the quote from the law firm they selected for their legal defense/representation. The request must indicate at least the following:

- Name of Legal Counsel

- Name of Law Firm

- If not in the Lawyer Registry, Proof of Eligibility

- Quote

The quote must include:

1. The initial payment required by Counsel to commence work immediately. This is the initial amount to be claimed against the Resilience Fund.

2. A global estimated fee based on an hourly rate OR fixed fee OR monthly retainer fee.

###### A.2.10.1.1.1.4.2.1.1 - Resilience Fund Qualified Counsel [Core]  <!-- UUID: bdb4beda-794e-42e6-a9d0-06632235c478 -->

If the Legal Counsel is RF-qualified in the Lawyer Registry ([A.2.10.1.1.2 - Lawyer Registry](4c327b04-48f7-4941-b996-1c629eb42bf7)), the claim is automatically submitted to the Claim Approval process ([A.2.10.1.1.1.4.2.2 - Resilience Fund Claim Approval](d9cd69ff-88ed-4869-9ca7-ff87ce8f1ff6)).

###### A.2.10.1.1.1.4.2.1.2 - Not Resilience Fund Qualified Counsel [Core]  <!-- UUID: 9f423880-3184-4172-9ac5-6e8a371f5bb0 -->

If Legal Counsel is NOT RF-qualified in the Lawyer Registry ([A.2.10.1.1.2 - Lawyer Registry](4c327b04-48f7-4941-b996-1c629eb42bf7)), then the Support Facilitators, or alternatively the Resilience Fund Technical Committee Member, will verify if the Legal Counsel complies with requisites in Lawyer Registry Acceptance Criteria and LR Resilience Fund Acceptance Criteria. See:  [A.2.10.1.1.2.2 - Lawyer Registry Acceptance Criteria](2b66ce16-d104-4238-b7d5-e4c6fe8d961b) and [A.2.10.1.1.2.3 - Resilience Fund Representation Requirements](b39f4808-18ae-456b-86fc-d449a69ea99a).

If the Legal Counsel of the quote is determined by the Resilience Technical Committee to comply with the requirements of this Artifact, the quote is pre-approved and the legal counsel is added to the LR.

If the Legal Counsel doesn’t comply with the LR requirements, the claim is rejected and the Beneficiary must propose a different Legal Counsel.

###### A.2.10.1.1.1.4.2.2 - Resilience Fund Claim Approval [Core]  <!-- UUID: d9cd69ff-88ed-4869-9ca7-ff87ce8f1ff6 -->

If a Beneficiary incurs a Loss Event, they can submit a Reimbursement Payout Claim against the LD RF according to the process specified in the subdocuments herein.

###### A.2.10.1.1.1.4.2.2.1 - Resilience Fund Claim Approval Payout Claim [Core]  <!-- UUID: d47f9aa8-96d1-4be7-910c-505693b1784a -->

The Support Facilitator must review the Reimbursement Claim and decide whether to trigger a Governance Poll to perform a claims payout, by developing an internal model with input from experts and professionals.

The Payout Reimbursement Claim must contain the following elements:

    ◦ Description of Loss Event with relevant commentaries and context

    ◦ Advance Payment or Reimbursement

    ◦ Type of process

    ◦ Date of writ/subpoena/lawsuit

    ◦ Supportive Documentation

        ▪ Law firm’s proposal and invoice OR quote

        ▪ Copy of the Lawsuit/writ/ communication OR official requirement issued by a Court or Governmental Agency Supportive documentation is highly sensible. It is required to use encryption tools.

###### A.2.10.1.1.1.4.2.2.2 - Resilience Fund Claim Approval Coverage Framework [Core]  <!-- UUID: fe131e29-a159-453e-a3e0-7577af4e147b -->

In consultation with the Resilience Technical Committee, the Support Facilitators must develop a framework for establishing limits and coverage amounts per case, and apply these limits to individual claims.

###### A.2.10.1.1.1.4.2.2.3 - Resilience Fund Claim Approval Support Facilitators Review [Core]  <!-- UUID: 26044d1d-f92c-4945-9a1c-4907c56d4038 -->

The Support Facilitators will review the Payout Claim and if it contains all required elements and supportive documentation, will immediately transmit it to the Resilience Fund Technical Committee.

###### A.2.10.1.1.1.4.2.2.4 - Resilience Fund Claim Approval Technical Commitee Review [Core]  <!-- UUID: 07cd5714-47aa-46ef-a162-ab96875631d6 -->

The Resilience Fund Technical Committee will verify the merits of the claim according to the following substantial criteria (non-exhaustive list):

- Absence of Exclusions

- Identity and Role of Beneficiary

- Time scope

- Authenticity of writ/lawsuit

- Reasonability of lawyer fees, which must take into account market rates in the respective jurisdiction

###### A.2.10.1.1.1.4.2.2.5 - Resilience Fund Claim Approval Technical Committee Review Process [Core]  <!-- UUID: 313d72e5-62db-4dd4-b125-97467508f44c -->

From the moment the Payout Claim is filed, the Resilience Technical Committee will have five (5) working days to provide a payout recommendation. The recommendations of the Technical Committee are made in their sole and absolute discretion, are definitive, and are not subject to appeal.

###### A.2.10.1.1.1.4.2.2.6 - Resilience Fund Claim Approval Quorum And Decision Majorities [Core]  <!-- UUID: 10662753-b167-4043-b952-225cc9dd9e49 -->

Decisions related to claim payouts require a quorum of three (3) experts from the Resilience Technical Committee with a simple majority (>50%).

###### A.2.10.1.1.1.4.2.2.7 - Resilience Fund Claim Approval Decision Protections [Core]  <!-- UUID: 99079da7-e8e9-4660-96a6-269625d821cc -->

The recommendations of the Resilience Technical Committee are non-binding and will not give rise to any right or claim to the beneficiaries nor give rise to any obligation or responsibility.

###### A.2.10.1.1.1.4.2.2.8 - Resilience Fund Claim Approval Support Facilitators Decision [Core]  <!-- UUID: bf63fc62-3555-4b9b-a561-053fb35721b5 -->

Based on the recommendation of the Resilience Technical Committee, the Support Facilitators will decide whether to trigger a Governance Poll through the Weekly Governance Cycle to perform a claim payout.

###### A.2.10.1.1.1.4.2.3 - Resilience Fund Payout / Reimbursement [Core]  <!-- UUID: 9edd8feb-790b-42de-bf42-ba5d6550df1c -->

If the Governance Poll for paying out a claim is successful, an Executive Vote must be created and approved through Sky Governance processes to draw the funds from the Surplus Buffer and send them to the Beneficiary’s registered wallet. The spend must be accounted for in the budget in [A.2.10.1.1.1.1.1 - Resilience Fund Current Budget](aa1e93e5-8fc0-4e12-ad9d-8bb9f6cd8956).

###### A.2.10.1.1.1.4.3 - Resilience Fund Caps And Exclusions [Core]  <!-- UUID: e99c4433-e55b-49b1-b73a-8bc1ae3a56b6 -->

Unless otherwise approved by a governance vote of Sky, claim funds approved under this Section are subject to the caps and exclusions specified in the subdocuments of this document.

###### A.2.10.1.1.1.4.3.1 - Resilience Fund Aggregate Cap [Core]  <!-- UUID: 327407b2-9c87-4d7a-b772-1a61ac9d2da3 -->

Claims will be subject to an aggregate cap for all claims in relation to a Claim Event determined by the risk models elaborated by the Resilience Technical Committee.

###### A.2.10.1.1.1.4.3.2 - Resilience Fund Direct Costs And Legal Expenses Cap [Core]  <!-- UUID: c103cdb7-0213-492f-b900-96175ac89e5b -->

Claims can only be used to reimburse Beneficiaries for their losses and disbursements directly arising from a Claim Event, and reasonable legal expenses. "Reasonable legal expense" is a variable amount that will be determined taking into account the average market rates of the respective jurisdiction.

###### A.2.10.1.1.1.4.3.3 - Resilience Fund Caps Government Or Regulatory Fines Or Damages Exclusion [Core]  <!-- UUID: f44b8c82-f420-4d14-ad89-8b885408e10e -->

Must not be used to reimburse the payment of government or regulatory fines or damages awarded by the court.

###### A.2.10.1.1.1.4.4 - Refund Of Amounts To Resilience Fund [Core]  <!-- UUID: 608f5fd0-f441-47b2-8775-4f8b019e8c41 -->

Where Beneficiaries receive financial benefit or reimbursement of any type as a result of orders of a court, governmental or investigative body or regulatory agency that results in a windfall to the Beneficiary, these windfall amounts will be returned by the Beneficiary to the Resilience Fund within 14 days of receipt.

###### A.2.10.1.1.1.4.4.1 - Refund Of Amounts To Resilience Fund Examples [Core]  <!-- UUID: 6855b494-f493-4dad-a7be-a43a17959016 -->

By way of example only and without limiting the generality of the principle described in [A.2.10.1.1.1.4.4 - Refund Of Amounts To Resilience Fund](608f5fd0-f441-47b2-8775-4f8b019e8c41), such amounts include, without limitation:

- Amounts awarded by a court towards the Beneficiary’s legal fees or disbursements;

- An award of damages to a Beneficiary in relation to a Claim Event;

- Monies or digital assets located by police or other investigative bodies that were identified as the property of Sky; and

- Interest payable to a Beneficiary in relation to a Claim Event.

###### A.2.10.1.1.1.4.5 - Resilience Fund Litigation / Defense Management [Core]  <!-- UUID: cb5e73d2-0b65-4465-94db-eb70fb8c814c -->

Beneficiaries and their legal teams must, in the conduct of the litigation and as a condition of receiving reimbursement from the Resilience Fund, satisfy all of the conditions listed in the subdocuments of this document.

###### A.2.10.1.1.1.4.5.1 - Good Faith In Resilience Fund Litigation / Defense Management [Core]  <!-- UUID: 4ca172c5-b48c-4e62-8b23-055573cb2376 -->

Beneficiaries and their legal teams must act honestly, consistently, and fairly in handling claims and litigation.

###### A.2.10.1.1.1.4.5.2 - Promptness In Resilience Fund Litigation / Defense Management [Core]  <!-- UUID: 2981a7cf-cdc2-4967-816b-dcbbc21f3ee8 -->

Beneficiaries and their legal teams must make an early assessment of the prospects of success and deal with claims promptly.

###### A.2.10.1.1.1.4.5.3 - Cost Control In Resilience Fund Litigation / Defense Management [Core]  <!-- UUID: 455bd317-a36c-48ba-9c34-0034b824b3e4 -->

Beneficiaries and their legal teams  must keep costs to a minimum and avoid reliance on technical defenses which have low probability of success.

###### A.2.10.1.1.1.4.5.4 - Alternative Dispute Resolution In Resilience Fund Litigation / Defense Management [Core]  <!-- UUID: c7222199-c81b-4d67-b7c1-044391c288d5 -->

Beneficiaries and their legal teams must consider alternative dispute resolution (ADR) options at all times.

##### A.2.10.1.1.2 - Lawyer Registry [Core]  <!-- UUID: 4c327b04-48f7-4941-b996-1c629eb42bf7 -->

The Lawyer Registry (also "LR") is a registry of specialized Ecosystem Actors who are qualified to perform legal work for Sky Ecosystem or participants in the Sky Ecosystem, including, but not limited to, legal representation or legal defense.

Lawyers will be onboarded in the Lawyer Registry covering at least the areas specified in [A.2.10.1.1.2.1 - Lawyer Registry Covered Areas](a176f67f-009f-44a0-a19b-169c2eb376a4).

###### A.2.10.1.1.2.1 - Lawyer Registry Covered Areas [Core]  <!-- UUID: a176f67f-009f-44a0-a19b-169c2eb376a4 -->

`| Category                         | Areas of Law                                         | Examples                                                                                                          |  
|----------------------------------|------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------|  
| Disputes/Investigations          | Regulatory Enforcement – Securities/Finance Law      | SEC/FinCEN/CFTC/Central Bank matters, Tax authority actions, OFAC orders, Sanctions                               |  
|                                  | Securities Law Disputes (private party claims, class actions, etc.) | Sky investor claims, Lawsuits against Sky CORE actors                                                            |  
|                                  | Intellectual Property                                | Patent Claims/Trolls, Trademark Claims/Trolls                                                                     |  
|                                  | General Litigation – Any other Party-Party Disputes  | Disputes between Sky and 3rd party suppliers, Breach of contract disputes, Employment law disputes, Disputes between Sky and Ecosystem actors |  
| Commercial Matters (non-litigious) | Commercial and Contracts                            | Commercial transactions (Audits, listing agreements, inter-Agent agreements affecting Sky Core etc.), Contracts and Procurement (includes contract management), Competition/Anti-Trust Law, Data protection and Privacy, Insurance Law |  
|                                  | Intellectual Property, Information Technology        | IT procurement, licenses, and contracts, Convergent technologies, Intellectual property rights, Data protection and privacy, Trademark/Patent applications |  
|                                  | Corporate Structuring, Entity Formation/Reporting, Corporate Financing and Tax | Entity formation assistance provided to Sky Core, Annual Reporting/Filings, Company Law, Corporate Finance, Tax Law |`

###### A.2.10.1.1.2.2 - Lawyer Registry Acceptance Criteria [Core]  <!-- UUID: 2b66ce16-d104-4238-b7d5-e4c6fe8d961b -->

To be included in the Lawyer Registry, lawyers must satisfy all requirements described in the following subelements.

###### A.2.10.1.1.2.2.1 - Lawyer Registry Licensing Criterion [Core]  <!-- UUID: fd8dec1d-6872-439d-b30a-eb4d39e2310b -->

Licensed legal professionals in their respective jurisdiction.

###### A.2.10.1.1.2.2.2 - Lawyer Registry Technology Experience Criterion [Core]  <!-- UUID: bbe5b615-0bfd-4dd4-b6a8-bae4af500261 -->

Proven experience with Sky Ecosystem crypto, or emerging technologies.

###### A.2.10.1.1.2.2.3 - Lawyer Registry No Conflicts Criterion [Core]  <!-- UUID: e74ab7b2-273e-4593-aee5-38af6c45dba6 -->

No Conflict of Interest in the matter over which they have carriage.

###### A.2.10.1.1.2.2.4 - Lawyer Registry Conflict Checks Criterion [Core]  <!-- UUID: e9fd410d-7bf4-483c-b6bf-2206dbb8c513 -->

Lawyers must have internal processes to conduct conflict checks prior to any engagement under this Section.

###### A.2.10.1.1.2.2.5 - Lawyer Registry Conflict Handling Criterion [Core]  <!-- UUID: d2581c75-828d-46dc-aac2-e2ae6ffd4e57 -->

Where conflicts arise within the lawyer’s firm, the firm must:
1. In the case where a Beneficiary is handling the claim, cease all further work and immediately notify the Resilience Technical Committee in writing and cooperate with the Resilience Technical Committee to avoid a continuing conflict or, where this is not practicable, transfer the matter to another LR registered Lawyer, and

2. In the case where the Guardian is handling the claim, cease all further work and immediately notify the Guardian in writing and cooperate with the Guardian to avoid a continuing conflict or, where this is not practicable, transfer the matter to another LR registered Lawyer.

###### A.2.10.1.1.2.3 - Resilience Fund Representation Requirements [Core]  <!-- UUID: b39f4808-18ae-456b-86fc-d449a69ea99a -->

Legal counsel providing services funded through the RF must fulfill additional requirements specified in the subdocuments herein. Legal counsel qualified for RF will be listed as such in the Lawyer Registry.

###### A.2.10.1.1.2.3.1 - Resilience Fund Representation Experience Requirement [Core]  <!-- UUID: 04852c06-a9c0-4775-a891-1fd8946083a7 -->

Lead Counsel, Lead Barristers, and Lead Trial Attorneys (as applicable) must each have a minimum of ten (10) years of relevant legal experience and demonstrable expertise in the specific areas of law, legal processes, and jurisdictions listed on the Lawyer Registry.

###### A.2.10.1.1.2.3.2 - Resilience Fund Representation Expertise Requirement [Core]  <!-- UUID: 23612175-bf87-4c2a-b295-a46900a36bbd -->

Lawyers included on the Lawyer Registry for litigious categories, must have been Lead Counsel in at least 15 cases in the relevant area of law, type of process, and jurisdiction for which they are listed. Lawyers included on the Lawyer Registry for non-litigious matters must have demonstrable experience in the relevant area of law, type of process and jurisdiction indicated in the table set out under [A.2.10.1.1.2.1 - Lawyer Registry Covered Areas](a176f67f-009f-44a0-a19b-169c2eb376a4).

###### A.2.10.1.1.2.4 - Lawyer Registry Template [Core]  <!-- UUID: d4bc5f95-a5a8-4f55-8db8-eb9f30cc0abf -->

Entries in the LR must follow this template:

- .x: [Advisor name and short description]

- .x.1: [Name of Firm]

- .x.2: [Specialization Area]

- .x.3: [Jurisdiction]

- .x.4: [RF qualified (y/n)]

###### A.2.10.1.1.2.5 - Requirements For Resilience Technical Committee [Core]  <!-- UUID: ba0f1c77-3fe8-45b5-bb5b-1bc84a3a5f8f -->

The Resilience Technical Committee will verify the eligibility criteria of new candidates in the Lawyer Registry and submit a list of approved candidates to the Support Facilitators.

###### A.2.10.1.1.2.6 - Lawyer Registry Update Process [Active Data Controller]  <!-- UUID: 2e3f851c-6ee2-472a-aa4f-cf637ff1cd8a -->

The current approved lawyers in the Lawyer Registry are defined as Active Data in [A.2.10.1.1.2.6.0.6.1 - Lawyer Registry Current Approved Legal Counsels](e1f72c98-e3f7-43b5-857c-82294abbbe09). 

The Active Data is updated as follows:

- The Responsible Party is the Support Facilitators.

- The Update Process must follow the protocol for ‘Direct Edit’.

###### A.2.10.1.1.2.6.0.6.1 - Lawyer Registry Current Approved Legal Counsels [Active Data]  <!-- UUID: e1f72c98-e3f7-43b5-857c-82294abbbe09 -->

There are no active legal counsels in the Lawyer Registry.

##### A.2.10.1.1.3 - The Guardian [Core]  <!-- UUID: 0f808bde-fc68-4bda-bc6d-049c6aaaab1b -->

The Guardian is a specialized Ecosystem Actor that will be exclusively mandated to retain and instruct counsel to assist with the legal defense of actors in the Sky Ecosystem that, due to their organizational structure or circumstances, may be unable to obtain legal representation when pursuing or defending claims against adversarial parties.

##### A.2.10.1.1.4 - Legal Defense Standard Operational Protocols [Core]  <!-- UUID: bd82af2f-6617-4d4e-8acb-e23c7d2c904b -->

This document must define the Standard Operational Protocols (SOPs) for reacting against legal or regulatory actions against a participant of the Sky Ecosystem.

#### A.2.10.1.2 - Legal Risk Management [Core]  <!-- UUID: f50b0f4d-05c3-48ef-9073-997c9f678feb -->

This document defines the framework for managing, retaining, transferring, and structuring legal risk through instruments such as self-insurance and insurance.

##### A.2.10.1.2.1 - The Policyholder [Core]  <!-- UUID: fbc37039-df17-4146-9cbc-69dbc13c1d85 -->

The Policyholder is a specialized Ecosystem Actor in charge of executing agreements with external entities with the exclusive purpose of structuring and transferring risk to third parties through instruments such as insurances, reinsurances, mutuals, or other types of arrangements. These instruments will provide extended risk coverage for participants of the Sky Ecosystem and Agents.

The object of the Policyholder is to

- Act as a legal counterparty with insurance brokers, insurance, reinsurance, underwriters, or risk management companies.

- Act as a policyholder of insurance contracts, which will have as beneficiaries participants of the Sky Ecosystem.

- Hire suppliers and contractors necessary for the operation of self-insurance or insurance instruments, such as 

◦ The Resilience Technical Committee for claim management 

◦ Managers, Directors, and other executive staff of the legal vehicle. The power of directors will be limited to administrative and operative roles.

Sky Governance will have all necessary control mechanisms over the Policyholder:

- Sky Governance can designate and remove Directors, Supervisor, and Committees

- Sky Governance can instruct the entity to act and ratify decisions

- Power of directors is limited to administrative/operative roles

- The Policyholder will not manage Sky's assets nor will be legally affiliated with Sky.

The setup and operational budget of the legal vehicle will be sourced initially from the [A.2.10.1.1.1.1.1 - Resilience Fund Current Budget](aa1e93e5-8fc0-4e12-ad9d-8bb9f6cd8956). This is intended to move later to a separate budget.

##### A.2.10.1.2.2 - Policyholder Management [Core]  <!-- UUID: b376e933-f145-42a6-ac8b-462b6dbce497 -->

This document governs the adding and removing of Policyholders. SKY holders must first approve the structure and associated costs of the Policyholder, based on a Governance Poll initiated by Facilitators if they deem it necessary.

The list of currently approved Policyholders is maintained in [A.2.10.1.2.3 - Current Active Policyholders](6db0f9ee-9011-44da-8b75-521218f91aba).

##### A.2.10.1.2.3 - Current Active Policyholders [Core]  <!-- UUID: 6db0f9ee-9011-44da-8b75-521218f91aba -->

There are currently no active Policyholders.

#### A.2.10.1.3 - Privacy and Operational Security [Core]  <!-- UUID: 42c525ca-c541-4bf5-ac6a-7bd19960d583 -->

This document must define policies pertaining to operational security, privacy, and pseudonymity for participants in the Sky Ecosystem. The general purpose of this framework is to maximize security and safety for contributors and users and minimize potential attack vectors for the Ecosystem.

#### A.2.10.1.4 - Advocacy And Public Policy [Core]  <!-- UUID: 336b0e21-d62a-49d3-9179-14f467b7609c -->

This document defines the framework and processes for public policy, advocacy, and governmental relations. The general purpose of this framework is to develop innovative regulatory frameworks and standards that protect open source resources and position the Public Good Purpose of the Sky Ecosystem.

#### A.2.10.1.5 - Legal And Regulatory Risk Monitoring [Core]  <!-- UUID: 035ec13b-5676-45f0-a3b3-8b8e24a4adcf -->

This document defines the general framework and standard processes for monitoring and assessing risk and implementing responses. Risk assessment will include external/jurisdictional risk monitoring and internal risk monitoring.

Responses will be structured as Standard Operational Protocols (SOPs). The categories of Legal and Regulatory Risk Monitoring responses are:

- Preventive responses that reduce the likelihood of occurrence of a risk event

- Reactive responses that reduce the severity of consequences if the risk event materializes.

- Emergency Responses and Contingency Plans.

#### A.2.10.1.6 - Public Procurement Framework [Core]  <!-- UUID: d5ffcc76-3cde-475d-8336-fcb5ce499988 -->

This document defines a Public Procurement Framework for contributors and actors involved in the Sky Ecosystem. The purpose is to develop a standard framework that governs the entire lifecycle of service providers, which includes the following processes:

- Application process

- Selection process (scoring / evaluating proposals or applications)

- Hiring and payment process

- Performance evaluation and reporting

- Terminating involvement and resolving disputes

#### A.2.10.1.7 - Audit Procedure for Atlas Amendments [Core]  <!-- UUID: 92dcb95c-5a3d-45a4-a1e6-865686909c64 -->

This document must define the procedure for performing ex-post legal and technical audits of amended Atlas documents. The general purpose of this procedure is to ensure internal consistency and alignment of the Atlas as a whole.

#### A.2.10.1.8 - Technical And Legal Standards [Core]  <!-- UUID: 7c4e41ab-c8b4-4938-be92-994c58cf3e2e -->

This document defines the required technical-legal standards and tools such as, but not limited to, legal agreements ([A.2.9 - Ecosystem Accords](104c3543-ce94-4a2f-9968-57f1ee858085)), templates, and legal structures required to perform specific functions or roles in the Sky Ecosystem. The general purpose of this framework is to minimize trust assumptions and dependencies on specific actors, minimize personal exposure, and increase the accountability and predictability in their behavior.

#### A.2.10.1.9 - Code And Asset Licenses [Core]  <!-- UUID: 1d5042e4-d7b9-4a2b-b935-aae25220308a -->

Ecosystem Actors should generally release code and assets under the Apache 2.0 license, unless there are specific and clear reasons to use a different license, as determined by the Support Facilitators.

The Support Facilitators must ensure that a Foundation and other appropriate legal entities exists to properly protect intellectual property and trademarks related to the Sky Ecosystem.

Such Foundations or other entities must over time be set up to follow instructions from Sky Governance.

All Ecosystem Actors must take steps to protect the brands and trademarks relevant to the Sky Ecosystem, and in doing so must follow guidelines and best practice defined by the Foundations related to Trademarks, Code and Asset licenses.

## A.2.11 - Resilience Research and Preparedness [Article]  <!-- UUID: 29b21344-c651-4ea8-9d25-c1b0948c9dca -->

This Article defines infrastructure and processes to support resilience research and legal preparedness.

### A.2.11.1 - Resilience Research And Preparedness [Section]  <!-- UUID: 9bb5e917-2a88-4e9c-bb5c-2d803b0ddcf0 -->

The Support Scope is responsible for conducting ongoing resilience and preparedness research.

#### A.2.11.1.1 - Role Of Support Facilitators [Core]  <!-- UUID: aeb75fe3-f52b-4cdf-a206-1e54ef648d88 -->

The Support Facilitators must ensure that resilience research and preparedness efforts are continuously maintained to ensure the ecosystem is well-positioned to handle any legal uncertainty or risk that should arise. These projects must generally be broadly diversified across all jurisdictions where the Sky Ecosystem could be directly or indirectly exposed, but efforts and resources must be prioritized towards jurisdictions where risks are more likely to emerge.

##### A.2.11.1.1.0.3.1 - Resilience Research And Preparedness - Element Annotation [Annotation]  <!-- UUID: dff5ff4c-acb4-47cd-93a1-b435dd6db87e -->

This element refers to activities and studies aimed at strengthening Sky Ecosystem’s ability to respond effectively to legal uncertainties or risks, including monitoring and analysis of legal trends and regulatory changes; scenario planning and risk modeling; and the development of strategies to mitigate potential threats.

#### A.2.11.1.2 - Budget [Core]  <!-- UUID: 236dc6f0-afe4-4d9f-86ba-7bc975df3f7b -->

The Resilience Research and Preparedness budget is specified in [A.2.11.1.2.1 - Current Budget](afb4b3c3-96ad-422d-9033-bd4e5feca90c). The Support Facilitators can trigger a payout from the budget to a relevant recipient address through a Governance Poll.

##### A.2.11.1.2.1 - Current Budget [Core]  <!-- UUID: afb4b3c3-96ad-422d-9033-bd4e5feca90c -->

The Resilience Research and Preparedness budget is

- Up to 2,000,000 USDS available per year.

The full amount is immediately available at the start of the calendar year.

#### A.2.11.1.3 - Research Objectives [Core]  <!-- UUID: 47c4b698-5cd0-4917-9bf2-96cf385a5098 -->

Resilience Research and Preparedness (also "Resilience Research") projects must fulfill at least one of the following objectives:

- Bootstrap necessary infrastructure to develop one of the high-order legal resilience objectives as defined in this Article:

    ◦ Legal Defense

    ◦ Legal Risk Management

    ◦ Privacy and Operational Security

    ◦ Advocacy and Public Policy

    ◦ Legal and Regulatory Risk Monitoring

    ◦ Public Procurement Framework

    ◦ Atlas Amendment and Audit

    ◦ Technical and Legal Standards

- Design and implement processes that contribute directly to one of the high-order legal resilience objectives defined in this Article.

- Implement specific preventive or reactive legal risk mitigation tools.

- Execute specific activities or tasks necessary to fulfill one of the high-order legal resilience objectives defined in this Article.

#### A.2.11.1.4 - Application Process [Core]  <!-- UUID: f6af14d7-e62d-44c5-aa65-35c9ec979f4c -->

Ecosystem Actors can apply for a Resilience Research Project by submitting a proposal to be processed by the Support Scope. To submit a Resilience Research Proposal, the Ecosystem Actor must make a post on the Sky Forum following the template provided in [A.2.11.1.4.5 - Application Template](6cecf165-923a-4720-91f6-11c434afa641) and comply with all requirements described in the subdocuments herein.

##### A.2.11.1.4.1 - Costs And Benefits [Core]  <!-- UUID: e0eedeec-b982-413d-8381-2ceecf5f2e6b -->

Resilience Research Proposals must provide a clear and detailed account of both direct and indirect costs, as well as the anticipated results and benefits in relation to the Resilience Research Objectives.

##### A.2.11.1.4.2 - Team [Core]  <!-- UUID: e59dcf34-88f7-4ded-9101-b6ea71797cfe -->

Resilience Research Proposals must detail their headcount, team skillset composition, and reliance on third parties.

##### A.2.11.1.4.3 - Timeline And Milestones [Core]  <!-- UUID: 6f62cb26-d7cc-4a97-8837-79b80bd15d1b -->

Resilience Research Proposals must provide a clear timeline with detailed, granular milestones and the KPIs to review at each milestone.

##### A.2.11.1.4.4 - Risk Mitigation Impact [Core]  <!-- UUID: eb9be99b-81d4-46a6-95ff-e81ac56bd33c -->

Resilience Research Proposals must justify how the project will mitigate a specific risk or help bootstrap resources necessary to improve legal resilience.

##### A.2.11.1.4.5 - Application Template [Core]  <!-- UUID: 6cecf165-923a-4720-91f6-11c434afa641 -->

Applications for Resilience Research projects must follow this template:

- .x: [Project Name]

- .x.1: [Project Abstract: In 3-5 sentences, what problem are you trying to solve?]

- .x.2: [Objectives: What are you hoping to accomplish? How do you define and measure success for this project?]

- .x.3: [Outcomes: How does this project benefit the Sky Ecosystem? How does this project help fulfill one of the Legal Resilience Objectives in [A.2.10 - Legal Resilience](ac707ae4-65da-4cf9-8a34-8b9304cd9a95)]

- .x.4: [Scope: What will you research/build /design/implement? What is the expected output?]

- .x.5: [Project Team: How many people are working on this project? Please list their names and roles for the project and how many hours per month each person will work on this project?]

- .x.6: [Background: Relevant links, reference to other projects or research papers]

- .x.7: [Methodology: How do you plan to achieve your objectives?]

- .x.8: [Timeline: Please include a brief explanation of the milestones/roadmap, along with expected deliverables and KPIs.]

- .x.9: [Budget: Requested grant amount and how this will be used. Please provide the requested amount and outline how the funds will be used.]

#### A.2.11.1.5 - Review Process [Core]  <!-- UUID: 35aec115-f27c-42f2-9812-644a2df8f38f -->

The Support Facilitators must ensure that all Research Proposals are reviewed. The Support Facilitators should document their reviews of all Research Proposals they deem high quality, and publish them in the Sky Forum.

##### A.2.11.1.5.1 - Budget Availability [Core]  <!-- UUID: 9fd21b41-d5ca-4c19-ba21-c2120365b051 -->

Proposals should only be reviewed if there are available funds in the Resilience Research and Preparedness budget.

##### A.2.11.1.5.2 - Factors To Consider [Core]  <!-- UUID: d80f4451-c773-4ddf-b448-c42aaf0b64ec -->

Multiple factors should be considered when reviewing Research Proposals, including the amount of remaining budget, the potential impact on the Resilience Research Objectives, and whether the Research Proposal helps improve legal resilience as described in [A.2.10 - Legal Resilience](ac707ae4-65da-4cf9-8a34-8b9304cd9a95).

##### A.2.11.1.5.3 - Approval Process [Core]  <!-- UUID: cbf70252-fde5-4df7-8552-c778ecc3506a -->

Resilience Research Projects require different approval processes depending on the total cost of the project. Projects with a total cost under 15,000 USDS can be directly approved by the Support Facilitator and included in an Executive Vote without a prior Governance Poll. Projects with a total cost of 15,000 USDS or above require a Governance Poll followed by inclusion in an Executive Vote.

The Support Facilitator must formally approve the inclusion of funding in a Governance Poll or directly in an Executive Vote, as applicable, by replying to the Forum Post containing their evaluation (see [A.2.11.1.5 - Review Process](35aec115-f27c-42f2-9812-644a2df8f38f)).

###### A.2.11.1.5.3.0.3.1 - Included In An Executive Vote [Annotation]  <!-- UUID: e7f4ca65-be7d-4c05-b657-5c6243308e71 -->

The element "Included In An Executive Vote" refers to the Support Facilitators’ act of adding a Resilience Research and Preparedness grant payment to an Executive Vote. The Support Facilitators are also responsible for providing provenance for such requests by confirming payment requests on the Executive Sheet. See [A.1.10.1.3.0.3.1 - Executive Sheet - Element Annotation](52aef6ac-9eda-4795-9dab-73ea85b8ca31).

##### A.2.11.1.5.4 - Active Projects [Core]  <!-- UUID: dd379ac9-5e10-48ac-9b64-a1cb63d6ff51 -->

There are currently no active resilience research projects.

## A.2.12 - Ecosystem Security Infrastructure [Article]  <!-- UUID: 2427d573-5e69-4429-a267-97fa6e84ac43 -->

This Article defines ecosystem security infrastructure and processes to protect the Sky Protocol and its users.

### A.2.12.1 - Ecosystem Security Infrastructure [Section]  <!-- UUID: 49398799-ca02-4770-a42f-16292260076d -->

This Section manages Sky Ecosystem security infrastructure and initiatives.

#### A.2.12.1.1 - Bug Bounty Program For Critical Infrastructure [Core]  <!-- UUID: e48aa6f8-7806-40c5-a53d-d577249cc6e4 -->

As one of the most important DeFi protocols with a high TVL, the Sky Protocol is a honeypot for hackers and other nefarious actors. The Sky Protocol must always be protected by an active Bug Bounty Program. This document regulates the budget and processes of the Bug Bounty Program, which serves to protect the Sky Protocol and its users from hacks and exploits. The Bug Bounty Program is conducted on the Immunefi platform.

##### A.2.12.1.1.1 - Introduction [Core]  <!-- UUID: 54134f24-84a2-4130-80a5-a519f291c918 -->

The Bug Bounty Program aims to create incentives for hackers to contribute to the resilience of the Sky Protocol as opposed to exploiting vulnerabilities for personal gain. Immunefi is the party responsible for conducting the Bug Bounty Program; its setup and operations are based on standards set by Immunefi.
 
The Sky Ecosystem must continue to maintain a Bug Bounty Program for SparkLend until the launch of the Spark Agent.

##### A.2.12.1.1.2 - Scope [Core]  <!-- UUID: b9ed6d24-10e6-48dc-9348-9e2098d8dd31 -->

The subdocuments herein describe the scope of the Sky Bug Bounty Program, which currently includes both Sky Protocol and Spark Protocol.

###### A.2.12.1.1.2.1 - Assets In Scope [Core]  <!-- UUID: bc8630bb-ee26-47d6-9e9a-90c87bfcb7a1 -->

The Assets In Scope of the Sky Core Bug Bounty Program will be those identified as critical infrastructure for the Sky Ecosystem.

For Sky Core, the Assets In Scope accepted for this Bug Bounty Program are specified on Sky’s listing on the Immunefi platform, which can be found at ([https://immunefi.com/bounty/makerdao/](https://immunefi.com/bounty/makerdao/)). Assets in Scope include smart contracts, frontend applications, data infrastructure and oracles.

For SparkLend, the Assets In Scope for the Bug Bounty Program is specified on SparkLend’s listing on the Immunefi platform, which can be found at ([https://immunefi.com/bounty/sparklend/](https://immunefi.com/bounty/sparklend/)). For SparkLend, the Assets In Scope only include smart contracts.

The Support Facilitator is responsible for maintaining these lists of Assets In Scope, in consultation with the relevant stakeholders.

###### A.2.12.1.1.2.2 - Severity Classification [Core]  <!-- UUID: 223f562e-3542-4f08-9071-838cb41ad681 -->

The Immunefi Vulnerability Severity Classification System  ([https://immunefi.com/severity-updated/](https://immunefi.com/severity-updated/)) is applicable to both Sky Core and SparkLend. The Support Facilitator is authorized to adopt a new severity system for the Bug Bounty Programs in consultation with relevant technical stakeholders.

###### A.2.12.1.1.2.3 - Impacts In Scope [Core]  <!-- UUID: 9a38cad6-c0e0-4ca2-931e-b9999710c6d5 -->

For Sky Core, the Impacts In Scope accepted for the Bug Bounty Program is specified on Sky’s listing on the Immunefi platform, which can be found at ([https://immunefi.com/bounty/makerdao/](https://immunefi.com/bounty/makerdao/)). The impacts are categorized into ‘smart contract’ and ‘websites and applications.’

For SparkLend, the Impacts In Scope for the Bug Bounty Program is specified on SparkLend’s listing on the Immunefi platform, which can be found at ([https://immunefi.com/bounty/sparklend/](https://immunefi.com/bounty/sparklend/)).

###### A.2.12.1.1.2.4 - Out Of Scope Vulnerabilities And Other Limitations [Core]  <!-- UUID: bfcb512b-787c-4509-b130-7bf1abd84c36 -->

A selection of vulnerabilities is deemed out of scope for the Bug Bounty Program. An overview of these out of scope vulnerabilities can be found on Sky’s listing on the Immunefi platform ([https://immunefi.com/bounty/makerdao/](https://immunefi.com/bounty/makerdao/)). Feasibility limitations also apply, which can be found in the aforementioned listing on the Immunefi website.

Specific rules applying to the Bug Bounty Program can be found at the website above, listed under the following categories:

- Repeatable attack limitations

- Restrictions on security researcher eligibility

- Public disclosure of known issues

- Proof of Concept (PoC) requirements

- Other terms and information

- Prohibited activities

For SparkLend, the rules, terms, and exceptions can be found on SparkLend’s listing on the Immunefi platform ([https://immunefi.com/bounty/sparklend/](https://immunefi.com/bounty/sparklend/)).

##### A.2.12.1.1.3 - Rewards Terms And Conditions [Core]  <!-- UUID: f934a75a-20f1-46d1-ae5e-56fa7da7b4cd -->

The subelements herein describe the Bug Bounty Program’s terms and conditions for rewards.

###### A.2.12.1.1.3.1 - Rewards For Smart Contract Vulnerabilities [Core]  <!-- UUID: 3dea6103-8e97-4602-866c-371054b71a01 -->

The Rewards per Threat Level for Smart Contract Vulnerabilities, including related terms, conditions and exceptions, are specified in Sky’s listing on the Immunefi platform ([https://immunefi.com/bounty/makerdao/](https://immunefi.com/bounty/makerdao/)).

For SparkLend, the Rewards per Threat Level for Smart Contract Vulnerabilities, including related terms, conditions and exceptions, are specified on SparkLend’s listing on the Immunefi platform ([https://immunefi.com/bounty/sparklend/](https://immunefi.com/bounty/sparklend/)).

###### A.2.12.1.1.3.2 - Rewards For Website And Application Vulnerabilities [Core]  <!-- UUID: 9c4f269d-b365-4e44-89bc-e99d71737f40 -->

The Rewards per Threat Level for Website and Application Vulnerabilities, including related terms, conditions and exceptions, are specified in Sky’s listing on the Immunefi platform ([https://immunefi.com/bounty/makerdao/](https://immunefi.com/bounty/makerdao/)).

###### A.2.12.1.1.3.3 - Rewards Payment Terms [Core]  <!-- UUID: cf4e6968-18a3-48d8-b38e-15ae8009d03d -->

The subelements herein describe the payment terms for the Bug Bounty Program for Sky Critical Infrastructure.

###### A.2.12.1.1.3.3.1 - Rewards Denomination [Core]  <!-- UUID: f06632c1-5c19-4851-ac68-b6d21466f1c4 -->

Payments are denominated in USD. However, payouts are done in USDS assuming a full 1:1 ratio with the USD. However, if the price of USDS deviates from the USD value by more than 1%, the amount of USDS will be adjusted.

###### A.2.12.1.1.3.3.2 - Rewards Payout Process [Core]  <!-- UUID: 07f4faa6-f900-46e6-87d4-137fe2e5cb99 -->

All bounty payouts are handled by Sky Governance. Upon confirmation, bug bounty payouts should be included in the next possible Executive Vote. This would involve sending USDS directly from the protocol’s buffer to the whitehat hacker.

Immunefi will publicly contact the Core Facilitator with the request, including a specification of the respective vulnerability report, the requested amount and the Ethereum mainnet addresses of the beneficiaries. This should also include the payment details of the Immunefi fee, if it applies. Immunefi and the Core Facilitator should make sure the payout is made within one full calendar month after the report was approved.

For Bug Bounty rewards over USD 1,000,000: after the first million is paid out, the remaining amount is paid out over time with up to USD 1,000,000 per consecutive month until the determined amount for payout is reached.

###### A.2.12.1.1.3.3.3 - Rewards Budget [Core]  <!-- UUID: 97359514-045c-4699-8b1e-e68fe13f8840 -->

The Bug Bounty Programs incur fixed and variable costs.

- Variable costs: Bug bounty payouts including related fees to Immunefi are considered variable costs and are covered by the process described in [A.2.12.1.1.3.3 - Rewards Payment Terms](cf4e6968-18a3-48d8-b38e-15ae8009d03d).

- Fixed costs: Fixed costs comprise service fees for the Immunefi Premium Triaging Service, and compensation of a part-time Bug Bounty program steward. These costs will be funded by Sky.

## A.2.13 - Purpose System [Article]  <!-- UUID: b888a6f2-df29-4254-bc74-8dff265f2697 -->

This Article governs the Purpose System, which aims to fund open-source AI and software projects that benefit the Sky Ecosystem and public good.

### A.2.13.1 - Funding [Section]  <!-- UUID: d6d4b091-8143-4a43-a3cf-b5dfa18a8d35 -->

This Section must define the elements and infrastructure necessary to implement the Purpose System effectively. This includes establishing a process for allocating purpose funds to individual Agents.

### A.2.13.2 - Direct And Specific Impact Solutions [Section]  <!-- UUID: a2de9679-22b6-432b-861f-f315d422e51e -->

At all times, at least 10% of the Purpose System funds must be used for more direct and specific impact solutions.

## A.2.14 - Ecosystem Entity Grants [Article]  <!-- UUID: 7be35f96-8230-41d6-aab4-0a76bd705a25 -->

This Article defines the Ecosystem Entity Grants, which aim to fund the Sky Frontier Foundation and the Sky Fortification Foundation.

### A.2.14.1 - Ecosystem Entity Grants [Section]  <!-- UUID: 5d5759e4-8077-4af5-9a1a-eaeab5088dd7 -->

Information regarding ecosystem entities grants to the Sky Frontier Foundation and the Fortification Foundation is detailed in the documents herein.

#### A.2.14.1.1 - Sky Frontier Foundation Grants [Core]  <!-- UUID: 1f5d9b2d-d94d-4945-bcf5-74b9152de90c -->

Information regarding ecosystem entity grants to the Sky Frontier Foundation is detailed in the documents herein.

##### A.2.14.1.1.1 - August 2025 Grant [Core]  <!-- UUID: ecc26bbd-ee6c-4ede-a3da-176cb8857d87 -->

The approved and disbursed August 2025 grant to the Sky Frontier Foundation is as follows:

- Recipient: Sky Frontier Foundation
- Recipient Address: `0xca5183FB9997046fbd9bA8113139bf5a5Af122A0`
- Transaction Hash: `0x9dff3cf283969f0d6b54347829463aabbcad43e79ebb7ad20c5154e951586e3f`
- USDS amount: 50,000,000
- SKY amount: 1,977,443,914.00
- USDS/SKY LP (UNI-V2) amount: 28,829,858.44
- DAI amount: 35.41
- ENS amount: 46,362.27
- stkAAVE amount: 1,467.08
- COMP amount: 643.73
- AAVE amount: 60
- WETH amount: 0.0296

The amounts above are rounded down; refer to onchain data for exact figures.

#### A.2.14.1.2 - Fortification Foundation Grants [Core]  <!-- UUID: ec2ebbba-6944-44cb-a04d-4572c6bea1e7 -->

Information regarding ecosystem entity grants to the Fortification Foundation is detailed in the documents herein.

##### A.2.14.1.2.1 - August 2025 Grant [Core]  <!-- UUID: fc6b41c6-f9e3-4690-a75a-6d3d68e8d942 -->

The approved and disbursed August 2025 grant to the Fortification Foundation is as follows:

- Recipient: Fortification Foundation
- Recipient Address: `0x483413ccCD796Deddee88E4d3e202425d5E891C6`
- Transaction Hash: `0x9dff3cf283969f0d6b54347829463aabbcad43e79ebb7ad20c5154e951586e3f`
- USDS amount: 10,000,000
- SKY amount: 200,000,000
