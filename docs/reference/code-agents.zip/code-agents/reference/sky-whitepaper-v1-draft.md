# Sky Protocol Whitepaper

**Version:** 1.0 (Draft)
**Date:** December 2025
**Status:** Superseded - see `active/whitepaper/sky-whitepaper.md` for current version

---

## Executive Summary

Sky is the evolution of MakerDAO—the protocol that created DAI, the first decentralized stablecoin at scale. Sky transforms the original decentralized lending protocol into a comprehensive **Central Bank + Commercial Bank** architecture, where Sky Core regulates risk and lends in bulk to specialized agents (Primes), which then deploy capital into the broader ecosystem while maintaining regulatory capital requirements.

What makes Sky different from traditional banking:
- **Real-time transparent rules** — All governance logic is public via the Atlas
- **Cryptoeconomic enforcement** — Rules are enforced by code and economic incentives, not courts
- **Autonomous operation** — Agents execute 99% of operations without human intervention
- **Escalation to human judgment** — Edge cases can escalate to governance for reasonable resolution

Sky deploys ~$10B+ of stablecoin reserves into yield-generating strategies across DeFi and traditional finance while maintaining solvency, peg stability, and regulatory compliance.

---

## Part 1: Core Architecture

### 1.1 The Central Bank Model

Sky operates as a **decentralized central bank**:

- **Sky Core** holds the balance sheet, issues USDS, and sets monetary policy
- **Primes** (like Spark, Grove) are "commercial banks" that borrow from Sky Core and deploy capital into yield strategies
- **Halos** are lighter agents that wrap specific investments or products

Capital flows downward through increasingly specialized layers:
```
Sky Core → Primes → Halos → End Investments (DeFi, RWAs, CLOs)
```

Each layer posts risk capital and operates within rate limits. If a Prime or Halo fails, losses are absorbed by their risk capital first—Sky Core's balance sheet is protected.

### 1.2 How Agents Work

Agents are autonomous entities that deploy capital according to predefined rules:

| Type | Role | Examples |
|------|------|----------|
| **Primes** | Deploy capital at scale into specific domains | Spark (DeFi), Grove (credit), Keel (Solana) |
| **Halos** | Wrap individual products or strategies | CLO tranches, yield vaults |
| **Executors** | Operate systems with collateral backing | Settlement, verification, trading |

Agents can operate autonomously because they're bound by:
- **Rate limits** — Maximum capital movement per time period
- **Encumbrance ratios** — Must maintain risk capital vs deployed capital
- **Slashing** — Penalties for violations accrue automatically

### 1.3 Escalation to Human Judgment

99% of operations are automated. Edge cases escalate to governance for human resolution—this gives Sky the efficiency of code with the flexibility of human judgment when needed.

---

## Part 2: Token System

### 2.1 Core Tokens

| Token | Role | Details |
|-------|------|---------|
| **USDS** | Stablecoin | 1:1 with DAI; ~$5-6B supply; pegged to $1 USD |
| **sUSDS** | Savings token | Deposit USDS → earn Sky Savings Rate (SSR) automatically |
| **SKY** | Governance token | 24,000 SKY = 1 MKR; staking rewards; deflationary via buyback/burn |
| **DAI** | Legacy stablecoin | Still exists (~$5.4B); 1:1 convertible with USDS |

### 2.2 sUSDS (Savings Token)

sUSDS is the yield-bearing representation of USDS:
- Deposit USDS → receive sUSDS
- sUSDS accrues value at the Sky Savings Rate
- Redeem sUSDS → receive USDS + accrued yield
- SSR set by governance based on protocol revenue and market conditions

### 2.3 SKY (Governance Token)

**Staking System:**
- Stake SKY → earn staking rewards
- Two tiers: High Activity Staking Rewards (HASR) and Standard Activity Staking Rewards (SASR)
- Freely unstakeable at any time

**SKY-Backed Borrowing:**
- Stake SKY as collateral
- Borrow USDS at the SKY Borrow Rate
- Funded via segregated stUSDS system (see Part 5)

**Deflationary Tokenomics:**
- No new SKY emissions except emergency recapitalization
- Continuous buyback/burn via Smart Burn Buffer
- Supply decreases over time as protocol grows

### 2.4 stUSDS (Segregated Risk Capital)

stUSDS provides risk capital for SKY-backed borrowing:

- Users deposit USDS → receive stUSDS
- Earn stUSDS Rate (higher than SSR to compensate for risk)
- Bear haircut risk if SKY liquidations fail

**Key Innovation:** Protocol is isolated from SKY collateral losses. stUSDS holders explicitly accept downside risk. Dynamic debt ceiling eliminates governance bottleneck:

```
Max SKY-Backed Debt = Total USDS in stUSDS Contract
```

---

## Part 3: Agent Framework

### 3.1 Prime Agents

Primes are the heavyweight capital-deploying agents. Each Prime:
- Has 10 billion tokens at genesis (emissions permanently disabled)
- Controls a SubProxy account (on-chain treasury)
- Has an associated Foundation and Nested Contributors
- Operates via Agent Artifacts (on-chain parameters and configurations)

**Current Prime Agents:**

| Prime | Focus | Products |
|-------|-------|----------|
| **Spark** | DeFi lending/liquidity | SparkLend, Spark Liquidity Layer, Spark Savings |
| **Grove** | Institutional credit | CLO allocations, RWA strategies |
| **Keel** | Ecosystem expansion | Solana deployment, USDS adoption |
| **Obex** | Agent incubator | Prime and Halo development |

### 3.2 Spark Deep Dive

Spark is the most developed Prime, with three product lines:

**Spark Liquidity Layer (SLL)**
- Cross-chain USDS/sUSDS/USDC liquidity
- Deployed on 6 chains: Ethereum, Base, Arbitrum, Unichain, Optimism, Avalanche
- Rate-limited operations via ALM Controller contracts
- Core Operator Relayer Multisig: 2/5 signing requirement

**SparkLend**
- Lending market with direct Sky liquidity access
- Overcollateralized positions
- Governance-controlled parameters

**Spark Savings**
- Best risk-adjusted stablecoin yields at scale
- Vaults with configurable max yield and supply caps
- Target liquidity: 10% of deposits or fixed minimum

### 3.3 Halo Agents

Halos are general-purpose agents that can wrap any value with agency:

**Standard Halos**
- Lighter-weight than Primes
- Created via Light Agent Primitive
- Operate on parent Prime's Executor Accord

**Passthrough Halos** (Post-Laniakea)
- Enable partnerships with institutional asset managers
- Provide standardized legal frameworks and smart contract infrastructure
- Each investment product is a Halo Unit

### 3.4 Executor Agents

Executors perform privileged system operations:

**Operational Executors**
- Handle day-to-day execution of Prime strategies
- Provide collateralized operational insurance
- Post escrow, face slashing for failures

**Core Executors**
- Oversee Operational Executors
- Ensure alignment with Atlas
- Participate in Core Council governance

**Core Council**
- Group of Executors responsible for Sky Core operationalization
- Monitor compliance, enforce Atlas, oversee governance
- Currently 1 seat; expands to up to 7 members long-term

---

## Part 4: Governance

### 4.1 Governance Philosophy

Sky governance is built on **Alignment Engineering**—designing structures where self-interested actions align with Universal Alignment (harmony with human values and public good).

**Key Principles:**
- **Spirit of the Atlas** — Foundational principles guide all governance actions
- **Universal Alignment** — Optimize for holistic outcomes, not narrow interests
- **Slippery Slope Prevention** — Any misalignment addressed immediately

### 4.2 Governance Actors

**Aligned Delegates (ADs)**
- Control delegated voting power from SKY holders
- Ranked by delegated voting power (Levels 1-3)
- Receive compensation tied to voting activity
- Subject to derecognition for misalignment

**Facilitators**
- Interpret the Atlas and Artifacts on behalf of Executor Agents
- Have broad discretionary authority when Atlas lacks clear guidance
- Every Operational and Core Executor must have a Facilitator

### 4.3 Decision Processes

**Weekly Governance Cycle:**
- Operational decisions via Governance Polls + Executive Votes
- Polls begin Monday; 3-day duration
- Executive Votes approximately bi-weekly (30-day expiration)

**Atlas Edit Cycle:**
- For modifying Atlas documents
- Requires Ranked Delegate with sufficient stake to trigger proposal
- Governance Poll only (no Executive Vote)

**Root Edit (Prime-level):**
- Token holders modify Agent Artifacts
- 1% token holding to submit proposals (Nested Contributors exempt)
- 7-day Facilitator review → 3-day vote → 10% quorum → >50% approval
- Not operational until 2,000+ holders own 10%+ of genesis supply

### 4.4 Emergency Response

**Emergency Response Group (ERG):**
- Facilitators, Aligned Delegates, domain experts
- Geographically distributed for resilience
- Coordinated via Signal/PagerDuty
- Can expedite Executive Votes for emergencies

---

## Part 5: Risk Capital Framework

### 5.1 Two-Tier Capital Structure

**Junior Risk Capital (JRC)** — First to absorb losses:
- **IJRC** — Prime's own capital; foundation of risk capacity
- **SEJRC** — Rented from other Primes via JRC Rental Primitive
- **TEJRC** — Tokenized external providers via smart contract

**Senior Risk Capital (SRC)** — Only absorbs after JRC depleted:
- **ISRC** — Internal (from Sky surplus buffers)
- **ESRC** — External (from srUSDS holders)

### 5.2 Risk Capital Ratios

| Ratio | Formula | Meaning |
|-------|---------|---------|
| **EPI** (External Per Internal) | 1.00 | Max EJRC = IJRC amount |
| **SPJ** (Senior Per Junior) | Varies | How much SRC each JRC type can enable |
| **Encumbrance Ratio** | RRC / TRC | Target ≤ 90%; penalties if >100% |

### 5.3 Loss Absorption Waterfall

```
Loss Event
    ↓
1. Tip JRC (10% of Total JRC) — Prime's IJRC absorbs first
    ↓
2. Remaining JRC (pro-rata) — IJRC + EJRC share proportionally
    ↓
3. Senior Risk Capital — Only after JRC = 0
    ↓
4. Genesis Capital Haircut — Ultimate backstop
    ↓
5. USDS Peg Adjustment — Last resort (below $1)
```

### 5.4 Penalty Schedule

**Low Severity (100% ≤ Encumbrance < 103%):**
- 0-30 min: 500% APY on shortfall
- 30-60 min: 1,000% APY
- 60+ min: 1,500% APY

**High Severity (Encumbrance ≥ 103%):**
- 0-15 min: 1,500% APY
- 15-30 min: 2,000% APY
- 30-60 min: 2,500% APY
- 60+ min: 3,000% APY

---

## Part 6: Treasury Management

### 6.1 Treasury Waterfall

Net revenue is allocated through a waterfall:

```
Net Revenue
    ↓
Step 1: Security & Stability Maintenance (10%)
    ├── Core Executor Budget: up to 5%
    ├── Core Executor Reward: up to 3%
    ├── Aligned Delegates: up to 1%
    └── Governance Accessibility: 1%
    ↓ (90% passes through)
Step 2: High Activity Staking Rewards (5%)
    ↓ (95% passes through)
Step 3: Stability Capital Retention (variable)
    SCR = (1 - (SCB/TS)/TSCB) × RF
    ↓ (remainder passes through)
Step 4: Smart Burn (80%) + Standard Activity Staking (20%)
```

### 6.2 Income Sources

- Stability Fees from Base Rate
- Internal/External Senior Risk Capital Income
- Agent Upkeep Fees and Creation Fees
- Sky Core Vault Income
- LitePSM Income

### 6.3 Smart Burn Engine

Buys and burns SKY using intelligent algorithm—more when price is low, retaining capital when high:

```
Burn Rate = (1 - MC / TMC) × 50%
```

Where TMC = 8.5 + (200 × growth_rate) × annual_profits

---

## Part 7: Laniakea Infrastructure (Post-Upgrade)

Laniakea is Sky's infrastructure for **automated capital deployment at scale**. It enables deployment of stablecoin reserves into yield-generating strategies while maintaining governance control, risk isolation, and regulatory compliance.

### 7.1 The Four Layers

Capital flows through increasingly specialized deployment layers:

```
USDS → Generator → Prime → Halo → RWA Endpoints
                      ↓
              Core Approved Collateral (Morpho, Aave, Curve)
                      ↓
              Foreign Prime → Foreign Halo (altchains)
```

Each layer uses the same **PAU (Parallelized Allocation Unit)** pattern:

| Component | Purpose |
|-----------|---------|
| **Controller** | Entry point, enforces rate limits |
| **ALMProxy** | Holds custody, executes calls |
| **RateLimits** | Linear replenishment with configurable max and slope |

### 7.2 Configurator Unit

Governance layer controlling PAUs:

| BEAM Type | Order | Holders | Powers |
|-----------|-------|---------|--------|
| **aBEAM** | Third | Core Council | Create inits, grant cBEAMs (timelocked) |
| **cBEAM** | Second | GovOps teams | Set rate limits, call controller actions |
| **pBEAM** | First | Sentinels | Execute operations directly on contracts |

**SORL (Second-Order Rate Limit):**
- Max 20% increase per 18h cooldown
- Decreases always instant (emergency response never blocked)

### 7.3 LCTS (Liquidity Constrained Token Standard)

Queue-based token conversion for capacity-constrained assets:

**Multi-Generation Model:**
- Active generation: accepts deposits/withdrawals
- Locked generation: frozen during processing period
- Finalized generation: fully converted

**Weekly Cycle:**
- Tuesday noon: Active generation locks, new generation opens
- Wednesday noon: All locked generations settle proportionally

**Capacity Sources:**
- Net flow netting (subscribe ↔ redeem cancel out)
- OSRC capacity from auction
- Weekly redemption limit (governance-set)

### 7.4 Sentinel Network

Autonomous systems operating within Sky:

**Governance Sentinels:**
- stl-gen — Generator governance
- stl-prime — Prime governance: settlement, verification, carry
- stl-halo — Halo governance
- stl-exec — Executor governance; Synome override permissions

**Operations Sentinels:**
- stl-unit — Per Halo Unit operations
- stl-erc — Per ERC token: LCTS settlement
- stl-auction — Sealed-bid auctions for OSRC and SPTP

**Execution Sentinels:**
- stl-base — Public baseline execution (fail-safe)
- stl-stream — Proprietary optimization (private data, earns carry)
- stl-trade — Proprietary trader for privately-owned assets

### 7.5 Weekly Settlement Cycle

**Fixed Schedule:**
- Measurement Period: Tuesday 12:00 UTC → Tuesday 12:00 UTC (7 days)
- Processing Period: Tuesday 12:00 UTC → Wednesday 12:00 UTC (24 hours)
- Moment of Settlement: Wednesday 12:00 UTC

**Key Events:**
1. OSRC Auction — Sealed-bid uniform-price auction for Senior Risk Capital
2. SPTP Bucket Auction — Capacity reservations for duration matching
3. Tug-of-War — Redistribute excess SPTP capacity
4. LCTS Settlement — Process subscribe/redeem queues

---

## Part 8: General Risk Framework

### 8.1 The Unifying Principle

**Capital Requirement = Drawdown Magnitude × Forced Realization Probability**

Assets matched to long-duration liabilities get "held-to-maturity" treatment (risk weight only). Unmatched assets require full mark-to-market capital.

### 8.2 SPTP (Stressed Pull-to-Par)

Time until an asset converges to fundamental value under stress. Used for liability matching.

**SPTP Bucket System:**
- 101 buckets, each 0.5 months (15 days)
- Two-layer capacity: Weekly Lindy measurement + structural caps
- Key checkpoints: 75% at 1mo, 55% at 3mo, 35% at 12mo, 12.6% at 42mo

### 8.3 Rate Risk vs Credit Spread Risk

| Risk Type | Behavior | SSR Response | SPTP Applicability |
|-----------|----------|--------------|-------------------|
| Credit spread widening | Mean-reverting | SSR flat/down | SPTP protects |
| General rate rise | Can be permanent | SSR rises | SPTP does NOT protect |

**Rate hedging requirement:** All fixed-rate exposure must be rate-hedged for SPTP eligibility.

### 8.4 Asset Treatment

| Asset | SPTP | If Matched | If Unmatched |
|-------|------|------------|--------------|
| JAAA (CLO AAA) | 42mo | ~4-5% risk weight | ~10% FRTB |
| T-bills | 4wk-3mo | ~0.2-0.5% risk weight | ~1-2% FRTB |
| Sparklend | None (no pull-to-par) | N/A | Gap risk (1-2%+) |

---

## Part 9: Passthrough Halos

### 9.1 Purpose

Enable partnerships with institutional asset managers:
- Standardized legal frameworks (reusable across products)
- Pre-audited smart contract infrastructure (factory deployment)
- Rapid time-to-market (days instead of months)

### 9.2 Immediate Capital at Scale

When a new Halo Unit is properly onboarded (factory deployed, Sentinel integrated, artifact reporting), every Prime automatically rebalances into the new Unit.

**Traditional Launch:** Months of investor outreach, gradual accumulation
**Passthrough Launch:** Instant access to all Primes, hundreds of millions on Day 1

### 9.3 Halo Unit Structure

Each Unit uses LCTS (queue-based) for capacity-constrained strategies:
- Investors deposit → receive proportional shares
- Unit Sentinel processes as capacity allows
- Investors can exit queue before deployment

---

## Part 10: Accessibility & Compliance

### 10.1 Geographic Controls

**Limited Filtering (Hide Yield):**
- Users in certain jurisdictions don't see staking rewards, SSR, yield features
- Regulatory caution for unclear jurisdictions

**Full Block:**
- Restricted locations: Cuba, Iran, Syria, North Korea, certain Ukrainian territories
- IP-based blocking at frontend level

### 10.2 Compliance Philosophy

**Passive (IP-Based), NOT Active (KYC-Based)**
- Protocol layer remains permissionless
- Frontends enforce geographic restrictions
- Shifts compliance burden to application layer

**Institutional Access (Post-Laniakea):**
- Institutional KYC Network for regulated entities
- Passthrough Halos handle KYC at Halo boundary
- Enables compliant institutional participation

---

## Part 11: Technical Infrastructure

### 11.1 Smart Contract Architecture

**SkyLink (Multichain):**
- Native token transfers to L2s and major L1s
- Native savings rates (sUSDS earning SSR)
- Native token rewards distribution
- 1:1 USDC ↔ USDS conversion on all chains

**BEAM Pattern (Bounded External Access Module):**
Whitelisted operators adjust parameters within governance-set bounds:
- min/max: Value bounds
- step: Maximum change size
- tau: Minimum time between changes

### 11.3 Key Invariants

1. Rate limits are universal — every capital flow is rate-limited
2. Governance above deployed contracts — no redeployment needed
3. Same contracts, different config — layers differ only in targets and values
4. Unlimited rate limits are immutable — withdrawals always possible
5. Instant decrease, constrained increase — emergency response never blocked
6. Timelock additions, instant removals — monitoring window + emergency response

### 11.4 Oracle Protection

**Capped OSM Wrapper:**
```
Effective SKY Price = min(PIP_SKY, Governance-Set Cap)
```
Prevents price spike exploitation attacks.

---

## Part 12: Key Metrics

### 12.1 System Health

| Metric | Description | Target |
|--------|-------------|--------|
| USDS Peg | Market price vs $1.00 | 0.999 - 1.001 |
| Total Value Locked | All collateral backing USDS | ~$10B+ |
| Encumbrance Ratio | RRC / TRC per Prime | ≤ 90% |
| SSR | Sky Savings Rate | Market-determined |

### 12.2 Agent Health

| Metric | Description |
|--------|-------------|
| CRR | Capital Requirement Ratio per position |
| TRRC | Total Required Risk Capital |
| TRC | Total Risk Capital actually held |

---

## Appendix A: Glossary

| Term | Definition |
|------|------------|
| **Atlas** | Constitutional governance document; human-readable |
| **Synome** | Machine-readable operational database |
| **PAU** | Parallelized Allocation Unit; standard building block |
| **BEAM** | Bounded External Access Module; authorized role with constraints |
| **LCTS** | Liquidity Constrained Token Standard; queue-based conversion |
| **SPTP** | Stressed Pull-to-Par; time until asset converges to fundamental value |
| **Sentinel** | Autonomous system operating within Sky |
| **Prime** | Capital-deploying agent category |
| **Halo** | Lighter operational agent category |
| **Executor** | Governance operator agent |
| **SSR** | Sky Savings Rate |
| **SRC/JRC** | Senior/Junior Risk Capital |

---

## Appendix B: Current vs Post-Laniakea

| Aspect | Current | Post-Laniakea |
|--------|---------|---------------|
| Settlement | Monthly | Weekly |
| Risk Capital | Manual verification | Sentinel automation |
| Capital Requirements | Asset-specific | Unified GRF |
| Rate Limits | Implicit | Explicit PAU with SORL |
| srUSDS Queues | Single queue | Multi-generation LCTS |
| Halo Deployment | Bespoke | Factory-deployed |
