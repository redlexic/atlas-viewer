# Phase 1 Requirements: Governance Layer for Spark ALM Controller

## Executive Summary

Phase 1 adds a governance layer on top of the deployed Spark ALM Controller system. This layer provides controlled, auditable management of rate limits and static parameters without modifying existing contracts.

The governance layer uses a **multi-ATWL architecture** where each layer type has its own Allocation Target Whitelist (ATWL) and Configurator:
- **Generator-ATWL + Generator-Configurator** — for Generator layer operations
- **Mainnet ATWL + Mainnet Configurator** — for mainnet Prime and Halo operations
- **Per-chain Altchain ATWLs + Configurators** — for Foreign Prime and Foreign Halo operations on each altchain

**Deployment patterns by layer:**
- **Primes** deploy into:
  - **Halos** (the primary long-term deployment path)
  - **Core Approved Collateral** (legacy DeFi endpoints like major Morpho vaults, Curve pools, Aave pools directly approved by Sky Core)
  - **Foreign Primes** (via bridge)
- **Halos** deploy into **RWA strategies**, custodian vaults, and regulated offramps (not external DeFi)

---

## Goals

### Primary Goals

1. **Constraint on Rate Limit Changes**
   - Prevent rapid, unbounded increases to rate limits
   - Allow instant decreases for emergency response
   - Create predictable, monitorable growth patterns

2. **Whitelist-Based Authorization**
   - Only pre-approved targets and operations can be configured
   - All approvals go through a timelock for monitoring
   - Removals are instant to enable emergency response
   - Support both **general** and **limited** onboarding (see below)

3. **Enumeration and Visibility**
   - All configured rate limits are enumerable
   - All approved whitelist entries are enumerable
   - Monitoring systems can track state changes

4. **No Redeployment**
   - Works with existing deployed contracts
   - Configurator becomes the exclusive path for configuration
   - Existing admin roles transferred to Configurator

### Security Goals

1. **Bounded Growth**: Rate limits cannot increase faster than a defined rate (e.g., 20% per 24 hours)
2. **Monitoring Window**: All new target approvals have a delay before they can be used
3. **Emergency Response**: Decreases and removals are always instant
4. **Separation of Concerns**: Different roles for operations vs governance

### Phase 1 Scope

**Included:**
- Rate limit management (all types)
- maxSlippage parameter (for Aave, Curve, OTC, Uniswap V4)
- maxExchangeRate parameter (for ERC4626 vaults)
- layerZeroRecipient parameter (for cross-chain transfers to Foreign Prime PAUs)
- General and limited onboarding entry types

**Deferred to later phases:**
- mintRecipient (CCTP) configuration
- OTC buffer configuration
- Uniswap V4 tick limits
- Laniakea Factory integration (no-delay onboarding for factory-deployed PAUs)
- Other specialized parameters

---

## System Architecture

### Layer Hierarchy

```
                    MAINNET                              ALTCHAIN
                    
┌──────────────┐                                    
│   ERC20      │                                    
│  Stablecoin  │                                    
└──────┬───────┘                                    
       │                                            
       ▼                                            
┌──────────────┐                                    
│  Generator   │  ◄── Generator-ATWL + Generator-Configurator
│    PAU       │                                    
└──────┬───────┘                                    
       │ ERC4626 vault                              
       ▼                                            
┌──────────────┐         bridge          ┌──────────────┐
│    Prime     │ ──────────────────────► │   Foreign    │
│    PAU       │   (no vault, direct)    │  Prime PAU   │
└──┬───┬───┬───┘                         └──────┬───────┘
   │   │   │                                    │
   │   │   │  ◄── Mainnet ATWL + Mainnet Configurator      ◄── Altchain ATWL + Altchain Configurator
   │   │   │      (controls Prime + Halo)                      (controls Foreign Prime + Foreign Halo)
   │   │   │                                    │
   │   │   └──────────────┐                     │
   │   │                  │                     │
   │   │ ERC4626 vault    │ Direct to Core      │ various vault types
   │   ▼                  │ Approved Collateral ▼
   │ ┌──────────────┐     │              ┌──────────────┐
   │ │    Halo      │     │              │   Foreign    │
   │ │    PAU       │     │              │  Halo PAU    │
   │ └──────┬───────┘     │              └──────┬───────┘
   │        │             │                     │
   │        ▼             ▼                     ▼
   │    RWA/Custodian   Morpho, Aave,      RWA/Custodian
   │    Endpoints       Curve (legacy)     Endpoints
   │
   └──► Core Approved Collateral
        (Morpho, Aave, Curve - legacy DeFi directly approved by Sky Core)
```

**Key deployment patterns:**
- **Primes** deploy primarily into **Halos** (long-term path) and can also deploy into **Core Approved Collateral** (legacy DeFi approved by Sky Core)
- **Halos** deploy into **RWA strategies**, custodian vaults, and regulated offramps (not external DeFi)

### Governance Layer Architecture

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                              GENERATOR GOVERNANCE                                │
│  ┌───────────────────────┐  ┌─────────────────┐  ┌───────────────────────────┐  │
│  │ Generator-ATWLModifier│──│Generator-ATWLState│──│ Generator-Configurator   │  │
│  └───────────────────────┘  └─────────────────┘  └────────────┬──────────────┘  │
└───────────────────────────────────────────────────────────────┼─────────────────┘
                                                                │
                                                                ▼
                                                    Generator PAUs (RateLimits, Controllers)
                                                    
┌─────────────────────────────────────────────────────────────────────────────────┐
│                              MAINNET GOVERNANCE                                  │
│  ┌─────────────────────┐  ┌─────────────────┐  ┌─────────────────────────────┐  │
│  │ Mainnet-ATWLModifier│──│ Mainnet-ATWLState│──│   Mainnet-Configurator     │  │
│  └─────────────────────┘  └─────────────────┘  └────────────┬────────────────┘  │
└───────────────────────────────────────────────────────────────┼─────────────────┘
                                                                │
                                                                ▼
                                                    Mainnet Prime + Halo PAUs
                                                    
┌─────────────────────────────────────────────────────────────────────────────────┐
│                          PER-CHAIN ALTCHAIN GOVERNANCE                           │
│  ┌───────────────────────┐  ┌───────────────────┐  ┌─────────────────────────┐  │
│  │ Altchain-ATWLModifier │──│ Altchain-ATWLState│──│ Altchain-Configurator   │  │
│  └───────────────────────┘  └───────────────────┘  └────────────┬────────────┘  │
└───────────────────────────────────────────────────────────────────┼─────────────┘
                                                                    │
                                                                    ▼
                                                    Foreign Prime + Foreign Halo PAUs (on that chain)
```

### ATWL Scope Summary

| ATWL | Configurator | Controls | Used By |
|------|--------------|----------|---------|
| Generator-ATWL | Generator-Configurator | Generator operations | All Generator PAUs |
| Mainnet ATWL | Mainnet Configurator | Prime + Halo operations | All mainnet Prime and Halo PAUs |
| Altchain ATWL (per chain) | Altchain Configurator | Foreign Prime + Foreign Halo operations | All Foreign Prime and Foreign Halo PAUs on that chain |

### Connection Types Between Layers

| Connection | Mechanism | Control |
|------------|-----------|---------|
| Generator → Prime | ERC4626 vault | Rate limits on deposit/withdraw to Prime vaults |
| Prime → Halo | ERC4626 vault (or other vault types) | Rate limits + vault-specific parameters |
| Prime → Core Approved Collateral | Direct (ERC4626, Aave, Curve) | Rate limits + protocol-specific parameters |
| Prime → Foreign Prime | Direct bridge transfer (no vault) | Rate limits on LayerZero/CCTP transfers |
| Foreign Prime → Foreign Halo | Various vault types | Rate limits + vault-specific parameters |
| Halo → RWA/Custodian | Asset transfer | Rate limits on transfers to custodian addresses |

### Role Distribution

| Role | Holder | Responsibility |
|------|--------|----------------|
| **Governance** | Core Council | Approve new targets, cancel pending approvals |
| **Operations** | GovOps | Configure rate limits within approved bounds, instant decreases |
| **Emergency** | Freezer/Mom | Cancel pending approvals |
| **Admin** | PauseProxy | System-level configuration changes, set timelock parameters |

---

## Whitelist Entry Types

Each ATWL supports two types of whitelist entries:

### General Onboarding

**Purpose**: Approve a target that any PAU within the ATWL's scope can use.

**Use cases**:
- **For Primes**: 
  - Core Approved Collateral (legacy DeFi like major Morpho vaults, Curve pools, Aave pools directly approved by Sky Core)
  - Halo vaults (the primary long-term deployment path for Primes)
- **For Halos**: Custodian vaults, RWA deployment endpoints (when multiple Halos share the same custodian)
- Common infrastructure (PSM, standard bridges)

**Behavior**:
- Entry is approved in ATWLState with no PAU restriction
- Any PAU managed by that Configurator can configure the target
- Example: A Morpho vault (Core Approved Collateral) approved in Mainnet ATWL can be used by Prime A, Prime B, etc.

### Limited Onboarding

**Purpose**: Approve a target that only a **specific PAU** can use.

**Use cases**:
- **Bridge routing**: Each Prime needs a specific route to its own Foreign Prime PAU on each chain
- **Regulated endpoints**: RWA offramps that only accept assets from a specific, KYC'd Halo
- **Isolated strategies**: A yield strategy or custodian that should only be accessible to one PAU

**Behavior**:
- Entry is approved in ATWLState with a specific PAU restriction
- Only the designated PAU's Controller/RateLimits can be configured with this target
- Example: The LayerZero route from "Prime A" to "Foreign Prime A on Base" is limited to Prime A only

### Storage Model

ATWLState stores an optional `restrictedToPau` field for each entry:
- If `restrictedToPau == address(0)`: General onboarding (any PAU can use)
- If `restrictedToPau != address(0)`: Limited onboarding (only that PAU can use)

---

## Contract Behaviors

### Key Structure

Rate limit keys in the existing system are computed using `keccak256(abi.encode(...))`. The key structure varies by operation type:

| Operation Type | Key Structure | Example |
|----------------|---------------|---------|
| ERC4626 deposit/withdraw | `hash(LIMIT_4626_DEPOSIT, token)` | Morpho vault deposit |
| Aave deposit/withdraw | `hash(LIMIT_AAVE_DEPOSIT, aToken)` | SparkLend WETH deposit |
| Asset transfer | `hash(LIMIT_ASSET_TRANSFER, asset, destination)` | SYRUP to ops multisig |
| PSM operations | `hash(LIMIT_PSM_DEPOSIT, asset)` | USDC PSM deposit |
| CCTP bridging | `hash(LIMIT_USDC_TO_DOMAIN, domain)` | USDC to Base |
| LayerZero transfer | `hash(LIMIT_LAYERZERO_TRANSFER, oftAddress, destinationEndpointId)` | USDS to Base via LayerZero |
| Spark Vault take | `hash(LIMIT_SPARK_VAULT_TAKE, vault)` | Take from spUSDC vault |

Static parameters are keyed by target address or endpoint:

| Parameter | Key | Example |
|-----------|-----|---------|
| maxSlippage | target address | Aave aToken, Curve pool |
| maxExchangeRate | target address | ERC4626 vault |
| layerZeroRecipient | destination endpoint ID | Foreign Prime PAU on Base |

---

### ATWLState (Allocation Target Whitelist State)

**Purpose**: Storage for approved whitelist entries. Contains no logic—just data and access control.

#### What It Stores

**Rate Limit Entries** — Each entry represents an approved rate limit configuration:
- The full key (as computed by RateLimitHelpers)
- Initial max amount (the starting ceiling when first configured)
- Initial slope (the starting recharge rate when first configured)
- Whether this is an unlimited rate limit
- **restrictedToPau**: Optional PAU address restriction (address(0) = general, non-zero = limited)

**Static Parameter Presets** — Each preset represents an approved specific value:
- Target address or endpoint ID
- Parameter type (MAX_SLIPPAGE, MAX_EXCHANGE_RATE, or LAYERZERO_RECIPIENT in Phase 1)
- The specific approved value
  - For MAX_SLIPPAGE: a single uint256
  - For MAX_EXCHANGE_RATE: a (shares, maxExpectedAssets) tuple
  - For LAYERZERO_RECIPIENT: a bytes32 recipient address
- **restrictedToPau**: Optional PAU address restriction (address(0) = general, non-zero = limited)

#### Behaviors

**Adding a Rate Limit Entry**
- Only the modifier role (ATWLModifier contract) can add entries
- The key must not already exist
- If marked as unlimited, the initial max amount and slope are ignored
- restrictedToPau may be address(0) (general) or a specific PAU address (limited)
- Once added, the entry is immediately queryable

**Removing a Rate Limit Entry**
- Only the modifier role can remove entries
- The entry must exist
- Once removed, the entry is no longer queryable

**Adding a Static Parameter Preset**
- Only the modifier role can add presets
- The exact (target, param_type, value, restrictedToPau) combination must not already exist
- Multiple values can be approved for the same (target, param_type) — this creates a "menu" of options
- Once added, the preset is immediately queryable

**Removing a Static Parameter Preset**
- Only the modifier role can remove presets
- The preset must exist
- Once removed, the preset is no longer queryable
- Removing a preset does NOT affect any Configurator configs currently using that value

**Queries**
- Can check if a rate limit key is approved
- Can check if a rate limit key is approved as unlimited
- Can check if a rate limit key is general or limited (and to which PAU)
- Can retrieve the initial values for a rate limit entry
- Can check if a specific (target, param_type, value) preset is approved
- Can list all approved values for a given (target, param_type)

---

### ATWLModifier (Allocation Target Whitelist Modifier)

**Purpose**: Governance logic for whitelist changes. Additions require timelock; removals are instant.

Note: Each function operates on a single entry. "Batching" is achieved at the multisig level by bundling multiple calls into one transaction.

#### What It Stores

**Pending Additions** — Each pending item contains:
- The parameters for the addition (including restrictedToPau)
- The timestamp after which execution is allowed
- The address that initiated it

**Configuration**
- Timelock duration (default: 4 days, minimum: 1 day)

#### Behaviors

**Initiating a Rate Limit Addition**
- Only the governance role can initiate
- The key must not already be pending
- The key must not already be approved in ATWLState
- restrictedToPau parameter specifies general (address(0)) or limited (specific PAU) onboarding
- Creates a pending addition with execution time = now + timelock duration
- Emits an event for monitoring systems

**Initiating a Static Parameter Preset Addition**
- Only the governance role can initiate
- The exact (target, param_type, value, restrictedToPau) must not already be pending
- The exact (target, param_type, value, restrictedToPau) must not already be approved in ATWLState
- Creates a pending addition with execution time = now + timelock duration
- Emits an event for monitoring systems

**Executing a Rate Limit Addition**
- Anyone can call (permissionless)
- The addition must be pending
- The current time must be >= the execution time
- Calls ATWLState to add the entry
- Deletes the pending addition
- Emits an event

**Executing a Static Parameter Preset Addition**
- Anyone can call (permissionless)
- The addition must be pending
- The current time must be >= the execution time
- Calls ATWLState to add the preset
- Deletes the pending addition
- Emits an event

**Cancelling a Pending Addition**
- Governance, emergency role, or admin can cancel
- The addition must be pending
- Deletes the pending addition without executing
- Emits an event

**Cancelling All Pending Additions**
- Governance, emergency role, or admin can cancel
- Clears all pending rate limit additions and preset additions
- Emits an event

**Removing a Rate Limit Entry (Instant)**
- Only the governance role can remove
- Calls ATWLState to remove the entry immediately
- No timelock required
- Emits an event

**Removing a Static Parameter Preset (Instant)**
- Only the governance role can remove
- Calls ATWLState to remove the preset immediately
- No timelock required
- Does NOT affect Configurator configs currently using this value — only prevents future selection
- Emits an event

**Changing Timelock Duration**
- Only admin can change
- New duration must be at least 1 day

---

### Configurator

**Purpose**: Operations interface for managing rate limits and static parameters. Enforces second-order constraints on rate limit increases. Each Configurator instance manages all PAUs within its ATWL scope (e.g., Mainnet Configurator manages all mainnet Prime and Halo PAUs).

#### What It Stores

**Rate Limit Configs** — For each configured rate limit:
- The current max amount
- The current slope
- The timestamp of the last increase
- Whether this is unlimited (immutable once set)
- Keyed by (rate_limits_contract, key)

**Static Parameter Configs** — For each configured parameter:
- The current value
- Keyed by (controller_contract, target, param_type)

**Key Registry** — List of all configured keys per contract (for enumeration)

**Constraints**
- Max increase percentage (default: 20% / 2000 bps)
- Cooldown period (default: 24 hours)

#### Rate Limit Behaviors

**Adding a Rate Limit**
- Only the operator role can add
- The key must be approved in ATWLState
- **If the entry is limited**: The rate_limits_contract must match the restrictedToPau in the ATWLState entry
- The key must not already be configured in Configurator
- If ATWLState entry is marked unlimited:
  - Calls `rateLimits.setUnlimitedRateLimitData(key)`
  - Stores config as unlimited (immutable)
- If ATWLState entry is not unlimited:
  - Initial values (max_amount, slope) come from the ATWLState entry
  - The last_increase_time is set to now
  - Calls `rateLimits.setRateLimitData(key, max_amount, slope)`
- Adds the key to the registry for enumeration
- Emits an event

**Modifying a Rate Limit (Non-Unlimited Only)**
- Only the operator role can modify
- The key must already be configured
- The rate limit must NOT be unlimited (unlimited rate limits are immutable)
- **For increases** (new_max > current_max):
  - At least `cooldown_period` must have elapsed since the last increase
  - The new max_amount cannot exceed current max_amount × (1 + max_increase_percentage)
  - Updates the last_increase_time to now
- **For decreases** (new_max <= current_max):
  - Always allowed — no cooldown requirement
  - Does NOT reset the last_increase_time (preserves the increase schedule)
- Calls `rateLimits.setRateLimitData(key, new_max, new_slope)`
- Emits an event

**Removing a Rate Limit**
- Only the operator role can remove
- The key must already be configured
- Removes the config from storage
- Removes the key from the registry
- Calls `rateLimits.setRateLimitData(key, 0, 0)` to disable
- Emits an event

**Rate Limit Increase Constraints — Worked Example**
- Starting at 10M with 20% max increase and 24h cooldown:
  - Hour 0: Can increase to max 12M (20% of 10M)
  - Hour 12: Cannot increase (cooldown active)
  - Hour 12: CAN decrease to any value (always allowed)
  - Hour 24: Can increase to max 14.4M (20% of 12M)
  - Hour 24: If decreased to 8M earlier, can increase to max 9.6M (20% of 8M)
- Maximum growth over 7 days: 10M × 1.20^7 ≈ 35.8M

#### Static Parameter Behaviors (Phase 1: maxSlippage, maxExchangeRate, layerZeroRecipient)

**Setting maxSlippage**
- Only the operator role can set
- The value must be an approved preset in ATWLState for this (target, MAX_SLIPPAGE)
- **If the preset is limited**: The controller_contract must match the restrictedToPau
- Calls `controller.setMaxSlippage(target, value)`
- Stores the config for enumeration
- Emits an event

**Setting maxExchangeRate**
- Only the operator role can set
- The (shares, maxExpectedAssets) tuple must be an approved preset in ATWLState for this (target, MAX_EXCHANGE_RATE)
- **If the preset is limited**: The controller_contract must match the restrictedToPau
- Calls `controller.setMaxExchangeRate(target, shares, maxExpectedAssets)`
- Stores the config for enumeration
- Emits an event

**Setting layerZeroRecipient**
- Only the operator role can set
- The recipient (bytes32) must be an approved preset in ATWLState for this (destinationEndpointId, LAYERZERO_RECIPIENT)
- **If the preset is limited**: The controller_contract must match the restrictedToPau
- Calls `controller.setLayerZeroRecipient(destinationEndpointId, recipient)`
- Stores the config for enumeration
- Emits an event

**Changing a Static Parameter**
- Only the operator role can modify
- The config must already exist
- The new value must be an approved preset in ATWLState
- No cooldown or percentage constraints — can change to any approved value instantly
- Calls the appropriate controller setter
- Emits an event

**Removing a Static Parameter**
- Only the operator role can remove
- The config must already exist
- Removes from storage and registry
- Calls the controller setter with value 0
- Emits an event

#### Admin Behaviors

**Changing Constraints**
- Only admin can change
- Can modify max_increase_percentage and cooldown_period
- Changes apply to all future operations

#### Query Behaviors

- Can list all configured keys for any contract
- Can get the full config for any rate limit
- Can check if a rate limit is unlimited
- Can check if an increase is currently allowed (cooldown elapsed?)
- Can calculate the maximum allowed increase amount

---

## Invariants

### Security Invariants

1. **No configuration without whitelist approval**: A rate limit key cannot be added to Configurator unless ATWLState has an approved entry for that key.

2. **Limited entries are PAU-specific**: If an ATWLState entry has restrictedToPau set, only that specific PAU's Controller/RateLimits can be configured with it.

3. **Bounded increase rate**: The max_amount of any non-unlimited rate limit can increase by at most `max_increase_bps` per `cooldown_period`.

4. **Instant decrease**: Decreases to non-unlimited rate limits are never blocked by cooldown or percentage limits.

5. **Unlimited rate limits are immutable**: Once a rate limit is configured as unlimited, it cannot be modified. It can only be removed entirely.

6. **Timelock on new approvals**: No new entry can be added to ATWLState without first being pending for `timelock_duration`.

7. **Instant removal from whitelist**: Entries can be removed from ATWLState immediately (no timelock).

8. **Preset-only static params**: Static parameters can only be set to values that exist as approved presets in ATWLState.

9. **Removing preset doesn't affect active config**: If a preset is removed from ATWLState, any Configurator config using that value remains active—it just can't be selected again.

10. **Removing whitelist entry doesn't block modifications**: If a rate limit entry is removed from ATWLState, any existing Configurator config can still be modified (increased/decreased) until it is removed from Configurator. Only adding new configs requires whitelist approval.

### Operational Invariants

11. **Enumerable keys**: All configured keys for any contract can be listed.

12. **Enumerable whitelist**: All approved entries and presets can be listed.

13. **Pending additions visible**: All pending additions (in timelock) can be queried.

14. **ATWL scope isolation**: Each ATWL only affects PAUs within its designated scope (Generator, Mainnet Prime+Halo, or specific Altchain Foreign Prime+Foreign Halo).

---

## User Stories

### Story 1: Onboarding Core Approved Collateral (Prime → Morpho Vault)

**As** governance,  
**I want to** approve a major Morpho vault as Core Approved Collateral that any Prime can deploy to,  
**So that** GovOps can allocate Prime capital to this Sky Core-approved DeFi endpoint.

**Background**: Core Approved Collateral consists of legacy DeFi endpoints (major Morpho vaults, Curve pools, Aave pools) directly approved by Sky Core. Primes can deploy into these directly. Onboarding requires:
- Deposit rate limit (bounded)
- Withdraw rate limit (typically unlimited, since withdrawals should always be possible)
- maxExchangeRate setting (to prevent exchange rate manipulation attacks)

**Flow:**

1. **Governance initiates** (Day 0) — Core Council multisig bundles these calls:
   ```
   Mainnet-ATWLModifier.initiate_rate_limit_addition(
       key: hash(LIMIT_4626_DEPOSIT, MORPHO_VAULT),
       max_amount: 10_000_000e18,
       slope: 115_740e18,  // ~10M per day
       unlimited: false,
       restrictedToPau: address(0)  // General onboarding - any Prime can use
   )
   Mainnet-ATWLModifier.initiate_rate_limit_addition(
       key: hash(LIMIT_4626_WITHDRAW, MORPHO_VAULT),
       max_amount: 0,
       slope: 0,
       unlimited: true,
       restrictedToPau: address(0)  // General onboarding
   )
   Mainnet-ATWLModifier.initiate_preset_addition(
       MORPHO_VAULT, MAX_EXCHANGE_RATE, 
       shares: 1e18, maxExpectedAssets: 1.01e18,
       restrictedToPau: address(0)
   )
   Mainnet-ATWLModifier.initiate_preset_addition(
       MORPHO_VAULT, MAX_EXCHANGE_RATE, 
       shares: 1e18, maxExpectedAssets: 1.02e18,
       restrictedToPau: address(0)
   )
   ```

2. **Monitoring period** (Days 0-4):
   - Offchain systems verify the vault address is legitimate
   - Check that rate limit values are reasonable
   - If suspicious, emergency role cancels

3. **Execute after timelock** (Day 4+) — Anyone can call each one:
   ```
   Mainnet-ATWLModifier.execute_rate_limit_addition(hash(LIMIT_4626_DEPOSIT, MORPHO_VAULT))
   Mainnet-ATWLModifier.execute_rate_limit_addition(hash(LIMIT_4626_WITHDRAW, MORPHO_VAULT))
   Mainnet-ATWLModifier.execute_preset_addition(MORPHO_VAULT, MAX_EXCHANGE_RATE, ...)
   ```

4. **GovOps configures for Prime A** (Day 4+):
   ```
   Mainnet-Configurator.add_rate_limit(PRIME_A_RATE_LIMITS, hash(LIMIT_4626_DEPOSIT, MORPHO_VAULT))
   Mainnet-Configurator.add_rate_limit(PRIME_A_RATE_LIMITS, hash(LIMIT_4626_WITHDRAW, MORPHO_VAULT))
   Mainnet-Configurator.set_max_exchange_rate(PRIME_A_CONTROLLER, MORPHO_VAULT, shares: 1e18, maxExpectedAssets: 1.02e18)
   ```

5. **GovOps can also configure for Prime B** (same Core Approved Collateral, different Prime):
   ```
   Mainnet-Configurator.add_rate_limit(PRIME_B_RATE_LIMITS, hash(LIMIT_4626_DEPOSIT, MORPHO_VAULT))
   // ... etc
   ```

6. **Core Approved Collateral is now usable by any Prime**:
   - General onboarding means any Prime PAU can deploy to this Morpho vault
   - Each Prime has its own rate limit config (can differ in actual values after modifications)

---

### Story 2: Setting Up Prime → Foreign Prime Bridge Route (Limited Onboarding)

**As** governance,  
**I want to** approve a LayerZero bridge route from Prime A to Foreign Prime A on Base,  
**So that** only Prime A can use this specific route.

**Background**: Bridge routes between Prime and Foreign Prime are PAU-specific because:
- Each Prime has its own dedicated Foreign Prime on each chain
- Routing capital to the wrong Foreign Prime would break accounting

**Flow:**

1. **Governance initiates** (Day 0) — Core Council multisig bundles:
   ```
   Mainnet-ATWLModifier.initiate_rate_limit_addition(
       key: hash(LIMIT_LAYERZERO_TRANSFER, USDS_OFT, BASE_ENDPOINT_ID),
       max_amount: 50_000_000e18,
       slope: 10_000_000e18 / 1 day,
       unlimited: false,
       restrictedToPau: PRIME_A_RATE_LIMITS  // Limited to Prime A only
   )
   Mainnet-ATWLModifier.initiate_preset_addition(
       BASE_ENDPOINT_ID, 
       LAYERZERO_RECIPIENT, 
       bytes32(FOREIGN_PRIME_A_BASE_ALM_PROXY),
       restrictedToPau: PRIME_A_CONTROLLER  // Limited to Prime A only
   )
   ```

2. **Execute after timelock** (Day 4+)

3. **GovOps configures for Prime A**:
   ```
   Mainnet-Configurator.add_rate_limit(PRIME_A_RATE_LIMITS, hash(LIMIT_LAYERZERO_TRANSFER, USDS_OFT, BASE_ENDPOINT_ID))
   Mainnet-Configurator.set_layerzero_recipient(PRIME_A_CONTROLLER, BASE_ENDPOINT_ID, bytes32(FOREIGN_PRIME_A_BASE_ALM_PROXY))
   ```
   ✅ Succeeds — PRIME_A_RATE_LIMITS matches restrictedToPau

4. **Attempt to configure for Prime B**:
   ```
   Mainnet-Configurator.add_rate_limit(PRIME_B_RATE_LIMITS, hash(LIMIT_LAYERZERO_TRANSFER, USDS_OFT, BASE_ENDPOINT_ID))
   ```
   ❌ Reverts — entry is limited to Prime A only

5. **Prime B needs its own entry** with its own Foreign Prime B destination:
   ```
   Mainnet-ATWLModifier.initiate_rate_limit_addition(
       key: hash(LIMIT_LAYERZERO_TRANSFER, USDS_OFT, BASE_ENDPOINT_ID),
       ...,
       restrictedToPau: PRIME_B_RATE_LIMITS
   )
   Mainnet-ATWLModifier.initiate_preset_addition(
       BASE_ENDPOINT_ID, 
       LAYERZERO_RECIPIENT, 
       bytes32(FOREIGN_PRIME_B_BASE_ALM_PROXY),  // Different destination!
       restrictedToPau: PRIME_B_CONTROLLER
   )
   ```

---

### Story 3: Generator Onboarding a New Prime (Generator-ATWL)

**As** governance,  
**I want to** approve a new Prime's ERC4626 vault in the Generator layer,  
**So that** the Generator can deploy stablecoin capital to the Prime.

**Background**: The Generator layer has its own separate ATWL and Configurator. Primes present themselves to the Generator as ERC4626 vaults.

**Flow:**

1. **Governance initiates on Generator-ATWL** (Day 0):
   ```
   Generator-ATWLModifier.initiate_rate_limit_addition(
       key: hash(LIMIT_4626_DEPOSIT, PRIME_A_VAULT),
       max_amount: 100_000_000e18,
       slope: 50_000_000e18 / 1 day,
       unlimited: false,
       restrictedToPau: address(0)  // General (any Generator can use)
   )
   Generator-ATWLModifier.initiate_rate_limit_addition(
       key: hash(LIMIT_4626_WITHDRAW, PRIME_A_VAULT),
       unlimited: true,
       restrictedToPau: address(0)
   )
   ```

2. **Execute after timelock** (Day 4+)

3. **GovOps configures Generator to deploy to Prime A**:
   ```
   Generator-Configurator.add_rate_limit(GENERATOR_RATE_LIMITS, hash(LIMIT_4626_DEPOSIT, PRIME_A_VAULT))
   Generator-Configurator.add_rate_limit(GENERATOR_RATE_LIMITS, hash(LIMIT_4626_WITHDRAW, PRIME_A_VAULT))
   ```

4. **Capital flow enabled**: Generator can now deposit stablecoin into Prime A's vault

**Note**: In later phases, Laniakea Factory-deployed Primes will bypass the timelock and be available immediately.

---

### Story 4: Onboarding Core Approved Collateral (Prime → SparkLend WETH)

**As** governance,  
**I want to** approve SparkLend WETH as Core Approved Collateral for Prime PAUs,  
**So that** GovOps can deploy Prime capital to SparkLend.

**Background**: Aave-style markets are Core Approved Collateral that Primes deploy into. Onboarding requires:
- Deposit rate limit (bounded)
- Withdraw rate limit (typically unlimited)
- maxSlippage setting (to limit losses from Aave's exchange rate)

**Flow:**

1. **Governance initiates** (Day 0) — Core Council multisig bundles:
   ```
   Mainnet-ATWLModifier.initiate_rate_limit_addition(
       key: hash(LIMIT_AAVE_DEPOSIT, WETH_SPTOKEN),
       max_amount: 50_000e18,
       slope: 10_000e18 / 1 day,
       unlimited: false,
       restrictedToPau: address(0)  // General onboarding - any Prime can use
   )
   Mainnet-ATWLModifier.initiate_rate_limit_addition(
       key: hash(LIMIT_AAVE_WITHDRAW, WETH_SPTOKEN),
       max_amount: 0,
       slope: 0,
       unlimited: true,
       restrictedToPau: address(0)
   )
   Mainnet-ATWLModifier.initiate_preset_addition(WETH_SPTOKEN, MAX_SLIPPAGE, 0.999e18, restrictedToPau: address(0))
   Mainnet-ATWLModifier.initiate_preset_addition(WETH_SPTOKEN, MAX_SLIPPAGE, 0.995e18, restrictedToPau: address(0))
   ```

2. **Execute after timelock** (Day 4+)

3. **GovOps configures for Prime A**:
   ```
   Mainnet-Configurator.add_rate_limit(PRIME_A_RATE_LIMITS, hash(LIMIT_AAVE_DEPOSIT, WETH_SPTOKEN))
   Mainnet-Configurator.add_rate_limit(PRIME_A_RATE_LIMITS, hash(LIMIT_AAVE_WITHDRAW, WETH_SPTOKEN))
   Mainnet-Configurator.set_max_slippage(PRIME_A_CONTROLLER, WETH_SPTOKEN, 0.999e18)
   ```

---

### Story 4b: Prime Deploying into a Halo (Primary Long-Term Path)

**As** governance,  
**I want to** approve a Halo's vault so that a Prime can deploy capital into it,  
**So that** the Prime can access RWA and specialized strategies through the Halo layer.

**Background**: While Primes can deploy directly into Core Approved Collateral (legacy DeFi), the primary long-term deployment path is **Prime → Halo**. Halos provide access to RWA strategies, custodian vaults, and other specialized endpoints that Primes cannot access directly. The connection uses an ERC4626 vault interface.

**Flow:**

1. **Governance initiates** (Day 0) — Core Council multisig bundles:
   ```
   Mainnet-ATWLModifier.initiate_rate_limit_addition(
       key: hash(LIMIT_4626_DEPOSIT, HALO_RWA_VAULT),
       max_amount: 25_000_000e18,
       slope: 10_000_000e18 / 1 day,
       unlimited: false,
       restrictedToPau: address(0)  // General - any Prime can deploy to this Halo
   )
   Mainnet-ATWLModifier.initiate_rate_limit_addition(
       key: hash(LIMIT_4626_WITHDRAW, HALO_RWA_VAULT),
       max_amount: 0,
       slope: 0,
       unlimited: true,
       restrictedToPau: address(0)
   )
   Mainnet-ATWLModifier.initiate_preset_addition(
       HALO_RWA_VAULT, MAX_EXCHANGE_RATE, 
       shares: 1e18, maxExpectedAssets: 1.01e18,
       restrictedToPau: address(0)
   )
   ```

2. **Execute after timelock** (Day 4+)

3. **GovOps configures for Prime A**:
   ```
   Mainnet-Configurator.add_rate_limit(PRIME_A_RATE_LIMITS, hash(LIMIT_4626_DEPOSIT, HALO_RWA_VAULT))
   Mainnet-Configurator.add_rate_limit(PRIME_A_RATE_LIMITS, hash(LIMIT_4626_WITHDRAW, HALO_RWA_VAULT))
   Mainnet-Configurator.set_max_exchange_rate(PRIME_A_CONTROLLER, HALO_RWA_VAULT, shares: 1e18, maxExpectedAssets: 1.01e18)
   ```

4. **Capital flow enabled**: 
   - Prime A can now deposit into the Halo's vault
   - The Halo then deploys that capital into RWA strategies, custodians, etc.
   - This is the primary long-term architecture: Prime → Halo → RWA/Custodian

---

### Story 5: Halo Onboarding a Regulated Offramp (Limited)

**As** governance,  
**I want to** approve an offramp endpoint that only a specific Halo can use,  
**So that** regulatory requirements are met for RWA deployment.

**Background**: Halos deploy into RWA strategies, custodian vaults, and regulated offramps (not external DeFi). Some offramps have legal restrictions on which entities can send funds — only assets from a specific, KYC'd origin are accepted.

**Flow:**

1. **Governance initiates** (Day 0):
   ```
   Mainnet-ATWLModifier.initiate_rate_limit_addition(
       key: hash(LIMIT_ASSET_TRANSFER, USDC, REGULATED_RWA_CUSTODIAN),
       max_amount: 10_000_000e6,
       slope: 5_000_000e6 / 1 day,
       unlimited: false,
       restrictedToPau: HALO_RWA_RATE_LIMITS  // Only this specific Halo
   )
   ```

2. **Execute after timelock** (Day 4+)

3. **GovOps configures for the RWA Halo**:
   ```
   Mainnet-Configurator.add_rate_limit(HALO_RWA_RATE_LIMITS, hash(LIMIT_ASSET_TRANSFER, USDC, REGULATED_RWA_CUSTODIAN))
   ```
   ✅ Succeeds

4. **Other Halos cannot use this offramp**:
   ```
   Mainnet-Configurator.add_rate_limit(HALO_OTHER_RATE_LIMITS, hash(LIMIT_ASSET_TRANSFER, USDC, REGULATED_RWA_CUSTODIAN))
   ```
   ❌ Reverts — limited to HALO_RWA only

---

### Story 5b: Halo Onboarding a Custodian Vault (General)

**As** governance,  
**I want to** approve a custodian vault that multiple Halos can deploy to,  
**So that** Halos can safely offboard assets to institutional custody.

**Background**: Halos deploy into custodian vaults for institutional-grade asset custody. When a custodian accepts assets from multiple Halos (no KYC restriction per origin), it can be onboarded as a general entry.

**Flow:**

1. **Governance initiates** (Day 0):
   ```
   Mainnet-ATWLModifier.initiate_rate_limit_addition(
       key: hash(LIMIT_ASSET_TRANSFER, USDC, INSTITUTIONAL_CUSTODIAN),
       max_amount: 50_000_000e6,
       slope: 20_000_000e6 / 1 day,
       unlimited: false,
       restrictedToPau: address(0)  // General - any Halo can use
   )
   ```

2. **Execute after timelock** (Day 4+)

3. **GovOps configures for Halo A**:
   ```
   Mainnet-Configurator.add_rate_limit(HALO_A_RATE_LIMITS, hash(LIMIT_ASSET_TRANSFER, USDC, INSTITUTIONAL_CUSTODIAN))
   ```

4. **GovOps can also configure for Halo B**:
   ```
   Mainnet-Configurator.add_rate_limit(HALO_B_RATE_LIMITS, hash(LIMIT_ASSET_TRANSFER, USDC, INSTITUTIONAL_CUSTODIAN))
   ```

5. **Each Halo has independent rate limits**: Halo A and Halo B each have their own rate limit configs that can be adjusted independently.

---

### Story 6: Onboarding Core Approved Collateral on Altchain (Foreign Prime → Base Morpho)

**As** governance,  
**I want to** approve a Morpho vault on Base as Core Approved Collateral for Foreign Prime PAUs,  
**So that** GovOps can deploy bridged capital to L2 DeFi strategies.

**Background**: Each altchain has its own ATWL and Configurator. Foreign Primes deploy into Core Approved Collateral (Sky Core-approved DeFi) on their respective chains, just like mainnet Primes do.

**Flow:**

1. **Governance initiates on Base-ATWL** (Day 0):
   ```
   Base-ATWLModifier.initiate_rate_limit_addition(
       key: hash(LIMIT_4626_DEPOSIT, BASE_MORPHO_VAULT),
       max_amount: 5_000_000e18,
       slope: 2_000_000e18 / 1 day,
       unlimited: false,
       restrictedToPau: address(0)  // Any Foreign Prime on Base can use
   )
   Base-ATWLModifier.initiate_rate_limit_addition(
       key: hash(LIMIT_4626_WITHDRAW, BASE_MORPHO_VAULT),
       unlimited: true,
       restrictedToPau: address(0)
   )
   ```

2. **Execute after timelock** (Day 4+)

3. **GovOps configures for Foreign Prime A on Base**:
   ```
   Base-Configurator.add_rate_limit(FOREIGN_PRIME_A_BASE_RATE_LIMITS, hash(LIMIT_4626_DEPOSIT, BASE_MORPHO_VAULT))
   Base-Configurator.add_rate_limit(FOREIGN_PRIME_A_BASE_RATE_LIMITS, hash(LIMIT_4626_WITHDRAW, BASE_MORPHO_VAULT))
   ```

---

### Story 7: Gradually Increasing a Rate Limit

**As** a GovOps operator,  
**I want to** increase a Prime's deposit limit to a Core Halo over time,  
**So that** exposure grows predictably.

**Flow:**

Starting: Prime A's Morpho vault deposit limit at 10M.

1. **Day 1** - First increase:
   ```
   Mainnet-Configurator.set_rate_limit(
       PRIME_A_RATE_LIMITS,
       hash(LIMIT_4626_DEPOSIT, MORPHO_VAULT),
       new_max: 12_000_000e18,  // +20%
       new_slope: 138_888e18
   )
   ```
   ✅ Succeeds. Cooldown starts.

2. **Day 1** (12 hours later):
   ```
   Mainnet-Configurator.set_rate_limit(..., new_max: 14_000_000e18, ...)
   ```
   ❌ Reverts: cooldown not elapsed.

3. **Day 2** (24+ hours later):
   ```
   Mainnet-Configurator.set_rate_limit(..., new_max: 14_400_000e18, ...)
   ```
   ✅ Succeeds (+20% of 12M).

4. **Growth trajectory**: 10M → 12M → 14.4M → 17.3M → ... → 35.8M (after 7 days)

---

### Story 8: Emergency Response

**As** GovOps,  
**I want to** immediately reduce a Prime's exposure to compromised Core Approved Collateral,  
**So that** losses are minimized.

**Flow:**

1. **Alert**: Core Approved Collateral Protocol X shows signs of exploit.

2. **Immediate decrease** (no cooldown):
   ```
   Mainnet-Configurator.set_rate_limit(
       PRIME_A_RATE_LIMITS,
       hash(LIMIT_4626_DEPOSIT, PROTOCOL_X_VAULT),
       new_max: 0,
       new_slope: 0
   )
   ```
   ✅ Succeeds instantly.

3. **Note**: Withdraw rate limit is unlimited and immutable—capital can still exit.

4. **Cooldown preserved**: When threat passes, the increase cooldown continues from where it was (decrease doesn't reset it).

---

### Story 9: Attempting to Modify an Unlimited Rate Limit

**As** GovOps,  
**I try to** reduce an unlimited withdraw rate limit during an emergency.

**Flow:**

1. **Attempt**:
   ```
   Mainnet-Configurator.set_rate_limit(
       PRIME_A_RATE_LIMITS,
       hash(LIMIT_4626_WITHDRAW, MORPHO_VAULT),
       new_max: 1_000_000e18,
       new_slope: 0
   )
   ```
   ❌ Reverts: Unlimited rate limits are immutable.

2. **Only option**: Remove the rate limit entirely:
   ```
   Mainnet-Configurator.remove_rate_limit(PRIME_A_RATE_LIMITS, hash(LIMIT_4626_WITHDRAW, MORPHO_VAULT))
   ```
   ✅ Succeeds. But now withdrawals are blocked entirely (no rate limit = 0).

3. **Lesson**: Unlimited rate limits are a deliberate design choice—they cannot be "dialed down" later.

---

### Story 10: Emergency Cancellation of Pending Approval

**As** an emergency responder,  
**I want to** cancel a suspicious pending whitelist addition,  
**So that** it never becomes active.

**Flow:**

1. **Monitoring detects**: Pending addition for unknown contract address.

2. **Cancel specific entry**:
   ```
   Mainnet-ATWLModifier.cancel_rate_limit_addition(hash(LIMIT_4626_DEPOSIT, SUSPICIOUS_ADDRESS))
   ```
   ✅ Pending removed.

3. **Or cancel everything** (nuclear option):
   ```
   Mainnet-ATWLModifier.cancel_all_pending()
   ```
   ✅ All pending additions cleared.

---

### Story 11: Deprecating Core Approved Collateral

**As** governance,  
**I want to** remove Core Approved Collateral from the whitelist after it's been deprecated,  
**So that** no new Primes can onboard it, while existing operations continue.

**Background**: A Core Approved Collateral endpoint (Morpho vault) is being sunset. Governance wants to prevent new Primes from deploying to it, but existing Primes should continue to operate until they wind down.

**Flow:**

1. **Current state**: 
   - Morpho Vault is whitelisted in Mainnet-ATWLState (general onboarding)
   - Prime A has it configured (deposit limit: 10M)
   - Prime B has it configured (deposit limit: 5M)

2. **Governance removes from whitelist** (instant):
   ```
   Mainnet-ATWLModifier.remove_rate_limit_entry(hash(LIMIT_4626_DEPOSIT, MORPHO_VAULT))
   Mainnet-ATWLModifier.remove_rate_limit_entry(hash(LIMIT_4626_WITHDRAW, MORPHO_VAULT))
   ```
   ✅ Entries removed from ATWLState.

3. **Existing configs continue working**:
   - Prime A can still deposit/withdraw (rate limits still active)
   - Prime B can still deposit/withdraw (rate limits still active)
   - GovOps can still decrease Prime A's limit (e.g., 10M → 5M) ✅
   - GovOps can still increase Prime A's limit (subject to 20%/24h constraint) ✅

4. **New configurations blocked**:
   ```
   Mainnet-Configurator.add_rate_limit(PRIME_C_RATE_LIMITS, hash(LIMIT_4626_DEPOSIT, MORPHO_VAULT))
   ```
   ❌ Reverts: key not approved in ATWLState.

5. **Full wind-down** (when ready):
   ```
   // Prime A removes its config
   Mainnet-Configurator.remove_rate_limit(PRIME_A_RATE_LIMITS, hash(LIMIT_4626_DEPOSIT, MORPHO_VAULT))
   
   // Prime B removes its config
   Mainnet-Configurator.remove_rate_limit(PRIME_B_RATE_LIMITS, hash(LIMIT_4626_DEPOSIT, MORPHO_VAULT))
   ```
   ✅ Once removed from Configurator, cannot be re-added (whitelist entry gone).

6. **Key insight**: Whitelist removal is a "soft deprecation" — it prevents expansion while allowing graceful wind-down.

---

## Default Configuration Values

| Parameter | Default | Notes |
|-----------|---------|-------|
| Timelock duration | 4 days | Minimum 1 day |
| Max increase per period | 20% (2000 bps) | Configurable by admin |
| Cooldown period | 24 hours | Configurable by admin |

---

## Integration with Existing System

### Deployment Sequence (Per ATWL Scope)

**For Generator Layer:**
1. Deploy Generator-ATWLState
2. Deploy Generator-ATWLModifier, pointing to Generator-ATWLState
3. Deploy Generator-Configurator, pointing to Generator-ATWLState
4. For each Generator PAU's RateLimits: Grant Generator-Configurator the `DEFAULT_ADMIN_ROLE`
5. For each Generator PAU's Controller: Grant Generator-Configurator the `DEFAULT_ADMIN_ROLE`

**For Mainnet Prime + Halo:**
1. Deploy Mainnet-ATWLState
2. Deploy Mainnet-ATWLModifier, pointing to Mainnet-ATWLState
3. Deploy Mainnet-Configurator, pointing to Mainnet-ATWLState
4. For each Prime and Halo PAU's RateLimits: Grant Mainnet-Configurator the `DEFAULT_ADMIN_ROLE`
5. For each Prime and Halo PAU's Controller: Grant Mainnet-Configurator the `DEFAULT_ADMIN_ROLE`

**For Each Altchain (Foreign Prime + Foreign Halo):**
1. Deploy Altchain-ATWLState
2. Deploy Altchain-ATWLModifier, pointing to Altchain-ATWLState
3. Deploy Altchain-Configurator, pointing to Altchain-ATWLState
4. For each Foreign Prime and Foreign Halo PAU's RateLimits: Grant Altchain-Configurator the `DEFAULT_ADMIN_ROLE`
5. For each Foreign Prime and Foreign Halo PAU's Controller: Grant Altchain-Configurator the `DEFAULT_ADMIN_ROLE`

### Existing Controller Functions Used

The Configurator calls these existing functions on the Controllers:

| Function | Controller | Purpose |
|----------|------------|---------|
| `setMaxSlippage(address, uint256)` | Both | Set slippage tolerance for a target |
| `setMaxExchangeRate(address, uint256, uint256)` | Both | Set exchange rate threshold for ERC4626 |
| `setLayerZeroRecipient(uint32, bytes32)` | Both | Set recipient address for LayerZero transfers |

The Configurator calls these existing functions on RateLimits:

| Function | Purpose |
|----------|---------|
| `setRateLimitData(bytes32, uint256, uint256)` | Set bounded rate limit |
| `setUnlimitedRateLimitData(bytes32)` | Set unlimited rate limit |

### Role Summary (Per ATWL Scope)

| Contract | Role | Holder | Capabilities |
|----------|------|--------|--------------|
| ATWLState | modifier | ATWLModifier | Add/remove whitelist entries |
| ATWLState | owner | PauseProxy | Change modifier address |
| ATWLModifier | governance | Core Council | Initiate additions, remove entries, cancel pending |
| ATWLModifier | admin | PauseProxy | Set timelock duration, manage roles, cancel pending |
| ATWLModifier | emergency | Freezer/Mom | Cancel pending additions |
| Configurator | operator | GovOps | Configure rate limits and static params |
| Configurator | admin | PauseProxy | Set increase constraints, manage roles |

---

## Future Considerations

### Laniakea Factory Integration (Phase 2+)

The Laniakea Factory will be able to deploy PAU infrastructure automatically. When integrated:

- **Factory-deployed Primes**: Can be added to Generator-ATWL with **no timelock delay**
- **Factory-deployed PAUs**: Pre-verified, can be onboarded immediately
- **Automated whitelist entries**: Factory can add entries directly to ATWLState

This requires:
- A `FACTORY` role on ATWLState that can bypass ATWLModifier's timelock
- Trust assumptions around the Factory's deployment verification
- Integration with cross-chain registries for altchain deployments

---

## Open Questions

1. **Key computation**: Should Configurator recompute keys from (limit_type, target, ...) or accept pre-computed keys? Pre-computed is simpler but requires trust that the key matches what's in ATWLState.

2. **Enumeration pagination**: For contracts with many keys, listing could be expensive. Should we add pagination from the start?

3. **Cross-ATWL coordination**: When a target is deprecated across multiple chains, should there be a coordinated mechanism, or is per-chain removal sufficient?

4. **Limited entry key collision**: If the same rate limit key needs both a general and limited entry (for different use cases), how should this be handled? Options:
   - Include restrictedToPau in the key lookup
   - Require different keys for different scopes
   - Disallow overlap entirely