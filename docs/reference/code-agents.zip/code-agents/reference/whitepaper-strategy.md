# Sky Whitepaper Strategy (Deprecated)

**Status:** Deprecated (retained for history)
**Replaced By:** `active/whitepaper/README.md`
**Date:** December 2025

> This document is retained for historical context only. Do not update it.

---

## Target Audiences (in order of priority)

1. **Institutional allocators** — Want yield, need risk framework credibility
2. **Crypto-native investors** — Want tokenomics clarity, growth story
3. **Technical integrators** — Want architecture details (appendix)

---

## Core Narrative Arc

```
Hook (why care) → Credibility (why trust) → Mechanics (how it works) → Opportunity (how to participate)
```

---

## Opening Messaging

Sky Ecosystem is the world's largest decentralized stablecoin protocol, backing USDS which has more than 9 billion USDS in circulation. There's more than $300B stablecoins that don't earn a yield, and that capital naturally wants to earn a yield, which is why institutions and smart money are increasingly using USDS for its broadly recognized risk-adjusted return.

Sky generates profits from the stablecoin business model, and a minimum of 75% of profits are used for SKY buybacks and distributed to SKY holders as staking rewards.

---

## Main Document Structure

### Part 1: The Hook (1-2 pages)
**"World's Largest Decentralized Stablecoin"**

- 9B+ USDS in circulation
- The $300B opportunity: stablecoins sitting idle, wanting yield
- Why institutions/smart money are moving to USDS
- The profit share: 75%+ flows to SKY holders via buybacks + staking

*Goal: Reader immediately understands the scale and the value proposition*

### Part 2: Brief History (0.5 pages)
**"From MakerDAO to Sky"**

- MakerDAO created DAI (first decentralized stablecoin at scale)
- Evolution: single product → full financial infrastructure
- Key milestones: launch, Endgame, rebrand, agent deployment

*Goal: Establish credibility through track record, show this isn't new/untested*

### Part 3: How Sky Makes Money (1-2 pages)
**"The Stablecoin Business Model"**

- Where yield comes from (lending spreads, RWA income, DeFi yields)
- Revenue waterfall: stability first, then SKY holders
- Simple flow diagram: Revenue → Buffers → Buybacks/Rewards
- Current metrics (SSR, TVL, revenue run rate)

*Goal: Investor-friendly explanation of the economics*

### Part 4: Token System (1-2 pages)
**"USDS, sUSDS, and SKY"**

- USDS: The stablecoin (1:1 USD, liquid, composable)
- sUSDS: The yield token (deposit USDS, earn SSR automatically)
- SKY: The governance + profit-sharing token
- Deflationary dynamics: buyback/burn, no emissions

*Goal: Clear token utility for each, why hold SKY*

### Part 5: The Agent Framework (2-3 pages)
**"How Sky Scales: The Central Bank Model"**

- Sky Core as central bank, Primes as commercial banks
- Why this matters: efficiency, specialization, risk isolation
- Current Primes: Spark, Grove, Keel, Obex
- How Halos enable rapid product deployment

*Goal: Show the structural innovation that enables scale*

### Part 6: Risk Management (2-3 pages)
**"Institutional-Grade Risk Framework"**

- Basel III-inspired capital requirements
- Loss absorption waterfall (JRC → SRC → buffers)
- Encumbrance ratios and real-time monitoring
- Why this matters: institutions need auditable risk frameworks

*Goal: Build institutional confidence through familiar risk language*

### Part 7: Growth Vectors (1-2 pages)
**"Where Sky Is Going"**

- Multi-chain expansion (SkyLink, L2 deployments)
- Institutional partnerships (Passthrough Halos)
- New asset classes via GRF
- Generator Agents: expansion into new currencies (brief, future-looking)
- The Laniakea upgrade: automated settlement at scale

*Goal: Forward-looking growth story*

### Part 8: Governance (1 page)
**"How Decisions Are Made"**

- SKY voting
- Escalation model (code handles 99%, humans resolve edge cases)
- The Atlas as constitution

*Goal: Brief, shows decentralization without getting into weeds*

---

## Appendices

### Appendix A: Protocol Features
*Exhaustive list of Sky Core mechanisms*

| Feature | Description |
|---------|-------------|
| Sky Savings Rate (SSR) | Base yield rate for sUSDS holders |
| Smart Burn Engine | Algorithmic SKY buyback/burn |
| Stability Capital Buffer | Retained earnings for solvency |
| LitePSM | USDC ↔ USDS peg stability |
| SkyLink | Multi-chain token bridging |
| Capped OSM | Oracle price manipulation protection |
| Emergency Response System | Freeze/recovery procedures |
| Governance Polls | SKY holder decision-making |
| Executive Votes | On-chain parameter changes |
| stUSDS System | Segregated risk capital for SKY borrowing |
| Base Rate | Protocol-wide stability fee |
| Treasury Waterfall | Revenue allocation logic |
| ... | (continue exhaustively) |

### Appendix B: Agent Framework Primitives
*Features available to Sky agents*

| Primitive | Agent Types | Description |
|-----------|-------------|-------------|
| Allocation System | Primes, Halos | Deploy capital into approved strategies via PAU |
| Distribution Rewards | Primes | Token rewards to incentivize integrations |
| Integration Boost | Primes | Targeted incentives for specific protocols |
| JRC Rental | Primes | Rent junior risk capital from other Primes |
| TEJRC Tokenization | Primes | External parties provide JRC via smart contract |
| Light Agent Primitive | Primes | Create Halos under Prime umbrella |
| Executor Accord | All | Framework for executor relationships |
| Root Edit | All | Governance modification of agent artifacts |
| Agent Token | All | Native token with disabled emissions |
| SubProxy Account | All | On-chain treasury for agent operations |
| Rate Limit System | All | Bounded capital movement velocity |
| Encumbrance Monitoring | All | Real-time risk capital verification |
| ... | | (continue exhaustively) |

### Appendix C: Token Reference

**Core Tokens**

| Token | Type | Description |
|-------|------|-------------|
| USDS | Stablecoin | Primary unit of account, 1:1 USD peg |
| sUSDS | Yield token | Deposit USDS, earn SSR automatically |
| SKY | Governance | Voting rights + profit share via staking/buybacks |
| stUSDS | Risk capital | Segregated capital for SKY-backed borrowing |
| DAI | Legacy stablecoin | 1:1 convertible with USDS |

**Agent Framework Tokens**

| Token | Type | Description |
|-------|------|-------------|
| Agent Tokens | Governance | Per-agent voting (SPARK, GROVE, etc.) |
| TEJRC | Risk capital | Tokenized external junior risk capital |
| TISRC | Risk capital | Tokenized internal senior risk capital |
| TESRC | Risk capital | Tokenized external senior risk capital |
| srUSDS | Queue token | Represents position in SRC redemption queue |
| Halo Unit Shares | Ownership | Pro-rata claim on Halo Unit assets |

**Future/Expansion Tokens**

| Token | Type | Description |
|-------|------|-------------|
| SGAs | Stablecoin | Sky Generated Assets — new currencies issued by Generators |

### Appendix D: Contract Addresses
*(Current key addresses)*

### Appendix E: Glossary
*(Term definitions)*

---

## Coverage Model

```
Main Document          → Business-level understanding
                         (what Sky does, why it matters)

Appendix A (Features)  → Every Sky Core mechanism
Appendix B (Primitives)→ Every agent capability
                         ─────────────────────────
                         Together = complete technical design

Appendix C (Tokens)    → Every token in the system
Appendix D (Addresses) → Deployment specifics
Appendix E (Glossary)  → Term definitions
```

A reader going through A + B gets the full picture of "what can happen in Sky" without gaps.

---

## Key Principles

| Principle | Application |
|-----------|-------------|
| **Lead with value** | Don't start with architecture; start with "biggest stablecoin, 75% to holders" |
| **Familiar before novel** | Basel III before SPTP; central bank before Sentinels |
| **Progressive disclosure** | Simple explanation first, technical details in appendix |
| **Numbers matter** | $9B, $300B opportunity, 75% profit share — concrete > abstract |
| **Institutional language** | "Risk-adjusted return", "capital requirements", "loss absorption" |

---

## What to Cut/Minimize

- Synome/Atlas architecture details (implementation, not value prop)
- Governance process minutiae
- Smart contract specifics (move to appendix)
- Historical MakerDAO mechanics

## What to Emphasize

- Scale ($9B, world's largest)
- Yield opportunity ($300B idle)
- Profit distribution (75%+ to SKY)
- Risk framework (Basel III credibility)
- Growth story (institutional adoption, multi-chain)

---

## Generator Agents (Future Growth)

See `generator-strategy.md` for details on incorporating Generators.

Key points:
- Frame as future growth opportunity
- Keep core flow as Sky → Prime → Halo → End Asset
- Generators enable new currencies (SGAs) and regional expansion
- Brief mention in Part 7 (Growth Vectors), not core architecture
