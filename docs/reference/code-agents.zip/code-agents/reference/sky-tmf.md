
rune

3
29d
Please note this is still a draft and there could be minor edits coming in the next few days. Actual implementation as atlas rules would be done through the Atlas Edit Proposal process.

This document outlines advanced long term features of how Sky Ecosystem handles the income generated from the Sky Protocol and Sky Agent Framework Primitives, designed to be future proofed so that Sky can remain as stable and immutable as possible over the long term with minimal need for future governance changes beyond the security, risk and governance maintenance needs carried out by the Core Council.

The Sky TMF is described in this post in order to illustrate the intended long term plan that will be brought to a future Atlas Edit Proposal, in order to form the basis of long term financial performance forecasts for the Sky Ecosystem. In practice the proposals that will implement them could differ slightly from the exact details here, and there are various components and features that may be introduced sequentially, but generally they are expected reflect the overall rules and example scenarios described in this post.

The design of the Sky TMF described here is still a simplification because it doesn’t take into account the upcoming long term feature of Generator Agents and the handling of multiple Sky Generated Assets. They will be dealt with in a future long term proposal that will further refine how the TMF works.

It is a continuation of the last iteration of the Sky TMF described in this post: Sky Ecosystem Entities and the Treasury Management Function - this post also provides more context around the Fortification Conserver role and Fortification Foundation.

The Sky Treasury Management Function details
The Sky TMF is a single, linear waterfall mechanism designed to manage all protocol net revenue (Revenue minus Expenses). All calculations and transfers are denominated in USDS.

The Waterfall Flow
All protocol net revenue enters the top of the funnel and is distributed sequentially through five steps. Crucially, each step calculates its allocation based on the Step Result passed down from the previous step.

Key Definition: Net Revenue Ratio
The Net Revenue Ratio determines how aggressively the protocol funds stability buffers and token burn based on the total protocol net revenue.

Target Constant: 3 Billion USDS
Cap Threshold: 1,000 Billion USDS (1 Trillion)
Formula (Piecewise Hyperbolic):

# Constants
TARGET_CONSTANT = 3_000_000_000  # 3 Billion
CAP_THRESHOLD   = 1_000_000_000_000  # 1 Trillion

if current_yearly_net_revenue < CAP_THRESHOLD:
    # Hyperbolic curve to prevent quadratic drag
    net_revenue_ratio = current_yearly_net_revenue / (current_yearly_net_revenue + TARGET_CONSTANT)
else:
    # Snaps to 1.0 at 1 Trillion
    net_revenue_ratio = 1.0
Note: The ratio follows a hyperbolic curve that prevents “quadratic drag” (rewards decreasing) as revenue grows. It smoothly approaches 0.997 at 1 Trillion Net Revenue, at which point it snaps to exactly 1.0.

Step 1: Security and maintenance
The first allocation funds the core teams doing governance security, protocol security and risk management, and ongoing maintenance and development of critical core infrastructure.

Allocation (Genesis Phase): 21% of Total Net Revenue
Allocation (Post-Genesis): 4–10% of Total Net Revenue (governance determined)
Destination: Core Budget & Operational Multisigs
Step 1 Result: Total Net Revenue − Step 1 Allocation
Step 2: Aggregate Backstop Capital (Solvency Buffer)
This step builds the protocol’s “Savings Account” (denominated in USDS) to protect against bad debt or insolvency events.

Target Size: 1.5% of Total Supply (Liabilities)
Allocation Rate Formula:

# Calculate how much space is left in the buffer (1.0 = Empty, 0.0 = Full)
fill_factor = 1.0 - (current_buffer_size / target_buffer_size)

# Apply 10% floor to the Net Revenue Ratio
effective_ratio = max(net_revenue_ratio, 0.10)

# Calculate dynamic rate (Max 50% when empty)
step_2_rate = fill_factor * 0.50 * effective_ratio
Allocation Logic (Three Phases):

Phase 1: Safety Floor & Turbo Fill (< 125M USDS)

Condition: Current Buffer < 125,000,000 USDS
Allocation: MAX(0.25, step_2_rate) * step_1_result
Phase 2: Filling Phase (Filling toward Target)

Condition: 125M ≤ Current Buffer < Target Size
Allocation: step_2_rate * step_1_result
Phase 3: Hard Cap (Stop)

Condition: Current Buffer ≥ Target Size
Allocation: 0%
Step 2 Result: Step 1 Result − Step 2 Allocation

Step 3: Fortification Conserver Account
This step funds the Fortification Conserver, which is currently set as the Fortification Foundation. The Fortification Conserver is an Alignment Conserver responsible for legal defense, resilience, and unquantifiable risk management, as well as triggering the SKY emissions backstop in case of Sky Ecosystem insolvency. Currently the backstop SKY emissions feature is disabled, and will be implemented in a future upgrade to the system.

In the short run while Sky is at small scale, the Fortification Conserver role is less critical as it can depend on established existing legal infrastructure. As Sky grows in scale it will increasingly be unable to utilize recourse and protection mechanisms built by other, larger entities, and at that point the Fortification Conserver becomes more important, hence the growing allocation as Net Revenue scales.

Allocation Formula:

step_3_allocation = (0.20 * net_revenue_ratio) * step_2_result
Step 3 Result: Step 2 Result − Step 3 Allocation

Step 4: Smart Burn Engine
This step captures value for token holders by buying SKY from the market and burning it.

Allocation Formula:

step_4_allocation = (0.20 * net_revenue_ratio) * step_3_result
Step 4 Result: Step 3 Result − Step 4 Allocation

Step 5: Staking Rewards
All remaining USDS after Steps 1 through 4 flows into this final engine. This is the primary destination for surplus during the Genesis Phase.

Allocation: 100% of Step 4 Result
Destination: Distributed to SKY and USDS stakers
Example Scenarios
The following scenarios illustrate how the waterfall distributes capital under different financial conditions. Note how the sequential deductions ensure capital remains for the final step.

IMPORTANT: The numbers provided below are NOT financial forecasts or models. They are provided just as calculation examples to showcase how the math of the waterfall works in the TMF in various hypothetical scenarios.

Overview
Scenario	Net Revenue	Smart Burn	Staking Rewards
1. Early Stage (Genesis)	200M	~1.5M	~115.6M
2. Growth Stage (Post-Genesis)	2B	~114.8M	~1.32B
3. Mature Stage (Post-Genesis)	5B	~503.1M	~3.52B
4. Massive Scale (Post-Genesis)	20B	~2.64B	~12.55B
Scenario 1: Early Stage / Low Profit (Genesis Phase)
Total Net Revenue: 200 Million USDS
Net Revenue Ratio: 0.0625 (200M / (200M + 3B))
Buffer Status: 50M (Target 150M) → Phase 1 (Safety Floor)
# Initial State
net_revenue = 200_000_000

# Step 1: Security (21% - Genesis Phase)
step_1_allocation = net_revenue * 0.21         # 42,000,000
step_1_result     = net_revenue - step_1_allocation  # 158,000,000

# Step 2: Backstop (Phase 1: Safety Floor)
# Formula: (1 - 50/150) * 50% * max(0.0625, 0.10) = 0.66 * 0.5 * 0.10 = 3.3%
# Floor of 25% applies because 25% > 3.3%
step_2_allocation = step_1_result * 0.25       # 39,500,000
step_2_result     = step_1_result - step_2_allocation # 118,500,000

# Step 3: Fortification (Ratio: 0.0625 * 20% = 1.25%)
step_3_allocation = step_2_result * 0.0125     # 1,481,250
step_3_result     = step_2_result - step_3_allocation # 117,018,750

# Step 4: Burn (Ratio: 0.0625 * 20% = 1.25%)
step_4_allocation = step_3_result * 0.0125     # 1,462,734
step_4_result     = step_3_result - step_4_allocation # 115,556,016

# Step 5: Staking Rewards
final_staking_rewards = 115_556_016  # ~115.6 Million
Scenario 2: Growth Stage / Medium Profit (Post-Genesis)
Total Net Revenue: 2 Billion USDS
Net Revenue Ratio: 0.40 (2B / (2B + 3B))
Buffer Status: 500M (Target 1.5B) → Phase 2 (Filling)
# Initial State
net_revenue = 2_000_000_000

# Step 1: Security (10% - Post-Genesis)
step_1_allocation = net_revenue * 0.10         # 200,000,000
step_1_result     = net_revenue - step_1_allocation  # 1,800,000,000

# Step 2: Backstop (Phase 2: Filling)
# Fill Factor = (1.5B - 500M) / 1.5B = 0.666
# Rate = 0.666 * 50% * 0.40 = 13.33%
step_2_allocation = step_1_result * 0.1333     # 240,000,000
step_2_result     = step_1_result - step_2_allocation # 1,560,000,000

# Step 3: Fortification (Ratio: 0.40 * 20% = 8%)
step_3_allocation = step_2_result * 0.08       # 124,800,000
step_3_result     = step_2_result - step_3_allocation # 1,435,200,000

# Step 4: Burn (Ratio: 0.40 * 20% = 8%)
step_4_allocation = step_3_result * 0.08       # 114,816,000
step_4_result     = step_3_result - step_4_allocation # 1,320,384,000

# Step 5: Staking Rewards
final_staking_rewards = 1_320_384_000  # ~1.32 Billion
Scenario 3: Mature Stage / High Profit (Post-Genesis)
Total Net Revenue: 5 Billion USDS
Net Revenue Ratio: 0.625 (5B / (5B + 3B))
Buffer Status: 10B (Target 7.5B) → Phase 3 (Hard Cap/Full)
# Initial State
net_revenue = 5_000_000_000

# Step 1: Security (8% - Post-Genesis)
step_1_allocation = net_revenue * 0.08         # 400,000,000
step_1_result     = net_revenue - step_1_allocation  # 4,600,000,000

# Step 2: Backstop (Phase 3: Full)
# Buffer > Target, so Allocation is 0
step_2_allocation = 0
step_2_result     = step_1_result - 0          # 4,600,000,000

# Step 3: Fortification (Ratio: 0.625 * 20% = 12.5%)
step_3_allocation = step_2_result * 0.125      # 575,000,000
step_3_result     = step_2_result - step_3_allocation # 4,025,000,000

# Step 4: Burn (Ratio: 0.625 * 20% = 12.5%)
step_4_allocation = step_3_result * 0.125      # 503,125,000
step_4_result     = step_3_result - step_4_allocation # 3,521,875,000

# Step 5: Staking Rewards
final_staking_rewards = 3_521_875_000  # ~3.52 Billion
Scenario 4: Massive Scale (Post-Genesis, Full Buffer)
Total Net Revenue: 20 Billion USDS
Net Revenue Ratio: 0.87 (20B / (20B + 3B))
Buffer Status: 20B (Target 15B) → Phase 3 (Hard Cap/Full)
# Initial State
net_revenue = 20_000_000_000

# Step 1: Security (8% - Post-Genesis)
step_1_allocation = net_revenue * 0.08         # 1,600,000,000
step_1_result     = net_revenue - step_1_allocation  # 18,400,000,000

# Step 2: Backstop (Phase 3: Full)
# Buffer > Target, so Allocation is 0
step_2_allocation = 0
step_2_result     = step_1_result - 0          # 18,400,000,000

# Step 3: Fortification (Ratio: 0.87 * 20% = 17.4%)
step_3_allocation = step_2_result * 0.174      # 3,201,600,000
step_3_result     = step_2_result - step_3_allocation # 15,198,400,000

# Step 4: Burn (Ratio: 0.87 * 20% = 17.4%)
step_4_allocation = step_3_result * 0.174      # 2,644,521,600
step_4_result     = step_3_result - step_4_allocation # 12,553,878,400

# Step 5: Staking Rewards
final_staking_rewards = 12_553_878_400  # ~12.55 Billion