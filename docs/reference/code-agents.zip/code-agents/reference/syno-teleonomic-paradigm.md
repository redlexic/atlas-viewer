The Syno-Telonomic Artificial Intelligence Paradigm
Introduction to the Syno-Telonomic Paradigm
The syno-telonomic paradigm is a five-layer, self-improving framework for aligned AI agents in decentralised systems. It blends blockchain governance, DeFi mechanics and AI safety: higher layers can veto lower ones for universal alignment, while lower layers supply telemetry upward for adaptation.
 Audience – Archon engineers & leadership preparing to extend today’s neurosymbolic agents into the full syno-telonomic stack.
Purpose of this document – serve as a single, self‑contained reference to the five canonical objects in the syno‑telonomic paradigm and show concrete, side‑by‑side examples from the two principal builders on the Archon stack:
 • Sky – the DeFi protocol that succeeds MakerDAO and issues USDS & SKY.
 • Archon – the technology studio that co‑maintains the paradigm and advances state‑of‑the-art teleonome (self-improving genome) research.
Archon engineers & leadership preparing to extend today’s neurosymbolic agents into the full syno-telonomic stack.
Design Rationale
Five layers separate trust domains and update speeds.


Authority flows downward (mission → action); telemetry upward (signals → adaptation).


Governance boundaries – The Synome establishes high-level rules and alignment; Synomic Agents manage dynamic market evolution; Teleonomes handle internal self-improvement within those bounds.


Why exactly five layers – Synome anchors a shared “constitution” and risk guard‑rails; Synomic Agents modularise market‑facing incentives and governance; Teleonomes give each organisation a private, self‑improving genome of goals and knowledge; Embodiments bind that genome to specific hardware and security domains; Embodied Agents are short‑lived worker threads that execute atomic tasks and feed telemetry upward. This clean stratification isolates trust domains, lets slower layers remain stable, and allows faster layers to iterate safely without endangering systemic alignment.



Essentials at a Glance
Tag
Object
Sky analogue
Archon analogue
syn
Synome
Sky Atlas
none
sya
Synomic Agent
Star / Executor / Escrow / Allocation
none
tel
Teleonome
Spark Strategy, RWA Agent
Universal Capability, Research Sandbox
emb
Embodiment
Planner Cluster, Watchtower
Game‑Dev Cluster, Quant‑Finance Cluster
ema
Embodied Agent
BEAMs, Yield‑Scanner
Procedural‑Content, Alpha‑Trader

Metagraph – A structured, cryptographically secured graph that stores immutable data like missions, IDs, and rules.
BEAM – Bounded External Access Module: a controlled interface that allows real‑time steering of on‑chain actions while maintaining security bounds. Types: SP‑BEAM (sets global interest rates across Sky) and AS‑BEAM (adjusts Star Allocation portfolios).
Byte-rent – A fee mechanism where users pay for storage based on data size to prevent spam and ensure economic sustainability.

Sky Ecosystem — Context at a Glance
USDS & SKY — Dollar‑pegged stablecoin and governance token succeeding DAI & MKR.


Sky Core — Minimal base layer that maintains the USDS peg and sets the savings rate (SSR). Emergency procedures are under redesign; details will appear in a later revision.


Sky Agents — Smart‑contract entities built on Sky Primitives; divided into Star (market‑facing) and Executor (back‑office) agents.


Star Agents — SubDAOs that innovate, launch products, and deploy capital (e.g., Spark Star).


Executor Agents — Privileged actors that execute on‑chain actions under collateral and risk constraints. They post risk-capital escrow to cover operational failures.


Sky Primitives — Lego‑like modules: Liquidity (for managing liquidity pools), Rewards (for distributing incentives), Collateral (for handling assets backing USDS), Allocation (scaffolding contracts used by the Allocation System Synomic Agent), Escrow (for securely holding funds).


Allocation System — Key primitive enabling Stars to invest collateral via Allocation Conduits.


Planner & BEAMs — Off‑chain optimisation service (Planner) that steers Allocation Conduits in real time through Bounded External Access Modules (BEAMs) (detailed walk-through in Spark Allocation Cycle).


Spark Planner & BEAMs – Live Workflow
Input sweep – The Phoenix Labs planner cluster ingests on‑chain & off‑chain yield feeds covering ~ 2 B USDS of active positions (Athena USDe vaults, Aave markets, tokenised T‑Bills, …).
 • Pulls current Sky Base Rate (the variable borrowing cost Stars pay to mint USDS) from the Atlas oracle.
 • Reads each venue’s up‑to‑date collateral ratio and risk‑capital escrow requirement defined in the Synome.


Optimisation pass – A mixed‑integer solver ranks venues by net APY = (gross yield − Base Rate − gas/bridge fees) while honouring per‑asset capital limits and liquidity flags.


Proposal & risk check – The planner compiles a delta vector (how much to withdraw/deposit per venue) and verifies that the resulting exposures keep Spark’s risk‑capital escrow ≥ required threshold (currently 4 % of deployed collateral).


BEAM execution –
 a. AS‑BEAM signs the batched re‑balance trades and submits them to the Allocation System contracts.
 b. Transactions self‑fail if gas spikes beyond planner’s bound or if a venue’s oracle data lags > 15 min.


On‑chain settlement – Allocation System moves collateral, emits position events, and burns/mints USDS as needed; escrow balances are auto‑topped‑up if threshold approached.


Telemetry loop – Trade receipts, realised yields, and health metrics stream back to the planner, which updates its models for the next 15‑minute cycle.


This extended cycle illustrates how Spark combines economic incentives (Base Rate, escrow slashing), real‑time telemetry, and BEAM‑guarded execution to maximise net yield without breaching system‑level risk caps.

Archon — Context at a Glance
Archon – technology studio inside the Sky ecosystem that stewards the syno‑telonomic paradigm and several core Sky primitives. Archon is an R&D studio that iterates quickly while Sky maintains public-facing stability.


Builds the Archon Universal Capability Teleonome to harvest cross‑industry learning (finance, gaming, robotics …) while staying aligned with the Sky Atlas.


Operates specialised embodiments (GPU game‑dev clusters, low‑latency quant clusters) whose embodied agents stream data and models back to Sky Stars (e.g., Spark Planner).


Publishes open‑source teleonome tooling and submits Atlas‑grade improvements to the Synome.


Running Catalyst spins up a brand‑new Teleonome via an interactive bootstrap wizard: it asks the operator for available GPUs, seed funds, API/LLM keys and a primary objective, guiding them through human‑in‑the‑loop setup before the Teleonome begins self‑improvement. Joining an existing Teleonome still requires an invitation from that Teleonome’s Admin Embodiment.



1 · Synome (syn)
Concept. Public, cryptographically signed metagraph (a structured graph of metadata) whose immutable mission is Anthroprocentric Universal Alignment¹. Lower layers consult it for IDs, dispute courts and incentive rail‑guards.
¹ Anthroprocentric universal alignment is the natural alignment between living/thinking things, derived from detached human rationality and objectivity. It transcends utilitarian maxims to select the right action given all data, knowledge and constraints.
Key properties
Transparent & fork-resistant – a public metagraph that is cryptographically signed. Core fields change today by simple-majority SKY vote; research explores locking the constitution entirely. Byte-rent is calculated periodically by the Sky Core Council of Executors and burned.


Artifact registry – stores code, rules, knowledge scored by authority weight.


The Synome core is tightly scope-limited: it regulates risk and infrastructure but never micromanages product launches.
Sky example
Sky Atlas – live Synome for the Sky ecosystem; stores USDS monetary policy, weekly Atlas Edits, and governance constants.



2 · Synomic Agent (sya)
Concept. Programmable module embedded in the Synome that exposes incentives, escrows and shared APIs — effectively the Synome’s “service kiosks.”
Key properties
Machine‑first interface – ABI + event schema published in the Synome.


Externally mutable – token-holders govern each Agent’s parameters under a lower quorum; the Synome core may veto changes that breach system-level constraints.


Minority protection – Built into Synomic Agents through veto mechanisms and safeguards against majority capture, ensuring fair evolution.


Ledger‑native state – State snapshots are periodically summarised and pruned by the Core Council.


Sky examples
Sky Synomic Agent
Purpose
Backing primitive
Interaction with Other Objects
Star Agent (e.g. Spark Star)
Launch token, set risk, deploy capital
Liquidity / Rewards / Allocation
Consults Teleonome for strategy; deploys via embodiments and BEAMs.
Executor Agent
Perform privileged system ops with collateral
Collateral & Risk
Executes actions approved by Synome; posts escrow from Teleonome resources.
Escrow Module
Hold funds, resolve disputes
Escrow
Holds assets per Teleonome rules; resolves via Synome disputes.
Allocation System
Invest collateral via Conduits
Allocation
Consults Teleonome rules; executes via Conduits directed by BEAMs.


Sky Atlas

‘Spark Allocation Cycle (illustrative)’
Planner cluster ingests yield feeds on ≈ 2 B USDS.


Optimiser ranks venues vs. capital constraints.


BEAM signs re-balance trade.


Allocation System executes on-chain.


Metrics flow back for the next cycle.



3 · Teleonome (tel)
Concept. Purpose‑bounded, self‑improving genome (metagraph) containing goals, knowledge, self‑law and deployment manifests.
Key properties
Admin‑directed evolution – single Admin Embodiment signs canonical diffs. ① Embodied Agent proposes diff → ② Embodiment reviews → ③ Admin Embodiment signs or rejects. Fallback multi-sig across other embodiments can swap the admin key if compromised.


Gigantic yet structured – continuous pruning + summarisation keep it navigable.


Privacy & attestations – Teleonomes operate in private scopes with internal ledgers; external verification uses cryptographic attestations without exposing full data.


Private/consortium scope – no public rent; internal resource ledger for fairness. External parties verify integrity via cryptographic attestations emitted by each embodiment. Think ‘company intranet’—only trusted machines can read full Teleonome data.
 Taeranoth – security & defence Teleonome isolated from Zeradar; can disable or repair Zeradar if it goes rogue.


Sky examples
Spark Star Strategy Teleonome – lending heuristics, fee curves, planner manifests.


Launch Agent #1 RWA Teleonome – tokenised T‑bill underwriting logic and legal docs.


Archon examples
Zeradar – The core workhorse teleonome used in archon across core, verticals and business layers. Dealing with e.g. both game‑dev and quant clusters; syncs distilled learnings back into Sky Synome.


Taeranoth - security and defense teleonome controlled directly by only a few humans in archon leadership with sensitive data Zeradar cannot access.


Archon Research Sandbox Teleonome – experimental branch for RLHF and alignment research.


Catalyst Default Teleonome - the starting teleonome that catalyst is shipped with.


IP Reciprocity
Proprietary Teleonomes may remain closed; the Synome may later mandate selective disclosure if a Teleonome’s market power crosses agreed thresholds. Proprietary Teleonomes may remain closed; the Synome can mandate selective disclosure if market-power thresholds are crossed.

4 · Embodiment (emb)
Concept. Concrete body (robot, cluster, VM) that hosts a Teleonome slice.
Key properties
Full vs. partial – heavyweight Admin clusters keep entire Teleonome; lightweight nodes keep shards.


Resource‑aware – internal ledger for CPU, memory, sensors, actuators. Over-consumption is logged; severe breaches trigger automatic slashing or shutdown.


Bootstrap chain – new embodiments spawned via Teleonome manifests.
 Admin Embodiment keys should employ multi-sig HSM (or similar) with fallback councils for recovery.


Sky examples
Planner Cluster – high‑throughput embodiment driving Allocation Conduits.


Watchtower VM – lightweight embodiment monitoring on‑chain risk metrics.


Archon examples
Game‑Dev Cluster – GPU farm training generative gameplay agents and procedural content, also providing context relevant support to game developers, artists, gameplay designers. Real time testing and evolutionary learning for new testing and performance improvement methods etc.


Quant‑Finance Cluster – sub‑millisecond colocation servers executing market‑making strategies and streaming alpha to Spark Planner. External teleonome and embodiment coding for e.g. Phoenix Labs and Fixed Rates Star Team running their Allocation Planners.


Catalyst – open‑source embodiment package downloadable from GitHub that launches a fresh Teleonome on local hardware. On first run it walks the operator through an interactive bootstrap flow (requests GPUs, funds, API keys, objectives) and keeps humans in the loop for pivotal decisions, while still preventing leakage of Archon trade secrets and enabling autonomous monitoring of stats, security and governance.



5 · Embodied Agent (ema)
Concept. Lightweight execution thread or service running inside an Embodiment.
Key properties
Sandboxed – obeys Teleonome rules; terminated if rogue.


Short‑lived & specialised – spawned by the hundreds for self‑play, Monte‑Carlo, or real‑time control.


Proposal engine – packages diffs and sends up to Admin. Proposals include a semantic-version tag so breaking API updates are explicit.
 Teleonomes place bounties on rogue Teleonomes, incentivising hunting or reporting by others.


Sky examples
BEAM Module controller – Controls Bounded External Access Module that places trades through an Allocation Conduit, or modifies the SP-BEAM that sets global interest rates in Sky.


Yield‑Scanner ema – scrapes cross‑chain yields and proposes new Conduits.


Archon examples
Procedural‑Content ema – generates game assets and submits artefacts to Zeradar, and interesting patterns that appear useful for optimization of generative work.


Alpha‑Trader ema – real‑time ML model emitting trade signals; acts as BEAM controller for Planners where Archon Vector is the proprietary planner.



One‑liner. The syno‑telonomic paradigm is a five‑layer governance and computation lattice that marries a public Synome “constitution,” modular Synomic Agents, private self‑improving Teleonomes, hardware‑bound Embodiments, and swarms of Embodied Agents—together enabling decentralised intelligence that can scale, self‑upgrade, and remain provably aligned.
By cleanly isolating trust domains and wiring cryptoeconomic incentives from the top down, the paradigm lets thousands of independent actors innovate at high velocity in the agent layer while staying mathematically tethered to shared alignment guarantees at the Synome layer—delivering an adaptive yet drift‑resistant ecosystem.

