# Generator Agent Strategy for Whitepaper

**Purpose:** How to incorporate Generator Agents into the Sky whitepaper

---

## Key Principle

- Generators are a **future growth opportunity**, not core to current architecture
- Core flow remains: **Sky → Prime → Halo → End Asset**
- Generators enable expansion into new currencies and asset classes

---

## Placement in Whitepaper

- **NOT** in Part 1 (core architecture) — keep the simple flow
- Add as a subsection in **Part 7: Growth Vectors** under "New Currencies & Asset Classes"
- Brief mention (0.5 pages max)

---

## Framing

Position Generators as the mechanism for Sky to expand beyond USDS:

> **Expanding Beyond USDS**
>
> The Sky Agent Framework is designed to support multiple currencies. **Generator Agents** can issue new Sky Generated Assets (SGAs) — stablecoins pegged to other currencies or asset classes — while tapping into Sky's core liquidity networks and risk infrastructure.
>
> Each Generator spawns its own ecosystem:
> ```
> Generator → Stars (deploy capital) → Halos (wrap assets)
> ```
>
> This architecture enables regional expansion (e.g., peso-pegged stablecoins for Mexico) and new asset classes without modifying Sky Core. The Generator inherits Sky's proven risk framework while adapting to local market conditions.

---

## What to Include

- Generators issue SGAs (new currencies)
- They tap into Sky's liquidity networks
- Each Generator has its own Stars (≈ Primes) and Halos
- This is the growth vector for geographic/currency expansion

---

## What to Exclude

- MXNS specifics (keep generic)
- DAOC structure
- Sentinel details (already covered elsewhere)
- Star vs Prime terminology (just say "similar to Primes")

---

## Token Reference Addition

In Appendix C (Token Reference), add under "Future/Expansion":

| Token | Type | Description |
|-------|------|-------------|
| SGAs | Stablecoin | Sky Generated Assets — new currencies issued by Generators |

---

## Background Context

From MXNS project documentation:

**Generator Agent** — A Sky Agent powered by the Sky Agent Framework that is able to issue Sky Generated Assets (SGAs — similar to USDS), and tap into the core liquidity networks of Sky.

**Star Agent** — A Sky Agent powered by the Sky Agent Framework that has access to a wide range of Sky Primitives, which lets it take various actions on behalf of Sky. Most notably it can deploy SGA collateral via the Allocation System, and earn income on SGA adoption by end users and integrators through the Distribution Reward.

Each Generator spawns:
- Stars (capital deployment, similar to Primes)
- Halos (asset wrapping, same as current)
- Sentinels (operational automation)

The Generator model enables regional stablecoins (MXNS for Mexico, etc.) while inheriting Sky's risk framework and liquidity infrastructure.
