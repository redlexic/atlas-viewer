This is a copy paste from some internal slides - meant to just give some extra context on the laniakea upgrade

Laniakea Upgrade Objectives
Onboard one Prime per week using copy/paste methods
New Primes instantly access leverage and diversify across standard structured products available as Halo Tokens
Assets by at least one major global asset manager/bank partner
Entirely monitored and secured by redundant Sentinels
Onboard one New Halo Token per week to all Primes simultaneously
Halo Tokens can be either subscribed to or traded with intents
srUSDS provides large scale cheap external risk capital

Laniakea Upgrade Requirements
Parallelized Allocation System
Halo Unit Token Standard
Sentinel
General Risk Framework
Passthrough Halo (bank/AM partner)
Institutional KYC Network
Sky Intents (closed canceable limit orderbook)
