# Renamed: Agent Master

The primary entrypoint for this repository is `agent-master.md`.

- Open `agent-master.md` to navigate the canonical document set under `active/`.
